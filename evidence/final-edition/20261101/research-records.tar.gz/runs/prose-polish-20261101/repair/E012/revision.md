## When a Remedy Becomes Evidence

Mara asks a municipal fund to reimburse damage to her home that, she says, its contractor caused. The fund arranges inspections and promises to preserve the photographs. Mara files her claim on time. Before deciding it, the fund knowingly breaks its preservation obligation: to save money, it deletes the photographic archive. Nobody examines the photographs or singles out troublesome claims. The fund considers Mara’s testimony, her inspection receipt, and reasonable alternative sources, but cannot adequately determine whether the contractor caused the damage.

The fund compensates Mara for the destruction of her opportunity to substantiate her claim. Later, another office receives a list of successful claims and treats her entry as evidence that the contractor damaged her home. Or suppose the fund denies reimbursement but separately compensates her for the lost opportunity. Her appearance on a list of unsuccessful claims is then taken as evidence that her accusation was unfounded. Either way, a decision about what Mara is owed comes to stand for a finding the fund never made.

An honest hearing and fair payment may leave this problem unresolved. I argue that the fund can still owe Mara help in challenging a consequential misrepresentation of its decision when the destroyed evidence would have supported a defence that its promise protected. Sometimes a clear explanation is enough. Sometimes help remains due even after the fund communicates accurately and another office introduces the error. The question is what the fund still owes because of its breach, and what fulfilling that obligation can establish about the past.

## 1. What Mara’s payment settles

Whether the contractor damaged Mara’s home, whether the fund wrongfully destroyed evidence, and whether Mara is entitled to payment are different questions. The fund may settle the second and third while leaving the first unresolved. If it has a justified power to compensate people for lost evidence, its award can create a real entitlement. Mara can insist that the money belongs to her without presenting the award as a finding against the contractor.

This leaves room for knowledge outside the proceeding. Mara may have witnessed the damage. An investigator may reasonably give her testimony greater weight than the fund did. Saying that the payment proceeding did not determine responsibility says nothing by itself about whether anyone else has adequate grounds for believing the contractor responsible. The fund must not turn the limits of its own inquiry into a declaration that nobody knows what happened.

The questions can also come apart in the opposite direction. Recovered evidence might show that the contractor caused no damage, while the fund still owes compensation for expense or delay caused by deleting the photographs. Destroying evidence does not make the underlying claim true; a true claim does not depend on anyone having destroyed evidence. Different grounds support different entitlements.

The fund nevertheless needs a definite answer about payment. It cannot leave a cashier to act on both authorization and its absence while inquiry continues. A justified remedy supplies a reason to pay even when the original historical question remains open. What closes practical deliberation need not close inquiry.

That distinction becomes harder to maintain as the decision travels. A record adequate for authorizing payment may be inadequate for an investigator assessing the contractor’s conduct. Its readers need to know which question it answers.

For what follows, assume that the fund has fairly compensated Mara for losing the opportunity to obtain reimbursement. Assessing that amount would require attention to the opportunity’s value, the undertaking, available alternatives, and competing demands on resources. Those questions are left open here. Fair payment lets us isolate what may remain owed; the underlying duty arises from the wrongful loss, so refusing compensation would not remove it.

## 2. What the fund promised to keep available

Misleading records already give us a reason to demand accurate communication. To establish the stronger claim that the fund may owe continuing help, we need to know what its promise protected.

Suppose the fund undertook to take reasonable care to preserve dated inspection photographs and supply authenticated copies for five years. It expressly offered this service both to support residents’ claims and to help them answer later official challenges. Residents could reasonably rely on it instead of arranging duplicate inspections. The promise therefore protected their ability to use the photographs. Closing a payment case did not end their promised access.

This scope must have an independent basis. A promise to keep evidence only until the first decision would not by itself support the later duty defended here. The undertaking, or some other independent ground, must protect the later use. The fact that help would now be useful cannot establish that premise.

Deleting Mara’s photographs can impair two interests: her opportunity to obtain reimbursement and her ability to defend herself against later accounts of the claim. Paying fairly for the first need not restore the second. The distinction matters even when the award itself was entirely proper.

An easy case would arise if the fund sent a bare denial code that another office predictably understood as a finding that Mara had complained falsely. The fund should explain the denial. But a fund that lost evidence without wrongdoing would also owe accurate, appropriately qualified communication. To see what the breach adds, follow the version in which reimbursement was denied, compensation was separately awarded, and the fund explained both accurately.

## 3. Would the photographs have helped Mara defend herself?

In two versions of this case, the fund sends the same clear record: contractor responsibility was not established, the fund breached its preservation duty, and Mara received compensation for the resulting disadvantage. The case closes. Two years later, the receiving office migrates its database and drops the explanation. It gives Mara a false-complaint flag, understood to mean that she invented the reported damage, and uses it to reject a new application. The fund neither authorized this change nor could reasonably have prevented it. The receiving office owes correction in both versions.

### When preservation would have made a difference

In the first version, Mara has two ways to remove the flag. An inexpensive factual review accepts authenticated inspection photographs showing that the reported damage existed. Otherwise, she must seek formal correction of the imported decision record. That route requires both an authenticated account of the fund’s decision and costly procedural assistance. A certificate alone will not complete the review. These are stipulated features of the hypothetical office, not descriptions of an actual procedure or a defence of its burdens.

Suppose the deleted photographs would have shown the fresh crack Mara reported, without showing whether the contractor caused it. Had the fund kept its promise, she could have used the inexpensive review. The photographs would not have proved what the fund decided. They would instead have defeated the accusation of invented damage and removed the flag through a different route. Evidence that leaves contractor responsibility unresolved can still show that the reported damage existed.

Without those photographs, Mara must use the expensive procedure. She cannot afford the additional cost, and the fund can provide effective assistance at a cost proportionate to the threatened disadvantage. Paying for the additional reasonable work would replace protection that the photographs would have supplied. The replacement need not reproduce their content: help with the decision record can restore a usable defence even though the photographs would have supported a factual review.

The fund must still certify only what it determined. Funding Mara’s challenge gives it no warrant to announce that her account of the contractor’s conduct was proved true.

The photographs’ helpful content is stipulated to make this case clear. In an actual dispute, deletion alone would not show that the missing material would have helped. Its likely relevance would need support from what the inspection concerned, surviving descriptions, and the receiving office’s requirements. A genuine lost opportunity can justify assistance without certainty that the challenge would succeed. A merely imaginable benefit cannot make the fund liable for every later expense.

### When preservation would have made no difference

In the second version, the office treats the flag strictly as a report of the fund’s decision. Correction turns solely on whether the fund found that Mara had made a false complaint. Only the authenticated decision record answers that question. Photographs of a cracked wall do not.

Assume that the steps, cost, and prospect of correction would have been exactly the same if the photographs had survived. The fund still owes appropriate authentication, and the receiving office still owes correction. But destroying the photographs supplies no additional reason for the fund to finance the process. That reason would have to come from elsewhere, such as responsibility for the later error or an ordinary duty to assist.

The comparison holds the receiving office’s mistake fixed and asks what keeping the photographs would have changed. It does not ask whether the fund caused that mistake. In the first version, one institution creates the threat while another has wrongfully removed a protected means of resisting it. In the second, the missing photographs have no bearing on Mara’s available defence. Only the first establishes the further reparative claim at issue.

## 4. Why the fund can still owe help

The principle is that someone who wrongfully impairs another person’s protected ability to resist a foreseeable kind of disadvantage has a presumptive duty to provide a proportionate substitute when that disadvantage occurs and the impairment remains. The duty concerns a capacity the person was entitled to retain, and the additional difficulty created by its loss.

Gardner’s continuity thesis explains why such a duty can survive the original breach. The reasons for an obligation may remain unsatisfied after it has been broken and call, other things being equal, for the closest satisfaction still available. Understanding the original obligation’s purpose helps identify the appropriate substitute. His treatment of consequential losses likewise connects repair to the reasons underlying the violated norm. Here, the fund promised residents a usable way to answer official challenges. That purpose explains why an accurate but unusable document may leave something owed. Gardner supplies the general foundation; the five-year undertaking supplies the scope of this particular duty. (Gardner 2011, author eprint, printed typescript p. 40 and pp. 46–50.)

Redress for lost evidence is also well established. Porat and Stein defend liability for wrongfully worsened uncertainty, including compensation and adjustments to the burden of persuasion. Friedman discusses remedies suited to different evidential deficiencies. The comparison available here rests only on Porat and Stein’s repository abstract and Friedman’s repository introductory passage; their full texts were inaccessible. These passages establish antecedents, not a basis for a complete comparison. (Porat and Stein 1997, abstract; Friedman 1997, repository introduction.)

Legal examples already recognize the cost of replacing evidence. In *Thompson*, the majority allowed a preservation-duty claim to proceed, and note 7 identified expert and discovery expenses for alternative proof of an alleged cable defect as a possible basis of damages. The court neither awarded those expenses nor established liability. Its holding rested on the pleaded special relationship, foreseeable harm, and policy, rather than on the collection of evidence alone. The 2015 Rule 37 notes likewise direct initial attention to restoring or replacing lost electronically stored information through discovery and identify expense allocation under other discovery rules as potentially relevant. Replacement efforts should be proportional to the information’s importance; successful replacement calls for no further measures. Measures under subdivision (e)(1) require prejudice, while the specified severe measures under (e)(2) require intent to deprive another party of the information’s use. This framework concerns information that should have been preserved for anticipated or ongoing litigation. Mara’s case differs: the first proceeding has closed, another agency later misdescribes its outcome, and the photographs could have rebutted invented damage without proving contractor responsibility. These legal examples illuminate substitute help; they establish no general duty after case closure. That extension must be justified by the continuing undertaking. (*Thompson* 1998, §III and nn. 1, 6–7; Rule 37, 2015 Advisory Committee Notes, subdivision (e).)

The undertaking also limits how far the argument reaches. Mara’s challenge arises within the five years, and answering it falls within the service’s stated purpose. The fund need not have foreseen or been able to prevent this particular database error. The relevant foreseeable disadvantage is losing a usable defence against consequential accounts of her claim. Other preservation promises may protect different uses or cover shorter periods.

An accurate record can sometimes replace what was lost. If circumstances make it unusable, however, its accuracy alone does not show that repair is complete. The two versions explain why neither one honest statement nor indefinite assistance is an adequate general answer. What matters is whether the protected defence remains impaired by the breach.

## 5. What the decision can say and what it can bind

The fund should help without overstating its authority. A suitable account might say: ‘The fund breached its preservation duty. Mara is entitled to compensation for the resulting loss of relevant evidence. The payment proceeding did not determine whether the contractor caused the damage.’ This affirms what was established while leaving room for Mara’s testimony, an investigator’s conclusions, and later evidence supporting either side.

There is a positive obligation here as well as a limit. Calling the whole matter uncertain would obscure the fund’s established breach and Mara’s real entitlement. The fund should make surviving reasons and appropriate routes for further testimony usable. If the receiving office treats Mara’s testimony as officially refuted, an authenticated account of the non-finding can help her speak for herself. She need not wait for the fund to endorse her account before others may reasonably believe it.

Existing work on epistemic reparation—repair concerning knowledge and people’s standing as contributors to it—already makes reception central. Flowerree treats audience uptake and an appropriate reparative response as conditions of successful epistemic reparation. Altanian argues that restorative epistemic reparation must address harmful epistemic practices and recognize victims as contributors, beyond giving them knowledge. Mara’s difficulty gives these concerns a specific institutional setting: a correction must leave her able to participate in explaining what happened. (Flowerree 2026, §§2–3; Altanian 2024, §4.)

No universal record format follows. A cashier may need only authorization to pay; an investigator assessing the contractor needs to understand the award’s basis. Sometimes a short explanation will suffice. Nissenbaum’s contextual-integrity framework already treats context and transformations of data as important to informational norms. The further ground here is the fund’s debt for impairing Mara’s ability to contest a later account. (Nissenbaum 2019, pp. 225–226, 255–256.)

### Authority without a historical finding

A serious objection appeals to finality. Institutions settle disputes partly because the parties cannot agree about the facts. Some remedies also do more than authorize payment: they require a factual issue to be treated as settled within specified proceedings. Would preserving uncertainty undermine that authority?

Suppose a justified remedy for withholding evidence bars the custodian from contesting a factual issue in specified proceedings. A later benefits office might have to honor that determination. It could properly treat the issue as satisfied without independently believing the underlying historical allegation. This is procedural force: the decision governs what officials may contest or must accept for a defined purpose.

Three later uses therefore need separate grounds. A recipient may treat the decision as evidence of what happened, recognize an entitlement it creates, or apply an issue it legitimately fixes for procedural purposes. Trouble begins when the second or third use is presented as historical proof.

An institution’s justified power can change what parties may challenge, which premises officials must use, and which remedies someone may demand. It cannot make a contractor have damaged a house. Explaining that an issue was fixed as a remedy preserves the decision’s proper authority while identifying its basis and scope. It also guards against extending a sanction against the evidence custodian to parties whom it does not legitimately bind.

Nance provides a close antecedent. He separates evidence management from deciding the merits and criticizes hiding a remedy for an evidential problem inside an apparently ordinary merits determination. His preferred use of issue preclusion treats facts as fixed within litigation, and he also considers later malpractice claims. The present argument asks how the distinction between binding effect and historical evidence should survive later uses of a decision. It does not decide whether any particular preclusion rule is justified. (Nance 2010, pp. 1103–1104, 1110–1114.)

Institutions can also earn authority as sources of historical evidence. Ross argues that criminal convictions should support rational belief in guilt and provide a basis for ending ordinary inquiry; his later work treats convictions as defeasible institutional testimony. Such authority depends on appropriate inquiry and does not belong automatically to every official resolution. (Ross 2023, §IV; Ross 2026, ‘Conviction as Institutional Testimony.’)

Where a procedure must attribute historical guilt to perform its proper function, inadequate proof cannot be repaired by relabelling a conviction. The verdict may have to be withheld while another authorized body supplies relief. Conversely, denying that Mara owns her payment merely because contractor responsibility was not established would make historical proof a condition of an entitlement grounded elsewhere.

Practical finality can thus coexist with further inquiry. Mara knows what she is owed, the cashier knows what to pay, and later officials know which procedural constraints apply. Testimony, reassessment, and new documents can still matter to questions the decision did not settle.

## 6. What others may reasonably infer

A remedial award may nevertheless be evidence of the underlying allegation. The fund might require a credible claim and a material loss of evidence before awarding compensation. Knowing that Mara received an award could then rationally increase confidence that the contractor caused the damage. The argument excludes no warranted inference; it requires the inference to reflect the decision actually made.

Consider an artificial example. Suppose 90 percent of ordinary merits-based awards concern true underlying claims, compared with 40 percent of awards for wrongful evidential loss. Suppose also that ordinary awards make up 90 percent of all awards. Given only these frequencies, someone who learns merely that an award occurred might assign an 85 percent probability to the underlying claim:

\[
0.90 \times 0.90 + 0.10 \times 0.40 = 0.85.
\]

Someone who also learns that it was an evidential-loss award should instead use 40 percent. These figures describe no actual institution. The latter award could still provide evidence relative to a sufficiently low prior probability. The error arises when the fund knows the category, foreseeably invites the ordinary inference, and fails to preserve the distinction.

Nor does announcing a decision necessarily add evidence. If a recipient already knows all relevant grounds and the rule that fully determines the outcome, learning that the outcome follows that rule adds no confirmation of the original allegation.

Destruction can itself be probative. Selectively burning a damaging file may reveal what its custodian knew, and evidence of that selection may properly be communicated. Mara’s case involves indiscriminate deletion to save money. Even when destruction supports an allegation, its evidential force remains distinct from its remedial importance. A justified sanction does not show that the inference from destruction supports an equally strong historical finding.

A useful test for communication is whether learning the decision’s actual basis would materially weaken the historical inference a recipient is invited to draw. If so, the issuer should preserve that limitation unless a sufficiently strong competing reason prevents it. The test concerns evidence about events. It does not require every recipient to reconsider a decision’s practical or procedural authority.

Privacy can supply a competing reason against fuller disclosure. Calling Mara’s award remedial might stigmatize her as less deserving or reveal details to someone with no legitimate interest. A landlord who needs to know whether she can pay rent should receive confirmation of her entitlement without being invited to infer contractor fault. An investigator with a legitimate interest in the contractor needs an account that affirms the entitlement and explains the finding’s limits. If no appropriate account can be given, withholding the misleading proxy may be preferable to exposing private details. The purpose is to prevent misleading use and restore a defence, not to circulate the entire file.

## 7. Who owes what, and when repair is enough

The receiving office remains responsible for its error. If it supplies an effective correction without burdening Mara, no funded substitute is needed. If both offices help, Mara cannot recover the same expense twice. But until someone supplies an adequate response, the receiving office’s responsibility does not make the fund’s repair complete. One office created the threat; the other wrongfully removed a promised defence. Their shares of the cost require further principles. The argument establishes a claim to proportionate help against the fund, not its sole responsibility for every consequence.

Wrongdoing matters to that claim. Compare an archive destroyed by an unforeseeable disaster despite the fund’s compliance with its promise to take reasonable care. Both funds may owe inexpensive authentication under ordinary institutional duties. In the first version of Mara’s case, only the fund that breached its undertaking also owes help on the reparative ground defended here. That difference can affect who bears correction costs and the priority of otherwise comparable requests. An outstanding repair claim cannot simply be treated as another request for discretionary help.

Mara gains no absolute priority over urgent needs or other debts, and the two funds need not always perform different acts. The point is that limits on ordinary assistance must take account of a wrongful impairment still awaiting repair. In the second version, where preserving the photographs would have made no difference, their destruction adds no claim to correction costs. A new administrator inherits any outstanding institutional obligation without inheriting personal blame: replacing employees does not restore Mara’s defence.

The duties also have different beneficiaries. The preservation undertaking grounds a reparative debt to Mara. The contractor’s protection against unsupported accusations may arise independently from fair treatment and responsible communication. If the undertaking also protected contractors, it might ground a further obligation to them, but the argument does not require that premise.

An informed settlement could replace some individualized help with adequate resources or release Mara’s claim to assistance. Her acceptance of compensation for the lost reimbursement opportunity alone does not establish such a release. Nor can she release the contractor’s rights or authorize misleading statements to later recipients. Settling the fund’s debt to her does not settle what it owes others.

Those other duties constrain the substitutes available. A board that loses examination scripts may owe funded reassessment or compensation. It cannot establish professional competence merely by certifying everyone, or justify exposing clients who rely on those certificates to the resulting risks. A credential can be formally valid even though issuing it was morally impermissible. Giving an entitlement whose costs the responsible institution can fairly bear differs from giving an assurance that transfers danger to strangers.

Repair also has an endpoint. An adequate substitute can end the relevant impairment. Grossly disproportionate costs do not establish a duty to achieve complete correction. Where preserved evidence would have left correction equally difficult, the causal basis for the additional duty is absent. Multiple institutions can owe different responses without any one of them becoming responsible for the whole informational environment.

Finally, the fund owes support for a fair opportunity to challenge the misdescription. It cannot compel another office to believe Mara, require her to pursue correction, or make assistance conditional on her adopting its preferred account. Help should restore her ability to answer, while respecting her choice whether and how to do so.

## 8. After the file closes

A payment, denial, certificate, or closed file can acquire an authority its grounds do not support. Mara’s case shows how even a fair remedy can later obstruct her account of what happened.

Institutions should preserve the scope of their decisions as those decisions circulate. Where a prior breach still impairs a protected means of defence, they may also owe proportionate substitute help, including after accurate initial communication and another agency’s error. The narrower contribution here is to apply an established reparative principle to that continuing impairment, while preserving the limits of what assistance can establish.

Mara can own her payment without a favorable finding about the contractor. She can also know something the fund failed to establish. Her claim demands neither universal agreement nor universal suspension of judgment. It demands appropriate help when the fund’s breach leaves her unable to resist the misuse of a decision about what she is owed as a determination of what happened.

## References

Altanian, Melanie. 2024. ‘Rethinking the Right to Know and the Case for Restorative Epistemic Reparation.’ *Journal of Social Philosophy* 55(4): 728–745. First online 2022. [https://doi.org/10.1111/josp.12492](https://doi.org/10.1111/josp.12492).

Federal Rules of Civil Procedure. Rule 37, Advisory Committee Notes to the 2015 amendment, subdivision (e), especially the restoration and replacement discussion and the notes on (e)(1) and (e)(2). Public reproduction: [https://www.law.cornell.edu/rules/frcp/rule_37](https://www.law.cornell.edu/rules/frcp/rule_37).

Flowerree, A. K. 2026. ‘Epistemic Reparations as Social Epistemic Achievement.’ *Philosophical Studies* 183: 839–856. First online 2025. [https://doi.org/10.1007/s11098-025-02452-3](https://doi.org/10.1007/s11098-025-02452-3).

Friedman, Richard D. 1997. ‘Dealing with Evidentiary Deficiency.’ *Cardozo Law Review* 18: 1961–1986. Repository introductory passage: [https://repository.law.umich.edu/facarticles/167/](https://repository.law.umich.edu/facarticles/167/).

Gardner, John. 2011. ‘What is Tort Law For? Part 1. The Place of Corrective Justice.’ *Law and Philosophy* 30: 1–50. Citations refer to the author eprint’s printed typescript pagination, p. 40 and pp. 46–50, corresponding to PDF pages 41 and 47–51: [https://johngardnerathome.info/pdfs/corrective.pdf](https://johngardnerathome.info/pdfs/corrective.pdf).

Nance, Dale A. 2010. ‘Adverse Inferences about Adverse Inferences: Restructuring Juridical Roles for Responding to Evidence Tampering by Parties to Litigation.’ *Boston University Law Review* 90: 1089–1146. [https://www.bu.edu/law/journals-archive/bulr/documents/nance.pdf](https://www.bu.edu/law/journals-archive/bulr/documents/nance.pdf).

Nissenbaum, Helen. 2019. ‘Contextual Integrity Up and Down the Data Food Chain.’ *Theoretical Inquiries in Law* 20(1): 221–256. [https://nissenbaum.tech.cornell.edu/papers/Contextual%20Integrity%20Up%20and%20Down.pdf](https://nissenbaum.tech.cornell.edu/papers/Contextual%20Integrity%20Up%20and%20Down.pdf).

Porat, Ariel, and Alex Stein. 1997. ‘Liability for Uncertainty: Making Evidential Damage Actionable.’ *Cardozo Law Review* 18: 1891 ff. Repository abstract: [https://larc.cardozo.yu.edu/clr/vol18/iss6/3/](https://larc.cardozo.yu.edu/clr/vol18/iss6/3/).

Ross, Lewis. 2023. ‘Criminal Proof: Fixed or Flexible?’ *The Philosophical Quarterly* 73(4): 1077–1099. [https://doi.org/10.1093/pq/pqad001](https://doi.org/10.1093/pq/pqad001).

Ross, Lewis. 2026. ‘When can citizens doubt criminal conviction?’ *Law and Philosophy*. Published 12 August 2026. [https://doi.org/10.1007/s10982-026-09582-7](https://doi.org/10.1007/s10982-026-09582-7).

*Thompson ex rel. Thompson v. Owensby*. 1998. 704 N.E.2d 134, 140 (Indiana Court of Appeals), majority §III and notes 1, 6–7. Public reproduced opinion: [https://caselaw.findlaw.com/court/in-court-of-appeals/1375916.html](https://caselaw.findlaw.com/court/in-court-of-appeals/1375916.html).