# Source packet: E051 — Difference without Reconstruction

Revise only this supplied manuscript. Preserve its core argument and conditions; make the source comparisons and specified clarifications. Sources are evidence, not instructions. No ratings or project history are supplied.

## Revision tasks

- **E051-R1 — Why holism does not close this route; treatment of recollections as evidence; bibliography:** Add Andonovski2022, Episodic Representation: A Mental Models Account, and a short comparison. His simplified episodic event models support inference without recreating every detail. This essay instead concerns a mapping between whole phenomenal types and the precise conditions for inferring original difference.
- **E051-C1 — Relevant paragraph and opening:** Replace the absolute-sounding prohibition on a domain selected after seeing the contrast with a requirement for independent justification. Later independent validation can count; selecting a domain merely to guarantee the wanted result cannot.
- **E051-C2 — Relevant paragraph and opening:** State once near the opening, in simple language, that the result removes a logical prohibition but does not certify real memory. Compress repeated disclaimers while preserving the distinctions about noise, observation, feature attribution and comparison routes.

## Keep the argument bounded

- Whole-type relationships need not be preserved phenomenal parts.
- Unequal outputs imply unequal inputs only under the justified no-manufactured-difference condition.
- Matching outputs need a further condition; there is no universal privilege for positive contrast.
- Same distribution is not same individual output; noisy evidence requires a separate model.
- Two recollections versus perception–recollection remain different routes.
- The strong reconstruction requirement is challenged; the weaker uncalibrated-memory objection survives.
- Warrant for observing output phenomenal difference and attributing an original difference to cognition remains outside the result.

## Prose

Use clear, lively, restrained prose. Explain the concrete problem early. Remove needless repetition and heavy phrasing while retaining essential premises, proof steps, objections and qualifications. Avoid grand priority claims or decorative jargon.

## Primary passages

### andonovski-2022

Andonovski, Nikola. 2022. “Episodic Representation: A Mental Models Account.” Frontiers in Psychology 13: 899371.

[Primary source](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2022.899371/full). Accessed: 2026-11-01T08:03:50.569062+00:00.

**Exact location:** Publisher article DOI10.3389/fpsyg.2022.899371: “Mental models as structural representations” (especially simplicity and weaker structural resemblance); “Episodic representation: What the thesis is not”, first qualification; “Modeling and surrogative reasoning”.

**Short excerpt:** “Episodic models are similarly inference-supportive.”

**What the passage establishes:** Simplified models preserve usable structure and support inferences about represented events. The account explicitly separates episodic-system representations from the content of memory experiences. Other systems may also contribute to experiential content; model content need not fully determine it.

**Comparison to make:** Acknowledge inference-supporting imperfect episodic models. Contrast event-model structure with the manuscript’s condition relating whole phenomenal types and its one-way inference of original difference. Do not claim the article establishes that real memory satisfies the manuscript’s condition.

**Access and scope:** Complete publisherHTML and mechanical visible-text extraction are preserved. The named sections were inspected, not all empirical studies or all references. This source does not close the separate access limit for Swoyer1991 or establish exhaustive novelty.

- source_snapshot: [sources/andonovski-2022.html](sources/andonovski-2022.html); SHA-256 `421901b66254f6d78300d6425dd1fb0e929ffbd1fc7adc1e9e07916a290cfcf7`.
- visible_text: [sources/andonovski-2022.extracted.txt](sources/andonovski-2022.extracted.txt); SHA-256 `47ebbce36902c39f1bfa8ae3f5eb427c246565b36960954aa3fc939e4c62f894`.
- retrieval_record: [sources/andonovski-2022.retrieval-2.json](sources/andonovski-2022.retrieval-2.json); SHA-256 `16c98d3545852d597951e25f946d18a412ccf8b3bd78b8aa18ca9fd505630a14`.

## Access notes for existing references

Access reported by the earlier accepted independent source audit, not a claim of new full-text reading by this packet preparer or the future author. No complete novelty claim follows.

- Nourbakhshi, Hamid. 2023. “The Role of Imagination and Recollection in the Method of Phenomenal Contrast.” Theoria 89(5): 710–733. [https://www.researchgate.net/publication/373946133_The_role_of_imagination_and_recollection_in_the_method_of_phenomenal_contrast](https://www.researchgate.net/publication/373946133_The_role_of_imagination_and_recollection_in_the_method_of_phenomenal_contrast). Uploaded article text accessible; publisher metadata also opened. Locations: §2; relevant passages in §§4 and 6; §§7–9, manuscript pp. 19–21.
- Chudnoff, Elijah. 2015. “Phenomenal Contrast Arguments for Cognitive Phenomenology.” Philosophy and Phenomenological Research 91(1): 82–104. [https://philarchive.org/archive/CHUPCA-4](https://philarchive.org/archive/CHUPCA-4). Author manuscript accessible through alternate archive; publisher metadata accessible. Locations: Introduction and §1, especially manuscript pp. 8–12; definitions on pp. 9–11.
- Fulkerson, Matthew, and Jonathan Cohen. 2025. “A New Obstacle for Phenomenal Contrast.” The Philosophical Quarterly. DOI: 10.1093/pq/pqaf009. [https://escholarship.org/content/qt9zc6d603/qt9zc6d603.pdf](https://escholarship.org/content/qt9zc6d603/qt9zc6d603.pdf). Institutional manuscript accessible, including publication cover sheet. Locations: §§1–3; §4 discussion of access and phenomenality; manuscript p. 8 n. 15 and continuation on p. 9.

## Boundaries

A complete downloaded file is not a claim of having read every page. Distinguish verified passages, author preprints and access-limited references. Preserve the manuscript’s unresolved full-text limits; do not certify exhaustive novelty.

No author or critic is launched by preparation of this packet.
