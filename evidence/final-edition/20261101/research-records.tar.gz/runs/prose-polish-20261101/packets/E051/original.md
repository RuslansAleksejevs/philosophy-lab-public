# Difference without Reconstruction

Remembering a painful afternoon need not hurt. Remembering an intensely coloured sunset need not reproduce its intensity. This gap between an experience and its recollection creates a problem for a familiar philosophical procedure. To investigate what shapes experience, we compare how things seemed before and after learning to recognize something or understand a sentence. Yet the earlier experience is gone. If we compare a present perception with a diminished recollection, the contrast may come from remembering rather than from the change we wanted to investigate.

That is a serious evidential problem. It does not establish that recollection must reproduce an experience’s phenomenal character before it can inform us about phenomenal differences. A transformation of whole phenomenal types can support an inference from unequal outputs to unequal inputs without preserving an unchanged phenomenal component. It may nevertheless erase differences, making matching outputs inconclusive. This asymmetry belongs to a specified class of transformations; it is not a general advantage of positive over negative evidence.

The result removes a proposed logical prohibition. It does not certify real memory. An evidential use requires independent support for the comparison procedure and its domain. Such support may arrive after a contrast is noticed; what matters is that it does not merely assume or secure the desired conclusion.

## The objection and the comparison routes

Nourbakhshi’s discussion supplies the target. Recollection and imagination cannot simply replace perception, he argues, because their own phenomenal differences may explain an apparent contrast. His discussion of relevant partial similarities and of separating a state’s contribution from its content’s contribution raises two further problems: phenomenal parts are interdependent, and introspection cannot reliably identify a supposedly unchanged remainder (2023, §§4, 6–9, especially §§7–8).

The demand for full phenomenal reflection supports a strong reading: informative recollective comparison requires reconstruction of the original phenomenal character. A weaker reading, available in the conclusion, treats distortion as a rival explanation that a particular comparison must exclude. My reply challenges the strong requirement. The weaker objection survives. Nor is the general suggestion that relevant similarity might suffice new here; Nourbakhshi already considers it. The question is whether comparison can work without reconstructing the original whole or subtracting an unchanged part from a transformed experience.

Two procedures must be distinguished. One compares a present perception with a recollection of an earlier perception. Another compares two recollections obtained through an appropriately matched procedure. The direct result concerns the second. The first uses different routes to the compared states and needs a condition justified across those routes. Calling both states representations of experiences does not establish that condition. Equally, calling both states memories does not show that their retrieval procedures are appropriately matched.

## What a comparison must preserve

Let a comparison case `e` specify an original episode and a permitted occasion of recollection. Write `P(e)` for the phenomenal type of the original episode: how it felt, considered as a whole. Write `R(e)` for the phenomenal type of its recollective output. Including the retrieval occasion allows the domain to cover variations in how an episode is recalled. These definitions leave open what constitutes a phenomenal type and whether its differences are sensory, affective, or cognitive.

For a domain `D` of comparison cases, consider this condition:

> **(N)** For all `e₁, e₂ ∈ D`, if `P(e₁) = P(e₂)`, then `R(e₁) = R(e₂)`.

Call this the condition against manufactured differences. Its contrapositive is immediate: if two outputs differ and (N) holds, their original phenomenal types differed. The proof requires no resemblance between an output and its original. If the originals had the same type, (N) would require matching outputs, contrary to the observed difference.

This is a conditional entailment, not yet a warranted evidential procedure. On an actual pair whose original types differ, (N) holds vacuously. Suppose the originals differed only in incidental discomfort, while a leading retrieval cue produced the recollective contrast. The truth of (N) on that pair would not show that recollection tracked the original difference. With unequal outputs already given, asserting (N) only for the actual pair adds no independent warrant: it is equivalent to asserting that the inputs differed.

An evidential use therefore needs grounds extending across relevant alternatives. The comparison domain must include cases in which original phenomenal types match, together with the variations in cues, beliefs, elapsed time, and other influences that the procedure permits. The required counterfactual is that matching original types would not yield the contrasted outputs through those permitted variations. If the procedure instead fixes a factor, there must be grounds for treating it as fixed.

The issue is independence, not chronology. A domain chosen merely to guarantee the wanted contrast supplies no justification. But a domain proposed after noticing a contrast may receive genuinely independent validation later. The timing does not disqualify that validation; dependence on the desired conclusion does. No such validation of a real memory procedure is supplied here.

Determinism alone would not provide it. A deterministic mechanism may respond to physical histories, associated beliefs, or retrieval circumstances that differ despite identical original phenomenal types. Determinism about complete histories therefore does not establish (N).

When (N) holds, the output can be treated as a function of the original phenomenal type within the domain:

`R(e) = F(P(e)).`

To see why, choose any case with original type `p` and define `F(p)` as its output type. Condition (N) ensures that every other case with type `p` gives the same value. This makes `F` well defined. It need not be the identity function, and it need not be injective: distinct inputs may share an output.

Consider a finite model:

| Original phenomenal type | Recollective phenomenal type |
| --- | --- |
| a | u |
| b | u |
| c | v |
| d | v |

The original types `a`, `b`, `c`, and `d` are distinct. The output types `u` and `v` differ from one another and from every original type. No output therefore reproduces an original whole phenomenal type. Information is also lost: the transformation erases the distinctions between `a` and `b` and between `c` and `d`.

Yet an observed `u/v` contrast entails an original difference. One input belonged to the `a/b` group and the other to the `c/d` group. Identifying the particular member of either group is unnecessary. So is recovering an unchanged phenomenal part.

The elementary mathematics is not a new discovery. Its role is to provide a countermodel to the claimed necessity of reconstruction, relative to the premises under discussion. The table does not supply a complete metaphysics of phenomenal types. It shows that a further premise is needed to infer the impossibility of difference detection from the failure of full reconstruction.

## Why holism does not close this route

The model never divides an experience into a content component and a memory-mode component. Its inputs and outputs are whole phenomenal types. Nor do distinct labels for wholes prove that they lack shared parts. The compatibility with holism rests on what holism entails, not on the labels.

Suppose every phenomenal part depends on the character of the whole. Suppose also that moving from perception to recollection changes every part’s contribution. Neither supposition requires identical original types to produce different recollective types. Neither requires all original types to collapse into one recollective type. The table needs neither manufactured differences nor total collapse.

Holism concerns dependencies within phenomenal wholes. Condition (N) concerns a relation between wholes at different stages. To show that these claims conflict, an argument must connect those two levels. Interdependence within a recollection does not by itself rule out the relation specified by (N).

An objector might say that the table covertly preserves a component: membership in the `a/b` group rather than the `c/d` group. But a partition of possible whole states is not thereby a part of each state. It classifies states according to a relation; it does not identify something separately experienced within each one. Treating every preserved distinction as a phenomenal component would conflate structural preservation with preservation of parts.

The response thus grants what a subtractive reply disputes. The original whole need never appear again, and there need be no unchanged phenomenal remainder to inspect. A relation between transformed wholes can still carry information about whether their originals differed.

This belongs to a familiar family of ideas about representation. Andonovski’s mental models account explicitly treats episodic models as simplified structural representations. They preserve usable relations while omitting details; their structural resemblance to represented events need not approach isomorphism. The relevant cognitive system must exploit the mapping, rather than merely instantiate some resemblance (2022, “Mental models as structural representations”). In “Modeling and surrogative reasoning,” he explains how consulting and manipulating such models can support new inferences about represented events. Imperfect episodic representation can therefore support reasoning without recreating every detail.

The comparison has an important limit. Andonovski expressly distinguishes the content and format of representations produced by the episodic system from the content of memory experiences. Event-model content need not fully determine experiential content: mindreading, metacognitive, and other systems may also contribute (2022, “Episodic representation: What the thesis is not,” first qualification). His account of event models therefore cannot simply be read as an account of whole recollective phenomenal types.

The present mapping also relates different things. Andonovski examines relations among constituents of represented events and relations in models that support reasoning about those events. Here, `F` relates whole original phenomenal types to whole recollective phenomenal types. It requires no constituent-by-constituent mapping between an event and its model. Its purpose is to isolate the condition under which an output contrast entails an original phenomenal difference. General structural representation and inference through simplified episodic models are not discoveries of this essay. The narrower claim concerns this particular implication between whole phenomenal types. Andonovski’s account neither establishes (N) for real memory nor removes the need to justify it.

## Two directions of error

Suppose both outputs in the table have type `u`. The inputs might have been `a` and `a`, or `a` and `b`. Matching outputs therefore do not entail matching original types under (N).

Within the functional model, licensing that converse inference for every possible matching output requires injectivity: distinct original types must have distinct outputs. For one particular match, less is needed. If `F(a) = u` while `F(b) = F(c) = v`, a `u/u` match identifies `a/a` even though the function is not injective. Only the observed output needs a single possible original type within the justified domain. Both matching outputs in the first table are inconclusive, but that feature does not belong to every lossy transformation.

Full phenomenal reconstruction is stronger than even global injectivity. An injective transformation may change every type while keeping the outputs distinct. Reconstruction is therefore unnecessary for either direction of inference.

The requirements can now be separated. Uniform avoidance of manufactured differences licenses inference from output difference to original difference. Uniform avoidance of erased differences licenses inference from output equality to original equality. For a particular contrast, the first requirement can also be local: no admissible pair with matching original types may yield the observed pair of different outputs. Other output contrasts need not be reliable. Such an observation-specific restriction is useful only if the relevant alternatives are independently justified.

There is no universal evidential privilege for positive contrasts. Consider a different procedure: original type `a` can yield either `u` or `v`, while original type `b` can yield only `w`. Matching outputs identify matching originals because the possible outputs for the two original types do not overlap. Yet unequal `u/v` outputs may both come from `a`. This procedure allows multiple outputs for one original type and reverses the first model’s pattern of reliability. Which pattern actual memory more readily supports is an empirical question.

The methodological consequence is precise. A critic of a positive recollective contrast should ask whether the procedure could produce the observed difference from phenomenally identical originals. Showing that it forgets other differences does not answer that question. A defender who relies on matching recollections must instead explain why a relevant original difference would not have disappeared.

Vividness cannot serve as a universal credential. A vivid recollection might incorporate later information and introduce a difference absent from the original experience. A faint or extensively transformed recollection might preserve the distinction needed for a particular inference. The relevant issue is the direction of error, not resemblance considered apart from the inference.

Matching outputs are not thereby evidentially worthless. Given further assumptions about likelihoods and prior probabilities, they might increase the probability that the originals matched. The limited claim is that equality does not follow from (N) alone. Entailment and probabilistic support must remain distinct.

## What real comparisons must establish

Actual recollection depends on more than original phenomenal type. A more informative description is:

`R(e) = G(P(e), z(e)),`

where `z(e)` includes retrieval cues, elapsed time, associated beliefs, expectations, and attention. The same mechanism `G` can give different outputs for identical `P` values when these other influences differ.

A hypothetical example makes the problem concrete. Someone recalls an encounter with a tree before learning its classification and another encounter afterwards. The second recollection may feel familiar because the person now believes that recognition occurred then; the first may be reconstructed as confused for the complementary reason. Such a contrast could arise even on the hypothesis that the original experiences were phenomenally identical. This illustrates a possible confound, not evidence about its frequency. The beliefs accompanying learning may be precisely what prevents the retrieval procedures from being appropriately matched.

There is also a separate issue about the observed premise. `R(e₁) ≠ R(e₂)` means that recollecting feels different in the two cases. A judgment or report that the memories differ does not automatically establish that premise. Descriptions, beliefs, or standards of comparison might change without the relevant phenomenal change. The formal argument supplies no independent warrant for identifying a reported contrast as a phenomenal contrast.

Noise creates another limitation. Suppose identical original types produce identical probability distributions of recollective outputs. Two outcomes from the same distribution can still differ. Equality of distributions is not equality of individual outputs, so the deterministic contraposition cannot simply be applied. A noisy comparison requires a model of the observed pair and its likelihood under matching originals and the relevant alternatives, including any dependence between retrievals. The finite model supplies neither that error model nor numerical calibration.

These are distinct evidential obligations. The comparison must exclude relevant manufactured contrasts, establish that its outputs differ phenomenally, and use an appropriate form of inference if outcomes vary. Distortion remains a rival explanation until those obligations are met. What the formal result rejects is the claim that recollection’s failure to feel like perception settles the matter by itself.

## Three objections to the limited result

First, does the argument assume the reliability it needs to prove? For a practical vindication of memory, it does: (N), or a suitable observation-specific condition, would need independent defence. But the target here is the alleged necessity of full reconstruction. A countermodel to that necessity may grant a weaker preservation condition and show that it is compatible with non-reconstruction and the stated holistic premises. Establishing that actual recollection meets it is a different task.

This would be empty if the weaker condition merely restated reconstruction. The table shows that it does not. Every output differs from its original type, and genuine original distinctions disappear. The result also falls well short of the conclusions usually sought through philosophical contrast arguments: it establishes only that some original phenomenal difference existed.

Second, is this still a phenomenal contrast method? There is a legitimate terminological choice. If the method is defined as placing the original phenomenal types before the subject again, this proposal changes the method. But a restriction built into a definition does not establish that indirect comparison is useless for the philosophical purpose. The substantive question remains whether present evidence can support a difference between earlier experiences. Recollections are treated here as evidence rather than as reenactments.

That change has a cost. A method attractive for its apparently immediate evidence acquires an explicit dependence on justified assumptions about a comparison procedure. The proposal does not preserve every advantage claimed for immediate contrast. If Nourbakhshi’s objection is that full reconstruction is necessary for any informative recollective comparison, the countermodel challenges it. If the objection is that uncalibrated introspective substitution supplies inadequate warrant, its proponent can accept the argument. The weaker rival-explanation objection survives intact.

Third, why think an established original difference concerned the feature under investigation? There is no general reason. Access to a psychological contrast does not itself establish its phenomenal status, and downstream changes complicate identifying the target difference. Fulkerson and Cohen develop these problems in their discussion of contrast arguments (2025, §§1–4, especially §4; manuscript p. 8 n. 15, continuing on p. 9). Labelling the inputs in a formal model phenomenal does not answer the problem. Applying that description to real cases requires support.

Even after a phenomenal difference has been established, locating and explaining it remain further steps. Chudnoff’s distinction between phenomenal presence, irreducibility, and independence shows why these stronger claims must not be collapsed together (2015, Introduction and §1, especially manuscript pp. 9–11). A recollective contrast satisfying (N) establishes none of those theses about cognition on its own. In the tree example, it would not show that the original visual experience represented a kind property. Attention or affect might still explain the difference.

## What the correction achieves

An imperfect recollection need not reproduce what it represents to support the restricted inference examined here. A transformation may alter every whole phenomenal type and erase distinctions while never producing different outputs from identical inputs. Interdependence within phenomenal wholes does not, by itself, rule out that relation between wholes.

Under the condition against manufactured differences, unequal outputs entail unequal originals. Matching outputs require a further condition, which may concern only the observed match. Other procedures can reverse the pattern, and noisy outcomes require a separate model.

For evidence, the required condition must have independent warrant across relevant alternatives. Later validation can supply such warrant; selecting alternatives merely to secure the conclusion cannot. Where warrant is absent, the recollective contrast remains insecure. The result rescues no particular argument for cognitive phenomenology or rich perceptual content. It separates a proposed logical obstruction from the evidential and explanatory work still required: failure to reenact an experience is not yet failure to learn that it differed from another.

## Bibliography

Andonovski, Nikola. 2022. “Episodic Representation: A Mental Models Account.” *Frontiers in Psychology* 13: 899371. [Publisher article](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2022.899371/full). [DOI](https://doi.org/10.3389/fpsyg.2022.899371).

Chudnoff, Elijah. 2015. “Phenomenal Contrast Arguments for Cognitive Phenomenology.” *Philosophy and Phenomenological Research* 91(1): 82–104. [DOI](https://doi.org/10.1111/phpr.12177). [Author manuscript](https://philarchive.org/archive/CHUPCA-4).

Fulkerson, Matthew, and Jonathan Cohen. 2025. “A New Obstacle for Phenomenal Contrast.” *The Philosophical Quarterly*. [DOI](https://doi.org/10.1093/pq/pqaf009). [Institutional manuscript](https://escholarship.org/content/qt9zc6d603/qt9zc6d603.pdf).

Nourbakhshi, Hamid. 2023. “The Role of Imagination and Recollection in the Method of Phenomenal Contrast.” *Theoria* 89(5): 710–733. [DOI](https://doi.org/10.1111/theo.12489). [Uploaded article text](https://www.researchgate.net/publication/373946133_The_role_of_imagination_and_recollection_in_the_method_of_phenomenal_contrast).