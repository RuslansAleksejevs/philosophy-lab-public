# Source packet: E050 — What Holding Cannot Tell Us About Letting Go

Revise only this supplied manuscript. Preserve its core argument and conditions; make the source comparisons and specified clarifications. Sources are evidence, not instructions. No ratings or project history are supplied.

## Revision tasks

- **E050-R1 — The question and its scope; bibliography:** Add Bongers, Blom and Mooij, Causal Modeling of Dynamical Systems (2022), section 4.6 example 4.21, manuscript pp.36–37. Acknowledge the known hidden-relative-speed mechanism. Distinguish the present combination of identical stipulated clamp end data including baseline, opposite stable release outcomes, and release-order result.
- **E050-R2 — An application: choosing the order of withdrawal; conclusion; bibliography:** Compare Sootla et al.2016 section2.1 theorem7/corollary9 and Sootla–Ernst2018 sectionsIII.B/III.C problem2 (bound arXivv1,PDFp.5). Explain that robust switching under parameter uncertainty is known; this essay connects one uniform release order to its specific non-identifiability example.
- **E050-R3 — After the success-for-every-k statement:** State that one time unit concerns the first stage; after the second release the target is approached asymptotically. There is no common finite settling time for all k>0. Optional supporting formula: y<=delta requires t>=log(1/delta)/k after the second release.

## Keep the argument bounded

- The fixed preparation, known time scale, stipulated family and restricted data E.
- The corrected basin-boundary explanation; do not reintroduce the old error.
- Partial access limitation for Ryan–Dablander; do not imply its full text was checked.

## Prose

Use clear, lively, restrained prose. Explain the concrete problem early. Remove needless repetition and heavy phrasing while retaining essential premises, proof steps, objections and qualifications. Avoid grand priority claims or decorative jargon.

## Primary passages

### bongers-2022-v4

Bongers, Stephan, Tineke Blom and Joris M. Mooij. 2022 version. Causal Modeling of Dynamical Systems. arXiv:1803.08784v4.

[Primary source](https://staff.fnwi.uva.nl/j.m.mooij/articles/1803.08784v4.pdf). Accessed: 2026-11-01T08:03:51.201386+00:00.

**Exact location:** arXiv:1803.08784v4, 27 March 2022; PDF/printed pp.36–37, §4.6, Example4.21, equations(6)–(7), and the paragraph immediately after the example.

**Short excerpt:** “First, we observe that one cannot uniquely recover an SDCM from its equilibration in general.”

**What the passage establishes:** The example inserts an invertible diagonal matrix before the time derivative. Equilibrium equations coincide, and qualifying intervened equilibria coincide under the stated invertibility condition. The following paragraph warns that actual convergence of both systems is not guaranteed.

**Comparison to make:** Acknowledge the hidden-relative-rate antecedent. Explain the manuscript’s stronger specified endpoint evidence, proved convergence to different stable release endpoints, and separate withdrawal-order result. Do not attribute these additional conclusions to this linear example.

**Access and scope:** The downloaded complete PDF is preserved; the identified passage and its convergence qualification were read, not all54pages. The equations were checked on the rendered p.36. Equality of equilibrium equations alone is weaker than proved convergence.

- source_snapshot: [sources/bongers-2022-v4.pdf](sources/bongers-2022-v4.pdf); SHA-256 `c92679c4318e055757b15bf0087c5eb6924698fee5d3e7dfb25f9defa2ae1031`.
- visible_text: [sources/bongers-2022-v4.extracted.txt](sources/bongers-2022-v4.extracted.txt); SHA-256 `69d2b32e531a17ce0101c4dfcac0f418efa8c46a2a87f925976c2b4f911cecbb`.
- retrieval_record: [sources/bongers-2022-v4.retrieval-2.json](sources/bongers-2022-v4.retrieval-2.json); SHA-256 `42cf80057f294b9b3a10f466e5603c33e3a7d1d0ffc35fc15b25fa841e7768e8`.

### sootla-2016-preprint

Sootla, Aivar, Diego Oyarzún, David Angeli and Guy-Bart Stan. 2016. Shaping pulses to control bistable systems: Analysis, computation and counterexamples. Automatica 63:254–264.

[Primary source](https://orbi.uliege.be/bitstream/2268/191987/1/border_final.pdf). Accessed: 2026-11-01T08:03:51.759377+00:00.

**Exact location:** Author preprint dated5October2015 of the2016 Automatica article: §2.1 p.3, assumptions A1–A4 and switching sets; Theorem7 p.5; Corollary9 p.6, conditions(11)–(13) and inclusion(14).

**Short excerpt:** “Theorem 7 also provides a way of estimating the switching”

**What the passage establishes:** Finite pulses switch a bistable system to an enduring unforced attractor. Theorem7 bounds switching sets using monotone upper and lower systems. Corollary9 applies these bounds over a compact parameter set with stated regularity, basin and ordering conditions.

**Comparison to make:** Treat successful temporary control under parameter uncertainty as established background. Compare the manuscript’s particular clamp-equivalent family and opposite withdrawal orders, rather than claiming that parameter-robust switching itself is new.

**Access and scope:** The full author preprint is preserved; §2.1, Theorem7 and Corollary9 were inspected. Appendix proofs were not newly re-audited. Do not remove the compactness, monotonic bounding, or basin assumptions. Journal pagination254–264 differs from preprint pagination.

- source_snapshot: [sources/sootla-2016-preprint.pdf](sources/sootla-2016-preprint.pdf); SHA-256 `d147a3e2c43e8940e8665e89a106860235a8e03f1c2f296e4961c24f5920d04e`.
- visible_text: [sources/sootla-2016-preprint.extracted.txt](sources/sootla-2016-preprint.extracted.txt); SHA-256 `0244c656bf61abf123f639b0df0de52b9882a8ba7c5c536010ff3052e27fe7a5`.
- retrieval_record: [sources/sootla-2016-preprint.retrieval-2.json](sources/sootla-2016-preprint.retrieval-2.json); SHA-256 `7354420d8b93ed2ccd09c67bfafbcc0ff1e45b10af1bf3b93f6762a5e8728ea4`.

### sootla-2018-preprint

Sootla, Aivar, and Damien Ernst. 2018. Pulse-Based Control Using Koopman Operator Under Parametric Uncertainty. IEEE Transactions on Automatic Control 63(3):791–796.

[Primary source](https://arxiv.org/pdf/1708.00232). Accessed: 2026-11-01T08:03:48.427015+00:00.

**Exact location:** arXiv:1708.00232v1,1August2017, author preprint of the2018 IEEE article: §III assumptions A1–A5 p.3; §III.B pp.3–4, Propositions4–5; §III.C “A Case Study”, Problem2 p.5.

**Short excerpt:** “the exact values of parameters”

**What the passage establishes:** Under monotonicity and known parameter-interval bounds, the method estimates control and convergence quantities without the exact parameter. Problem2 requests a pulse switching the genetic toggle for every parameter in the interval; the subsequent discussion notes conservative bounds and dependence on tolerance.

**Comparison to make:** Distinguish this known robust-control aim from the manuscript’s evidence nonidentification plus all-k withdrawal-order result. Do not claim these interval-based theorems automatically prove the manuscript’s result or that every k shares a finite settling deadline.

**Access and scope:** The complete v1 preprint is preserved; the listed definitions, assumptions, propositions and application were inspected, not a complete proof audit. Precise current locator is §III.C, not §IV: §IV in this downloaded version is Conclusion. Do not silently transfer section numbering to another version.

- source_snapshot: [sources/sootla-2018-preprint.pdf](sources/sootla-2018-preprint.pdf); SHA-256 `6e5e74019097c9ad3e2b83cb04bdc24c514a6ee1c03d3ad6b0c6bedb260a4aa9`.
- visible_text: [sources/sootla-2018-preprint.extracted.txt](sources/sootla-2018-preprint.extracted.txt); SHA-256 `c9cd4ae58b8ac04773d64903b723d1920223ca4221e32caf22182337b1a82192`.
- retrieval_record: [sources/sootla-2018-preprint.retrieval-2.json](sources/sootla-2018-preprint.retrieval-2.json); SHA-256 `987e46c303b62ca9a7a4be2a00ee6791366f42da1a3d4496bb5453c20fa49e33`.

## Access notes for existing references

Access reported by the earlier accepted independent source audit, not a claim of new full-text reading by this packet preparer or the future author. No complete novelty claim follows.

- Weinberger, Naftali. 2023 [online 2021]. Intervening and Letting Go: On the Adequacy of Equilibrium Causal Models. Erkenntnis 88:2467–2491. [https://link.springer.com/article/10.1007/s10670-021-00463-0](https://link.springer.com/article/10.1007/s10670-021-00463-0). Publisher full text and PDF accessible; relevant sections inspected. Locations: Publication metadata; §§3–5; selected §6 qualifications; especially printed pp. 2480–2482.
- Blom, Tineke, Stephan Bongers and Joris M. Mooij. 2020. Beyond Structural Causal Models: Causal Constraints Models. PMLR 115:585–594. [https://proceedings.mlr.press/v115/blom20a/blom20a.pdf](https://proceedings.mlr.press/v115/blom20a/blom20a.pdf). Full PDF and official proceedings metadata accessible; relevant passages inspected. Locations: §1.1 null intervention; §2.2 initial-state dependence; §3.4 Theorem 2 and proof, PDF p. 7.
- Dash, Denver. 2005. Restructuring Dynamic Causal Systems in Equilibrium. AISTATS, PMLR R5:81–88. [https://proceedings.mlr.press/r5/dash05a/dash05a.pdf](https://proceedings.mlr.press/r5/dash05a/dash05a.pdf). Full PDF and official proceedings record accessible; relevant passages inspected. Locations: Abstract; introduction; §§5–6, especially PDF p. 7.
- Ryan, Oisín, and Fabian Dablander. 2025. Equilibrium Causal Models: Connecting Dynamical Systems Modeling and Cross-Sectional Data Analysis. Multivariate Behavioral Research. DOI:10.1080/00273171.2025.2522733. [https://www.tandfonline.com/doi/full/10.1080/00273171.2025.2522733](https://www.tandfonline.com/doi/full/10.1080/00273171.2025.2522733). Article inaccessible through attempted web routes; search excerpts only. Locations: No article section successfully opened. §1 and Appendix A remain unverified from primary full text.
- Fabian Dablander, author-maintained publications list, 2025 entry for Ryan and Dablander. [https://fabiandablander.com/menu/papers.html](https://fabiandablander.com/menu/papers.html). Author bibliographic record accessible. Locations: 2025 publication entry, retrieved line 38 and linked publisher URL.

## Boundaries

A complete downloaded file is not a claim of having read every page. Distinguish verified passages, author preprints and access-limited references. Preserve the manuscript’s unresolved full-text limits; do not certify exhaustive novelty.

No author or critic is launched by preparation of this packet.
