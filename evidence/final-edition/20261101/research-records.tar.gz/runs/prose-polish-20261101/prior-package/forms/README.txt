Submission package — E050, E012, E051

Submit three separate entries. For each, upload the matching essay PDF to PDF and the matching methodology PDF to Methodology Report. Do not upload this whole convenience archive as an essay or methodology report.

Deadline: 1 November 2026, 03:59 PST (San Francisco), 11:59 UTC.
The form text files contain ready-to-copy title, keywords, TL;DR, abstract and model disclosures. Their titles match the PDFs. Personal answers, attribution preference and declarations remain the submitter's choice and responsibility.

PDFs are anonymous. The editable LaTeX projects each contain main.tex and body.tex. Compile main.tex from its own project folder with Tectonic or XeLaTeX and the TeX Gyre Pagella fonts/packages declared in the preamble. The essays preserve the previously accepted wording; only layout and mathematical typesetting changed.

Nothing has been submitted. The private repository has not been published or updated by this packaging step.
