"""Build updated editable LaTeX and submission metadata from selected revisions."""
from pathlib import Path
import hashlib,importlib.util,json,re,shutil
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('original_pdf_builder',ROOT/'runs/submission-package-20261101/build_sources.py')
F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
OUT=ROOT/'output/submission-20261101';TEX=ROOT/'output/latex/submission-20261101'
OLD=RUN/'prior-package/forms'
def load(p):return json.loads(p.read_text())
def ref(p):return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def make(eid,md):
    title=re.sub(r'^#+\s*','',md.splitlines()[0])
    # The shared renderer supplies math delimiters for table data cells.
    rendered='\n'.join(re.sub(r'\\\((.*?)\\\)',r'\1',line) if line.startswith('| ') else line for line in md.splitlines())
    if eid=='E012':
        rendered=rendered.replace('The 2015 Rule 37 notes likewise','\n\nThe 2015 Rule 37 notes likewise').replace('Mara’s case differs:','\n\nMara’s case differs:')
    b=F.body(rendered)
    if eid=='E050':
        headings=re.findall(r'^### (A\.\d+) (.+)',md,flags=re.M)
        assert headings and '## Appendix' in md
        refs=re.findall(r'Appendix (A\.\d+)',md)
        assert refs and set(refs)<=set(n for n,t in headings),(refs,headings)
        for number,text in headings:
            h=F.inline(number+' '+text)
            b=b.replace(r'\subsection*{'+h+'}',r'\phantomsection\subsection*{'+h+r'}\label{app:'+number.lower()+'}')
        b=re.sub(r'Appendix (A\.\d+)',lambda m:r'\hyperref[app:'+m[1].lower()+']{Appendix '+m[1]+'}',b)
        plural=re.findall(r'Appendices (A\.\d+) and (A\.\d+)',md)
        assert all(n in dict(headings) for pair in plural for n in pair)
        b=re.sub(r'Appendices (A\.\d+) and (A\.\d+)',lambda m:r'Appendices \hyperref[app:'+m[1].lower()+']{'+m[1]+r'} and \hyperref[app:'+m[2].lower()+']{'+m[2]+'}',b)
        b=b.replace(r'\section*{Appendix:',r'\clearpage\section*{Appendix:')
        (RUN/'APPENDIX_LINKS.json').write_text(json.dumps({'headings':headings,'references':refs,'plural_references':plural,'all_targets_exist':True},indent=2)+'\n')
    # Keep any introduction with its immediately following table.
    b=re.sub(r'([^\n]+)\n\n(\\begin\{center\}\\renewcommand\{\\arraystretch\})',r'\n\\Needspace{11\\baselineskip}\n\1\n\n\2',b)
    titleprint=F.inline(title)
    if eid=='E050':titleprint=r'What Holding Cannot Tell Us\\About Letting Go'
    main=F.PREAMBLE.replace('TITLEMETA',F.esc(title)).replace('SHORTTITLE',F.esc(title)).replace('TITLEPRINT',titleprint)
    if eid=='E050':
        # Avoid a three-line spill page immediately before the new-page appendix.
        main=main.replace(r'\setlength{\parskip}{0.48em}',r'\setlength{\parskip}{0.36em}')
    (TEX/eid/'main.tex').write_text(main);(TEX/eid/'body.tex').write_text(b)
def support(eid,abstract,tldr,review):
    data=load(OLD/f'{eid}-form.json');data['abstract']=abstract;data['tldr']=tldr
    (OUT/f'{eid}-form.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    previous=(OLD/f'{eid}-form.txt').read_text()
    previous=re.sub(r'(?s)(TL;DR\n).*?(\n\nABSTRACT\n)',lambda m:m[1]+tldr+m[2],previous)
    previous=re.sub(r'(?s)(ABSTRACT\n).*?(\n\nAI INVOLVEMENT\n)',lambda m:m[1]+abstract+m[2],previous)
    (OUT/f'{eid}-form.txt').write_text(previous)
    method=(OLD/f'{eid}-methodology.txt').read_text()
    method=method.replace('## Final revision and preparation','## Source-focused revision and first preparation')
    method=method.replace('For the final revision, each author received','For that source-focused revision, each author received')
    method=method.replace('The three final essays were then typeset','The three revised essays were then typeset')
    method=method.replace('were used to prepare the final revision.','were used to prepare the source-focused revision.')
    method=method.replace('## Appendix A. Final author instructions','## Appendix A. Earlier author instructions')
    method=method.replace('from the final revision packet','from the source-focused revision packet')
    method=method.replace('## Appendix B. Essay-specific final tasks','## Appendix B. Earlier essay-specific tasks')
    method=method.replace('## Appendix C. Independent checker instructions','## Appendix C. Earlier independent checker instructions')
    method=method.replace('the exact checking-instruction block used for the separate final review','the exact checking-instruction block used for the separate source-focused revision review')
    addition='''## Further revision for readability

After reading the first PDFs, the human requested simpler, more natural and more pleasant prose without loss of meaning or rigor. The human also requested that the detailed calculations in the mathematical essay be moved into a structured appendix, with clear references and plain explanations in the main text. These were editorial directions; the AI chose the wording, organization and philosophical explanations.

A new fresh GPT-6 Astra/ultra editor received this essay's complete accepted manuscript, neutral prose instructions, essay-specific AI editorial tasks and the existing primary-source packet. It had no tools, browsing, project memory, other essays or previous review verdicts. The rewrite and revised abstract were preserved separately from their parent. A different fresh Astra/ultra checker received the complete parent and rewrite, their exact difference, the proposed abstract and TL;DR, primary passages and source-access notes. It did not receive the editor's self-assessment or earlier verdicts. The check covered preservation of reasoning, premises, source claims, qualifications and objections, as well as clarity and any appendix references.

'''+review+'''

The revised texts were typeset again, and all pages and metadata were checked. Earlier manuscripts, PDFs and reviews remain preserved. This editorial step does not claim a new independent literature search, empirical validation, or proof of originality.

'''
    method=method.replace('## Resources and retained records',addition+'## Resources and retained records')
    method+='\n## Appendix D. Readability editor instructions\n\nThe following is the exact common instruction block used for the later prose rewrite.\n\n'+(RUN/'AUTHOR_INSTRUCTIONS.txt').read_text()
    method+='\n\n## Appendix E. Readability checker instructions\n\nThe following is the exact common instruction block used for the independent check of the rewrite.\n\n'+(RUN/'CRITIC_INSTRUCTIONS.txt').read_text()+'\n'
    if eid=='E012':
        assert load(RUN/'repair/E012/FINAL_RECEIPT.json')['decision']=='READY'
        method+='\n## Appendix F. Check of the wording correction\n\nThe following is the exact instruction block for the further, narrowly scoped independent check. It accompanied the complete versions before and after the correction and their exact difference.\n\n'+(RUN/'repair/E012/INSTRUCTIONS.txt').read_text()+'\n'
    (OUT/f'{eid}-methodology.txt').write_text(method)
    # Quoted markup instructions must display their literal math delimiters.
    F.make_project(eid+'-methodology',method.replace(r'\( ... \)','LITERALINLINEDELIMITERS'),'Methodology Report')
    body_path=TEX/(eid+'-methodology')/'body.tex'
    body_path.write_text(body_path.read_text().replace('LITERALINLINEDELIMITERS',F.esc(r'\( ... \)')))
    if eid=='E050':
        main_path=TEX/(eid+'-methodology')/'main.tex'
        main_path.write_text(main_path.read_text().replace(r'\setlength{\parskip}{0.48em}',r'\setlength{\parskip}{0.36em}'))
def main():
    selection=load(RUN/'SELECTION.json');rows=[]
    for row in selection['essays']:
        eid=row['essay_id'];p=ROOT/row['manuscript']['path']
        assert ref(p)==row['manuscript']
        md=p.read_text();make(eid,md)
        metadata=load(ROOT/row['abstract']['path'])
        support(eid,metadata['abstract'],metadata['tldr'],row['review_account'])
        before=re.split(r'^## (?:Bibliography|References)',md,flags=re.M)[0]
        rows.append({'essay_id':eid,'source':ref(p),'whitespace_words_excluding_bibliography':len(before.split()),'abstract_words':len(metadata['abstract'].split()),'title':re.sub(r'^#+\s*','',md.splitlines()[0])})
    (RUN/'BUILD_MANIFEST.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(rows,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
