## Difference without Reconstruction

Remembering a painful afternoon need not hurt. Remembering an intensely coloured sunset need not reproduce its intensity. This distance between experiencing and remembering poses a problem for philosophers who use comparisons to investigate experience. To ask whether learning to recognize something changes how it looks, or whether understanding a sentence changes how it sounds, we often compare how things seemed before and afterwards. But the earlier experience is gone. A contrast between present perception and faded recollection may owe more to remembering than to the change we hoped to investigate.

The problem is serious, but it does not show that recollection must recreate an experience before it can tell us anything about differences between experiences. Consider comparing two recollections. Neither need feel like its original for their contrast to carry information. What matters for the inference examined here is that the comparison procedure would not produce that contrast from originals that felt the same. A procedure might satisfy this requirement while erasing other differences. Differing recollections could then establish an original difference even when matching recollections leave the matter open.

This is a conditional argument against a logical prohibition, not a demonstration that human memory meets the condition. Using the argument as evidence requires independent support for the procedure and the range of cases to which it applies. The task is to identify what that support must concern, without demanding more than the inference needs.

### The demand for reconstruction

Nourbakhshi argues that recollection and imagination cannot simply take perception's place in a phenomenal contrast argument: their own distinctive character may explain the apparent difference. He also considers whether relevant partial similarities could suffice. That suggestion faces difficulties if phenomenal parts depend on one another and introspection cannot reliably isolate an unchanged remainder (2023, §§4, 6–9, especially §§7–8).

His demand for full phenomenal reflection supports a strong reading: an informative recollective comparison requires reconstruction of the original phenomenal character. His conclusion also allows a weaker reading: distortion remains a rival explanation that a particular comparison must exclude. The argument here challenges the strong requirement. It leaves the weaker objection in place. Nor does it introduce the general thought that relevant similarity might suffice; Nourbakhshi already considers that possibility. The question is whether comparison can work without either recreating the original whole or finding an unchanged part within a transformed experience.

Two ways of comparing must remain separate. Someone may compare a present perception with a recollection of an earlier perception, or compare two recollections produced through an appropriately matched procedure. The result below directly concerns the second route. A perception–recollection comparison needs a condition justified across its different routes to the compared states. Calling both states representations of experiences does not supply that justification. Calling two states memories likewise does not establish that their retrieval procedures are matched.

A hypothetical case shows why matching matters. Someone recalls seeing a tree before learning its classification and seeing it again afterwards. The second recollection may feel familiar because the person now believes that recognition occurred then; the first encounter may be reconstructed as confused for the complementary reason. These recollections could differ even if the original experiences felt exactly the same. This is a possible confound, not a claim about how often it occurs. The beliefs acquired through learning may themselves prevent the two retrieval procedures from being appropriately matched.

### A comparison that loses detail

Call the way an episode feels, considered as a whole, its *phenomenal type*. Two episodes have the same phenomenal type when they are alike in this respect. This leaves open both what constitutes a phenomenal type and whether a difference between types is sensory, affective, or cognitive.

A comparison case \(e\) specifies an original episode and a permitted occasion of recollection. Let \(P(e)\) be the original episode's phenomenal type and \(R(e)\) the phenomenal type of its recollective output. Including the retrieval occasion lets us consider different ways of recalling an episode. Let \(D\) be the domain of cases to which the comparison procedure applies.

The basic requirement is simple: within that domain, originals of the same phenomenal type must yield recollections of the same phenomenal type. Formally, the condition against manufactured differences is:

\[
\text{(N)}\qquad P(e_1)=P(e_2)\quad\Longrightarrow\quad R(e_1)=R(e_2),\qquad e_1,e_2\in D.
\]

If (N) holds, differing outputs entail differing originals. The proof is just contraposition. Had the originals been of the same type, (N) would have required matching outputs, contrary to the observed difference. Nothing in this reasoning requires an output to resemble its original.

Condition (N) also allows us to write the output as a function of original phenomenal type within the domain:

\[
R(e)=F(P(e)).
\]

For each original type \(p\) occurring in \(D\), choose a case with that type and define \(F(p)\) as its output. Condition (N) guarantees that choosing another case with the same original type would give the same value. That is what makes \(F\) well defined. It does not require \(F\) to leave its input unchanged, or to give every distinct input a distinct output.

Consider this finite model:

| Original phenomenal type | Recollective phenomenal type |
| --- | --- |
| \(a\) | \(u\) |
| \(b\) | \(u\) |
| \(c\) | \(v\) |
| \(d\) | \(v\) |

The four original types are distinct. The output types \(u\) and \(v\) differ from each other and from every original type. No recollection therefore reproduces an original whole phenomenal type. The transformation also loses information: it erases the difference between \(a\) and \(b\), and between \(c\) and \(d\).

Yet a \(u/v\) contrast establishes that the originals differed. One came from the \(a/b\) group and the other from the \(c/d\) group. We need not identify the particular member of either group, recover the original experience, or inspect an unchanged phenomenal part.

The mathematics is elementary. Its purpose is to supply a countermodel to the proposed necessity of reconstruction, relative to the premises under discussion. The table offers no complete metaphysics of phenomenal types. It shows why the failure to reconstruct a whole experience does not, without a further premise, imply the impossibility of detecting an original difference.

### From a valid inference to evidence

The entailment alone does not give someone a reason to trust a comparison. Restricted to an actual pair whose originals differ, (N) is true vacuously: its antecedent is false. Suppose the original episodes differed only in incidental discomfort, while a leading retrieval cue produced the recollective contrast. The truth of (N) on that pair would not show that recollection tracked the original difference. Once differing outputs are given, asserting (N) only for the actual pair is equivalent to asserting that the originals differed. It adds no independent warrant.

Evidence requires support across relevant alternatives. The domain must include cases with matching original phenomenal types, together with the variations in cues, beliefs, elapsed time, and other influences that the procedure permits. The needed counterfactual claim is that matching originals would not produce the contrasted outputs through those permitted variations. If the procedure holds a factor fixed, there must be grounds for treating it as fixed.

Independence is the issue, not chronological priority. Choosing a domain merely to guarantee the desired result provides no justification. But noticing a contrast, proposing a domain, and subsequently validating it on independent grounds is not disqualified by that order. What matters is whether the validation depends on the conclusion it is meant to support.

Using the same deterministic mechanism for both recollections would not by itself establish (N). A mechanism may respond to physical histories, associated beliefs, and retrieval circumstances that differ even when the original episodes have the same phenomenal type. Determinism about complete histories is therefore different from the claim that recollective output is a function of original phenomenal type.

We can make the additional influences explicit by writing:

\[
R(e)=G(P(e),z(e)),
\]

where \(z(e)\) includes retrieval cues, elapsed time, beliefs, expectations, and attention. The same mechanism \(G\) can yield different outputs for the same \(P\) when these other influences vary. In the tree example, beliefs about whether recognition occurred could contribute to the contrast in just this way. A justified comparison must establish the relevant constraint on those influences; the shared mechanism does not establish it automatically.

### Wholes, parts, and imperfect representations

The model compares whole phenomenal types. It never separates an experience into a content component and a memory-mode component, then subtracts one to recover the other. Nor do the different labels in the table prove that its wholes share no parts. Compatibility with holism depends on what holism entails, not on how the types are named.

Suppose every phenomenal part's contribution depends on the whole experience. Suppose, further, that moving from perception to recollection changes every part's contribution. Neither claim requires matching original types to yield different recollective types. Neither requires every original type to collapse into a single recollective type. The table requires neither manufactured differences nor total collapse.

Holism concerns dependencies within phenomenal wholes. Condition (N) concerns a relation between wholes at different stages. An argument against their compatibility must connect those two levels. Interdependence within a recollection does not by itself rule out a relation through which differing recollections establish differing originals.

One might object that the table preserves a component after all: membership in the \(a/b\) group rather than the \(c/d\) group. But grouping possible whole states does not thereby identify a part within each state. The grouping classifies experiences according to a relation; it need not pick out something separately experienced in each one. Treating every preserved distinction as a phenomenal component would collapse the difference between preserving a relation and preserving a part.

The proposal can thus grant the claims that make subtraction unattractive. The original whole need never appear again, and there need be no unchanged phenomenal remainder available for inspection. Information about an original difference can instead depend on a relation between transformed wholes.

Andonovski's account of episodic representation provides a nearby antecedent for the broader idea of learning from imperfect representations. His episodic models are simplified structural representations: they retain usable relations while omitting details, and their resemblance to represented events need not approach a complete structural match. Resemblance alone is insufficient. The relevant cognitive system must be sensitive to the mapping and exploit it in some operation or task (2022, “Mental models as structural representations”). Consulting and manipulating a model can then support new inferences about the represented event (“Modeling and surrogative reasoning”).

There is a crucial boundary to this comparison. Andonovski distinguishes the content and format of representations produced by the episodic system from the content of memory experiences. Event-model content need not fully determine experiential content: mindreading, metacognitive, and other systems may also contribute (2022, “Episodic representation: What the thesis is not,” first qualification). His account of event models cannot therefore simply be treated as an account of whole recollective phenomenal types.

The mappings also concern different things. Andonovski examines how relations among constituents of events can be represented in models and used to reason about those events. Here, \(F\) relates whole original phenomenal types to whole recollective phenomenal types. It requires no constituent-by-constituent mapping between an event and its model. Neither structural representation in general nor inference through simplified episodic models is claimed as new. The narrower contribution is to isolate the condition under which a contrast between whole recollective types entails an original phenomenal difference. Andonovski's account does not establish that real memory satisfies (N).

### What a match can tell us

A procedure can avoid making differences while still losing them. In the table, two outputs of type \(u\) could come from \(a\) and \(a\), or from \(a\) and \(b\). Condition (N) therefore does not license an inference from matching outputs to matching original types.

Within the functional model, licensing that converse inference for every possible matching output requires *injectivity*: distinct original types must have distinct outputs. A particular match can require less. Consider a different domain containing just three original types, with \(F(a)=u\) and \(F(b)=F(c)=v\). A \(u/u\) match identifies \(a/a\), although the function is not injective. Only the observed output needs to have a single possible original type within the justified domain. Both matching outputs in the first table are inconclusive, but not every transformation that loses information has that feature.

Even global injectivity falls short of full phenomenal reconstruction. A transformation can change every type while keeping all its outputs distinct. Reconstruction is therefore unnecessary for either direction of inference: from difference to difference, or from equality to equality.

The two requirements address different errors. Avoiding manufactured differences licenses the inference from differing outputs to differing originals. Avoiding erased differences licenses the inference from matching outputs to matching originals. The first requirement, too, can be restricted to a particular observation. To trust one contrast, it is enough that no admissible pair of matching originals could yield that observed pair of different outputs. Other contrasts produced by the procedure need not be reliable. Such a restriction helps only when the relevant alternatives have independent justification.

There is consequently no universal evidential privilege for a positive contrast. Consider a procedure in which original type \(a\) can yield either \(u\) or \(v\), while original type \(b\) can yield only \(w\). The possible outputs for the two original types do not overlap, so matching outputs identify matching originals. Yet unequal \(u/v\) outputs can both come from \(a\). By allowing more than one output for a single original type, this procedure reverses the first model's pattern of reliability. Which pattern actual memory more readily supports is an empirical question.

A critic of differing recollections should therefore ask whether the procedure could produce the observed contrast from phenomenally matching originals. Showing that the procedure forgets other differences does not answer that question. Someone who relies on matching recollections faces the other problem: could a relevant original difference have disappeared?

Vividness cannot settle either issue by itself. A vivid recollection might incorporate later information and introduce a difference absent from the original experience. A faint or extensively transformed recollection might retain the distinction needed for a particular inference. Resemblance matters only insofar as it bears on the error relevant to that inference.

Nor does the failure of an entailment make matching outputs evidentially worthless. With further assumptions about likelihoods and prior probabilities, a match might increase the probability that the originals matched. The claim established here is narrower: their equality does not follow from (N) alone. Probabilistic support and entailment are different achievements.

### Establishing the observed contrast

So far, an output difference has meant a difference in how recollecting feels. A judgment or report that two memories differ does not automatically establish this premise. Descriptions, beliefs, or standards of comparison might change without the relevant phenomenal change. The formal argument gives no independent reason to identify a reported contrast with \(R(e_1)\ne R(e_2)\).

Noise raises a separate problem. Suppose matching original phenomenal types produce identical probability distributions of recollective outputs. Two outcomes drawn from the same distribution can nevertheless differ. Equality of distributions is not equality of individual outputs, so the deterministic inference by contraposition cannot simply be carried over.

A noisy comparison needs a model of how likely the observed pair is under matching originals and under the relevant alternatives. That model must allow for any dependence between the retrievals, rather than assuming they are independent. The finite table supplies neither an error model nor numerical calibration.

These obligations do different work. Establishing that the outputs differ phenomenally supports the observed premise. Excluding relevant manufactured contrasts supports the connection to the originals. Modelling variable outcomes determines what inference the evidence permits. None is settled merely by observing that recollection feels unlike perception.

### The reach of the argument

Granting (N) may look like assuming the reliability that needs to be proved. That would be a problem for an attempt to vindicate an actual memory procedure: (N), or a suitable condition for the observed contrast, would need independent defence. But the claim at issue is that informative comparison requires full reconstruction. To challenge that necessity, a countermodel may grant a weaker preservation condition and show that it is compatible with both non-reconstruction and the holistic premises under discussion.

The weaker condition does not conceal reconstruction under another name. In the table, every output differs from every original type, and some genuine original distinctions disappear. What survives is only enough to establish that some original phenomenal difference existed. This is considerably less than philosophical contrast arguments usually seek.

There is also a legitimate question about the name of the method. If a phenomenal contrast method is defined as placing the original phenomenal types before the subject again, the present proposal changes the method. Yet a restriction built into that definition does not establish that indirect comparison is useless for the philosophical purpose. Present recollections may still provide evidence about differences between earlier experiences.

This comes at a cost. A method appealing for its apparently immediate evidence now depends explicitly on justified assumptions about a comparison procedure. The proposal does not retain every advantage claimed for immediate contrast. Nourbakhshi's strong reconstruction requirement is challenged, while someone who objects to uncalibrated introspective substitution can accept the result. Distortion remains a rival explanation wherever the relevant evidential conditions have not been established.

Finally, detecting an original difference does not locate or explain it. Access to a psychological contrast does not itself establish that the contrast is phenomenal, and downstream changes can complicate the identification of the feature under investigation. Fulkerson and Cohen develop these problems in their discussion of contrast arguments (2025, §§1–4, especially §4; manuscript p. 8 n. 15, continuing on p. 9). Calling the inputs phenomenal in a formal model does not justify that description in an actual case.

Even when an original phenomenal difference has been established, attributing it to cognition requires a further argument. Chudnoff distinguishes phenomenal presence, irreducibility, and independence, separating the claim that cognition contributes to phenomenal character from stronger claims about that contribution (2015, Introduction and §1, especially manuscript pp. 9–11). A recollective contrast satisfying (N) establishes none of these theses about cognition on its own. In the tree example, it would not establish that the original visual experience represented the tree's kind. Attention or affect might still explain the difference.

The model therefore secures no particular argument for cognitive phenomenology or rich perceptual content. It identifies a more modest possibility: a procedure can transform whole experiences, lose some distinctions, and still retain evidence that two originals differed. Whether a real comparison does so depends on the warrant for its conditions. The failure to reenact an experience does not by itself show that its difference from another experience is beyond reach.

## Bibliography

Andonovski, Nikola. 2022. “Episodic Representation: A Mental Models Account.” *Frontiers in Psychology* 13: 899371. [Publisher article](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2022.899371/full). [DOI](https://doi.org/10.3389/fpsyg.2022.899371).

Chudnoff, Elijah. 2015. “Phenomenal Contrast Arguments for Cognitive Phenomenology.” *Philosophy and Phenomenological Research* 91(1): 82–104. [DOI](https://doi.org/10.1111/phpr.12177). [Author manuscript](https://philarchive.org/archive/CHUPCA-4).

Fulkerson, Matthew, and Jonathan Cohen. 2025. “A New Obstacle for Phenomenal Contrast.” *The Philosophical Quarterly*. [DOI](https://doi.org/10.1093/pq/pqaf009). [Institutional manuscript](https://escholarship.org/content/qt9zc6d603/qt9zc6d603.pdf).

Nourbakhshi, Hamid. 2023. “The Role of Imagination and Recollection in the Method of Phenomenal Contrast.” *Theoria* 89(5): 710–733. [DOI](https://doi.org/10.1111/theo.12489). [Uploaded article text](https://www.researchgate.net/publication/373946133_The_role_of_imagination_and_recollection_in_the_method_of_phenomenal_contrast).