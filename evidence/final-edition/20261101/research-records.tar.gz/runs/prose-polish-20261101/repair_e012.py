"""Apply one exact critic-proposed wording correction and check only that delta."""
from pathlib import Path
import difflib,importlib.util,json
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prose_pipeline',RUN/'pipeline.py')
P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
LANE=RUN/'repair/E012';LANE.mkdir(parents=True,exist_ok=True)
parent=RUN/'results/E012-author/derived/revision.md'
old=parent.read_text();needle='The fund pays Mara for destroying her opportunity'
replacement='The fund compensates Mara for the destruction of her opportunity'
assert old.count(needle)==1
revision=LANE/'revision.md';P.textnew(revision,old.replace(needle,replacement))
diff=LANE/'changes.diff';P.textnew(diff,''.join(difflib.unified_diff(old.splitlines(True),revision.read_text().splitlines(True),fromfile='polished-parent.md',tofile='corrected.md')))
instructions=LANE/'INSTRUCTIONS.txt'
P.textnew(instructions,'''You are a fresh independent checker of a single bounded wording correction in one philosophical essay. You did not write either supplied text. Use only these complete texts, their exact diff, and the schema. Do not use tools, browse, access files or other conversations, or delegate.

The scope is the new difference, not a repetition of a completed review of unchanged material. Read both texts completely to establish context and verify that the diff is exhaustive. Decide independently whether the revised sentence clearly assigns the destruction to the fund in context, preserves the original intended meaning, and introduces no ambiguity, grammatical fault, unsupported assertion or other semantic change. Confirm whether anything beyond that bounded wording changed. Do not assume the proposed correction is successful. No earlier verdict or author self-assessment is supplied.

Return READY only if this correction requires no further repair. Otherwise identify the exact necessary correction. In the broader schema fields, state the limited scope honestly: unchanged mathematics, source claims and philosophical arguments are checked only for preservation, not freshly re-audited; no abstract or source passages are part of this narrow packet. The language judgment concerns the changed sentence in context. Return only the required JSON.''')
jid='E012-repair-critic';schema=RUN/'schema/critic.json'
identity={'job_id':jid,'essay_id':'E012','scientific_role':'critic','manuscript_sha256':P.ref(revision)['sha256']}
prompt=('Read only these supplied materials. No tools. Return only JSON.\nExact output identity: '+json.dumps(identity)+'\n').encode();inline=[]
for label,path in [('INSTRUCTIONS',instructions),('ORIGINAL',parent),('REVISION',revision),('EXACT DIFF',diff),('REQUIRED SCHEMA',schema)]:
 raw=path.read_bytes();prompt+=('\n----- BEGIN '+label+' -----\n').encode();pos=len(prompt);prompt+=raw
 inline.append({**P.ref(path),'prompt_byte_start':pos,'prompt_byte_length':len(raw)})
 if label=='REVISION':start=pos
 prompt+=('\n----- END '+label+' -----\n').encode()
pp=LANE/'prompt.txt';P.textnew(pp,prompt.decode())
job={'id':jid,'essay_id':'E012','scientific_role':'critic','role':'argument','transport_profile':'no_tools','web_search':'disabled','model':'gpt-6-astra','effort':'ultra','service_tier':'default','manuscript_id':'E012','manuscript_file':str(revision.relative_to(ROOT)),'manuscript_sha256':P.ref(revision)['sha256'],'manuscript_byte_start':start,'manuscript_byte_length':len(revision.read_bytes()),'prompt_file':str(pp.relative_to(ROOT)),'prompt_sha256':P.ref(pp)['sha256'],'schema_file':str(schema.relative_to(ROOT)),'schema_sha256':P.ref(schema)['sha256'],'expected_output':identity,'inline_inputs':inline}
jp=LANE/'job.json';P.new(jp,job)
P.base.check_inputs(job,ROOT)
paths=[Path(__file__),parent,revision,diff,instructions,pp,schema,jp]
files=[P.ref(p) for p in paths]
parent_event=P.load(RUN/'CRITICS_ARCHIVE_RECEIPT.json')['event_id']
with P.Archive(ROOT/'research/archive').writer() as w:
 event=P.append(w,'research.prose.repair.inputs.accepted','E012-wording-repair-inputs',[parent_event],files,{'status':'E012_WORDING_REPAIR_INPUTS_ARCHIVED','change':'One exact replacement proposed in independent E012 finding F1, applied mechanically by the AI coordinator. All other bytes preserved.','review_scope':'Fresh independent check of only this new correction, with complete manuscript context.'})
 P.new(LANE/'START_RECEIPT.json',P.receipt(event))
print('Bounded correction archived; launching its fresh independent check.',flush=True)
for row in files:assert P.ref(ROOT/row['path'])==row
assert not (RUN/'results'/jid/'attempt-001').exists()
result=P.base.Dispatcher(RUN,ROOT).run_one(job);print(json.dumps(result),flush=True)
assert result['status']==P.base.COMPLETE,result
ctx={'root':ROOT,'run':RUN,'runner':P.base,'jobs':{jid:job}}
r=P.B.validate_terminal(ctx,jid,RUN/'results'/jid/'attempt-001/receipt.json')
prior={x['session_id'] for wave in ['AUTHORS','CRITICS'] for x in P.load(RUN/(wave+'_ARCHIVE_RECEIPT.json'))['roles']}
assert r['session_id'] not in prior and r['session_id']!=P.SID
with P.Archive(ROOT/'research/archive').writer() as w:
 event=P.append(w,'research.prose.repair.check.accepted','E012-wording-repair-check',[event['id']],r['files'],{'status':'E012_WORDING_REPAIR_CHECK_ARCHIVED','decision':r['value']['decision'],'native_configuration':r['proof'].get('configurations',[]),'independent_native_replay':True,'scope':'Single wording correction; unchanged arguments and sources not re-audited.','revision':P.ref(revision)},r['session_id'])
 P.new(LANE/'FINAL_RECEIPT.json',{**P.receipt(event),'decision':r['value']['decision'],'revision':P.ref(revision),'response':P.ref(RUN/'results'/jid/'attempt-001/response.json')})
print('Fresh correction check archived; inspect its decision before selection.',flush=True)
