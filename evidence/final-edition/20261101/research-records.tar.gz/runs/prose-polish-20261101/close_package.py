from pathlib import Path
import hashlib,json,sys,zipfile
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def ref(p):return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sel=load(RUN/'SELECTION.json');qa=load(RUN/'PDF_QA.json');visual=load(RUN/'VISUAL_QA.json')
assert visual['all_pages_inspected'] and visual['unresolved_defects']==[]
assert len(qa)==6 and sum(r['pages'] for r in qa)==visual['pages_inspected']
for r in qa:
 assert not r['author_metadata'] and not r['identifying_strings'] and not r['missing_urls'] and not r['file_attachments']
 assert not r['compiler_warnings'],r
 assert r['bytes']<50_000_000
 assert ref(ROOT/r['pdf'])['sha256']==r['sha256']
 assert ref(ROOT/r['source'])['sha256']==r['source_sha256']
 assert set(r['internal_links'])<=set(r['named_destinations'])
 viewed=next(x for x in visual['documents'] if x['pdf']==r['pdf'])
 assert viewed['sha256']==r['sha256'] and viewed['pages_inspected']==list(range(1,r['pages']+1))
 assert not r['unmatched_prose'] or r['pdf'] in visual.get('resolved_extraction_exceptions',{}),r['pdf']
for row in sel['essays']:
 assert ref(ROOT/row['manuscript']['path'])==row['manuscript']
 assert row['accepted_for_submission_package'] is True
 essay_qa=next(x for x in qa if x['pdf'].endswith(row['essay_id']+'-essay.pdf'))
 assert essay_qa['source']==row['manuscript']['path'] and essay_qa['source_sha256']==row['manuscript']['sha256']
 assert ref(ROOT/row['abstract']['path'])==row['abstract']
 metadata=load(ROOT/row['abstract']['path'])
 form=load(ROOT/'output/submission-20261101'/ (row['essay_id']+'-form.json'))
 assert metadata['abstract']==form['abstract'] and metadata['tldr']==form['tldr']
latex=load(RUN/'LATEX_DIAGNOSTICS.json')
assert latex['all_six_succeeded'] and len(latex['results'])==6
for row in latex['results']:
 assert row['desktop_compilation']['kind']=='success'
 for source in row['sources']:assert ref(ROOT/source['path'])['sha256']==source['sha256']
build=load(RUN/'BUILD_MANIFEST.json')
assert len(build)==3 and all(r['whitespace_words_excluding_bibliography']<6000 for r in build)
pdf=ROOT/'output/pdf/submission-20261101';tex=ROOT/'output/latex/submission-20261101';forms=ROOT/'output/submission-20261101'
(forms/'README.txt').write_text('''Submission package — revised prose, E050 / E012 / E051

This package supersedes the earlier PDFs. The three essays have been rewritten for clearer, more natural prose and separately checked for preservation of meaning and rigor. E050 has a structured mathematical appendix within the essay PDF and clickable references from the main text. Methodology reports and form abstracts have been updated for this editorial round.

Use three separate OpenReview entries. In each, upload the matching essay PDF to PDF and its methodology PDF to Methodology Report. Do not upload this convenience ZIP as the essay or report. The form text files contain the matching title, abstract, keywords, TL;DR and model disclosures. Personal choices and declarations remain for the submitter.

Deadline: 1 November 2026, 03:59 PST San Francisco / 11:59 UTC.

Each LaTeX folder contains main.tex and body.tex. Compile main.tex from that folder using Tectonic or XeLaTeX and the packages/fonts declared in its preamble. All PDFs are anonymous. No entry has been submitted by this preparation step.
''')
files=sorted(pdf.glob('*.pdf'))+sorted(tex.glob('*/*.tex'))+sorted(forms.glob('*.txt'))+sorted(forms.glob('*.json'))
zpath=ROOT/'output/Submission-Package-E050-E012-E051.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  arc='pdf/'+p.name if p.is_relative_to(pdf) else 'latex/'+str(p.relative_to(tex)) if p.is_relative_to(tex) else 'forms/'+p.name
  z.write(p,arc)
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
supporting=['PDF_QA.json','VISUAL_QA.json','BUILD_MANIFEST.json','APPENDIX_LINKS.json','RENDER_MANIFEST.json','RENDER_CAPTURE_REPAIR.json','LATEX_DIAGNOSTICS.json','repair/E012/FINAL_RECEIPT.json','build_package.py','compile_render.py','check_pdfs.py','close_package.py']
manifest={'status':'PROSE_POLISHED_INDEPENDENTLY_CHECKED_AND_PACKAGED','prepared_at':datetime.now(timezone.utc).isoformat(),'essays':sel['essays'],'artifacts':[ref(p) for p in files]+[ref(zpath)],'qa_and_build':[ref(RUN/n) for n in supporting],'author_receipt':ref(RUN/'AUTHORS_ARCHIVE_RECEIPT.json'),'critic_receipt':ref(RUN/'CRITICS_ARCHIVE_RECEIPT.json'),'original_package':ref(RUN/'prior-package/SNAPSHOT.json'),'submitted':False,'github_updated':False,'limits':'Independent context checks and preserved content/source limits; no proof of novelty or empirical validity.'}
dump(RUN/'READY.json',manifest)
print('Package rebuilt; saving final canonical receipt.',flush=True)
sys.path.insert(0,str(ROOT/'scripts'));from research_archive import Archive
parents=[load(RUN/'CRITICS_ARCHIVE_RECEIPT.json')['event_id']]+sel.get('additional_parent_events',[])
with Archive(ROOT/'research/archive').writer() as w:
 outputs=[w.put(p.read_bytes()) for p in files]
 outputs.extend(w.put((RUN/n).read_bytes()) for n in ['READY.json','SELECTION.json']+supporting)
 outputs.append(w.put(zpath.read_bytes()))
 event=w.append({'kind':'submission.prose.package.accepted','actor':{'id':'codex-prose-editorial-coordinator','role':'assistant'},'session_id':'01a190b5-03e2-70d0-8fcf-b4a1e67148d0','run_id':RUN.name,'operation_id':RUN.name+':final-package','attempt_id':RUN.name+':final-package:1','parents':parents,'outputs':list(dict.fromkeys(outputs)),'payload':manifest},RUN.name+':final-package:v1')
dump(RUN/'FINAL_RECEIPT.json',{'status':manifest['status'],'event_id':event['id'],'event_sequence':event['sequence'],'event_sha256':event['sha256'],'manifest':ref(RUN/'READY.json'),'submitted':False,'github_updated':False})
print('Accepted:',event['id'],flush=True)
