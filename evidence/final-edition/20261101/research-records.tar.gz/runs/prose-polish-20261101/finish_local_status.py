from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent

def load(p):
    return json.loads(p.read_text())

receipt = load(RUN / 'FINAL_RECEIPT.json')
restart = load(RUN / 'operations/COLLECTOR_RESTART_RECEIPT.json')
assert receipt['status'] == 'PROSE_POLISHED_INDEPENDENTLY_CHECKED_AND_PACKAGED'
assert restart['process_confirmed'] and restart['loaded']
event = receipt['event_id']

record = f'''## Язык трёх эссе переработан; PDF обновлены — 2026-11-01

По прямому поручению пользователя E050, E012 и E051 существенно переписаны
для более простого и естественного языка с сохранением строгости. Три свежих
автора Astra/ultra и три отдельных свежих критика завершили работу; все ответы
приняты каноническим архивом. E050/E051 получили READY. В E012 полный отзыв
MINOR_FIXES выявил одну двусмысленную фразу; точное исправление отдельно
получило READY у нового критика. Прежние тексты и все отзывы сохранены.

E050: подробные расчёты находятся в приложении A.1–A.5 внутри того же PDF.
В основном тексте объяснён смысл результатов и даны работающие ссылки.
Приблизительный объём без библиографии, включая приложение:
E050 — 3858, E012 — 4081, E051 — 3110 слов по подсчёту пробельных токенов.
Все 47 страниц шести итоговых PDF просмотрены; текст, ссылки, анонимность,
метаданные и шрифты проверены. Аннотации, отчёты и LaTeX обновлены.

Точные новые рукописи: runs/prose-polish-20261101/SELECTION.json.
Приёмка: runs/prose-polish-20261101/FINAL_RECEIPT.json,
{event}.
Пакет: output/Submission-Package-E050-E012-E051.zip; он заменяет прежний ZIP.
PDF: output/pdf/submission-20261101/; поля: output/submission-20261101/.
Сборщик после временной остановки снова запущен; подтверждён процесс,
не завершение полного нового прохода. Исторические пробелы остаются явными.

Следующий шаг — три отдельные заявки до 1 ноября, 03:59 PST / 11:59 UTC.
Подача только по прямой команде пользователя. На этом этапе подачи,
публикации или обновления GitHub не было. Проверка правок не доказывает
исчерпывающую новизну и не отменяет прежних ограничений источников.
Завершённые роли не повторять. Старые статусы ниже — история.

---

'''

agents = ROOT / 'AGENTS.md'
resume = ROOT / 'knowledge/resume.md'
for p, name in [(agents, 'AGENTS-before-close.md'), (resume, 'resume-before-close.md')]:
    destination = RUN / 'operations' / name
    if not destination.exists():
        destination.write_bytes(p.read_bytes())
current = agents.read_text()
assert not current.startswith(record.splitlines()[0])
agents.write_text(record + current)

summary = f'''## Текущая сводка проекта

Выбор пользователя — E050, E012 и E051. По новому поручению язык всех трёх существенно переработан; в E050 расчёты перенесены в структурированное приложение с ясными ссылками и объяснениями в тексте. Три свежих автора и три отдельных критика Astra/ultra завершили работу. Полные отзывы E050/E051 — READY; единственное замечание к E012 исправлено и отдельно проверено новым критиком. Потери существенного содержания не обнаружены.

- Точные рукописи: runs/prose-polish-20261101/SELECTION.json. Итоговая приёмка: runs/prose-polish-20261101/FINAL_RECEIPT.json, `{event}`.
- Новый пакет: output/Submission-Package-E050-E012-E051.zip. Три PDF эссе, три отчёта, шесть LaTeX-проектов и поля OpenReview обновлены; все 47 страниц проверены.
- Следующий шаг: три отдельные заявки пользователем либо по прямой команде. Дедлайн 1 ноября 2026, 03:59 PST / 11:59 UTC. Подачи здесь не было.
- Сохранены прежние версии, исходный MINOR_FIXES E012 и отдельная узкая проверка исправления. Сборщик снова запущен, процесс подтверждён; завершение полного прохода не заявляется.
- Ограничения источников, моделей и архива сохранены. Проверка правок не устанавливает исчерпывающую новизну, надёжность реальной памяти или полное покрытие журналов. GitHub на этом этапе не обновлялся.

Сводка — производная навигация и не изменяет прежние checkpoint.
'''
text = resume.read_text()
start = text.index('## Текущая сводка проекта')
end = text.index('\n## ', start + 3)
resume.write_text(text[:start] + summary + text[end:])

files = []
for p in [agents, resume]:
    files.append({'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
(RUN / 'operations/LOCAL_CLOSEOUT.json').write_text(json.dumps({
    'status': 'LOCAL_NAVIGATION_UPDATED_AFTER_PACKAGE_ACCEPTANCE_AND_COLLECTOR_RESTART',
    'at': datetime.now(timezone.utc).isoformat(),
    'parent_package_event': event,
    'files': files,
    'canonical_navigation_archive_claimed': False,
    'submitted': False,
    'github_updated': False
}, ensure_ascii=False, indent=2) + '\n')
print('Local status updated; prior navigation preserved.')
