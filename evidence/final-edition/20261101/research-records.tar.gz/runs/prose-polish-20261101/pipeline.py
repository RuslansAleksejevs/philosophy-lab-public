"""Bounded editorial wave; frozen no-tool transport and native validation reused."""
from pathlib import Path
import argparse,concurrent.futures,difflib,hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from research_archive import Archive,_check_event
spec=importlib.util.spec_from_file_location('polish_archive_base',ROOT/'runs/deep-verification-20261031/archive_progress_v4.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
base=B.import_runner(ROOT/'runs/deep-verification-20261031/runner_v4.py',ROOT)
SID='01a190b5-03e2-70d0-8fcf-b4a1e67148d0'
def ref(p):return B.descriptor(p,ROOT)
def load(p):return json.loads(p.read_text())
def new(p,d):p.parent.mkdir(parents=True,exist_ok=True);B.save_new(p,d)
def textnew(p,s):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(s)
def jobs(wave):return load(RUN/f'jobs-{wave}.json')['jobs']
def files_for_wave(wave):
 paths={RUN/'METHOD.json',RUN/'REQUEST.txt',RUN/'prepare.py',RUN/'pipeline.py',RUN/f'jobs-{wave}.json'}
 for j in jobs(wave):
  base.check_inputs(j,ROOT)
  paths.update(ROOT/r['path'] for r in j['inline_inputs'])
  paths.add(ROOT/j['prompt_file']);paths.add(ROOT/j['schema_file'])
 for n in ['runner_v4.py','archive_progress_v4.py','codex_rollout.py','web_transport_v4.py','web_transport_v3.py','web_transport_v2.py']:
  paths.add(ROOT/'runs/deep-verification-20261031'/n)
 return [ref(p) for p in sorted(paths)]
def append(w,kind,key,parents,files,payload,sid=SID):
 outputs=[]
 for row in files:
  raw=B.bound(row,ROOT);B.safe(raw.decode(),row['path']);outputs.append(w.put(raw))
 event=w.append({'kind':kind,'actor':{'id':'codex-prose-editorial-coordinator','role':'assistant'},'session_id':sid,'run_id':RUN.name,'operation_id':RUN.name+':'+key,'attempt_id':RUN.name+':'+key+':1','parents':parents,'outputs':list(dict.fromkeys(outputs)),'payload':{'files':files,**payload}},RUN.name+':'+key)
 return event
def receipt(event):return {'event_id':event['id'],'event_sequence':event['sequence'],'event_sha256':event['sha256'],'status':event['payload']['status'],'files':event['payload']['files'],'roles':event['payload'].get('roles',[])}
def accept_inputs(w,wave,parents):
 fs=files_for_wave(wave);new(RUN/f'{wave.upper()}_INPUT_MANIFEST.json',{'files':fs})
 event=append(w,'research.prose.inputs.accepted',wave+'-inputs',parents,fs,{'status':'PROSE_'+wave.upper()+'_INPUTS_ARCHIVED','wave':wave,'isolation':'Fresh single-essay no-tool sessions; exact inline slices bound; no previous ratings or other essays.'})
 new(RUN/f'{wave.upper()}_START_RECEIPT.json',receipt(event));return event
def gate(wave):
 r=load(RUN/f'{wave.upper()}_START_RECEIPT.json')
 e=load(ROOT/'research/archive/events'/f"{r['event_sequence']:012d}.json");_check_event(e)
 assert e['id']==r['event_id'] and e['sha256']==r['event_sha256']
 assert r['files']==files_for_wave(wave)
 for j in jobs(wave):
  prompt,_=base.check_inputs(j,ROOT)
  for x in j['inline_inputs']:
   raw=B.bound(x,ROOT);assert prompt[x['prompt_byte_start']:x['prompt_byte_start']+x['prompt_byte_length']]==raw
 return r
def dispatch(wave):
 gate(wave);js=jobs(wave)
 assert not any((RUN/'results'/j['id']/'attempt-001').exists() for j in js),'Never overwrite or repeat an attempt'
 d=base.Dispatcher(RUN,ROOT);finished=[]
 base.replace_status(RUN/f'process-{wave}.json',{'status':'RUNNING','started_at':base.now(),'finished':[]})
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futs=[pool.submit(d.run_one,j) for j in js]
  for fut in concurrent.futures.as_completed(futs):
   result=fut.result();finished.append(result);print(json.dumps(result),flush=True)
   base.replace_status(RUN/f'process-{wave}.json',{'status':'RUNNING' if len(finished)<len(js) else 'TERMINAL_LOCAL','finished':finished,'updated_at':base.now()})
 assert all(r['status']==base.COMPLETE for r in finished),finished
def validate_results(wave):
 js={j['id']:j for j in jobs(wave)};ctx={'root':ROOT,'run':RUN,'runner':base,'jobs':js}
 results=[B.validate_terminal(ctx,jid,RUN/'results'/jid/'attempt-001/receipt.json') for jid in js]
 sids=[r['session_id'] for r in results];assert len(set(sids))==len(sids) and SID not in sids
 if wave=='critics':
  old={r['session_id'] for r in load(RUN/'AUTHORS_ARCHIVE_RECEIPT.json')['roles']};assert not(old&set(sids))
 return results
def accept_results(w,wave,results):
 start=gate(wave);roles=[]
 for r in results:
  job=r['job'];jid=job['id'];eid=job['essay_id'];value=r['value'];fs=r['files'][:]
  if wave=='authors':
   assert value['read_complete']
   lane=RUN/'results'/jid/'derived';lane.mkdir(exist_ok=True)
   textnew(lane/'revision.md',value['manuscript_markdown'])
   textnew(lane/'changes.diff',''.join(difflib.unified_diff((RUN/'packets'/eid/'original.md').read_text().splitlines(True),value['manuscript_markdown'].splitlines(True),fromfile='parent.md',tofile='revision.md')))
   new(lane/'abstract.json',{'abstract':value['abstract'],'tldr':value['tldr']})
   fs.extend(ref(lane/n) for n in ['revision.md','changes.diff','abstract.json'])
  ev=append(w,'research.prose.role.accepted','accepted-'+jid,[start['event_id']],fs,{'status':'PROSE_ROLE_ARCHIVED','job_id':jid,'essay_id':eid,'scientific_role':job['scientific_role'],'native_configuration':r['proof'].get('configurations',[]),'independent_native_replay':True,'visible_capture_boundary':'Exact no-tool prompt and visible final bound by the frozen native validator; not hidden reasoning or whole-provider capture.','decision':value.get('decision'),'read_complete':value.get('read_complete',value.get('read_original_complete') and value.get('read_revision_complete'))},r['session_id'])
  role={'job_id':jid,'essay_id':eid,'session_id':r['session_id'],'event_id':ev['id'],'response':ref(r['receipt_path'].parent/'response.json')}
  if wave=='authors':role.update(revision=ref(lane/'revision.md'),diff=ref(lane/'changes.diff'),abstract=ref(lane/'abstract.json'))
  else:role.update(decision=value['decision'])
  roles.append(role)
 ev=append(w,'research.prose.wave.accepted',wave+'-accepted',[start['event_id']]+[r['event_id'] for r in roles],[],{'status':'PROSE_'+wave.upper()+'_ARCHIVED','roles':roles})
 new(RUN/f'{wave.upper()}_ARCHIVE_RECEIPT.json',receipt(ev));return ev
def prepare_critics():
 instruction='''You are a fresh independent checker of one rewritten philosophical essay. You did not write it. Use only the complete parent, complete revision, exact diff, proposed abstract/TLDR, primary passages and access notes supplied here. Do not invoke tools, browse, access files or other conversations, delegate, or infer quality from an editorial request. Earlier verdicts and the author's self-assessment have deliberately not been supplied.

Read both manuscripts completely. Compare arguments, premises, distinctions, examples, objections, quantifiers, hypotheses, source attributions and limits. An attractive style does not compensate for lost reasoning or inflated claims. Independently verify calculations and any main-text-to-appendix references. Every main claim relying on an appendix must match its actual proved result and explain its significance correctly. Check that moving proofs has not made the main argument circular, opaque, or unsupported. Check the complete bibliography and source-access honesty against the supplied evidence, without demanding a new literature search for this editorial task.

Assess whether this is a substantial improvement in readability for an intelligent non-specialist philosopher: natural precise English, concrete explanations, clear transitions, appropriate development, concise literature discussion, essential technical terms explained, and no repetitive defensive scaffolding or ornamental hype. Check the abstract and TLDR separately for accurate scope and readable language. Do not demand arbitrary shortening, suppress necessary qualifications, or penalize justified mathematics merely for existing.

Return READY only if no necessary correction is found. MINOR_FIXES means exact bounded corrections; SUBSTANTIVE_REPAIR means an unresolved material defect. Identify exact locations, evidence, and minimal necessary repairs. Distinguish optional stylistic preferences from required repairs. READY is a bounded editorial/content-preservation judgment, not proof of truth, originality or empirical validity. Return the required JSON only; do not rewrite the essay.'''
 textnew(RUN/'CRITIC_INSTRUCTIONS.txt',instruction)
 js=[]
 for row in load(RUN/'AUTHORS_ARCHIVE_RECEIPT.json')['roles']:
  eid=row['essay_id'];lane=RUN/'packets'/eid;rev=ROOT/row['revision']['path']
  expected={'job_id':eid+'-critic','essay_id':eid,'scientific_role':'critic','manuscript_sha256':ref(rev)['sha256']}
  prompt=('Read only these supplied materials. No tools. Return only JSON.\nExact output identity: '+json.dumps(expected)+'\n').encode();inline=[]
  paths=[('CHECKING INSTRUCTIONS',RUN/'CRITIC_INSTRUCTIONS.txt'),('ORIGINAL',lane/'original.md'),('REVISION',rev),('EXACT DIFF',ROOT/row['diff']['path']),('PROPOSED ABSTRACT AND TLDR',ROOT/row['abstract']['path']),('PRIMARY PASSAGES',lane/'sources/PRIMARY_PASSAGES.txt'),('SOURCE ACCESS NOTES',lane/'sources/SOURCE_ACCESS_NOTES.txt'),('REQUIRED SCHEMA',RUN/'schema/critic.json')]
  for label,p in paths:
   raw=p.read_bytes();prompt+=('\n----- BEGIN '+label+' -----\n').encode();pos=len(prompt);prompt+=raw
   inline.append({**ref(p),'prompt_byte_start':pos,'prompt_byte_length':len(raw)})
   if label=='REVISION':start=pos
   prompt+=('\n----- END '+label+' -----\n').encode()
  pp=lane/'critic/prompt.txt';textnew(pp,prompt.decode())
  js.append({'id':eid+'-critic','essay_id':eid,'scientific_role':'critic','role':'argument','transport_profile':'no_tools','web_search':'disabled','model':'gpt-6-astra','effort':'ultra','service_tier':'default','manuscript_id':eid,'manuscript_file':str(rev.relative_to(ROOT)),'manuscript_sha256':ref(rev)['sha256'],'manuscript_byte_start':start,'manuscript_byte_length':len(rev.read_bytes()),'prompt_file':str(pp.relative_to(ROOT)),'prompt_sha256':ref(pp)['sha256'],'schema_file':str((RUN/'schema/critic.json').relative_to(ROOT)),'schema_sha256':ref(RUN/'schema/critic.json')['sha256'],'expected_output':expected,'inline_inputs':inline})
 new(RUN/'jobs-critics.json',{'run_id':RUN.name,'wave':'critics','jobs':js})
def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
 if a.check:
  fs=files_for_wave('authors')
  for j in jobs('authors'):
   b,_=base.check_inputs(j,ROOT)
   for x in j['inline_inputs']:assert b[x['prompt_byte_start']:x['prompt_byte_start']+x['prompt_byte_length']]==B.bound(x,ROOT)
  print('Input hashes, exact inline slices and frozen transport preflight passed:',len(fs),'files. No model calls.');return
 with Archive(ROOT/'research/archive').writer() as w:
  accept_inputs(w,'authors',['event-e6a96dde07564cfa99fd6e6bd60918dc','event-b128f1d1e189481895259d240c92e717'])
 print('Author inputs canonically accepted; launching three fresh editors.',flush=True)
 dispatch('authors');results=validate_results('authors')
 with Archive(ROOT/'research/archive').writer() as w:
  ae=accept_results(w,'authors',results)
  prepare_critics();accept_inputs(w,'critics',[ae['id']])
 print('Revisions and checker inputs canonically accepted; launching three fresh checks.',flush=True)
 dispatch('critics');results=validate_results('critics')
 with Archive(ROOT/'research/archive').writer() as w:
  accept_results(w,'critics',results)
 print('All six roles archived. Inspect decisions before selecting or packaging.',flush=True)
if __name__=='__main__':main()
