"""One fresh no-tools grammar checker; unchanged frozen V4 CLI/native transport."""
from pathlib import Path
import argparse
import fcntl
import importlib.util
import json
spec=importlib.util.spec_from_file_location('grammar_gate',Path(__file__).with_name('grammar.py'))
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)

def run():
    with (M.G/'dispatch.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        ctx=M.gate();dispatcher=M.C.base.Dispatcher(M.G,M.ROOT)
        M.B.require(not list(M.RUN.glob('STOP*.json')) and not dispatcher.stopped(),'Preserved STOP blocks checker dispatch')
        M.B.require(not (M.G/'results'/M.JOB/'attempt-001').exists(),'Never relaunch an existing grammar attempt')
        result=dispatcher.run_one(ctx['jobs'][M.JOB]);print(json.dumps(result),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
    if a.check:M.gate();print(json.dumps({'status':'CANONICAL_GRAMMAR_GATE_PASS','provider_calls':0}))
    else:run()
