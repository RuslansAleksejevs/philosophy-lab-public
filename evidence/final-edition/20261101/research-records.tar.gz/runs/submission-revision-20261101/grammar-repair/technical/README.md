# One exact grammar correction and one fresh check

The accepted E050 full critique remains MINOR_FIXES with its single F1 finding.
The AI coordinator changed exactly one known sentence: subject–verb agreement
and placement of the section locator. EDIT.json, the unchanged accepted before
manuscript, corrected manuscript and exact diff are bound. No other byte may
change. This is a descendant revision, never a rewrite of an old artifact or
verdict. E012/E051 and the previous 112/156 inputs and closure remain unchanged.

Root's exact visible correction call/result are native lines 36124/36127, with
reviewed hashes in CAPTURE_SELECTION.json. Input acceptance first binds this
implementation and packet, then captures those two visible records, registers
the AI correction and revision lineage, and accepts the new checker inputs.
Every actual action uses the ordinary audited writer; no checkpoint/derived
refresh is performed here.

The one fresh Astra/ultra/Standard checker receives only neutral instructions,
complete accepted before and corrected after manuscripts, the exact diff and
JSON schema. It receives no old verdict, author self-assessment or other essay.
Its CLI, isolation, native replay and terminal validation are unchanged V4.
The canonical role is grammar_checker; argument denotes the old no-tools
transport profile only. Its session must differ from root and all six roles.

Root commands, in order:

```sh
python3 -B runs/submission-revision-20261101/grammar-repair/technical/grammar.py inputs --check
python3 -B runs/submission-revision-20261101/grammar-repair/technical/grammar.py inputs --apply
python3 -B runs/submission-revision-20261101/grammar-repair/technical/runner.py --check
python3 -B runs/submission-revision-20261101/grammar-repair/technical/runner.py
python3 -B runs/submission-revision-20261101/grammar-repair/technical/grammar.py result --check
python3 -B runs/submission-revision-20261101/grammar-repair/technical/grammar.py result --apply
```

START_RECEIPT.json and ARCHIVE_RECEIPT.json are in grammar-repair. A NOT_READY
report is preserved and accepted as a report but cannot authorize final closure.
READY requires full before/after/diff reading, only the intended change,
preserved meaning, correct grammar and no remaining finding. It certifies only
EXACT_GRAMMAR_CHANGE_ONLY, never a new whole-paper or novelty verdict.

Additive closure may call `ctx=grammar.gate()` and
`grammar.validate_accepted(ctx, writer, require_ready=True)` under its already
audited writer. That read-only function verifies canonical objects, both
lineages and the scoped decision; it performs no capture, put, append, provider
or fresh native replay. Keep the original full MINOR_FIXES verdict separately.

Tests use temporary synthetic files and mocked boundaries only:

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/grammar-repair/technical -p 'test_*.py' -q
```
