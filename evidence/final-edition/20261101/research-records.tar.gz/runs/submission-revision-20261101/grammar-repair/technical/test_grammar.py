"""Exact-change and isolated-role fixtures only; no provider or canonical writes."""
from pathlib import Path
import copy
import difflib
import importlib.util
import tempfile
import unittest
from unittest.mock import Mock,patch

spec=importlib.util.spec_from_file_location('grammar_tested',Path(__file__).with_name('grammar.py'))
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)

class Grammar(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.temp.name)
        self.before=('Synthetic beginning.\n'+M.OLD+'\nSynthetic end.\n').encode()
        self.after=self.before.replace(M.OLD.encode(),M.NEW.encode())
        self.source=self.root/'before.md';self.source.write_bytes(self.before)
        self.fixed=self.root/'after.md';self.fixed.write_bytes(self.after)
        self.diff=self.root/'changes.diff';self.diff.write_bytes(''.join(difflib.unified_diff(self.before.decode().splitlines(keepends=True),self.after.decode().splitlines(keepends=True),fromfile='E050-author-accepted',tofile='E050-grammar-corrected')).encode())
        self.edit={'essay_id':'E050','coordinator_session_id':M.C.SID,'source':M.B.descriptor(self.source,self.root),'corrected':M.B.descriptor(self.fixed,self.root),
            'diff':M.B.descriptor(self.diff,self.root),'old_utf8':M.OLD,'new_utf8':M.NEW,'replacement_count':1,'scientific_content_changed':False,
            'other_bytes_unchanged':True,'old_verdict_preserved':True,'finding_id':'F1'}
        self.pins=patch.multiple(M,SOURCE_SHA=self.edit['source']['sha256'],FIXED_SHA=self.edit['corrected']['sha256']);self.pins.start()
    def tearDown(self):self.pins.stop();self.temp.cleanup()
    def test_exact_literal_replacement_and_diff(self):M.exact_edit(self.edit,self.root)
    def test_other_byte_change_rejected_even_when_descriptor_updated(self):
        self.fixed.write_bytes(self.after+b'extra');self.edit['corrected']=M.B.descriptor(self.fixed,self.root)
        with patch.object(M,'FIXED_SHA',self.edit['corrected']['sha256']),self.assertRaisesRegex(ValueError,'exact accepted'):M.exact_edit(self.edit,self.root)
    def test_repeated_old_sentence_rejected(self):
        self.source.write_bytes(self.before+M.OLD.encode());self.edit['source']=M.B.descriptor(self.source,self.root)
        with patch.object(M,'SOURCE_SHA',self.edit['source']['sha256']),self.assertRaisesRegex(ValueError,'exact accepted'):M.exact_edit(self.edit,self.root)
    def test_false_diff_rejected(self):
        self.diff.write_text('fake');self.edit['diff']=M.B.descriptor(self.diff,self.root)
        with self.assertRaisesRegex(ValueError,'mechanical'):M.exact_edit(self.edit,self.root)
    def test_source_symlink_rejected(self):
        other=self.root/'preserved.md';self.source.rename(other);self.source.symlink_to(other)
        with self.assertRaises(ValueError):M.exact_edit(self.edit,self.root)
    def test_ready_is_strict_and_only_scoped(self):
        value={'decision':'READY','scope':M.SCOPE,'findings':[]}
        for k in ('read_before_complete','read_after_complete','read_diff_complete','only_intended_change','meaning_preserved','grammar_correct'):value[k]=True
        self.assertTrue(M.ready(value))
        for field,bad in (('scope','WHOLE_PAPER_READY'),('read_before_complete',False),('grammar_correct',1),('findings',['Unresolved issue']),('decision','NOT_READY')):
            modified=dict(value);modified[field]=bad;self.assertFalse(M.ready(modified))
    def test_reused_scientific_session_rejected_before_capture(self):
        ctx={'root':self.root,'run':self.root,'start':{'event_id':'input'},'files':[{'synthetic':True}]}
        event={'kind':M.INPUT_KIND,'payload':{'files':ctx['files']}}
        with patch.object(M,'canonical_previous',return_value={'sids':{'old-reviewer'}}),patch.object(M.B,'canonical_event',return_value=event),patch.object(M.B,'verify_event_files'),patch.object(M.B,'capture') as capture:
            with self.assertRaisesRegex(ValueError,'fresh'):M.accept_result(ctx,Mock(),{'session_id':'old-reviewer'})
            capture.assert_not_called()
    def test_original_terminal_inventory_has_no_silent_extra(self):
        g=self.root/'grammar-repair';attempt=g/'results'/M.JOB/'attempt-001';attempt.mkdir(parents=True)
        (attempt/'receipt.json').write_text('{}');(attempt/'response.json').write_text('{}');(attempt/'extra.txt').write_text('unbound')
        result={'receipt_path':attempt/'receipt.json','receipt':{'outputs':{str((attempt/'response.json').relative_to(self.root)):M.B.sha(b'{}')}},'web':[]}
        with patch.object(M.B,'validate_terminal',return_value=result),self.assertRaisesRegex(ValueError,'Exact original'):
            M.terminal({'root':self.root,'run':self.root,'grammar':g})

if __name__=='__main__':unittest.main()
