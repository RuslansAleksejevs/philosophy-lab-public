"""Exact one-sentence AI grammar correction and one fresh independent check."""
from pathlib import Path
import argparse
import difflib
import importlib.util
import json

LANE=Path(__file__).resolve().parent;G=LANE.parent;RUN=G.parent;ROOT=RUN.parents[1]
spec=importlib.util.spec_from_file_location('grammar_parent_acceptance',RUN/'technical/archive_v2.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A);C=A.C;B=C.B;L=A.L
JOB='E050-grammar-check';SCOPE='EXACT_GRAMMAR_CHANGE_ONLY'
SOURCE_SHA='8c50e9c8e0973bd1383be050b7be6acb762f8e476b8731c457d52c813dd65ff3'
FIXED_SHA='451823414dc95441657d7b0b8fccf1e415823f3f55d1cb6efdee7f4f5a770eaa'
OLD='In the cited arXiv:1708.00232v1 preprint of their 2018 article, §III.B, Propositions 4–5 (pp. 3–4), relies on assumptions A1–A5 and monotonicity with respect to parameter changes as well as states and inputs.'
NEW='In the cited arXiv:1708.00232v1 preprint of their 2018 article, Propositions 4–5 in §III.B (pp. 3–4) rely on assumptions A1–A5 and monotonicity with respect to parameter changes as well as states and inputs.'
INPUT_KIND='research.revision.grammar.inputs.accepted';RESULT_KIND='research.revision.grammar.check.accepted'

def exact_edit(edit,root):
    before=B.bound(edit['source'],root);after=B.bound(edit['corrected'],root)
    B.require(edit.get('essay_id')=='E050' and edit.get('coordinator_session_id')==C.SID
        and edit['source']['sha256']==SOURCE_SHA and edit['corrected']['sha256']==FIXED_SHA
        and edit.get('old_utf8')==OLD and edit.get('new_utf8')==NEW and edit.get('replacement_count')==1
        and before.count(OLD.encode())==1 and before.replace(OLD.encode(),NEW.encode(),1)==after,
        'Only the exact accepted E050 sentence replacement is permitted')
    diff=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),
        fromfile='E050-author-accepted',tofile='E050-grammar-corrected')).encode()
    B.require(B.bound(edit['diff'],root)==diff,'Exact mechanical grammar diff required')
    B.require(edit.get('scientific_content_changed') is False and edit.get('other_bytes_unchanged') is True
        and edit.get('old_verdict_preserved') is True and edit.get('finding_id')=='F1','Grammar scope declaration differs')

def setup(root=ROOT,run=RUN):
    g=run/'grammar-repair';parent=C.gate('critics',run,root)
    ref=B.descriptor(g/'INPUT_MANIFEST.json',root);manifest=B.strict_json(C.safe_file(ref,root));rows=manifest['files']
    indexed={r['path']:r for r in rows}
    B.require(len(indexed)==len(rows) and ref['path'] not in indexed,'Duplicate grammar input')
    B.require(all(indexed.get(r['path'])==r for r in parent['files']),'Preserved critic inputs must remain exact')
    for row in rows:C.safe_file(row,root)
    required=[g/n for n in ('EDIT.json','E050-corrected.md','changes.diff','CAPTURE_SELECTION.json','job.json','prompt.txt','schema.json','INSTRUCTIONS.txt','technical/grammar.py','technical/runner.py','technical/test_grammar.py','technical/README.md')]
    required += [run/n for n in ('AUTHORS_ARCHIVE_RECEIPT.json','CRITICS_ARCHIVE_RECEIPT.json','results/E050-author/ARCHIVE_RECEIPT.json','results/E050-critic/ARCHIVE_RECEIPT.json')]
    B.require(all(str(p.relative_to(root)) in indexed for p in required),'Grammar dependency not input-bound')
    edit=B.load(g/'EDIT.json',root);exact_edit(edit,root)
    for key,name in (('source','results/E050-author/derived/revision.md'),('corrected','grammar-repair/E050-corrected.md'),('diff','grammar-repair/changes.diff'),('prior_critic_response','results/E050-critic/attempt-001/response.json')):
        B.require(edit[key]['path']==str((run/name).relative_to(root)) and indexed.get(edit[key]['path'])==edit[key],'Exact correction/source path required')
    job=B.load(g/'job.json',root);prompt,_=C.base.check_inputs(job,root)
    B.require(job.get('id')==JOB and job.get('essay_id')=='E050' and job.get('scientific_role')=='grammar_checker'
        and job.get('transport_profile')=='no_tools' and job.get('role')=='argument' and job.get('web_search')=='disabled',
        'Exactly one fresh no-tool grammar checker required')
    expected={'job_id':JOB,'essay_id':'E050','scientific_role':'grammar_checker','manuscript_sha256':FIXED_SHA,'scope':SCOPE}
    B.require(job.get('expected_output')==expected and job.get('manuscript_file')==edit['corrected']['path']
        and job.get('manuscript_sha256')==FIXED_SHA,'Checker must target exact corrected bytes')
    allowed=[g/'INSTRUCTIONS.txt',root/edit['source']['path'],g/'E050-corrected.md',g/'changes.diff',g/'schema.json']
    inline=job.get('inline_inputs',[]);B.require(len(inline)==5 and [r['path'] for r in inline]==[str(p.relative_to(root)) for p in allowed],
        'Checker receives only neutral instructions, full before/after, diff and schema')
    ranges=[]
    for row in inline:
        r={k:row[k] for k in ('path','sha256','bytes')};raw=B.bound(r,root);a=row['prompt_byte_start'];length=row['prompt_byte_length']
        B.require(indexed.get(r['path'])==r and type(a) is int and a>=0 and type(length) is int and length==len(raw)
            and prompt[a:a+length]==raw,'Checker inline bytes differ');ranges.append((a,a+length))
    B.require(all(a[1]<=b[0] for a,b in zip(ranges,ranges[1:])),'Checker inline ranges overlap')
    for key in ('prompt','schema'):B.require(indexed.get(job[key+'_file'],{}).get('sha256')==job[key+'_sha256'],'Unbound checker prompt/schema')
    waves={wave:B.load(run/(wave.upper()+'_ARCHIVE_RECEIPT.json'),root) for wave in ('authors','critics')}
    for wave,receipt in waves.items():
        e=C.direct_event(receipt,root)
        B.require(receipt['status']=='SUBMISSION_'+wave.upper()+'_ARCHIVED' and e['run_id']==run.name
            and e['payload'].get('roles')==receipt['roles'] and len(receipt['roles'])==3,'Exact accepted prior wave required')
    return dict(parent,grammar=g,edit=edit,waves=waves,jobs={JOB:job},runner=C.base,manifest=manifest,manifest_ref=ref,
        indexed=indexed,files=rows+[ref])

def canonical_previous(ctx,w):
    data,events,known=A.canonical_bases(ctx,w);roles={};sids={C.SID}
    for wave,receipt in ctx['waves'].items():
        e=events.get(receipt['event_id'])
        B.require(e is not None and e['sequence']==receipt['event_sequence'] and e['sha256']==receipt['event_sha256']
            and e['kind']=='research.revision.wave.accepted' and e['payload']['roles']==receipt['roles'],'Canonical prior wave differs')
        for item in receipt['roles']:
            ev=events.get(item['event_id']);B.require(ev is not None and ev['id'] in e['parents'] and ev['session_id']==item['session_id']
                and ev['payload'].get('scientific_role')==item['scientific_role'],'Prior accepted role differs')
            sids.add(item['session_id']);roles[item['job_id']]=item
            if item['essay_id']=='E050':B.verify_event_files(ctx,w,ev)
    author,critic=roles['E050-author'],roles['E050-critic'];edit=ctx['edit']
    B.require(author['revision']==edit['source'] and critic['event_id']==edit['prior_critic_event_id'],'Correction must follow exact accepted author and critic')
    raw=B.bound(edit['prior_critic_response'],ctx['root']);B.require(w.get(edit['prior_critic_response']['sha256'])==raw,'Accepted full critique bytes differ')
    value=B.strict_json(raw)
    B.require(value.get('decision')=='MINOR_FIXES' and value.get('manuscript_sha256')==SOURCE_SHA
        and len(value.get('findings',[]))==1 and value['findings'][0].get('id')=='F1' and value['findings'][0].get('severity')=='minor',
        'Only the recorded single minor grammar finding is repaired')
    B.require(author['lineage_entry_id'] in known and known[author['lineage_entry_id']]['id']==author['lineage_event_id'],
        'Accepted author lineage missing')
    return {'events':events,'known':known,'author':author,'critic':critic,'sids':sids,'entity':data['essays']['E050']['entity']}

def local_receipt(event,**extra):return dict(C.event_receipt(event),**extra)

def accept_inputs(ctx,w):
    old=canonical_previous(ctx,w);key=ctx['run'].name+':grammar:inputs:v1';prior=B.existing(w,key)
    if prior:
        B.require(prior['kind']==INPUT_KIND and prior['payload']['files']==ctx['files'],'Grammar input retry differs')
        B.verify_event_files(ctx,w,prior);receipt=local_receipt(prior,**prior['payload']['correction'])
        B.save_new(ctx['grammar']/'START_RECEIPT.json',receipt);return receipt
    A.store(ctx,w,ctx['files'])
    intake=w.append(B.request(ctx,'research.revision.grammar.inputs.bound',C.SID,'grammar-intake',
        [ctx['start']['event_id'],ctx['waves']['critics']['event_id']],ctx['files'],
        {'status':'E050_GRAMMAR_INPUTS_BOUND','files':ctx['files']}),ctx['run'].name+':grammar:intake:v1')
    selection=B.load(ctx['grammar']/'CAPTURE_SELECTION.json',ctx['root'])
    B.require(selection['session_id']==C.SID and selection['reviewed_tool_lines']==[36124,36127]
        and selection['start_line']==36124 and selection['end_line']==36127 and selection['max_bytes']==512*1024*1024,
        'Exact AI correction call/result selection required')
    cap=B.capture(ctx['root']/'research/archive',B.resolve_session(C.SID,ctx['root']),C.SID,ctx['root'],
        start_line=36124,end_line=36127,reviewed_tool_lines=[36124,36127],max_bytes=512*1024*1024,
        run_id=ctx['run'].name,archive_writer=B.SessionWriter(w,C.SID,ctx['run'].name))
    B.require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==2 and len(cap['tool_link_ids'])==1
        and {r['source_line']:r['sha256'] for r in cap['raw_records']}=={r['source_line']:r['sha256'] for r in selection['raw_records']},
        'Exact visible AI edit provenance differs')
    edit=ctx['edit'];files=[B.descriptor(ctx['grammar']/'EDIT.json',ctx['root']),edit['corrected'],edit['diff']]
    correction=w.append(B.request(ctx,'research.revision.grammar.corrected',C.SID,'grammar-correction',
        [intake['id'],old['author']['event_id'],old['critic']['event_id'],cap['coverage_event_id']],files,
        {'status':'EXACT_AI_GRAMMAR_CORRECTION_ARCHIVED','files':files,'old_verdict':'MINOR_FIXES','scope':SCOPE,
         'raw_event_ids':cap['raw_event_ids'],'coverage_event_id':cap['coverage_event_id']}),ctx['run'].name+':grammar:corrected:v1')
    events={e['id']:e for e in w._state['records']};known=L.index(events.values())
    entry=L.base_entry(ctx['run'].name+':E050:grammar-correction:v1',old['entity'],'revision','Exact AI coordinator subject–verb and citation-placement repair; other bytes unchanged.')
    entry.update(parents=[old['author']['lineage_entry_id']],artifacts=[dict(edit['corrected'],role='grammar_corrected_manuscript')],
        evidence=[correction['id'],old['critic']['event_id']],actor={'role':'AI','session_id':C.SID},
        workflow={'run_id':ctx['run'].name,'essay_id':'E050','stage':'grammar_correction'},gaps=['Full critic MINOR_FIXES preserved; independent scoped check is pending.'])
    lev=L.append(w,entry,C.SID,known,events)
    details={'corrected_revision':edit['corrected'],'original_revision':edit['source'],'diff':edit['diff'],
        'old_full_critic':edit['prior_critic_response'],'old_full_critic_event_id':old['critic']['event_id'],
        'correction_event_id':correction['id'],'correction_lineage_entry_id':entry['id'],'correction_lineage_event_id':lev['id']}
    event=w.append(B.request(ctx,INPUT_KIND,C.SID,'grammar-inputs',[intake['id'],correction['id'],lev['id'],ctx['waves']['critics']['event_id']],ctx['files'],
        {'status':'E050_GRAMMAR_INPUTS_ARCHIVED','files':ctx['files'],'correction':details,'job_id':JOB,'scope':SCOPE,'scientific_role':'grammar_checker'}),key)
    receipt=local_receipt(event,**details);B.save_new(ctx['grammar']/'START_RECEIPT.json',receipt);return receipt

def gate(root=ROOT,run=RUN):
    ctx=setup(root,run);receipt=B.load(ctx['grammar']/'START_RECEIPT.json',root);event=C.direct_event(receipt,root)
    B.require(event['kind']==INPUT_KIND and event['run_id']==run.name and receipt['status']=='E050_GRAMMAR_INPUTS_ARCHIVED'
        and event['payload']['files']==ctx['files'] and receipt['files']==ctx['files']
        and event['bindings']==receipt['bindings']
        and all(receipt.get(k)==v for k,v in event['payload']['correction'].items()),'Exact canonical grammar input gate required')
    ctx['start']=receipt;return ctx

def terminal(ctx):
    result=B.validate_terminal(dict(ctx,run=ctx['grammar']),JOB,ctx['grammar']/'results'/JOB/'attempt-001/receipt.json')
    p=result['receipt_path'];actual={str(x.relative_to(ctx['root'])):B.sha(B.read(x,ctx['root'])) for x in p.parent.iterdir() if x.name!='receipt.json'}
    B.require(not result['web'] and not result['receipt'].get('disposition') and result['receipt']['outputs']==actual,'Exact original no-tool checker terminal required')
    B.require(all(result['value'].get(k)==v for k,v in ctx['jobs'][JOB]['expected_output'].items()),'Checker output identity/scope differs')
    return result

def ready(value):
    return value.get('decision')=='READY' and value.get('scope')==SCOPE and value.get('findings')==[] and all(value.get(k) is True for k in
        ('read_before_complete','read_after_complete','read_diff_complete','only_intended_change','meaning_preserved','grammar_correct'))

def accept_result(ctx,w,result):
    old=canonical_previous(ctx,w);first=B.canonical_event(w,ctx['start']['event_id'])
    B.require(first['kind']==INPUT_KIND and first['payload']['files']==ctx['files'],'Canonical grammar inputs differ');B.verify_event_files(ctx,w,first)
    B.require(result['session_id'] not in old['sids'],'Grammar checker must be fresh relative to all six roles and root')
    key=ctx['run'].name+':grammar:checker:v1';event=B.existing(w,key);files=result['files']
    if event:
        B.require(event['kind']==RESULT_KIND and event['payload']['files']==files and event['session_id']==result['session_id'],'Checker retry differs')
        B.verify_event_files(ctx,w,event)
    else:
        caps=[];sid=result['session_id'];source=B.resolve_session(sid,ctx['root']);scope=B.SessionWriter(w,sid,ctx['run'].name)
        for msg in result['messages']:
            cap=B.capture(ctx['root']/'research/archive',source,sid,ctx['root'],start_line=msg['line'],end_line=msg['line'],run_id=ctx['run'].name,archive_writer=scope)
            B.require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==1 and cap['raw_records'][0]['sha256']==msg['record_sha256'],'Checker visible capture differs');caps.append(cap['coverage_event_id'])
        A.store(ctx,w,files)
        event=w.append(B.request(ctx,RESULT_KIND,sid,JOB,[first['id'],ctx['start']['correction_lineage_event_id']]+caps,files,
            {'status':'E050_GRAMMAR_CHECK_ARCHIVED','files':files,'job_id':JOB,'scientific_role':'grammar_checker','transport_role':'argument',
             'transport_profile':'no_tools','scope':SCOPE,'checker_report':B.descriptor(result['receipt_path'].parent/'response.json',ctx['root']),
             'terminal_receipt':B.descriptor(result['receipt_path'],ctx['root']),'stdout_boundary':result['stdout_boundary'],
             'capture_event_ids':caps,'full_critic_verdict_preserved':'MINOR_FIXES','ready_for_exact_change':ready(result['value'])}),key)
    events={e['id']:e for e in w._state['records']};known=L.index(events.values());ident=ctx['run'].name+':E050:grammar-check:v1'
    line=L.base_entry(ident,old['entity'],'critique','Fresh independent check of the exact local grammar change; no repeat of the full scientific critique.')
    line.update(parents=[ctx['start']['correction_lineage_entry_id']],artifacts=[dict(event['payload']['checker_report'],role='scoped_grammar_critique')],
        evidence=[event['id']],actor={'role':'AI','session_id':result['session_id']},workflow={'run_id':ctx['run'].name,'essay_id':'E050','job_id':JOB,'scope':SCOPE},
        gaps=['Scope is grammar, exact diff and preservation of meaning; no new full-paper or novelty verdict.'])
    lev=L.append(w,line,result['session_id'],known,events)
    details={k:ctx['start'][k] for k in ('corrected_revision','original_revision','diff','old_full_critic','old_full_critic_event_id','correction_event_id','correction_lineage_entry_id','correction_lineage_event_id')}
    receipt=local_receipt(event,**details,checker_report=event['payload']['checker_report'],checker_session_id=result['session_id'],
        checker_lineage_entry_id=ident,checker_lineage_event_id=lev['id'],scope=SCOPE,ready_for_exact_change=event['payload']['ready_for_exact_change'])
    B.save_new(ctx['grammar']/'ARCHIVE_RECEIPT.json',receipt);return receipt

def validate_accepted(ctx,w,require_ready=True):
    old=canonical_previous(ctx,w);receipt=B.load(ctx['grammar']/'ARCHIVE_RECEIPT.json',ctx['root']);event=B.canonical_event(w,receipt['event_id'])
    first=B.canonical_event(w,ctx['start']['event_id'])
    B.require(first['kind']==INPUT_KIND and first['payload']['files']==ctx['files'] and first['bindings']==ctx['start']['bindings'],
        'Canonical grammar input binding differs');B.verify_event_files(ctx,w,first)
    B.require(event['kind']==RESULT_KIND and event['sequence']==receipt['event_sequence'] and event['sha256']==receipt['event_sha256']
        and event['run_id']==ctx['run'].name and event['session_id']==receipt['checker_session_id'] and event['session_id'] not in old['sids']
        and ctx['start']['event_id'] in event['parents'] and event['payload']['checker_report']==receipt['checker_report']
        and event['payload']['files']==receipt['files'] and event['bindings']==receipt['bindings']==first['bindings']
        and event['payload']['status']==receipt['status']=='E050_GRAMMAR_CHECK_ARCHIVED'
        and event['payload']['scientific_role']=='grammar_checker' and event['payload']['scope']==receipt.get('scope')==SCOPE,
        'Canonical scoped checker differs')
    B.verify_event_files(ctx,w,event)
    for k in ('corrected_revision','original_revision','diff','old_full_critic','old_full_critic_event_id','correction_event_id','correction_lineage_entry_id','correction_lineage_event_id'):
        B.require(receipt.get(k)==ctx['start'].get(k),'Correction receipt linkage differs')
    known=old['known'];correction=known.get(receipt['correction_lineage_entry_id']);line=known.get(receipt['checker_lineage_entry_id'])
    B.require(correction is not None and correction['id']==receipt['correction_lineage_event_id']
        and receipt['correction_event_id'] in correction['parents']
        and correction['payload']['entry']['parents']==[old['author']['lineage_entry_id']]
        and any(x['sha256']==FIXED_SHA for x in correction['payload']['entry']['artifacts']),
        'Exact corrected revision lineage differs')
    B.require(line is not None and line['id']==receipt['checker_lineage_event_id'] and event['id'] in line['parents']
        and line['payload']['entry']['parents']==[receipt['correction_lineage_entry_id']]
        and line['payload']['entry']['actor']['session_id']==receipt['checker_session_id']
        and any(x['sha256']==receipt['checker_report']['sha256'] for x in line['payload']['entry']['artifacts']),
        'Scoped critique lineage differs')
    value=B.strict_json(B.bound(receipt['checker_report'],ctx['root']));C.base.validate(value,B.load(ctx['jobs'][JOB]['schema_file'],ctx['root']))
    B.require(all(value.get(k)==v for k,v in ctx['jobs'][JOB]['expected_output'].items()) and ready(value)==receipt['ready_for_exact_change']
        and ready(value)==event['payload']['ready_for_exact_change'],'Accepted checker decision consistency differs')
    if require_ready:B.require(ready(value),'Scoped grammar change is not READY')
    return {'input_event':first,'result_event':event,'receipt':receipt,'value':value,'old_full_critic':old['critic']}

def prepare(mode,root=ROOT,run=RUN):
    ctx=setup(root,run) if mode=='inputs' else gate(root,run)
    return ctx,None if mode=='inputs' else terminal(ctx)

def finish(mode,ctx,w,result=None):
    w._ensure_audited();ctx,result=prepare(mode,ctx['root'],ctx['run'])
    return accept_inputs(ctx,w) if mode=='inputs' else accept_result(ctx,w,result)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('inputs','result'));p.add_argument('--apply',action='store_true');p.add_argument('--check',action='store_true');args=p.parse_args()
    B.require(not(args.apply and args.check),'Choose check or apply');ctx,result=prepare(args.mode)
    if args.apply:
        with B.Archive(ROOT/'research/archive').writer() as w:answer=finish(args.mode,ctx,w,result)
        print(json.dumps(answer))
    else:print(json.dumps({'status':'GRAMMAR_READ_ONLY_PREFLIGHT_PASS','mode':args.mode,'archive_writes':0,'provider_calls':0}))
