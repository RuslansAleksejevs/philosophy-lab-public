#!/usr/bin/env python3
"""Interpret one exact accepted grammar READY response with three positive observations."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
LANE=Path(__file__).resolve().parent;RUN=LANE.parent;ROOT=RUN.parents[1]
PINS={'common_v2.py':'be5181a8fc4266a9eb1cd091c71b8ad303df7cff2e5b563cb328467b8374e712',
      'archive_v2.py':'55a2ded61d831754c78e9526cb22e77513e366883882a60853dfde78b968366c'}
for name,digest in PINS.items():
    if hashlib.sha256((RUN/'technical'/name).read_bytes()).hexdigest()!=digest:
        raise ValueError('Frozen technical implementation changed: '+name)
spec=importlib.util.spec_from_file_location('revision_closure_archive',RUN/'technical/archive_v2.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A);C=A.C;B=C.B;L=A.L
from philosophy_round import checkpoint
ORIGINAL_CLOSURE_SHA='20f813e8058d601f5dddccf320d351610cc5df4a89be10063f1a33e5ceaf0bfc'
B.require(B.sha((RUN/'closure/close_revisions.py').read_bytes())==ORIGINAL_CLOSURE_SHA,'Frozen original closure changed')
B.require(B.sha((RUN/'closure-grammar/close_revisions.py').read_bytes())=='429c8d74ee0ac64eb878226bc38d3fc821c04dc8d82f5f4cf4df7dda923701c1','Frozen grammar closure changed')
GRAMMAR_SOURCE_SHA='d6d26e6a58db33c3e0e435aae3e2e32cf99b2328802bdca854b8fd010221c1b7'
B.require(B.sha((RUN/'grammar-repair/technical/grammar.py').read_bytes())==GRAMMAR_SOURCE_SHA,'Grammar adapter changed')
spec=importlib.util.spec_from_file_location('revision_closure_grammar',RUN/'grammar-repair/technical/grammar.py')
G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)

SELECTED=['E050','E012','E051']
ARTIFACTS={'decisions':'DECISIONS.json','summary':'CHANGE_SUMMARY_RU.md','word_counts':'WORD_COUNTS.json',
           'source_ledger':'SOURCE_LEDGER.json','checkpoint':'CHECKPOINT.json'}
FIELDS=('question','outcome','contribution','criticism','limitations','next_step','method_change','comparability','coverage_boundary')
STATUS='SUBMISSION_REVISIONS_VERIFIED_BOUNDED'
KEY='content-closure-with-exact-positive-observations-v1'
BOUNDARY=('Three exact AI revisions and three separate whole-text AI critiques are canonically accepted. '
 'E012 and E051 have READY critiques. The original E050 whole-text verdict remains MINOR_FIXES with finding F1. '
 'A separate fresh checker accepted only the exact sentence correction, its grammar, diff and preservation of meaning. '
 'That scoped READY does not replace the original whole-text verdict or constitute another scientific or novelty review. '
 'The accepted checker itself said READY; its three findings are exact positive observations. The historical empty-findings predicate computed false and remains preserved. '
 'The critics confirmed reading the exact original/revised manuscripts; their supplied primary passages and source-check limits are preserved, '
 'not the later coordinator decisions, summaries, source ledger or word counts. '
 'This finite receipt confirms content-only revision acceptance. The standard administrative checkpoint '
 'remains INCOMPLETE and philosophical truth NOT_CERTIFIED. No whole-provider capture, exhaustive novelty, '
 'anonymous submission package, public release or actual submission is certified or launched.')

CASE_EVENT={'event_id':'event-a162fe57bd454b2eb5400691006df18d','event_sequence':729505,'event_sha256':'1195cca5342c8a0a45d608ec59e04e3288b961c90ef93296f9b788aaad94b5a8'}
CASE_REPORT={'path':'runs/submission-revision-20261101/grammar-repair/results/E050-grammar-check/attempt-001/response.json','sha256':'56bba28c2cf83a7c3673519065e70ccfbd1e3e329bea422000ab8ab14ab263ff','bytes':1141}
OBSERVATIONS=[
 'The revised sentence is grammatical: the plural subject “Propositions 4–5” correctly takes “rely”.',
 'The meaning and source locator remain intact: arXiv:1708.00232v1, 2018 article, §III.B, Propositions 4–5, pp. 3–4.',
 'The manuscripts and complete diff show only the intended local sentence correction.']
FLAGS=('read_before_complete','read_after_complete','read_diff_complete','only_intended_change','meaning_preserved','grammar_correct')
AMENDMENT={'schema':'exact-accepted-grammar-observations.v1','status':'TECHNICAL_INTERPRETATION_OF_EXACT_ACCEPTED_READY',
 'accepted_event':CASE_EVENT,'checker_report':CASE_REPORT,'positive_observations':OBSERVATIONS,
 'recorded_reviewer_decision':'READY','preserved_ready_for_exact_change':False,
 'effective_scoped_readiness':'READY_FROM_EXACT_ACCEPTED_RESPONSE','new_model_calls':0,
 'scope':'EXACT_GRAMMAR_CHANGE_ONLY','generic_nonempty_findings_allowed':False,
 'diagnosis':{'path':'runs/submission-revision-20261101/operations/GRAMMAR_RESPONSE_SCHEMA_DIAGNOSIS.json','sha256':'327c245091af0aea99047b7e54e4690af77a43dfff91962fe343b53ddc11a4ea','bytes':3669}}

def exact_positive_readiness(grammar,root):
    receipt,event,value=grammar['receipt'],grammar['result_event'],grammar['value']
    B.require(all(receipt.get(k)==v for k,v in CASE_EVENT.items()) and event.get('id')==CASE_EVENT['event_id']
              and event.get('sequence')==CASE_EVENT['event_sequence'] and event.get('sha256')==CASE_EVENT['event_sha256'],'Only the exact accepted grammar event is eligible')
    B.require(receipt.get('checker_report')==event['payload'].get('checker_report')==CASE_REPORT,'Exact checker report descriptor required')
    B.require(receipt.get('ready_for_exact_change') is False and event['payload'].get('ready_for_exact_change') is False,
              'Historical computed false must remain preserved')
    expected={'job_id':G.JOB,'essay_id':'E050','scientific_role':'grammar_checker','manuscript_sha256':G.FIXED_SHA,'scope':G.SCOPE,'decision':'READY'}
    B.require(all(value.get(k)==v for k,v in expected.items()) and all(value.get(k) is True for k in FLAGS),'Exact scoped READY and all six true flags required')
    B.require(value.get('findings')==OBSERVATIONS,'Only the three literal positive observations are accepted')
    raw=C.safe_file(CASE_REPORT,root)
    B.require(B.strict_json(raw)==value,'Parsed checker response differs from its exact accepted bytes')
    return {'recorded_reviewer_decision':'READY','recorded_ready_for_exact_change':False,
            'effective_scoped_readiness':'READY_FROM_EXACT_ACCEPTED_RESPONSE','amendment':B.descriptor(root/'runs/submission-revision-20261101/closure-grammar-observations/AMENDMENT.json',root)}

def implementation_paths(root,run):
    return [run/'closure-grammar-observations'/n for n in ('close_revisions.py','test_close_revisions.py','README.md','AMENDMENT.json','INDEPENDENT_REVIEW.json')]+[
      run/'operations/GRAMMAR_RESPONSE_SCHEMA_DIAGNOSIS.json']+[
      run/'closure-grammar'/n for n in ('close_revisions.py','test_close_revisions.py','README.md','MANIFEST.json')]+[
      run/'closure'/n for n in ('close_revisions.py','test_close_revisions.py','README.md','MANIFEST.json')]+[
      run/'grammar-repair/technical/grammar.py']+[
      run/'technical'/n for n in ('common_v2.py','archive_v2.py','runner_v2.py')]+[
      root/'scripts'/n for n in ('research_archive.py','philosophy_round.py','essay_lineage.py','capture_codex.py','codex_rollout.py')]

def local_check(request_path,root=ROOT,run=RUN):
    ref=B.descriptor(request_path,root);request=B.strict_json(C.safe_file(ref,root))
    B.require(request.get('schema')=='submission-revisions-scoped-closure.v1' and request.get('run_id')==run.name
              and request.get('session_id')==C.SID and request.get('selected')==SELECTED,'Wrong closure request identity')
    contexts={wave:C.gate(wave,run,root) for wave in ('authors','critics')}
    lineage_ref=request['lineage_inputs']
    B.require(lineage_ref['path']==str((run/'LINEAGE_INPUTS.json').relative_to(root)),'Wrong base lineage path')
    bases=B.strict_json(C.safe_file(lineage_ref,root))
    B.require(bases.get('schema')=='submission-revision-lineage.v1' and set(bases.get('essays',{}))==set(SELECTED),'Exact three originals required')
    for row in bases['essays'].values():B.bound(row['manuscript'],root)
    waves={};wave_refs=request['wave_receipts']
    B.require(set(wave_refs)=={'authors','critics'},'Exactly two accepted waves required')
    for wave in wave_refs:
        B.require(wave_refs[wave]['path']==str((run/(wave.upper()+'_ARCHIVE_RECEIPT.json')).relative_to(root)),'Wrong wave receipt path')
        waves[wave]=B.strict_json(C.safe_file(wave_refs[wave],root))
        B.require(waves[wave].get('status')=='SUBMISSION_'+wave.upper()+'_ARCHIVED','Wave not accepted')
    role_refs=request['role_receipts'];expected={str((run/'results'/(e+'-'+r)/'ARCHIVE_RECEIPT.json').relative_to(root)) for e in SELECTED for r in ('author','critic')}
    B.require(len(role_refs)==6 and {r['path'] for r in role_refs}==expected,'Exactly six canonical role receipts required')
    roles={}
    for row in role_refs:
        value=B.strict_json(C.safe_file(row,root));B.require(value.get('job_id') not in roles,'Duplicate role identity')
        roles[value['job_id']]=value
    arts=request['artifacts'];B.require(set(arts)==set(ARTIFACTS),'Exactly five coordinator artifacts required')
    documents={}
    for key,name in ARTIFACTS.items():
        B.require(arts[key]['path']==str((run/'coordinator'/name).relative_to(root)),'Wrong coordinator artifact path')
        raw=C.safe_file(arts[key],root);value=B.strict_json(raw) if name.endswith('.json') else raw.decode()
        B.require(bool(value),'Empty coordinator artifact');documents[key]=value
        if key not in {'summary','checkpoint'}:
            B.require(value.get('selected')==SELECTED and value.get('coordinator_session_id')==C.SID,'Wrong coordinator attribution')
    summary=documents['checkpoint']
    B.require(all(isinstance(summary.get(k),str) and summary[k].strip() for k in FIELDS)
              and summary['outcome']=='CONTINUE','Content completion needs an honest administrative CONTINUE checkpoint')
    chosen=request['selected_files'];B.require(set(chosen)==set(SELECTED),'Exact three selected files required')
    for eid,row in chosen.items():
        B.require(row['path']==str((run/'selected'/(eid+'.md')).relative_to(root)),'Selected file outside fixed path')
        B.bound(row,root)  # Byte identity only; new scientific bodies are read after all six canonical gates.
    selection_ref=request['capture_selection']
    B.require(selection_ref['path']==str((run/'coordinator/CAPTURE_SELECTION.json').relative_to(root)),'Wrong coordinator capture path')
    selection=B.strict_json(C.safe_file(selection_ref,root));rows=selection.get('raw_records',[])
    B.require(selection.get('session_id')==C.SID and selection.get('max_bytes')==512*1024*1024 and len(rows)==2
              and all(type(r.get('source_line')) is int and r['source_line']>34736 and B.HEX.fullmatch(r.get('sha256','')) for r in rows),'Two exact coordinator call/result records required')
    lines=sorted(r['source_line'] for r in rows)
    B.require(len(set(lines))==2 and selection.get('start_line')==lines[0] and selection.get('end_line')==lines[1]
              and selection.get('reviewed_tool_lines')==lines,'Capture range differs')
    grammar_ctx=G.gate(root,run);grammar_ref=request['grammar_check']
    B.require(grammar_ref['path']==str((run/'grammar-repair/ARCHIVE_RECEIPT.json').relative_to(root)),'Exact grammar receipt path required')
    grammar_receipt=B.strict_json(C.safe_file(grammar_ref,root))
    grammar_refs=[grammar_ref,grammar_ctx['manifest_ref'],B.descriptor(run/'grammar-repair/START_RECEIPT.json',root),B.descriptor(run/'grammar-repair/EDIT.json',root)]
    amendment_ref=B.descriptor(run/'closure-grammar-observations/AMENDMENT.json',root)
    B.require(B.strict_json(C.safe_file(amendment_ref,root))==AMENDMENT,'Exact readiness interpretation required')
    C.safe_file(AMENDMENT['diagnosis'],root)
    impl_ref=B.descriptor(run/'closure-grammar-observations/MANIFEST.json',root);impl=B.strict_json(C.safe_file(impl_ref,root))
    required={str(p.relative_to(root)) for p in implementation_paths(root,run)}
    B.require(impl.get('status')=='SUBMISSION_REVISION_EXACT_OBSERVATIONS_CLOSURE_PREPARED' and len(impl['files'])==len(required)
              and {r['path'] for r in impl['files']}==required,'Exact frozen closure implementation required')
    for row in impl['files']:C.safe_file(row,root)
    files=[ref,impl_ref,lineage_ref,selection_ref]+list(arts.values())+list(wave_refs.values())+role_refs+list(chosen.values())+impl['files']+grammar_refs
    B.require(len(files)==len({r['path'] for r in files}),'Duplicate closure input')
    return {'root':root,'run':run,'request_ref':ref,'request':request,'contexts':contexts,'bases':bases,
            'waves':waves,'roles':roles,'documents':documents,'artifacts':arts,'selection':selection,'files':files,
            'grammar_context':grammar_ctx,'grammar_receipt':grammar_receipt}

def committed(events,receipt):
    e=events.get(receipt.get('event_id'))
    B.require(e is not None and e['sequence']==receipt.get('event_sequence') and e['sha256']==receipt.get('event_sha256'),'Canonical event commitment differs')
    return e

def canonical_check(data,w):
    root,run=data['root'],data['run'];events={e['id']:e for e in w._state['records']}
    # First pass uses only accepted metadata. No scientific response is parsed before all six are accepted.
    accepted={};wave_events={};sids=set()
    for wave,role in (('authors','author'),('critics','critic')):
        ctx=data['contexts'][wave];start=committed(events,ctx['start'])
        B.require(start['kind']==C.KINDS[wave] and start['run_id']==run.name and start['payload'].get('files')==ctx['files'],'Canonical wave input mismatch')
        wave_receipt=data['waves'][wave];we=committed(events,wave_receipt);rows=wave_receipt.get('roles',[])
        B.require(we['kind']=='research.revision.wave.accepted' and we['run_id']==run.name and we['session_id']==C.SID
                  and we['payload'].get('status')=='SUBMISSION_'+wave.upper()+'_ARCHIVED'
                  and we['payload'].get('roles')==rows and len(rows)==3 and {r['essay_id'] for r in rows}==set(SELECTED)
                  and start['id'] in we['parents'],'Exact canonical three-role wave required')
        wave_events[wave]=we
        for row in rows:
            jid=row['essay_id']+'-'+role;local=data['roles'].get(jid)
            B.require(local is not None and all(local.get(k)==v for k,v in row.items()),'Local/group role differs')
            event=committed(events,local);p=event['payload'];sid=event['session_id']
            B.require(event['kind']=='research.revision.role.accepted' and event['run_id']==run.name and sid==row['session_id']
                      and p.get('status')=='SUBMISSION_REVISION_ROLE_ARCHIVED' and p.get('job_id')==jid
                      and p.get('essay_id')==row['essay_id'] and p.get('scientific_role')==role
                      and p.get('scientific') is True and p.get('independence_verified') is True
                      and p.get('transport_profile')=='no_tools' and p.get('transport_role')=='argument'
                      and p.get('receipt')==row['receipt'] and p.get('files')==local.get('files')
                      and event['id'] in we['parents'] and row['lineage_event_id'] in we['parents']
                      and start['id'] in event['parents'],'Invalid canonical scientific acceptance')
            B.require(sid not in sids|{C.SID},'Six fresh distinct author/critic sessions required');sids.add(sid)
            accepted[jid]={'row':row,'event':event,'ctx':ctx,'job':ctx['jobs'][jid]}
    B.require(len(accepted)==6 and wave_events['authors']['id'] in events[data['contexts']['critics']['start']['event_id']]['parents'],'Critics did not depend on the accepted authors')
    grammar=G.validate_accepted(data['grammar_context'],w,require_ready=False)
    interpretation=exact_positive_readiness(grammar,root)
    B.require(grammar['receipt']==data['grammar_receipt'] and grammar['receipt'].get('status')=='E050_GRAMMAR_CHECK_ARCHIVED'
              and grammar['result_event']['payload'].get('status')=='E050_GRAMMAR_CHECK_ARCHIVED','Scoped acceptance differs')
    bases,_,known=A.canonical_bases(data['contexts']['authors'],w)
    B.require(bases==data['bases'],'Base lineage changed')
    reports=[]
    for jid,item in accepted.items():
        row,event,ctx,job=item['row'],item['event'],item['ctx'],item['job'];eid=row['essay_id'];role=row['scientific_role']
        B.verify_event_files(ctx,w,event)
        receipt_raw=B.bound(row['receipt'],root);B.require(w.get(row['receipt']['sha256'])==receipt_raw,'Canonical terminal receipt differs')
        receipt=B.strict_json(receipt_raw)
        B.require(receipt.get('status')==B.COMPLETE and receipt.get('job_id')==jid and receipt.get('session_id')==row['session_id'],'Wrong completed role identity')
        for recorded,expected in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
            B.require(receipt.get(recorded)==job[expected],'Actual role configuration/input differs')
        B.require(job['model']=='gpt-6-astra' and job['effort']=='ultra' and job['service_tier']=='default'
                  and job['scientific_role']==role and job['essay_id']==eid,'Wrong configured scientific role')
        for kind in ('prompt','schema'):
            B.require(w.get(job[kind+'_sha256'])==B.read(job[kind+'_file'],root),'Canonical worker input differs')
        response_path=str((Path(row['receipt']['path']).parent/'response.json'))
        responses=[r for r in event['payload']['files'] if r['path']==response_path]
        B.require(len(responses)==1,'Exact accepted response required');response=responses[0]
        B.require(receipt['outputs'].get(response['path'])==response['sha256'],'Response not bound by terminal')
        value=B.strict_json(B.bound(response,root));C.base.validate(value,B.load(job['schema_file'],root))
        for k,v in job['expected_output'].items():B.require(value.get(k)==v and type(value.get(k)) is type(v),'Role output identity differs')
        lineage=known.get(row['lineage_entry_id']);B.require(lineage is not None and lineage['id']==row['lineage_event_id'],'Role lineage missing')
        ent=lineage['payload']['entry'];parent=run.name+':'+eid+':assigned' if role=='author' else accepted[eid+'-author']['row']['lineage_entry_id']
        B.require(ent['kind']==('revision' if role=='author' else 'critique') and ent['entity']==bases['essays'][eid]['entity']
                  and ent['parents']==[parent] and ent['actor'].get('session_id')==row['session_id']
                  and ent['workflow'].get('job_id')==jid and ent['workflow'].get('run_id')==run.name
                  and event['id'] in ent['evidence'] and event['id'] in lineage['parents'],'Role lineage attribution differs')
        if role=='author':
            assigned=known.get(parent);B.require(assigned and assigned['payload']['entry']['parents']==[bases['essays'][eid]['parent_entry']],'Author base parent differs')
            B.require(value.get('read_complete') is True and value.get('manuscript_sha256')==bases['essays'][eid]['manuscript']['sha256'],'Author did not read the exact original')
            revision=row['revision'];raw=B.bound(revision,root)
            B.require(value['manuscript_markdown'].encode()==raw and w.get(revision['sha256'])==raw
                      and revision in event['payload']['files'] and any(a['sha256']==revision['sha256'] for a in ent['artifacts']),'Selected revision differs from exact author field')
        else:
            B.require(value.get('read_original_complete') is True and value.get('read_revision_complete') is True,'Critic has not read both manuscripts')
            if eid=='E050':
                findings=value.get('findings',[])
                B.require(value.get('decision')=='MINOR_FIXES' and len(findings)==1 and findings[0].get('id')=='F1'
                          and findings[0].get('severity')=='minor' and grammar['receipt']['old_full_critic']==response
                          and grammar['receipt']['old_full_critic_event_id']==event['id'],'Only the exact preserved E050 MINOR_FIXES/F1 can be resolved')
            else:B.require(value.get('decision')=='READY','Other whole-text critiques must remain READY')
            B.require(not any(f.get('severity') in {'major','critical'} for f in value.get('findings',[])),'READY contradicts serious findings')
            author=accepted[eid+'-author']['row']
            for ref in (bases['essays'][eid]['manuscript'],author['revision'],author['diff']):
                fields=('sha256','bytes') if ref==bases['essays'][eid]['manuscript'] else ('path','sha256','bytes')
                B.require(any(all(x.get(k)==ref[k] for k in fields) for x in job['inline_inputs']),'Critic did not receive exact original/revision/diff')
            B.require(any(a['sha256']==response['sha256'] for a in ent['artifacts']),'Critique lineage report differs')
        item['response']=response;item['value']=value
        reports.append({'job_id':jid,'essay_id':eid,'scientific_role':role,'session_id':row['session_id'],
                        'accepted_event_id':event['id'],'lineage_event_id':lineage['id'],'response':response,
                        'native_check':event['payload']['native_check'],'configuration':ent.get('configuration',{}),
                        'requested_model':receipt['requested_model'],'requested_effort':receipt['requested_effort'],
                        'requested_service_tier':receipt['requested_service_tier']})
    gr=grammar['receipt'];ge=grammar['result_event'];gj=data['grammar_context']['jobs'][G.JOB]
    B.require(gr['original_revision']==accepted['E050-author']['row']['revision'] and gr['checker_session_id'] not in sids|{C.SID},'Grammar source or fresh session differs')
    B.require(gj['model']=='gpt-6-astra' and gj['effort']=='ultra' and gj['service_tier']=='default','Scoped checker configuration differs')
    terminal_ref=ge['payload']['terminal_receipt'];terminal=B.strict_json(B.bound(terminal_ref,root))
    B.require(terminal_ref in ge['payload']['files'] and terminal.get('status')==B.COMPLETE and terminal.get('job_id')==G.JOB
              and terminal.get('session_id')==gr['checker_session_id'],'Scoped terminal differs')
    for recorded,expected in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
        B.require(terminal.get(recorded)==gj[expected],'Scoped checker actual configuration/input differs')
    grammar_report={'job_id':G.JOB,'essay_id':'E050','scientific_role':'grammar_checker','scope':G.SCOPE,
      'session_id':gr['checker_session_id'],'accepted_event_id':ge['id'],'lineage_event_id':gr['checker_lineage_event_id'],
      'response':gr['checker_report'],'terminal_receipt':terminal_ref,'decision':'READY','resolved_findings':['F1'],
      'requested_model':terminal['requested_model'],'requested_effort':terminal['requested_effort'],'requested_service_tier':terminal['requested_service_tier'],
      'whole_text_review_repeated':False,'original_whole_text_critic_decision':'MINOR_FIXES',**interpretation}
    decision=data['documents']['decisions'];choices=decision.get('decisions',[])
    B.require(len(choices)==3 and {r.get('essay_id') for r in choices}==set(SELECTED),'Exact three coordinator decisions required')
    selected=[]
    for row in choices:
        eid=row['essay_id'];author=accepted[eid+'-author'];critic=accepted[eid+'-critic'];copy=data['request']['selected_files'][eid]
        B.require(row.get('selected_manuscript')==copy and row.get('author_event_id')==author['event']['id']
                  and row.get('critic_event_id')==critic['event']['id'] and isinstance(row.get('reason'),str) and row['reason'].strip()
                  and isinstance(row.get('limitations'),list) and all(isinstance(x,str) for x in row['limitations']),'Coordinator decision/version/review differs')
        expected_revision=author['row']['revision']
        if eid=='E050':
            B.require(row.get('critic_decision')=='MINOR_FIXES' and row.get('coordinator_decision')=='USE_CORRECTED_REVISION'
                      and row.get('scoped_checker_decision')=='READY' and row.get('resolved_findings')==['F1']
                      and row.get('correction_event_id')==gr['correction_event_id'] and row.get('scoped_checker_event_id')==ge['id'],'Scoped coordinator decision must preserve MINOR_FIXES and resolve only F1')
            expected_revision=gr['corrected_revision']
        else:B.require(row.get('critic_decision')=='READY' and row.get('coordinator_decision')=='USE_REVISION','Whole-text READY selection differs')
        B.require(B.bound(copy,root)==B.bound(expected_revision,root),'Selected file is not an exact accepted revision copy')
        selected.append({'essay_id':eid,'manuscript':copy,'author_event_id':author['event']['id'],'critic_event_id':critic['event']['id'],
                         'author_session_id':author['row']['session_id'],'critic_session_id':critic['row']['session_id'],
                         'critic_decision':critic['value']['decision'],'whole_text_reviewed_revision':author['row']['revision'],
                         'read_original_complete':True,'read_revision_complete':True})
        if eid=='E050':selected[-1].update(scoped_checker_event_id=ge['id'],correction_event_id=gr['correction_event_id'],
            scoped_checker_session_id=gr['checker_session_id'],scoped_checker_decision='READY',scope=G.SCOPE,resolved_findings=['F1'])
    starts=[e for e in events.values() if e['run_id']==run.name and e['kind']=='operation.started']
    B.require(len(starts)==1,'Exactly one round start required')
    start_payload=events[data['contexts']['authors']['start']['event_id']]['payload']
    question=events.get(start_payload['question_stage_event_id']);qcov=events.get(start_payload['question_coverage_event_id'])
    B.require(question and question['kind']=='round.stage' and question['payload'].get('stage')=='question'
              and question['session_id']==C.SID and question['run_id']==run.name and qcov and qcov['kind']=='capture.coverage'
              and qcov['run_id']==run.name and qcov['payload'].get('status')=='BOUNDED_COMPLETE','Bound question provenance missing')
    return {'events':events,'known':known,'accepted':accepted,'reports':reports,'selected':sorted(selected,key=lambda r:SELECTED.index(r['essay_id'])),
            'first':starts[0],'question':question,'question_coverage':qcov,'waves':wave_events,
            'grammar':grammar,'grammar_report':grammar_report}

def close_with_writer(data,w,checkpoint_api=checkpoint):
    w._ensure_audited()
    checked=canonical_check(data,w);root,run=data['root'],data['run'];arts=data['artifacts']
    ctx={'root':root,'run':run,'start':{'bindings':checked['first']['bindings']}}
    def append(kind,key,parents,refs,payload):
        return w.append(B.request(ctx,kind,C.SID,KEY,parents,refs,payload),run.name+':'+KEY+':'+key)
    for ref in data['files']:B.require(w.put(C.safe_file(ref,root))==ref['sha256'],'Closure input drift')
    parents=[checked['question']['id']]+[e['id'] for e in checked['waves'].values()]+[r['lineage_event_id'] for r in checked['reports']]+[
      checked['grammar']['result_event']['id'],checked['grammar']['receipt']['checker_lineage_event_id']]
    intake=append('research.revision.closure.inputs','inputs',parents,data['files'],{'status':'SUBMISSION_REVISION_CLOSURE_INPUTS_BOUND','request':data['request_ref'],'files':data['files'],'boundary':BOUNDARY})
    capture=B.existing(w,run.name+':'+KEY+':capture')
    if capture:
        B.require(capture['payload']['selection']==data['request']['capture_selection'],'Coordinator capture retry differs')
        coverage_id=capture['payload']['coverage_event_id'];raw_ids=capture['payload']['raw_event_ids']
    else:
        sel=data['selection'];scope=B.SessionWriter(w,C.SID,run.name)
        cap=B.capture(root/'research/archive',B.resolve_session(C.SID,root),C.SID,root,start_line=sel['start_line'],end_line=sel['end_line'],
            reviewed_tool_lines=sel['reviewed_tool_lines'],max_bytes=sel['max_bytes'],run_id=run.name,archive_writer=scope)
        B.require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==2 and len(cap['tool_link_ids'])==1
                  and {r['source_line']:r['sha256'] for r in cap['raw_records']}=={r['source_line']:r['sha256'] for r in sel['raw_records']},'Exact coordinator call/result capture failed')
        coverage_id=cap['coverage_event_id'];raw_ids=cap['raw_event_ids']
        append('research.revision.coordinator.capture_bound','capture',[intake['id'],coverage_id]+raw_ids,[],{'selection':data['request']['capture_selection'],'coverage_event_id':coverage_id,'raw_event_ids':raw_ids})
    stages={};previous=checked['question']['id']
    for stage in ('sources','contribution','critique','decision'):
        reports=[r for r in checked['reports']+[checked['grammar_report']] if stage!='critique' or r['scientific_role'] in {'critic','grammar_checker'}]
        refs={'sources':[arts['source_ledger']],'contribution':[arts['summary']],'critique':[],'decision':[arts['decisions'],arts['word_counts']]}[stage]
        event=append('research.revision.stage',stage,[intake['id'],previous]+[r['accepted_event_id'] for r in reports]+([] if stage=='critique' else raw_ids),refs,
            {'stage':stage,'files':refs,'per_item_attribution':reports,'coordinator_evidence_event_ids':[] if stage=='critique' else raw_ids,
             'artifact_author':'Mechanical index of independent critiques' if stage=='critique' else 'AI coordinator compilation/decision',
             'review_target':'Three accepted full-text critiques, plus one separately labelled exact-grammar-change check; later coordinator artifacts were not reviewed','new_scientific_roles':0,'boundary':BOUNDARY})
        stages[stage]=event['id'];previous=event['id']
    known=checked['known'];events=checked['events'];events.update({e['id']:e for e in w._state['records'] if e['run_id']==run.name})
    selections=[]
    for row in checked['selected']:
        eid=row['essay_id'];choice=next(x for x in data['documents']['decisions']['decisions'] if x['essay_id']==eid)
        entry=L.base_entry(run.name+':'+eid+':selected:v1',data['bases']['essays'][eid]['entity'],'selection',choice['reason'])
        entry.update(parents=[checked['accepted'][eid+'-'+role]['row']['lineage_entry_id'] for role in ('author','critic')],
            artifacts=[dict(row['manuscript'],role='selected_revised_manuscript')],evidence=[stages['decision'],row['author_event_id'],row['critic_event_id']],
            actor={'role':'AI','session_id':C.SID},workflow={'run_id':run.name,'essay_id':eid,'stage':'content_selection'},
            decision={'status':'SELECTED_AFTER_READY_CRITIQUE','origin':'AI_COORDINATOR'},gaps=choice['limitations']+[BOUNDARY])
        if eid=='E050':
            gr=checked['grammar']['receipt']
            entry['parents']=[gr['correction_lineage_entry_id'],checked['accepted']['E050-critic']['row']['lineage_entry_id'],gr['checker_lineage_entry_id']]
            entry['evidence'] += [gr['correction_event_id'],checked['grammar']['result_event']['id']]
            entry['decision']={'status':'SELECTED_AFTER_EXACT_F1_FIX_READY','origin':'AI_COORDINATOR','whole_text_critic_decision':'MINOR_FIXES','scoped_checker_decision':'READY'}
        selections.append(L.append(w,entry,C.SID,known,events)['id'])
    marker=B.existing(w,run.name+':'+KEY+':checkpoint')
    if marker:
        B.require(marker['payload']['request_sha256']==data['request_ref']['sha256'],'Checkpoint request changed')
        cp=B.canonical_event(w,marker['payload']['checkpoint_event_id'])
    else:
        cp=checkpoint_api(root,w,run.name,arts['checkpoint']['path'],[checked['question_coverage']['id'],coverage_id],incomplete=True)
        terminals=[e for e in w._state['records'] if e['run_id']==run.name and e['kind']=='operation.interrupted' and e['payload'].get('checkpoint')==cp['id']]
        B.require(len(terminals)==1,'Standard administrative terminal absent')
        marker=append('research.revision.checkpoint_api_returned','checkpoint',[cp['id'],terminals[0]['id'],intake['id']],[arts['checkpoint']],{'request_sha256':data['request_ref']['sha256'],'checkpoint_event_id':cp['id']})
    B.require(cp['kind']=='checkpoint' and cp['payload'].get('capture_status')=='INCOMPLETE' and cp['payload'].get('truth_status')=='NOT_CERTIFIED'
              and cp['payload'].get('summary')==data['documents']['checkpoint'] and cp['outputs']==[arts['checkpoint']['sha256']],'Administrative checkpoint differs')
    for row in data['bases']['essays'].values():B.bound(row['manuscript'],root)
    payload={'status':STATUS,'selected':SELECTED,'selected_revisions':checked['selected'],'accepted_roles':checked['reports'],
      'accepted_scoped_checks':[checked['grammar_report']],'scoped_checks_accepted':1,
      'whole_text_critic_decisions':{'E050':'MINOR_FIXES','E012':'READY','E051':'READY'},'resolved_findings':{'E050':['F1']},
      'scientific_results_accepted':6,'old_roles_repeated':0,'originals_unchanged':True,'content_only':True,
      'anonymous_submission_package_prepared':False,'submission_authorized':False,'provider_calls_by_closure':0,
      'selected_lineage_event_ids':selections,'typed_stage_event_ids':stages,'administrative_checkpoint_event_id':cp['id'],
      'administrative_capture_status':'INCOMPLETE','artifacts':arts,'request':data['request_ref'],'boundary':BOUNDARY}
    event=append('research.revision.completed','complete',[intake['id'],marker['id'],cp['id']]+list(stages.values())+selections,list(arts.values())+list(data['request']['selected_files'].values()),payload)
    receipt=dict(payload,event_id=event['id'],event_sequence=event['sequence'],event_sha256=event['sha256'])
    B.save_new(run/'FINAL_RECEIPT.json',receipt);return receipt

def prepare(request_path=LANE/'REQUEST.json',root=ROOT,run=RUN):
    data=local_check(request_path,root,run);return data,data['files']

def finish(ctx,writer,refs,*,allow_checkpoint_derived_updates=False,checkpoint_api=checkpoint):
    B.require(allow_checkpoint_derived_updates is True,'Explicit checkpoint derived-update permission required')
    writer._ensure_audited();fresh=local_check(ctx['root']/ctx['request_ref']['path'],ctx['root'],ctx['run'])
    B.require(fresh['request_ref']==ctx['request_ref'] and fresh['files']==refs==ctx['files'],'Closure changed after prepare')
    return close_with_writer(fresh,writer,checkpoint_api)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,default=LANE/'REQUEST.json');p.add_argument('--apply',action='store_true');p.add_argument('--check',action='store_true');p.add_argument('--allow-checkpoint-derived-updates',action='store_true');args=p.parse_args(argv)
    B.require(not(args.apply and args.check),'Choose check or apply');ctx,refs=prepare(args.request)
    if not args.apply:
        print(json.dumps({'status':'LOCAL_INPUTS_PASS','canonical_checks':'PENDING_ORDINARY_WRITER_AUDIT','archive_writes':0,'provider_calls':0}));return 0
    B.require(args.allow_checkpoint_derived_updates,'Explicit checkpoint derived-update permission required')
    with B.Archive(ROOT/'research/archive').writer() as w:receipt=finish(ctx,w,refs,allow_checkpoint_derived_updates=True)
    print(json.dumps(receipt,ensure_ascii=False));return 0

if __name__=='__main__':raise SystemExit(main())
