# Точная интерпретация уже принятого ответа grammar checker

Это отдельный конечный helper. `closure/`, `closure-grammar/`, grammar
adapter, исходный ответ, его квитанции и замороженные входы не меняются.
Новых моделей, научных ролей или архивной волны нет.

Принятый `E050-grammar-check` прямо сообщил `READY`, все шесть true-флагов
и три положительных наблюдения. Поле `findings` в его schema допускает
строки, однако прежний вычисляемый predicate требовал пустой список.
Поэтому канонически сохранённое `ready_for_exact_change:false` является
результатом этого технического условия, а не отрицательным решением критика.
Исходные `false` в событии и квитанции сохраняются.

Разрешён ровно один случай:

- Event `event-a162fe57bd454b2eb5400691006df18d`, sequence 729505,
  SHA `1195cca5342c8a0a45d608ec59e04e3288b961c90ef93296f9b788aaad94b5a8`.
- Response SHA `56bba28c2cf83a7c3673519065e70ccfbd1e3e329bea422000ab8ab14ab263ff`,
  1141 байт, точный путь из `AMENDMENT.json`.
- `READY`, точные identity/scope, все шесть флагов строго true и ровно три
  дословных положительных observations в прежнем порядке.
- Любой изменённый, дополнительный или пустой finding, другое событие,
  другая версия, неполное чтение либо изменённые bytes отклоняются.

Сначала выполняется прежний полный read-only
`G.validate_accepted(ctx, writer, require_ready=False)`. Он сохраняет
проверки канонических файлов, исходных ролей, scope, schema, lineage,
свежей сессии и совпадения прежнего computedfalse с исходным predicate.
Затем `exact_positive_readiness` проверяет единственный случай выше.
Нет общего разрешения непустых findings, изменения исходного ответа
или обхода независимой проверки.

В конечной квитанции scoped checker получает отдельные поля
`recorded_reviewer_decision: READY`, `recorded_ready_for_exact_change: false`,
`effective_scoped_readiness: READY_FROM_EXACT_ACCEPTED_RESPONSE` и точную
ссылку на amendment. Полнотекстовый E050 по-прежнему `MINOR_FIXES/F1`;
E012/E051 по-прежнему требуют полнотекстовых `READY`. Новая проверка касается
только точной грамматической правки. Содержание принято только после всех
остальных прежних условий; пакет подачи и отправка не подтверждаются.

## Входы и запуск

[Контракт предыдущего helper](../closure-grammar/README.md) сохраняется:
schema REQUEST `submission-revisions-scoped-closure.v1`, те же поля,
тот же `grammar_check` descriptor, те же пять coordinator artifacts,
selected copies и exact root capture. Меняется только каталог REQUEST:
`closure-grammar-observations/REQUEST.json`. Старые computedfalse в source
ledger и DECISIONS можно сохранять дополнительно; не заменять их true.

`MANIFEST.json` имеет статус
`SUBMISSION_REVISION_EXACT_OBSERVATIONS_CLOSURE_PREPARED` и 23 точных файла:
этот source/test/README, `AMENDMENT.json`, независимый review, принятый
технический diagnosis, четыре файла прежней grammar closure, четыре файла
исходной closure, grammar adapter, три technical v2 и пять production
dependencies. Review и diagnosis входят в конечные архивируемые inputs.

```sh
python3 -B runs/submission-revision-20261101/closure-grammar-observations/close_revisions.py --check
```

API прежний: `ctx, refs = M.prepare(request_path)`, затем под тем же
полностью проверенным writer:
`M.finish(ctx, writer, refs, allow_checkpoint_derived_updates=True)`.
Отдельный запуск root использует `--apply --allow-checkpoint-derived-updates`.
Один checkpoint/derived refresh, прежние lineages, отдельные delivery keys,
неизменяемые outputs и честные счётчики шесть исходных ролей плюс один
scoped checker сохранены. Новый полный аудит ради этой интерпретации не нужен.

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/closure-grammar-observations -p test_close_revisions.py
```

15 узких тестов используют точный уже принятый response как синтетическую
копию в tempdir. Проверяют metadata/flags/literal observations/bytes и
сохранность computedfalse; не запускают writer, native capture или модели.
Прежние 13 и 23 теста и их исходники остаются неизменными.
