"""Exact accepted-response predicate only; no provider, writer or scientific rerun."""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('positive_closure',HERE/'close_revisions.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
RAW=b'{\n  "job_id": "E050-grammar-check",\n  "essay_id": "E050",\n  "manuscript_sha256": "451823414dc95441657d7b0b8fccf1e415823f3f55d1cb6efdee7f4f5a770eaa",\n  "scientific_role": "grammar_checker",\n  "scope": "EXACT_GRAMMAR_CHANGE_ONLY",\n  "decision": "READY",\n  "read_before_complete": true,\n  "read_after_complete": true,\n  "read_diff_complete": true,\n  "only_intended_change": true,\n  "meaning_preserved": true,\n  "grammar_correct": true,\n  "findings": [\n    "The revised sentence is grammatical: the plural subject \xe2\x80\x9cPropositions 4\xe2\x80\x935\xe2\x80\x9d correctly takes \xe2\x80\x9crely\xe2\x80\x9d.",\n    "The meaning and source locator remain intact: arXiv:1708.00232v1, 2018 article, \xc2\xa7III.B, Propositions 4\xe2\x80\x935, pp. 3\xe2\x80\x934.",\n    "The manuscripts and complete diff show only the intended local sentence correction."\n  ],\n  "limitations": [\n    "Checked only the supplied texts and diff; no external source verification or new scientific or novelty review."\n  ],\n  "plain_summary_ru": [\n    "\xd0\x9f\xd1\x80\xd0\xb0\xd0\xb2\xd0\xba\xd0\xb0 \xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd0\xb0: \xd0\xb3\xd1\x80\xd0\xb0\xd0\xbc\xd0\xbc\xd0\xb0\xd1\x82\xd0\xb8\xd0\xba\xd0\xb0 \xd0\xb8\xd1\x81\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xbb\xd0\xb5\xd0\xbd\xd0\xb0, \xd1\x81\xd0\xbc\xd1\x8b\xd1\x81\xd0\xbb \xd0\xb8 \xd1\x81\xd1\x81\xd1\x8b\xd0\xbb\xd0\xba\xd0\xb0 \xd0\xbd\xd0\xb0 \xd0\xb8\xd1\x81\xd1\x82\xd0\xbe\xd1\x87\xd0\xbd\xd0\xb8\xd0\xba \xd1\x81\xd0\xbe\xd1\x85\xd1\x80\xd0\xb0\xd0\xbd\xd0\xb5\xd0\xbd\xd1\x8b. \xd0\x94\xd1\x80\xd1\x83\xd0\xb3\xd0\xb8\xd1\x85 \xd0\xb8\xd0\xb7\xd0\xbc\xd0\xb5\xd0\xbd\xd0\xb5\xd0\xbd\xd0\xb8\xd0\xb9 \xd0\xbd\xd0\xb5\xd1\x82."\n  ]\n}\n'

class ExactPositiveObservations(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name)
        self.path=self.root/M.CASE_REPORT['path'];self.path.parent.mkdir(parents=True);self.path.write_bytes(RAW)
        amendment=self.root/'runs/submission-revision-20261101/closure-grammar-observations/AMENDMENT.json'
        amendment.parent.mkdir();amendment.write_bytes(M.B.encoded(M.AMENDMENT))
        self.case={'receipt':dict(M.CASE_EVENT,checker_report=copy.deepcopy(M.CASE_REPORT),ready_for_exact_change=False),
          'result_event':{'id':M.CASE_EVENT['event_id'],'sequence':M.CASE_EVENT['event_sequence'],'sha256':M.CASE_EVENT['event_sha256'],
            'payload':{'checker_report':copy.deepcopy(M.CASE_REPORT),'ready_for_exact_change':False}},
          'value':json.loads(RAW)}
    def tearDown(self):self.tmp.cleanup()
    def check(self):return M.exact_positive_readiness(self.case,self.root)
    def test_exact_accepted_ready_is_interpreted_without_mutation(self):
        before=copy.deepcopy(self.case);result=self.check()
        self.assertEqual(before,self.case);self.assertFalse(M.G.ready(self.case['value']))
        self.assertEqual(result['effective_scoped_readiness'],'READY_FROM_EXACT_ACCEPTED_RESPONSE')
        self.assertFalse(result['recorded_ready_for_exact_change'])
    def test_changed_observation_rejected(self):
        self.case['value']['findings'][0]='Correction is still required.'
        with self.assertRaisesRegex(ValueError,'literal positive'):self.check()
    def test_extra_observation_rejected(self):
        self.case['value']['findings'].append('Another observation')
        with self.assertRaisesRegex(ValueError,'literal positive'):self.check()
    def test_empty_findings_not_this_exception(self):
        self.case['value']['findings']=[]
        with self.assertRaisesRegex(ValueError,'literal positive'):self.check()
    def test_reordered_observations_rejected(self):
        self.case['value']['findings'].reverse()
        with self.assertRaisesRegex(ValueError,'literal positive'):self.check()
    def test_not_ready_rejected(self):
        self.case['value']['decision']='NOT_READY'
        with self.assertRaisesRegex(ValueError,'six true'):self.check()
    def test_each_missing_or_nontrue_flag_rejected(self):
        for flag in M.FLAGS:
            for replacement in ('missing',False,1):
                with self.subTest(flag=flag,replacement=replacement):
                    prior=self.case['value'].copy()
                    if replacement=='missing':self.case['value'].pop(flag)
                    else:self.case['value'][flag]=replacement
                    with self.assertRaisesRegex(ValueError,'six true'):self.check()
                    self.case['value']=prior
    def test_scope_cannot_expand(self):
        self.case['value']['scope']='FULL_SCIENTIFIC_REVIEW'
        with self.assertRaisesRegex(ValueError,'scoped READY'):self.check()
    def test_changed_event_commitment_rejected(self):
        self.case['result_event']['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'exact accepted grammar event'):self.check()
    def test_different_report_rejected(self):
        self.case['receipt']['checker_report']['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'report descriptor'):self.check()
    def test_historical_receipt_false_cannot_be_replaced(self):
        self.case['receipt']['ready_for_exact_change']=True
        with self.assertRaisesRegex(ValueError,'computed false'):self.check()
    def test_historical_event_false_must_exist(self):
        self.case['result_event']['payload'].pop('ready_for_exact_change')
        with self.assertRaisesRegex(ValueError,'computed false'):self.check()
    def test_raw_report_drift_rejected(self):
        self.path.write_bytes(RAW+b' ')
        with self.assertRaisesRegex(ValueError,'Bound file changed'):self.check()
    def test_other_parsed_fields_cannot_be_changed(self):
        self.case['value']['limitations']=[]
        with self.assertRaisesRegex(ValueError,'exact accepted bytes'):self.check()
    def test_fixed_raw_fixture_matches_real_accepted_descriptor(self):
        self.assertEqual(len(RAW),M.CASE_REPORT['bytes']);self.assertEqual(M.B.sha(RAW),M.CASE_REPORT['sha256'])

if __name__=='__main__':unittest.main()
