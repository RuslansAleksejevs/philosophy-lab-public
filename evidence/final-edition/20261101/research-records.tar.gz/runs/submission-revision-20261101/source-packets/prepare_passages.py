"""Prepare finite exact source-text slices; no new retrieval or model calls."""
import hashlib
import json
from pathlib import Path
import sys

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from collector_safety import has_credential

def desc(p):
    b=p.read_bytes()
    return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}

def write(p,b):
    if has_credential(b.decode('utf-8')):raise ValueError('Unsafe source text')
    with p.open('xb') as f:f.write(b)

def jsonbytes(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()

def byanchors(text,start,end):
    a=text.index(start);b=text.index(end,a+len(start));return a,b

def pages(text,first,last):
    cuts=[0]+[i+1 for i,c in enumerate(text) if c=='\f']
    return cuts[first-1],cuts[last] if last<len(cuts) else len(text)

def lines(text,first,last):
    ls=text.splitlines(keepends=True)
    # For HTML visible text there are no form feeds; LF lines are authoritative.
    return sum(map(len,ls[:first-1])),sum(map(len,ls[:last]))

decoded=BASE/'E012/sources/thompson-1998.tool-visible.txt'
snapshot=BASE/'E012/sources/thompson-1998.web-snapshot.json'
write(decoded,json.loads(snapshot.read_text())['tool_result'].encode())

all_manifests=[]
for essay in ('E050','E012','E051'):
    folder=BASE/essay
    packet=json.loads((folder/'SOURCE_PACKET.json').read_text())
    text=('# Primary source passages: '+essay+'\n\n'
          'Only exact slices of the bound visible source text follow. The labels identify sources and locations; they contain no revision tasks or assessment. PDF extraction retains layout and may contain imperfect mathematical glyphs; the bound PDF is authoritative for typesetting. A downloaded full file does not imply every page was reviewed.\n').encode()
    segments=[];bound={}
    for s in packet['sources']:
        key=s['key']
        source=decoded if key=='thompson-1998' else ROOT/s['visible_text']['path']
        raw=source.read_bytes();visible=raw.decode()
        slices=[]
        if key=='bongers-2022-v4':
            slices=[('§4.6 Example4.21 and following convergence qualification; PDFpp36–37',byanchors(visible,'4.6 Realizing a given SCM as a stable SDCM','Corollary 4.22.'))]
        elif key=='sootla-2016-preprint':
            a=visible.index('2.1   Problem Formulation');b=visible.index('\f',a)
            c=visible.index('Theorem 7 Let');d=visible.index('\f',c)
            slices=[('§2.1 assumptions A1–A4 and switching sets; preprintp3 (two-column layout retained)',(a,b)),('Theorem7; preprintp5 (two-column layout retained)',(c,d)),('Corollary9, conditions11–13 and conclusion14; preprintp6',byanchors(visible,'Corollary 9 Consider','Theorem 7 states that'))]
        elif key=='sootla-2018-preprint':
            slices=[('§III assumptions A1–A5; v1 preprintp3 (two-column layout retained)',byanchors(visible,' A1. Let f','   At the first glance')),('§III.B, Propositions4–5; v1 preprintpp3–4 (two-column layout retained)',byanchors(visible,'B. Convergence Under Parametric Uncertainty','C. A Case Study')),('§III.C Problem2 and following qualification; v1 preprintp5',byanchors(visible,'   Problem 2. Switching Under Parametric Uncertainty.','   Next, we consider'))]
        elif key=='gardner-2011-eprint':
            slices=[('Typescriptp40 = PDFpage41; continuity thesis',pages(visible,41,41)),('Typescriptpp46–50 = PDFpages47–51; substitute performance, purpose and consequential losses',pages(visible,47,51))]
        elif key=='rule37-notes':
            slices=[('2015 Advisory Committee Note, scope of subdivision(e), visible-text lines203–206',lines(visible,203,206)),('2015note: proportionality, replacement, expense allocation, prejudice and severe measures; visible-text lines210–217',lines(visible,210,217))]
        elif key=='thompson-1998':
            slices=[('Majority§III, rendered source lines125–129',byanchors(visible,'L125:','L130:')),('Scope note1, rendered source lines139–140',byanchors(visible,'L139:','L141:')),('Majoritynotes6–7, rendered source lines146–148',byanchors(visible,'L146:','L149:'))]
        elif key=='andonovski-2022':
            slices=[('Mental models as structural representations, visible-text lines304–313',lines(visible,304,313)),('Episodic representation: What the thesis is not, first qualification, visible-text lines350–352',lines(visible,350,352)),('Modeling and surrogative reasoning, visible-text lines368–373',lines(visible,368,373))]
        for number,(location,(a,b)) in enumerate(slices,1):
            lo=len(visible[:a].encode());hi=len(visible[:b].encode());piece=raw[lo:hi]
            header=(f'\n\n===== BEGIN {key}/{number} =====\nSource: {s["citation"]}\nURL: {s["url"]}\nLocation: {location}\nSource visible-text SHA-256: {hashlib.sha256(raw).hexdigest()}\nByte interval: [{lo},{hi})\n\n').encode()
            text+=header;outlo=len(text);text+=piece;outhi=len(text)
            text+=(f'\n===== END {key}/{number} =====\n').encode()
            segments.append({'source_id':key,'segment':number,'location':location,'source_text':desc(source),'source_utf8_byte_start':lo,'source_utf8_byte_end_exclusive':hi,'slice_sha256':hashlib.sha256(piece).hexdigest(),'slice_bytes':len(piece),'slice_words':len(piece.decode().split()),'output_utf8_byte_start':outlo,'output_utf8_byte_end_exclusive':outhi})
        bound[str(source)]=desc(source)
        # The binary/original public source remains bound as provenance; it is not inlined.
        for field in ('source_snapshot','visible_text'):
            if field in s:bound[s[field]['path']]=s[field]
    out=folder/'PRIMARY_PASSAGES.txt';write(out,text)
    notes=packet['existing_citation_access']
    access=['# Source access notes: '+essay,'',notes['basis'],'',packet['access_boundary'],'']
    for s in packet['sources']:
        access += [s['citation'],s['url'],'Current packet access: '+s['availability'],'Relevant locations: '+' '.join(s['locations']),'Limits: '+' '.join(s['limitations']),'']
    for n in notes['notes']:
        access += [n['citation'],n['url'],'Earlier accepted source audit: '+n['previous_access'],'Earlier locations: '+n['previous_locations'],'']
    accessp=folder/'SOURCE_ACCESS_NOTES.txt';write(accessp,('\n'.join(access)+'\n').encode())
    manifest={'schema':'submission-primary-passages.v1','essay_id':essay,'files':[desc(out),desc(accessp)]+list({d['path']:d for d in bound.values()}.values()),'segments':segments,'source_packet_basis':desc(folder/'SOURCE_PACKET.json'),'word_count_source_slices':sum(s['slice_words'] for s in segments),'critic_input_boundary':'Inline PRIMARY_PASSAGES.txt and SOURCE_ACCESS_NOTES.txt only, plus the separately authorized revision and task. No SOURCE_PACKET tasks, comparison-to-make text, ratings, previous review verdicts or other essays.','author_input_boundary':'Own SOURCE_PACKET.md plus own PRIMARY_PASSAGES.txt and manuscript; no cross-essay administrative provenance.','raw_html_excluded':'E012/sources/rule37-notes.html remains unchanged local-only, outside files.','model_calls':0,'canonical_writes':0}
    for seg in segments:
        src=(ROOT/seg['source_text']['path']).read_bytes();piece=src[seg['source_utf8_byte_start']:seg['source_utf8_byte_end_exclusive']]
        assert text[seg['output_utf8_byte_start']:seg['output_utf8_byte_end_exclusive']]==piece
        assert hashlib.sha256(piece).hexdigest()==seg['slice_sha256']
    mp=folder/'PASSAGES_MANIFEST.json';write(mp,jsonbytes(manifest));all_manifests.append({'essay_id':essay,'passages':desc(out),'access_notes':desc(accessp),'manifest':desc(mp),'source_words':manifest['word_count_source_slices']})
report={'schema':'submission-primary-passages-preparation.v1','status':'PASS_EXACT_SLICES_NOT_DISPATCHED','packets':all_manifests,'all_slices_byte_equal_to_bound_visible_source':True,'new_web_retrievals':0,'original_source_packet_files_unchanged':True,'provider_calls':0,'canonical_writes':0,'scope':'Exact primary-source extraction and technical bindings only; no essay judgments or new literature search.'}
write(BASE/'PASSAGES_CHECKS.json',jsonbytes(report))
print(json.dumps(report,ensure_ascii=False,indent=2))
