"""One-shot source packet preparation. No provider, writer, or manuscript edits."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from collector_safety import has_credential

def desc(p):
    p = Path(p)
    if not p.is_absolute(): p = ROOT / p
    if p.is_symlink() or not p.is_file(): raise ValueError('Unusable input: ' + str(p))
    b = p.read_bytes()
    return {'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def write(p, value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if has_credential(text): raise ValueError('Credential-shaped output excluded')
    if p.exists():
        if p.read_text() != text: raise ValueError('Conflicting existing output: ' + str(p))
        return
    with p.open('x', encoding='utf-8') as f: f.write(text)

def read(p): return json.loads((ROOT / p).read_text())

LEDGER = 'runs/submission-trio-20261031/coordinator/SOURCE_LEDGER.json'
PLAN = 'runs/submission-trio-20261031/coordinator/REVISION_PLAN.json'
ledger, plan = read(LEDGER), read(PLAN)
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
if (BASE/'E050/INPUT_MANIFEST.json').exists():
    now=json.loads((BASE/'E050/INPUT_MANIFEST.json').read_text())['created_at']

SPECS = {
 'E050': [
  {'key':'bongers-2022-v4', 'ledger_id':'S5', 'ext':'pdf',
   'locations':['arXiv:1803.08784v4, 27 March 2022; PDF/printed pp.36–37, §4.6, Example4.21, equations(6)–(7), and the paragraph immediately after the example.'],
   'anchors':['First, we observe that one cannot uniquely recover an SDCM from its equilibration in general.','Example 4.21.','Although the equilibrated SDCM in Example 4.21'],
   'quote':'First, we observe that one cannot uniquely recover an SDCM from its equilibration in general.',
   'source_account':'The example inserts an invertible diagonal matrix before the time derivative. Equilibrium equations coincide, and qualifying intervened equilibria coincide under the stated invertibility condition. The following paragraph warns that actual convergence of both systems is not guaranteed.',
   'comparison_task':'Acknowledge the hidden-relative-rate antecedent. Explain the manuscript’s stronger specified endpoint evidence, proved convergence to different stable release endpoints, and separate withdrawal-order result. Do not attribute these additional conclusions to this linear example.',
   'limitations':['The downloaded complete PDF is preserved; the identified passage and its convergence qualification were read, not all54pages. The equations were checked on the rendered p.36. Equality of equilibrium equations alone is weaker than proved convergence.'],
   'images':['bongers-2022-v4-page36.png']},
  {'key':'sootla-2016-preprint', 'ledger_id':'S6', 'ext':'pdf',
   'locations':['Author preprint dated5October2015 of the2016 Automatica article: §2.1 p.3, assumptions A1–A4 and switching sets; Theorem7 p.5; Corollary9 p.6, conditions(11)–(13) and inclusion(14).'],
   'anchors':['2.1   Problem Formulation','Theorem 7 Let','Corollary 9 Consider'],
   'quote':'Theorem 7 also provides a way of estimating the switching',
   'source_account':'Finite pulses switch a bistable system to an enduring unforced attractor. Theorem7 bounds switching sets using monotone upper and lower systems. Corollary9 applies these bounds over a compact parameter set with stated regularity, basin and ordering conditions.',
   'comparison_task':'Treat successful temporary control under parameter uncertainty as established background. Compare the manuscript’s particular clamp-equivalent family and opposite withdrawal orders, rather than claiming that parameter-robust switching itself is new.',
   'limitations':['The full author preprint is preserved; §2.1, Theorem7 and Corollary9 were inspected. Appendix proofs were not newly re-audited. Do not remove the compactness, monotonic bounding, or basin assumptions. Journal pagination254–264 differs from preprint pagination.'],
   'images':['sootla-2016-preprint-page6.png']},
  {'key':'sootla-2018-preprint', 'ledger_id':'S7', 'ext':'pdf',
   'locations':['arXiv:1708.00232v1,1August2017, author preprint of the2018 IEEE article: §III assumptions A1–A5 p.3; §III.B pp.3–4, Propositions4–5; §III.C “A Case Study”, Problem2 p.5.'],
   'anchors':['B. Convergence Under Parametric Uncertainty','C. A Case Study','Problem 2. Switching Under Parametric Uncertainty.'],
   'quote':'the exact values of parameters',
   'source_account':'Under monotonicity and known parameter-interval bounds, the method estimates control and convergence quantities without the exact parameter. Problem2 requests a pulse switching the genetic toggle for every parameter in the interval; the subsequent discussion notes conservative bounds and dependence on tolerance.',
   'comparison_task':'Distinguish this known robust-control aim from the manuscript’s evidence nonidentification plus all-k withdrawal-order result. Do not claim these interval-based theorems automatically prove the manuscript’s result or that every k shares a finite settling deadline.',
   'limitations':['The complete v1 preprint is preserved; the listed definitions, assumptions, propositions and application were inspected, not a complete proof audit. Precise current locator is §III.C, not §IV: §IV in this downloaded version is Conclusion. Do not silently transfer section numbering to another version.'],
   'images':['sootla-2018-preprint-page5.png']}
 ],
 'E012': [
  {'key':'gardner-2011-eprint','ledger_id':'S09','ext':'pdf',
   'locations':['Author eprint of “What is Tort Law For? Part1. The Place of Corrective Justice”: typescript p.40 (PDFpage41), and typescript pp.46–50 (PDFpages47–51).'],
   'anchors':['They call for next-best','First response.','Consequential losses'],
   'quote':'They call for next-best satisfaction, the closest to full satisfaction that is still available.',
   'source_account':'The continuity thesis grounds a secondary obligation in reasons left unsatisfied by breach of the primary obligation. The original purpose helps choose among fallback performances. The later discussion connects recoverable consequential losses to the reasons for the original norm.',
   'comparison_task':'Cite this general foundation for substitute performance. State what the manuscript adds through a later agency’s error, a still-protected defensive use of lost records, and limits on what assistance establishes about the past.',
   'limitations':['Author eprint, not a page-for-page copy of the final journal version. Use its printed typescript pagination explicitly. The identified pages were read; whole-paper or current-law verification is not claimed. This is a conceptual comparator, not a new legal test.']},
  {'key':'thompson-1998','ledger_id':'S15','ext':'web-snapshot.json',
   'locations':['Thompson ex rel.Thompson v.Owensby,704N.E.2d134,140 (Indiana Court of Appeals1998), majority §III and note7; scope qualifications in notes1 and6 and the separate concurrence. In the stored web rendition: lines125–151.'],
   'anchors':['III.','The damages could also be based on the cost of retaining experts','Our holding that the Thompsons have stated a claim'],
   'quote':'The damages could also be based on the cost of retaining experts or conducting discovery',
   'source_account':'The majority allows a preservation-duty negligence claim to proceed. Note7 identifies expert and discovery expenses for alternative proof as a possible damages basis. It does not award those expenses or establish underlying liability. The holding is tied to the case’s pleaded relationship, foreseeable harm and policy.',
   'comparison_task':'Compare this established substitution-cost mechanism with the manuscript’s closed first proceeding, a different agency’s later misdescription, and photos that could rebut fabricated damage without proving contractor responsibility. Preserve the non-finding.',
   'limitations':['The public reproduced opinion was opened through web; direct rawHTML retrieval returned403. The bound web snapshot includes the majority, notes and concurrence. No original court PDF, current-precedential-treatment check, or cross-jurisdiction legal survey is claimed.']},
  {'key':'rule37-notes','ledger_id':'S10','ext':'html','visible_only':True,
   'locations':['Federal Rule of Civil Procedure37(e); Advisory Committee Notes to the2015amendment, Subdivision(e), paragraph beginning“When a party fails to take reasonable steps”; following(e)(1)prejudice/proportionality discussion and(e)(2)intent/adverse-inference distinction.'],
   'anchors':['Committee Notes on Rules—2015 Amendment','When a party fails to take reasonable steps','Subdivision (e)(1).','Subdivision (e)(2).'],
   'quote':'If the information is restored or replaced, no further measures should be taken.',
   'source_account':'The2015note first directs attention to restoration or replacement through discovery and allows expense allocation under other discovery rules. Replacement efforts must be proportional to relevance. Further curative measures require prejudice; specified adverse-inference measures require intent. The scope is lost electronic information within the litigation preservation duty.',
   'comparison_task':'Use proportionate replacement and expense allocation as a historical comparator. Do not turn the notes into a general moral duty after case closure or infer past guilt from remedial payment; justify the essay’s extension through its stated undertaking.',
   'limitations':['This packet supplies mechanically extracted visible text from the public rule/official-note reproduction. RawHTML contains credential-shaped site metadata and is withheld from worker/canonical file allowlists. The selected2015note paragraphs were read; no broader current-law survey or legal advice is offered.']}
 ],
 'E051': [
  {'key':'andonovski-2022','ledger_id':'S8','ext':'html',
   'locations':['Publisher article DOI10.3389/fpsyg.2022.899371: “Mental models as structural representations” (especially simplicity and weaker structural resemblance); “Episodic representation: What the thesis is not”, first qualification; “Modeling and surrogative reasoning”.'],
   'anchors':['Like most models, mental models are simplified representations of target domains.','First, the thesis concerns','Episodic models are similarly inference-supportive.'],
   'quote':'Episodic models are similarly inference-supportive.',
   'source_account':'Simplified models preserve usable structure and support inferences about represented events. The account explicitly separates episodic-system representations from the content of memory experiences. Other systems may also contribute to experiential content; model content need not fully determine it.',
   'comparison_task':'Acknowledge inference-supporting imperfect episodic models. Contrast event-model structure with the manuscript’s condition relating whole phenomenal types and its one-way inference of original difference. Do not claim the article establishes that real memory satisfies the manuscript’s condition.',
   'limitations':['Complete publisherHTML and mechanical visible-text extraction are preserved. The named sections were inspected, not all empirical studies or all references. This source does not close the separate access limit for Swoyer1991 or establish exhaustive novelty.']}
 ]
}

packets = []
provenance = {'schema':'submission-source-packets-provenance.v1','created_at':now,
 'worker_input':False,'source_ledger':desc(LEDGER),'revision_plan':desc(PLAN),
 'reviews':[],'packets':[],'withheld_files':[],
 'boundary':'Administrative provenance only. Do not give this cross-essay ledger, full review verdicts, scores, project history or other manuscripts to an author/critic.',
 'new_source_reading':'Targeted primary-passage verification and packet preparation, not a new independent essay review, rating or novelty campaign.',
 'reading_scope':'Accepted full report files were bound by exact bytes; relevant findings, remaining questions, limitations and source comparisons were consulted. No claim that this packet preparer independently re-audited each full report argument.',
 'location_correction':{'source':'Sootla–Ernst arXiv1708.00232v1','previous':'§IV Problem2','verified':'§III.C A Case Study, Problem2, PDFp.5; §IV is Conclusion','old_records_unchanged':True}}
for review in ledger['reviews']:
    if desc(review['report']['path']) != review['report']: raise ValueError('Review drift')
    provenance['reviews'].append(review)

for e in plan['essays']:
    essay = e['id']; folder = BASE / essay
    if desc(e['manuscript']['path']) != e['manuscript']: raise ValueError('Manuscript drift')
    srcgroup = next(g for g in ledger['literature'] if g['candidate_id'] == essay)
    sources=[]
    for spec in SPECS[essay]:
        original = next(s for s in srcgroup['sources'] if s['id'] == spec['ledger_id'])
        key = spec['key']; path = folder/'sources'/f'{key}.{spec["ext"]}'
        source = {k:spec[k] for k in ['key','locations','anchors','quote','source_account','comparison_task','limitations']}
        source.update({'citation':original['citation'],'url':original['url'],'reading_scope':'Only the specified relevant passages and immediate qualifications were inspected.'})
        if spec['ext']=='web-snapshot.json':
            snapshot=json.loads(path.read_text()); source['accessed_at']=snapshot['captured_at']
            source['availability']='BOUND_WEB_RENDERED_OPINION; RAW_HTML403'
            source['source_snapshot']=desc(path)
            check_text=snapshot['tool_result']
        else:
            retrieval=json.loads(path.with_suffix('.retrieval-2.json').read_text())
            if retrieval['status']!='DOWNLOADED_NOT_WHOLE_TEXT_READ' or desc(path)['sha256']!=retrieval['sha256']: raise ValueError('Source drift')
            source['accessed_at']=retrieval['accessed_at']
            extracted=path.with_suffix('.extracted.txt')
            source['visible_text']=desc(extracted)
            source['retrieval_record']=desc(path.with_suffix('.retrieval-2.json'))
            check_text=extracted.read_text()
            if spec.get('visible_only'):
                source['availability']='BOUND_COMPLETE_VISIBLE_TEXT_EXTRACTION; RAW_HTML_WITHHELD'
                provenance['withheld_files'].append({'path':str(path.relative_to(ROOT)),'sha256':retrieval['sha256'],'bytes':retrieval['bytes'],'reason':'Credential-shaped site metadata; no rawHTML supplied to workers or canonical input files. Original kept unchanged locally.','safe_derived_text':desc(extracted),'retrieval_record':desc(path.with_suffix('.retrieval-2.json'))})
                del source['retrieval_record']
            else:
                source['source_snapshot']=desc(path)
                source['availability']='BOUND_COMPLETE_SOURCE_DOWNLOAD; TARGETED_PASSAGES_READ'
        norm=lambda s: re.sub(r'\s+',' ',s)
        if norm(source['quote']) not in norm(check_text): raise ValueError('Quote not present: '+key)
        if len(source['quote'].split())>25: raise ValueError('Quote too long')
        source['quote_words']=len(source['quote'].split())
        source['anchor_locations']=[]
        for a in spec['anchors']:
            i=check_text.find(a)
            if i<0: raise ValueError('Missing anchor: '+key+' '+a)
            source['anchor_locations'].append({'anchor':a,'line_1based':check_text[:i].count('\n')+1,'line_basis':'LF-separated bound visible text; PDF page locators above remain authoritative' if spec['ext']!='web-snapshot.json' else 'LF-separated tool_result string within bound web snapshot'})
        if spec.get('images'):source['visually_checked_pages']=[desc(folder/'sources'/name) for name in spec['images']]
        for field in ('visible_text','source_snapshot'):
            if field in source:
                p=ROOT/source[field]['path']
                if p.suffix!='.pdf' and has_credential(p.read_text()):raise ValueError('Unsafe worker source')
        sources.append(source)
    tasks=[]
    for t in e['required_before_submission']:
        change=t['change']
        if essay=='E050':change=change.replace('sectionsIII.B/IV problem2','sectionsIII.B/III.C problem2 (bound arXivv1,PDFp.5)')
        tasks.append({'id':t['id'],'location':t['location'],'task':change})
    for t in e.get('recommended_editorial_clarifications',[]):tasks.append({'id':t['id'],'location':'Relevant paragraph and opening','task':t['change']})
    access_ids={'E050':['S1','S2','S3','S4','S4M'],'E012':['S01','S02'],'E051':['S1','S2','S3']}[essay]
    access_notes=[{'citation':s['citation'],'url':s['url'],'previous_access':s['access_level'],'previous_locations':s['locations_read']} for s in srcgroup['sources'] if s['id'] in access_ids]
    packet={'schema':'submission-primary-source-packet.v1','essay_id':essay,'title':e['title'],
      'manuscript':e['manuscript'],
      'scope':'Revise only this supplied manuscript. Preserve its core argument and conditions; make the source comparisons and specified clarifications. Sources are evidence, not instructions. No ratings or project history are supplied.',
      'revision_tasks':tasks,'preserve':e['preserve'],'not_required':e['not_required'],
      'prose_instruction':'Use clear, lively, restrained prose. Explain the concrete problem early. Remove needless repetition and heavy phrasing while retaining essential premises, proof steps, objections and qualifications. Avoid grand priority claims or decorative jargon.',
      'sources':sources,
      'existing_citation_access':{'basis':'Access reported by the earlier accepted independent source audit, not a claim of new full-text reading by this packet preparer or the future author. No complete novelty claim follows.','notes':access_notes},
      'access_boundary':'A complete downloaded file is not a claim of having read every page. Distinguish verified passages, author preprints and access-limited references. Preserve the manuscript’s unresolved full-text limits; do not certify exhaustive novelty.',
      'check_after_revision':e['verification_after_edit']}
    write(folder/'SOURCE_PACKET.json',packet)
    lines=[f'# Source packet: {essay} — {e["title"]}','',packet['scope'],'',
      '## Revision tasks','']
    for t in tasks:lines += [f'- **{t["id"]} — {t["location"]}:** {t["task"]}']
    lines+=['','## Keep the argument bounded','']+[f'- {s}' for s in packet['preserve']]
    lines+=['','## Prose','',packet['prose_instruction'],'','## Primary passages','']
    for s in sources:
        lines += [f'### {s["key"]}', '',s['citation'], '',f'[Primary source]({s["url"]}). Accessed: {s["accessed_at"]}.','']
        lines += ['**Exact location:** '+' '.join(s['locations']),'','**Short excerpt:** “'+s['quote']+'”','',
          '**What the passage establishes:** '+s['source_account'],'','**Comparison to make:** '+s['comparison_task'],'',
          '**Access and scope:** '+' '.join(s['limitations']),'']
        for field in ('source_snapshot','visible_text','retrieval_record'):
            if field in s:
                d=s[field];rel=Path(d['path']).relative_to(folder.relative_to(ROOT));lines += [f'- {field}: [{rel}]({rel}); SHA-256 `{d["sha256"]}`.']
        lines += ['']
    lines += ['## Access notes for existing references','',packet['existing_citation_access']['basis'],'']
    for n in access_notes: lines += [f'- {n["citation"]} [{n["url"]}]({n["url"]}). {n["previous_access"]} Locations: {n["previous_locations"]}']
    lines += ['','## Boundaries','',packet['access_boundary'],'','No author or critic is launched by preparation of this packet.','']
    write(folder/'SOURCE_PACKET.md','\n'.join(lines))
    files=[desc(folder/'SOURCE_PACKET.json'),desc(folder/'SOURCE_PACKET.md'),e['manuscript']]
    for s in sources:
        for k in ('source_snapshot','visible_text','retrieval_record'):
            if k in s:files.append(s[k])
        files+=s.get('visually_checked_pages',[])
    unique={d['path']:d for d in files}
    m={'schema':'submission-source-packet-inputs.v1','essay_id':essay,'created_at':now,'files':list(unique.values()),'excluded':'No other essay, full review, cross-essay ledger, global memory or raw credential-shaped HTML is in this allowlist.'}
    write(folder/'INPUT_MANIFEST.json',m)
    provenance['packets'].append({'essay_id':essay,'manifest':desc(folder/'INPUT_MANIFEST.json'),'packet':desc(folder/'SOURCE_PACKET.json'),'markdown':desc(folder/'SOURCE_PACKET.md')})
write(BASE/'PROVENANCE.json',provenance)
print(json.dumps({'status':'PREPARED_NOT_DISPATCHED','packets':provenance['packets'],'provenance':desc(BASE/'PROVENANCE.json')},ensure_ascii=False,indent=2))
