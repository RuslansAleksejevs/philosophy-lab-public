"""Freeze separate neutral critic packets only after canonical author acceptance."""
from pathlib import Path
import hashlib,importlib.util,json
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1]
spec=importlib.util.spec_from_file_location('revision_critic_preparation_common',RUN/'technical/common.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ref(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'sha256':sha(raw),'bytes':len(raw)}
def save(p,raw):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)
 return ref(p)
def main():
 accepted=json.loads((RUN/'AUTHORS_ARCHIVE_RECEIPT.json').read_text());event=C.direct_event(accepted)
 assert accepted['status']=='SUBMISSION_AUTHORS_ARCHIVED'
 assert event['kind']=='research.revision.wave.accepted' and event['payload']['roles']==accepted['roles']
 assert {r['essay_id'] for r in accepted['roles']}==C.ESSAYS
 bases=json.loads((RUN/'LINEAGE_INPUTS.json').read_text())['essays'];jobs=[]
 for row in sorted(accepted['roles'],key=lambda r:r['essay_id']):
  eid=row['essay_id'];revision=row['revision'];expected={'job_id':eid+'-critic','essay_id':eid,'scientific_role':'critic','manuscript_sha256':revision['sha256']}
  prompt=('Independently check the following single-essay revision. Do not invoke any tools. Return only the required final JSON.\nExact output identity: '+json.dumps(expected)+'\n\n').encode()
  paths=[('INDEPENDENT CHECKING INSTRUCTIONS',RUN/'CRITIC_INSTRUCTIONS.txt'),('PRESERVED ORIGINAL',ROOT/bases[eid]['manuscript']['path']),('REVISED MANUSCRIPT',ROOT/revision['path']),('MECHANICAL DIFF',ROOT/row['diff']['path']),('PRIMARY PASSAGES',RUN/'source-packets'/eid/'PRIMARY_PASSAGES.txt'),('SOURCE ACCESS NOTES',RUN/'source-packets'/eid/'SOURCE_ACCESS_NOTES.txt'),('REQUIRED FINAL JSON SCHEMA',RUN/'schema/critic.json')]
  inline=[];manuscript_start=None;raw=C.B.bound(revision,ROOT)
  for label,p in paths:
   body=p.read_bytes();prompt+=('\n----- BEGIN '+label+' -----\n').encode();start=len(prompt);prompt+=body
   inline.append({**ref(p),'prompt_byte_start':start,'prompt_byte_length':len(body)})
   if label=='REVISED MANUSCRIPT':manuscript_start=start
   prompt+=('\n----- END '+label+' -----\n').encode()
  pr=save(RUN/'packets'/eid/'critic/prompt.txt',prompt);sc=ref(RUN/'schema/critic.json')
  jobs.append({'id':eid+'-critic','essay_id':eid,'model':'gpt-6-astra','effort':'ultra','service_tier':'default','role':'argument','scientific_role':'critic','transport_profile':'no_tools','web_search':'disabled','manuscript_id':eid,'manuscript_file':revision['path'],'manuscript_sha256':revision['sha256'],'manuscript_byte_start':manuscript_start,'manuscript_byte_length':len(raw),'prompt_file':pr['path'],'prompt_sha256':pr['sha256'],'schema_file':sc['path'],'schema_sha256':sc['sha256'],'expected_output':expected,'inline_inputs':inline,'independence_group':eid+'-critic','max_external_attempts':1})
 result={'schema':'submission-revision-jobs.v1','run_id':RUN.name,'wave':'critics','author_wave_event_id':accepted['event_id'],'jobs':jobs}
 save(RUN/'jobs-critics.json',(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
 print(json.dumps({'status':'THREE_INDEPENDENT_CRITIC_PACKETS_FROZEN','jobs':[j['id'] for j in jobs],'prompt_bytes':[len((ROOT/j['prompt_file']).read_bytes()) for j in jobs],'model_calls':0,'author_logs_provided':False,'old_verdicts_provided':False}))
if __name__=='__main__':main()
