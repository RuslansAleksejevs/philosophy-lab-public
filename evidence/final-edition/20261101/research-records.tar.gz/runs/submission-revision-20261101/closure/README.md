# Конечная приёмка трёх редакций

Этот helper завершает только редакции E050, E012 и E051. Он не запускает
модели, службу, новые исследования, публикацию или подачу. Успешная конечная
квитанция имеет статус `SUBMISSION_REVISIONS_VERIFIED_BOUNDED`; это готовность
содержания, а не подтверждение анонимного пакета или отправки.

## Условия

1. Две принятые волны и все шесть отдельных ролей должны точно совпадать
   с каноническими событиями, файлами, сессиями и родительскими версиями.
   Перед разбором ответов проверяются метаданные всех шести приёмок.
2. Все три критика должны сообщить `READY`, прочитать исходную и новую
   рукопись (`read_original_complete` и `read_revision_complete` равны true).
   `MINOR_FIXES`, `SUBSTANTIVE_REPAIR` или серьёзная ошибка вместе с `READY`
   блокируют завершение. Решение координатора этого не обходит.
3. `selected/E050.md`, `selected/E012.md`, `selected/E051.md` — точные байты
   авторских `derived/revision.md`. Helper не создаёт и не редактирует их.
4. Исходные рукописи из `LINEAGE_INPUTS.json` сверяются с прежней lineage и
   каноническими объектами; их хеши повторно проверяются после checkpoint.
5. Содержательные выводы поздних файлов координатора не объявляются
   результатом независимой проверки. В конечной квитанции отдельно сохранены
   реальные сессии, принятые отзывы, native-check и записанная конфигурация.

## Файлы координатора и REQUEST

Root создаёт `closure/REQUEST.json` после приёмки критиков. Дескриптор везде
означает `{path, sha256, bytes}`; `path` относительно корня Philosophy Lab.
Не заполнять будущие события предположительными значениями.

```json
{
  "schema": "submission-revisions-closure.v1",
  "run_id": "submission-revision-20261101",
  "session_id": "01a190b5-03e2-70d0-8fcf-b4a1e67148d0",
  "selected": ["E050", "E012", "E051"],
  "wave_receipts": {
    "authors": "descriptor: AUTHORS_ARCHIVE_RECEIPT.json",
    "critics": "descriptor: CRITICS_ARCHIVE_RECEIPT.json"
  },
  "role_receipts": ["six descriptors: results/ESSAY-author|critic/ARCHIVE_RECEIPT.json"],
  "lineage_inputs": "descriptor: LINEAGE_INPUTS.json",
  "selected_files": {
    "E050": "descriptor: selected/E050.md",
    "E012": "descriptor: selected/E012.md",
    "E051": "descriptor: selected/E051.md"
  },
  "artifacts": {
    "decisions": "descriptor: coordinator/DECISIONS.json",
    "summary": "descriptor: coordinator/CHANGE_SUMMARY_RU.md",
    "word_counts": "descriptor: coordinator/WORD_COUNTS.json",
    "source_ledger": "descriptor: coordinator/SOURCE_LEDGER.json",
    "checkpoint": "descriptor: coordinator/CHECKPOINT.json"
  },
  "capture_selection": "descriptor: coordinator/CAPTURE_SELECTION.json"
}
```

Это поясняющий шаблон; строки `descriptor: ...` заменяются объектами.
`DECISIONS.json`, `WORD_COUNTS.json`, `SOURCE_LEDGER.json` содержат верхние
поля `selected` (тот же упорядоченный список) и `coordinator_session_id`.
У `DECISIONS.json` также ровно три строки `decisions`:

```json
{
  "essay_id": "E050",
  "selected_manuscript": "descriptor: selected/E050.md",
  "author_event_id": "actual accepted author event",
  "critic_event_id": "actual accepted critic event",
  "critic_decision": "READY",
  "coordinator_decision": "USE_REVISION",
  "reason": "Конкретная причина выбора этой версии.",
  "limitations": ["Сохраняемые ограничения."]
}
```

Source ledger может ссылаться на замороженные source-packet manifests и
точные принятые отзывы. Не нужно копировать весь текст отзывов. Подсчёт слов
и утверждения coordinator artifacts привязываются как выводы координатора;
helper их не выдаёт за новую научную проверку.

`CHECKPOINT.json` содержит девять непустых строк: `question`, `outcome`,
`contribution`, `criticism`, `limitations`, `next_step`, `method_change`,
`comparability`, `coverage_boundary`; `outcome` строго `CONTINUE`.
Конечное content-only завершение отдельно от исторического административного
`INCOMPLETE` и `NOT_CERTIFIED`.

`CAPTURE_SELECTION.json` — точные две строки фактического root tool call/result,
создавшего или зафиксировавшего итоговые файлы: `session_id` как выше,
`max_bytes: 536870912`, `start_line`, `end_line`, `reviewed_tool_lines`
(две уникальные возрастающие строки после 34736),
`raw_records: [{source_line, sha256}, {source_line, sha256}]`.
Штатный capture обязан подтвердить ровно два raw records и одну связь tool.
Никакой реконструкции отсутствующей реплики координатора не производится.

## Заморозка и запуск

После независимого review root связывает `closure/MANIFEST.json`:
`status: SUBMISSION_REVISION_CLOSURE_PREPARED`, `files` — ровно 11 дескрипторов:
три файла этого helper (`close_revisions.py`, `test_close_revisions.py`,
`README.md`), `technical/{common_v2,archive_v2,runner_v2}.py`,
`scripts/{research_archive,philosophy_round,essay_lineage,capture_codex,codex_rollout}.py`.
Это отдельный closure manifest; ранее замороженные 101 author inputs не меняются.
Технический gate использует `INPUT_MANIFEST-v2.json` для авторов и
`CRITIC_INPUT_MANIFEST.json` для критиков. Исправленный `METHOD-v2.json`
добавляет обязательные стадии; проверка сохранности исходных 101 файлов
выполняется самим замороженным `common_v2.py`.

Проверка локальных входов, без writer:

```sh
python3 -B runs/submission-revision-20261101/closure/close_revisions.py --check
```

Полная проверка канонических данных и конечная запись, только root:

```sh
python3 -B runs/submission-revision-20261101/closure/close_revisions.py --apply --allow-checkpoint-derived-updates
```

Если у root уже открыт проверенный writer, использовать тот же capability:

```python
ctx, refs = close_revisions.prepare(request_path)
receipt = close_revisions.finish(ctx, writer, refs,
    allow_checkpoint_derived_updates=True)
```

Не открывать второй writer. `finish` повторно сверяет входы под тем же lock.
Он сохраняет closure inputs, точную пару реплик координатора, четыре
атрибутированных stage indexes и три selection lineage. Затем вызывает один
штатный checkpoint с его derived refresh и записывает конечную квитанцию
`runs/submission-revision-20261101/FINAL_RECEIPT.json`.
Повтор использует те же delivery keys и точные bytes; прежние записи не
заменяются. Сбой до локальной квитанции допускает повтор с тем же REQUEST.
Сбой внутри штатного checkpoint может повторить derived rendering, но не
создаёт второй checkpoint. Отдельного checkpoint на эссе нет.

## Синтетические проверки

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/closure -p test_close_revisions.py
```

Тесты используют отдельный временный каталог и fake writer. Они проверяют
границы приёмки, точные версии, отсутствие override критика, конфигурацию,
смену входов, symlinks, повтор и сохранность оригиналов. Они не запускают
реальный архив, native capture, модели или службу. Реальные scientific
outputs используются только позднее после их канонической приёмки.
