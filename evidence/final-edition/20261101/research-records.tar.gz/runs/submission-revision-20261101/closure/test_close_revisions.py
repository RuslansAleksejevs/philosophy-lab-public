"""Synthetic closure gates; no real native, provider, collector or project archive."""
from pathlib import Path
import copy
import importlib.util
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('revision_close_test',Path(__file__).with_name('close_revisions.py'))
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)

class Writer:
    def __init__(self,records,objects):self._state={'records':records,'seen':{e['id']:e for e in records}};self.objects=objects
    def _ensure_audited(self):pass
    def get(self,h):return self.objects[h]
    def put(self,raw):h=M.B.sha(raw);self.objects[h]=raw;return h
    def append(self,request,key):
        old=next((e for e in self._state['records'] if e['delivery_key']==key),None)
        if old:
            if any(old.get(k)!=v for k,v in request.items()):raise ValueError('Synthetic retry conflict')
            return old
        e=dict(request,id='appended-'+str(len(self._state['records'])),sequence=len(self._state['records'])+1,
               sha256=M.B.sha(M.B.encoded(request)),delivery_key=key)
        self._state['records'].append(e);self._state['seen'][e['id']]=e;return e

class Closure(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name);self.run=self.root/'runs/submission-revision-20261101'
        self.events=[];self.objects={};self.contexts={};self.bindings={k:[] for k in ('method','instruction','config','input')}
        self.first=self.event('start','operation.started',{'protocol':'philosophy-round.v1'})
        qref=self.save(self.run/'QUESTION_RU.txt',b'Synthetic question\n')
        self.q=self.event('question','round.stage',{'stage':'question'},outputs=[qref['sha256']])
        self.qcov=self.event('qcov','capture.coverage',{'status':'BOUNDED_COMPLETE'})
        prior_plan=self.save(self.root/'prior/PLAN.json',{'synthetic':True})
        prior_payload={'status':'TRIO_VERIFICATION_AND_PLAN_COMPLETE_BOUNDED','plan':prior_plan}
        prior=self.event('prior-plan','research.verification.completed',prior_payload,run='old')
        prior_receipt=self.save(self.root/'prior/FINAL_RECEIPT.json',dict(prior_payload,event_id=prior['id']))
        self.bases={'schema':'submission-revision-lineage.v1','essays':{},'prior_plan':prior_plan,'prior_plan_receipt':prior_receipt,'prior_plan_event_id':prior['id']}
        for eid in M.SELECTED:
            original=self.save(self.root/'originals'/(eid+'.md'),('Original '+eid+'\n').encode())
            parent=self.lineage('base-'+eid,'entity/'+eid,'legacy_inventory',[],[],[original],'old-session')
            self.bases['essays'][eid]={'entity':'entity/'+eid,'parent_entry':'base-'+eid,'parent_event':parent['id'],'manuscript':original}
            self.lineage(self.run.name+':'+eid+':assigned','entity/'+eid,'selection',['base-'+eid],[self.first['id']],[original],M.C.SID)
        lineage_ref=self.save(self.run/'LINEAGE_INPUTS.json',self.bases)
        self.wave_refs={};self.role_refs=[];self.roles={};self.role_events={};self.responses={}
        self.selected={}
        for wave,role in [('authors','author'),('critics','critic')]:
            inref=self.save(self.run/(wave+'-input.json'),{'synthetic':wave})
            parents=[self.first['id']] if wave=='authors' else [self.waves['authors']['id']]
            payload={'status':M.C.STATUSES[wave],'files':[inref],'question_stage_event_id':self.q['id'],'question_coverage_event_id':self.qcov['id']}
            start=self.event(wave+'-input',M.C.KINDS[wave],payload,parents=parents)
            ctx={'root':self.root,'run':self.run,'wave':wave,'files':[inref],'start':self.receipt(start),'jobs':{}}
            rows=[]
            for eid in M.SELECTED:
                jid=eid+'-'+role;sid='synthetic-session-'+jid;orig=self.bases['essays'][eid]['manuscript']
                prompt=self.save(self.run/'packets'/jid/'prompt.txt',('Prompt '+jid).encode());schema=self.save(self.run/'schema'/(jid+'.json'),{'type':'object'})
                expected={'job_id':jid,'essay_id':eid,'scientific_role':role,'manuscript_sha256':orig['sha256']}
                job=dict(id=jid,essay_id=eid,scientific_role=role,model='gpt-6-astra',effort='ultra',service_tier='default',
                         prompt_file=prompt['path'],prompt_sha256=prompt['sha256'],schema_file=schema['path'],schema_sha256=schema['sha256'],expected_output=expected,inline_inputs=[])
                if role=='author':
                    val=dict(expected,read_complete=True,manuscript_markdown='Revised '+eid+'\n')
                    revision=self.save(self.run/'results'/jid/'derived/revision.md',val['manuscript_markdown'].encode())
                    diff=self.save(self.run/'results'/jid/'derived/changes.diff',b'Synthetic diff\n')
                    self.selected[eid]=self.save(self.run/'selected'/(eid+'.md'),val['manuscript_markdown'].encode())
                    extras=[revision,diff]
                else:
                    val=dict(expected,read_original_complete=True,read_revision_complete=True,decision='READY',findings=[])
                    author=self.roles[eid+'-author'];extras=[];job['inline_inputs']=[orig,author['revision'],author['diff']]
                rp=self.run/'results'/jid/'attempt-001/response.json';response=self.save(rp,val);self.responses[jid]=rp
                proof=self.save(rp.parent/'native-check.json',{'synthetic':True})
                receipt=self.save(rp.parent/'receipt.json',dict(status=M.B.COMPLETE,job_id=jid,session_id=sid,requested_model=job['model'],requested_effort=job['effort'],requested_service_tier=job['service_tier'],prompt_sha256=prompt['sha256'],schema_sha256=schema['sha256'],outputs={response['path']:response['sha256'],proof['path']:proof['sha256']}))
                parent=self.run.name+':'+eid+':assigned' if role=='author' else self.roles[eid+'-author']['lineage_entry_id']
                parent_event=next(e for e in self.events if e['kind']=='essay.lineage.entry' and e['payload']['entry']['id']==parent)
                files=[response,proof,receipt]+extras
                accepted=self.event('accepted-'+jid,'research.revision.role.accepted',dict(status='SUBMISSION_REVISION_ROLE_ARCHIVED',job_id=jid,essay_id=eid,scientific_role=role,transport_profile='no_tools',transport_role='argument',receipt=receipt,native_check=proof,files=files,scientific=True,independence_verified=True),sid=sid,parents=[start['id'],parent_event['id']])
                ident=self.run.name+':'+eid+':'+role+':v1'
                le=self.lineage(ident,'entity/'+eid,'revision' if role=='author' else 'critique',[parent],[accepted['id']],extras if role=='author' else [response],sid,job=jid)
                row={'job_id':jid,'essay_id':eid,'scientific_role':role,'session_id':sid,'event_id':accepted['id'],'lineage_event_id':le['id'],'lineage_entry_id':ident,'receipt':receipt}
                if role=='author':row.update(revision=revision,diff=diff)
                self.roles[jid]=row;self.role_events[jid]=accepted;rows.append(row);ctx['jobs'][jid]=job
                local=self.save(self.run/'results'/jid/'ARCHIVE_RECEIPT.json',dict(self.receipt(accepted),**row));self.role_refs.append(local)
            we=self.event(wave+'-wave','research.revision.wave.accepted',{'status':'SUBMISSION_'+wave.upper()+'_ARCHIVED','roles':rows,'scientific_results_accepted':3},parents=[start['id']]+[r[k] for r in rows for k in ('event_id','lineage_event_id')])
            if not hasattr(self,'waves'):self.waves={}
            self.waves[wave]=we;self.wave_refs[wave]=self.save(self.run/(wave.upper()+'_ARCHIVE_RECEIPT.json'),self.receipt(we));self.contexts[wave]=ctx
        self.summary={k:'Synthetic '+k for k in M.FIELDS};self.summary['outcome']='CONTINUE'
        decisions={'selected':M.SELECTED,'coordinator_session_id':M.C.SID,'decisions':[{'essay_id':eid,'selected_manuscript':self.selected[eid],'author_event_id':self.roles[eid+'-author']['event_id'],'critic_event_id':self.roles[eid+'-critic']['event_id'],'critic_decision':'READY','coordinator_decision':'USE_REVISION','reason':'Synthetic stated reason','limitations':['Synthetic limitation']} for eid in M.SELECTED]}
        self.arts={}
        for key,name in M.ARTIFACTS.items():
            val=decisions if key=='decisions' else self.summary if key=='checkpoint' else b'Synthetic summary\n' if key=='summary' else {'selected':M.SELECTED,'coordinator_session_id':M.C.SID}
            self.arts[key]=self.save(self.run/'coordinator'/name,val)
        self.selection={'session_id':M.C.SID,'max_bytes':512*1024*1024,'start_line':40000,'end_line':40003,'reviewed_tool_lines':[40000,40003],'raw_records':[{'source_line':40000,'sha256':'a'*64},{'source_line':40003,'sha256':'b'*64}]}
        selection=self.save(self.run/'coordinator/CAPTURE_SELECTION.json',self.selection)
        impl=[self.save(p,b'# synthetic implementation\n') for p in M.implementation_paths(self.root,self.run)]
        self.save(self.run/'closure/MANIFEST.json',{'status':'SUBMISSION_REVISION_CLOSURE_PREPARED','files':impl})
        self.request={'schema':'submission-revisions-closure.v1','run_id':self.run.name,'session_id':M.C.SID,'selected':M.SELECTED,'lineage_inputs':lineage_ref,'wave_receipts':self.wave_refs,'role_receipts':self.role_refs,'selected_files':self.selected,'artifacts':self.arts,'capture_selection':selection}
        self.request_path=self.run/'closure/REQUEST.json';self.save(self.request_path,self.request)
        self.gate=patch.object(M.C,'gate',side_effect=lambda wave,run,root:self.contexts[wave]);self.gate.start();self.w=Writer(self.events,self.objects)
    def tearDown(self):self.gate.stop();self.tmp.cleanup()
    def save(self,path,val):
        raw=val if isinstance(val,bytes) else M.B.encoded(val);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        ref=M.B.descriptor(path,self.root);self.objects[ref['sha256']]=raw;return ref
    def event(self,eid,kind,payload,sid=None,parents=None,outputs=None,run=None):
        e=dict(id=eid,kind=kind,payload=payload,session_id=sid or M.C.SID,run_id=run or self.run.name,sequence=len(self.events)+1,sha256=M.B.sha(eid.encode()),delivery_key='synthetic:'+eid,parents=parents or [],outputs=outputs or [],bindings=self.bindings)
        self.events.append(e);return e
    def receipt(self,e):return {'event_id':e['id'],'event_sequence':e['sequence'],'event_sha256':e['sha256'],'status':e['payload'].get('status'),'files':e['payload'].get('files',[]),'roles':e['payload'].get('roles',[]),'bindings':e['bindings']}
    def lineage(self,ident,entity,kind,parents,evidence,artifacts,sid,job=None):
        ent=M.L.base_entry(ident,entity,kind,'Synthetic lineage');ent.update(parents=parents,evidence=evidence,artifacts=[dict(a,role='synthetic') for a in artifacts],actor={'role':'AI','session_id':sid},workflow={'run_id':self.run.name,'job_id':job})
        return self.event('lineage-'+ident,'essay.lineage.entry',{'protocol':M.L.PROTOCOL,'entry':ent},sid=sid,parents=evidence,run='essay-lineage')
    def data(self):return M.local_check(self.request_path,self.root,self.run)
    def canonical(self):return M.canonical_check(self.data(),self.w)
    def rewrite_request(self):self.save(self.request_path,self.request)
    def change_response(self,jid,**updates):
        p=self.responses[jid];val=M.B.load(p,self.root);val.update(updates);old=M.B.descriptor(p,self.root);new=self.save(p,val)
        event=self.role_events[jid];files=event['payload']['files'];files[files.index(old)]=new
        rp=self.root/self.roles[jid]['receipt']['path'];rv=M.B.load(rp,self.root);rv['outputs'][new['path']]=new['sha256'];oldreceipt=self.roles[jid]['receipt'];newreceipt=self.save(rp,rv)
        files[files.index(oldreceipt)]=newreceipt;event['payload']['receipt']=newreceipt;self.roles[jid]['receipt']=newreceipt
        for le in self.events:
            if le['kind']=='essay.lineage.entry':
                for a in le['payload']['entry']['artifacts']:
                    if a['path']==old['path']:a.update(sha256=new['sha256'],bytes=new['bytes'])
        for wave in ('authors','critics'):
            self.wave_refs[wave]=self.save(self.run/(wave.upper()+'_ARCHIVE_RECEIPT.json'),self.receipt(self.waves[wave]))
        i=next(i for i,r in enumerate(self.role_refs) if r['path'].endswith('/'+jid+'/ARCHIVE_RECEIPT.json'))
        self.role_refs[i]=self.save(self.root/self.role_refs[i]['path'],dict(self.receipt(event),**self.roles[jid]));self.rewrite_request()

    def test_exact_six_roles_three_selected_and_unchanged_originals(self):
        c=self.canonical();self.assertEqual(len(c['reports']),6);self.assertEqual(len(c['selected']),3)
    def test_missing_sixth_acceptance_blocks_before_response_read(self):
        self.events.remove(self.role_events['E051-critic']);reads=[];original=M.B.bound
        def track(ref,root):
            if ref['path'].endswith('/response.json'):reads.append(ref['path'])
            return original(ref,root)
        with patch.object(M.B,'bound',side_effect=track),self.assertRaisesRegex(ValueError,'commitment'):self.canonical()
        self.assertEqual(reads,[])
    def test_critic_minor_fixes_cannot_be_coordinator_overridden(self):
        self.change_response('E050-critic',decision='MINOR_FIXES')
        with self.assertRaisesRegex(ValueError,'Critic requests fixes'):self.canonical()
    def test_critic_substantial_repair_blocks(self):
        self.change_response('E012-critic',decision='SUBSTANTIVE_REPAIR')
        with self.assertRaisesRegex(ValueError,'Critic requests fixes'):self.canonical()
    def test_both_read_flags_required(self):
        self.change_response('E051-critic',read_original_complete=False)
        with self.assertRaisesRegex(ValueError,'read both'):self.canonical()
    def test_revision_read_flag_required(self):
        self.change_response('E051-critic',read_revision_complete=False)
        with self.assertRaisesRegex(ValueError,'read both'):self.canonical()
    def test_ready_with_major_finding_rejected(self):
        self.change_response('E051-critic',findings=[{'severity':'major'}])
        with self.assertRaisesRegex(ValueError,'serious findings'):self.canonical()
    def test_author_did_not_read_original_rejected(self):
        self.change_response('E050-author',read_complete=False)
        with self.assertRaisesRegex(ValueError,'Author did not read'):self.canonical()
    def test_exact_selected_bytes_required_even_with_rebound_request(self):
        eid='E050';self.selected[eid]=self.save(self.root/self.selected[eid]['path'],b'Changed selected text\n')
        d=M.B.load(self.root/self.arts['decisions']['path'],self.root);d['decisions'][0]['selected_manuscript']=self.selected[eid]
        self.arts['decisions']=self.save(self.root/self.arts['decisions']['path'],d);self.rewrite_request()
        with self.assertRaisesRegex(ValueError,'exact accepted revision copy'):self.canonical()
    def test_original_drift_rejected(self):
        (self.root/self.bases['essays']['E012']['manuscript']['path']).write_bytes(b'Changed original')
        with self.assertRaisesRegex(ValueError,'Bound file changed'):self.data()
    def test_critic_parent_must_be_its_author(self):
        e=next(e for e in self.events if e['id']==self.roles['E012-critic']['lineage_event_id']);e['payload']['entry']['parents']=[self.roles['E050-author']['lineage_entry_id']]
        with self.assertRaisesRegex(ValueError,'lineage attribution'):self.canonical()
    def test_six_distinct_sessions_required(self):
        e=self.role_events['E051-critic'];sid=self.roles['E050-author']['session_id'];e['session_id']=sid;self.roles['E051-critic']['session_id']=sid
        self.wave_refs['critics']=self.save(self.run/'CRITICS_ARCHIVE_RECEIPT.json',self.receipt(self.waves['critics']))
        i=next(i for i,r in enumerate(self.role_refs) if 'E051-critic' in r['path']);self.role_refs[i]=self.save(self.root/self.role_refs[i]['path'],dict(self.receipt(e),**self.roles['E051-critic']));self.rewrite_request()
        with self.assertRaisesRegex(ValueError,'distinct'):self.canonical()
    def test_wrong_canonical_commitment_rejected(self):
        p=self.root/self.wave_refs['critics']['path'];v=M.B.load(p,self.root);v['event_sha256']='f'*64;self.wave_refs['critics']=self.save(p,v);self.rewrite_request()
        with self.assertRaisesRegex(ValueError,'commitment'):self.canonical()
    def test_critic_missing_diff_rejected(self):
        self.contexts['critics']['jobs']['E050-critic']['inline_inputs'].pop()
        with self.assertRaisesRegex(ValueError,'original/revision/diff'):self.canonical()
    def test_wrong_runtime_setting_rejected(self):
        self.contexts['authors']['jobs']['E050-author']['effort']='high'
        with self.assertRaisesRegex(ValueError,'configuration'):self.canonical()
    def test_wrong_coordinator_review_reference_rejected(self):
        p=self.root/self.arts['decisions']['path'];d=M.B.load(p,self.root);d['decisions'][0]['critic_event_id']='other';self.arts['decisions']=self.save(p,d);self.rewrite_request()
        with self.assertRaisesRegex(ValueError,'Coordinator decision'):self.canonical()
    def test_capture_must_be_after_authorization(self):
        self.selection['raw_records'][0]['source_line']=34736;self.request['capture_selection']=self.save(self.run/'coordinator/CAPTURE_SELECTION.json',self.selection);self.rewrite_request()
        with self.assertRaisesRegex(ValueError,'Two exact coordinator'):self.data()
    def test_selected_symlink_rejected(self):
        p=self.root/self.selected['E050']['path'];raw=p.read_bytes();p.unlink();q=self.root/'other.md';q.write_bytes(raw);p.symlink_to(q)
        with self.assertRaises(ValueError):self.data()
    def test_finish_requires_explicit_derived_permission(self):
        d=self.data()
        with self.assertRaisesRegex(ValueError,'derived-update'):M.finish(d,self.w,d['files'])
    def test_finish_rechecks_inputs_after_prepare(self):
        d=self.data();(self.root/self.arts['summary']['path']).write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'Bound file changed'):M.finish(d,self.w,d['files'],allow_checkpoint_derived_updates=True)
    def test_one_checkpoint_capture_and_selection_lineages_on_retry(self):
        d=self.data();calls=[]
        def cp(root,w,run,path,coverage,incomplete):
            calls.append(incomplete);e=w.append({'kind':'checkpoint','run_id':run,'payload':{'capture_status':'INCOMPLETE','truth_status':'NOT_CERTIFIED','summary':self.summary},'outputs':[d['artifacts']['checkpoint']['sha256']]},'synthetic-checkpoint')
            w.append({'kind':'operation.interrupted','run_id':run,'payload':{'checkpoint':e['id']}},'synthetic-terminal');return e
        cap={'status':'BOUNDED_COMPLETE','captured_records':2,'tool_link_ids':['link'],'raw_records':self.selection['raw_records'],'coverage_event_id':'synthetic-capture-coverage','raw_event_ids':['synthetic-call','synthetic-result']}
        with patch.object(M.B,'resolve_session',return_value=self.root/'synthetic-native'),patch.object(M.B,'SessionWriter',return_value=self.w),patch.object(M.B,'capture',return_value=cap) as capture:
            first=M.close_with_writer(d,self.w,cp);second=M.close_with_writer(d,self.w,cp)
        self.assertEqual(first,second);self.assertEqual(calls,[True]);self.assertEqual(capture.call_count,1)
        self.assertEqual(first['status'],M.STATUS);self.assertTrue(first['content_only']);self.assertFalse(first['submission_authorized'])
        self.assertEqual(len(first['selected_lineage_event_ids']),3)
        critique=next(e for e in self.events if e['kind']=='research.revision.stage' and e['payload']['stage']=='critique')
        self.assertEqual(critique['payload']['coordinator_evidence_event_ids'],[])
        self.assertEqual({r['scientific_role'] for r in critique['payload']['per_item_attribution']},{'critic'})
    def test_retry_after_durable_completion_before_local_receipt_reuses_all_events(self):
        d=self.data();calls=[]
        def cp(root,w,run,path,coverage,incomplete):
            calls.append(True);e=w.append({'kind':'checkpoint','run_id':run,'payload':{'capture_status':'INCOMPLETE','truth_status':'NOT_CERTIFIED','summary':self.summary},'outputs':[d['artifacts']['checkpoint']['sha256']]},'synthetic-checkpoint')
            w.append({'kind':'operation.interrupted','run_id':run,'payload':{'checkpoint':e['id']}},'synthetic-terminal');return e
        cap={'status':'BOUNDED_COMPLETE','captured_records':2,'tool_link_ids':['link'],'raw_records':self.selection['raw_records'],'coverage_event_id':'synthetic-capture-coverage','raw_event_ids':['synthetic-call','synthetic-result']}
        with patch.object(M.B,'resolve_session',return_value=self.root/'synthetic-native'),patch.object(M.B,'SessionWriter',return_value=self.w),patch.object(M.B,'capture',return_value=cap) as capture:
            with patch.object(M.B,'save_new',side_effect=OSError('synthetic receipt interruption')):
                with self.assertRaises(OSError):M.close_with_writer(d,self.w,cp)
            count=len(self.events);out=M.close_with_writer(d,self.w,cp)
        self.assertEqual(count,len(self.events));self.assertEqual(calls,[True]);self.assertEqual(capture.call_count,1)
        self.assertEqual(out['status'],M.STATUS);self.assertTrue((self.run/'FINAL_RECEIPT.json').is_file())
    def test_original_changed_during_checkpoint_blocks_final_acceptance(self):
        d=self.data()
        def cp(root,w,run,path,coverage,incomplete):
            e=w.append({'kind':'checkpoint','run_id':run,'payload':{'capture_status':'INCOMPLETE','truth_status':'NOT_CERTIFIED','summary':self.summary},'outputs':[d['artifacts']['checkpoint']['sha256']]},'synthetic-checkpoint')
            w.append({'kind':'operation.interrupted','run_id':run,'payload':{'checkpoint':e['id']}},'synthetic-terminal')
            (self.root/self.bases['essays']['E051']['manuscript']['path']).write_bytes(b'Synthetic unexpected mutation')
            return e
        cap={'status':'BOUNDED_COMPLETE','captured_records':2,'tool_link_ids':['link'],'raw_records':self.selection['raw_records'],'coverage_event_id':'synthetic-capture-coverage','raw_event_ids':['synthetic-call','synthetic-result']}
        with patch.object(M.B,'resolve_session',return_value=self.root/'synthetic-native'),patch.object(M.B,'SessionWriter',return_value=self.w),patch.object(M.B,'capture',return_value=cap):
            with self.assertRaisesRegex(ValueError,'Bound file changed'):M.close_with_writer(d,self.w,cp)
        self.assertFalse((self.run/'FINAL_RECEIPT.json').exists())
        self.assertFalse(any(e['kind']=='research.revision.completed' for e in self.events))

if __name__=='__main__':unittest.main()
