"""Freeze three isolated no-tool author packets; no model or archive calls."""
from pathlib import Path
import hashlib,json
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1]
BASES={'E050':('repository/essays/selection-20261018/E050.md','af21989e46757835e64576fa666612652b04c26a6d367740de2c9a910645023e'),'E012':('repository/essays/selection-20261018/E012.md','53400ffacb73c30c9af7ee9fa67578305d1ee1c13711881650dfca3cd4c82884'),'E051':('repository/essays/E051/original.md','b03f38b9a529885d165f0157b44a2dca2cafec23584229e9134ed99cd42836b8')}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ref(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'sha256':sha(raw),'bytes':len(raw)}
def save(p,raw):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)
 return ref(p)
def main():
 jobs=[]
 for eid,(original,expected_sha) in BASES.items():
  lane=RUN/'packets'/eid;raw=(ROOT/original).read_bytes();assert sha(raw)==expected_sha
  original_ref=save(lane/'original.md',raw)
  expected={'job_id':eid+'-author','essay_id':eid,'scientific_role':'author','manuscript_sha256':expected_sha}
  prompt=('Read the following isolated materials. Do not invoke any tools. Return only the required final JSON.\nExact output identity: '+json.dumps(expected)+'\n\n').encode()
  paths=[('AUTHOR INSTRUCTIONS',RUN/'AUTHOR_INSTRUCTIONS.txt'),('TARGETED TASKS',lane/'author/TASKS.txt'),('ORIGINAL MANUSCRIPT',lane/'original.md'),('SOURCE CONTEXT',RUN/'source-packets'/eid/'SOURCE_PACKET.md'),('PRIMARY PASSAGES',RUN/'source-packets'/eid/'PRIMARY_PASSAGES.txt'),('REQUIRED FINAL JSON SCHEMA',RUN/'schema/author.json')]
  inline=[];manuscript_start=None
  for label,p in paths:
   body=p.read_bytes();prompt+=('\n----- BEGIN '+label+' -----\n').encode();start=len(prompt);prompt+=body
   inline.append({**ref(p),'prompt_byte_start':start,'prompt_byte_length':len(body)})
   if label=='ORIGINAL MANUSCRIPT':manuscript_start=start
   prompt+=('\n----- END '+label+' -----\n').encode()
  pr=save(lane/'author/prompt.txt',prompt);sc=ref(RUN/'schema/author.json')
  jobs.append({'id':eid+'-author','essay_id':eid,'model':'gpt-6-astra','effort':'ultra','service_tier':'default','role':'argument','scientific_role':'author','transport_profile':'no_tools','web_search':'disabled','manuscript_id':eid,'manuscript_file':original_ref['path'],'manuscript_sha256':expected_sha,'manuscript_byte_start':manuscript_start,'manuscript_byte_length':len(raw),'prompt_file':pr['path'],'prompt_sha256':pr['sha256'],'schema_file':sc['path'],'schema_sha256':sc['sha256'],'expected_output':expected,'inline_inputs':inline,'independence_group':eid+'-author','max_external_attempts':1})
 result={'schema':'submission-revision-jobs.v1','run_id':RUN.name,'wave':'authors','jobs':jobs}
 save(RUN/'jobs-authors.json',(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
 print(json.dumps({'status':'THREE_AUTHOR_PACKETS_FROZEN','jobs':[j['id'] for j in jobs],'prompt_bytes':[len((ROOT/j['prompt_file']).read_bytes()) for j in jobs],'model_calls':0}))
if __name__=='__main__':main()
