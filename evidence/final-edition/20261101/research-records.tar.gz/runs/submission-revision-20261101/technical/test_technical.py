"""Synthetic gates only; no actual provider, service, source or archive run."""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import Mock,patch
spec=importlib.util.spec_from_file_location('revision_stage_tests',Path(__file__).with_name('archive.py'))
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M);C=M.C;B=C.B

class InputGates(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name)
        self.run=self.root/'runs/submission-revision-20261101';self.run.mkdir(parents=True)
        self.files={}
        required=['technical/'+n for n in ('common.py','runner.py','archive.py','test_technical.py','README.md')]
        required+=['METHOD.json','LINEAGE_INPUTS.json','technical/AUTHORIZATION_SOURCE.json','technical/USER_REQUEST.txt']
        required+=['../../runs/deep-verification-20261031/'+n for n in ('runner_v4.py','archive_progress_v4.py','codex_rollout.py','web_transport_v2.py','web_transport_v3.py','web_transport_v4.py')]
        required+=['../../scripts/'+n for n in ('research_archive.py','philosophy_round.py','essay_lineage.py','capture_codex.py','codex_rollout.py','collector_safety.py')]
        for name in required:self.write((self.run/name).resolve(),b'{}\n' if name.endswith('.json') else b'synthetic\n')
        self.jobs=[];lineage={'essays':{}}
        schema=self.write(self.run/'schema.json',b'{"type":"object"}\n')
        for eid in sorted(C.ESSAYS):
            raw=(eid+' исходный текст\n').encode();original=self.write(self.run/'packets'/eid/'original.md',raw)
            prompt=self.write(self.run/'packets'/eid/'prompt.txt',b'PREFIX\n'+raw+b'\nEND')
            lineage['essays'][eid]={'manuscript':original}
            self.jobs.append({'id':eid+'-author','essay_id':eid,'scientific_role':'author','transport_profile':'no_tools',
                'role':'argument','web_search':'disabled','model':'gpt-6-astra','effort':'ultra','service_tier':'default',
                'prompt_file':prompt['path'],'prompt_sha256':prompt['sha256'],'schema_file':schema['path'],'schema_sha256':schema['sha256'],
                'manuscript_sha256':original['sha256'],'expected_output':{'manuscript_sha256':original['sha256']},
                'inline_inputs':[dict(original,prompt_byte_start=7,prompt_byte_length=len(raw))]})
        self.write(self.run/'LINEAGE_INPUTS.json',B.encoded(lineage));self.freeze()
    def tearDown(self):self.tmp.cleanup()
    def write(self,p,raw):
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);ref=B.descriptor(p,self.root);self.files[ref['path']]=ref;return ref
    def freeze(self):
        self.write(self.run/'jobs-authors.json',B.encoded({'jobs':self.jobs}))
        (self.run/'INPUT_MANIFEST.json').write_bytes(B.encoded({'files':list(self.files.values())}))
    def check(self):return C.inputs('authors',self.run,self.root)
    def test_exact_three_no_tool_roles_and_unicode_slices(self):
        c=self.check();self.assertEqual(set(c['jobs']),{x+'-author' for x in C.ESSAYS})
    def test_transport_profile_is_not_scientific_role(self):
        self.jobs[0]['scientific_role']='argument';self.freeze()
        with self.assertRaisesRegex(ValueError,'Scientific author'):self.check()
    def test_live_tools_prohibited(self):
        self.jobs[0]['web_search']='live';self.freeze()
        with self.assertRaises(ValueError):self.check()
    def test_wrong_effort_rejected_by_frozen_validator(self):
        self.jobs[0]['effort']='high';self.freeze()
        with self.assertRaisesRegex(ValueError,'Astra/ultra'):self.check()
    def test_utf8_byte_offset_not_character_offset(self):
        self.jobs[0]['inline_inputs'][0]['prompt_byte_start']+=1;self.freeze()
        with self.assertRaisesRegex(ValueError,'inline source'):self.check()
    def test_bound_input_changed_after_manifest_fails(self):
        (self.root/self.jobs[0]['inline_inputs'][0]['path']).write_text('changed')
        with self.assertRaises(ValueError):self.check()
    def test_source_symlink_fails(self):
        p=self.root/self.jobs[0]['inline_inputs'][0]['path'];raw=p.read_bytes();p.unlink();other=self.root/'other.md';other.write_bytes(raw);p.symlink_to(other)
        with self.assertRaises(ValueError):self.check()
    def test_author_missing_original_fails_even_if_prompt_is_bound(self):
        job=self.jobs[0];raw=b'unrelated neutral text';ref=self.write(self.run/'other.txt',raw)
        prompt=self.write(self.root/job['prompt_file'],raw);job['prompt_sha256']=prompt['sha256']
        job['inline_inputs']=[dict(ref,prompt_byte_start=0,prompt_byte_length=len(raw))];self.freeze()
        with self.assertRaisesRegex(ValueError,'exact selected original'):self.check()
    def test_wrong_essay_original_fails(self):
        job=self.jobs[0];other=self.jobs[1]['inline_inputs'][0];raw=(self.root/other['path']).read_bytes()
        ref=self.write(self.root/job['prompt_file'],raw);job['prompt_sha256']=ref['sha256']
        job['inline_inputs']=[dict(other,prompt_byte_start=0)];self.freeze()
        with self.assertRaisesRegex(ValueError,'exact selected original'):self.check()
    def test_exact_attempt_inventory_not_silent_subset(self):
        job=self.jobs[0];attempt=self.run/'results'/job['id']/'attempt-001';attempt.mkdir(parents=True)
        (attempt/'receipt.json').write_text('{}');(attempt/'response.json').write_text('{}');(attempt/'extra.txt').write_text('new')
        result={'receipt':{'outputs':{str((attempt/'response.json').relative_to(self.root)):B.sha(b'{}')}},'web':[], 'session_id':'synthetic-fresh'}
        with patch.object(B,'validate_terminal',return_value=result),self.assertRaisesRegex(ValueError,'inventory'):
            M.terminal_results({'root':self.root,'run':self.run,'jobs':{job['id']:job}})
    def test_binary_formats_rejected_before_writer(self):
        ref=self.write(self.run/'source.pdf',b'%PDF-1.7\nsynthetic')
        with self.assertRaisesRegex(ValueError,'UTF-8'):C.safe_file(ref,self.root)

class DirectCommitment(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name)
        self.archive=B.Archive(self.root/'research/archive').init()
        with self.archive.writer() as w:
            self.event=w.append({'kind':'synthetic.input','actor':{'id':'fixture','role':'test'},'session_id':'synthetic-session',
                'run_id':'synthetic-run','operation_id':'synthetic-operation','attempt_id':'synthetic-attempt','payload':{'status':'SYNTHETIC'}},'synthetic-input')
        self.receipt=C.event_receipt(self.event)
    def tearDown(self):self.tmp.cleanup()
    def test_direct_event_exact(self):self.assertEqual(C.direct_event(self.receipt,self.root),self.event)
    def test_wrong_internal_sequence_rejected(self):
        # Valid event bytes under a different filename must not satisfy a wrong
        # requested sequence even when ID and SHA are otherwise exact.
        p=self.root/'research/archive/events/000000000002.json';p.write_bytes((self.root/'research/archive/events/000000000001.json').read_bytes())
        self.receipt['event_sequence']=2
        with self.assertRaisesRegex(ValueError,'commitment|mismatch'):C.direct_event(self.receipt,self.root)
    def test_changed_sha_rejected(self):
        self.receipt['event_sha256']='f'*64
        with self.assertRaises(ValueError):C.direct_event(self.receipt,self.root)

class RevisionMaterialization(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name);self.run=self.root/'runs/revision'
        self.attempt=self.run/'results/E051-author/attempt-001';self.attempt.mkdir(parents=True)
        self.original=self.root/'original.md';self.original.write_bytes(b'Original preserved.\n')
        self.text='New exact text.\n\nNo added trailing newline'
        (self.attempt/'response.json').write_bytes(B.encoded({'manuscript_markdown':self.text}))
        self.ctx={'root':self.root,'run':self.run}
        self.result={'job':{'id':'E051-author'},'value':{'manuscript_markdown':self.text},'receipt_path':self.attempt/'receipt.json'}
    def tearDown(self):self.tmp.cleanup()
    def materialize(self):return M.materialize_revision(self.ctx,self.result,B.descriptor(self.original,self.root))
    def test_exact_extraction_and_diff_original_preserved(self):
        first=self.materialize();again=self.materialize();self.assertEqual(first,again)
        self.assertEqual((self.root/first['revision']['path']).read_bytes(),self.text.encode())
        self.assertEqual(self.original.read_bytes(),b'Original preserved.\n')
        self.assertIn(b'-Original preserved.',(self.root/first['diff']['path']).read_bytes())
    def test_missing_manuscript_fails(self):
        self.result['value']={}
        with self.assertRaisesRegex(ValueError,'Complete revised'):self.materialize()
    def test_child_symlink_fails_before_publication(self):
        directory=self.attempt.parent/'derived';directory.mkdir();(directory/'revision.md').symlink_to(self.original)
        with self.assertRaisesRegex(ValueError,'symlink'):self.materialize()
        self.assertEqual(self.original.read_bytes(),b'Original preserved.\n')

class CriticBinding(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.tmp.name);self.run=self.root/'runs/revision';self.run.mkdir(parents=True)
        self.roles=[];self.events={};self.known={};self.data={'essays':{}};self.jobs={};self.objects={}
        for eid in sorted(C.ESSAYS):
            refs=[]
            for name in ('original.md','revision.md','changes.diff'):
                p=self.run/'results'/(eid+'-author')/'derived'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(eid+' '+name)
                ref=B.descriptor(p,self.root);refs.append(ref);self.objects[ref['sha256']]=p.read_bytes()
            # Base copy can live outside author result paths; critic gets this.
            original=self.run/'packets'/eid/'original.md';original.parent.mkdir(parents=True);original.write_bytes(self.objects[refs[0]['sha256']]);refs[0]=B.descriptor(original,self.root)
            event_id='event-'+eid;line_id='lineage-'+eid;entry_id='entry-'+eid
            role={'essay_id':eid,'session_id':'author-'+eid,'event_id':event_id,'lineage_event_id':line_id,'lineage_entry_id':entry_id,'revision':refs[1],'diff':refs[2]}
            self.roles.append(role);self.data['essays'][eid]={'manuscript':refs[0]}
            self.events[event_id]={'id':event_id,'kind':'research.revision.role.accepted','session_id':role['session_id'],'payload':{'scientific_role':'author'}}
            self.known[entry_id]={'id':line_id,'parents':[event_id]}
            self.jobs[eid+'-critic']={'essay_id':eid,'inline_inputs':refs}
        self.wave={'id':'wave','kind':'research.revision.wave.accepted','payload':{'status':'SUBMISSION_AUTHORS_ARCHIVED','roles':self.roles}}
        (self.run/'AUTHORS_ARCHIVE_RECEIPT.json').write_bytes(B.encoded({'event_id':'wave','roles':self.roles}))
        self.ctx={'root':self.root,'run':self.run,'jobs':self.jobs};self.w=Mock();self.w.get.side_effect=lambda h:self.objects[h]
    def tearDown(self):self.tmp.cleanup()
    def check(self):
        with patch.object(B,'canonical_event',return_value=self.wave),patch.object(B,'verify_event_files'),patch.object(M,'canonical_bases',return_value=(self.data,self.events,self.known)):
            return M.critic_binding(self.ctx,self.w)
    def test_exact_three_accepted_revisions_and_lineages(self):self.assertEqual(self.check(),self.wave)
    def test_unaccepted_revision_cannot_reach_critic(self):
        self.jobs['E051-critic']['inline_inputs'][1]=dict(self.jobs['E051-critic']['inline_inputs'][1],sha256='f'*64)
        with self.assertRaisesRegex(ValueError,'accepted revision'):self.check()
    def test_missing_diff_fails(self):
        self.jobs['E051-critic']['inline_inputs'].pop()
        with self.assertRaisesRegex(ValueError,'mechanical diff'):self.check()
    def test_author_log_excluded_from_critic_packet(self):
        self.jobs['E051-critic']['inline_inputs'].append({'path':str((self.run/'results/E051-author/attempt-001/response.json').relative_to(self.root))})
        with self.assertRaisesRegex(ValueError,'author log'):self.check()
    def test_wrong_canonical_lineage_parent_fails(self):
        self.known['entry-E051']['parents']=[]
        with self.assertRaisesRegex(ValueError,'linkage'):self.check()

if __name__=='__main__':unittest.main()
