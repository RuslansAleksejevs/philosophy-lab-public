#!/usr/bin/env python3
"""Dispatch exactly three fresh no-tool roles after their canonical wave gate."""
from pathlib import Path
import argparse
import concurrent.futures
import fcntl
import importlib.util
import json
import os
spec=importlib.util.spec_from_file_location('revision_common',Path(__file__).with_name('common_v2.py'))
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)

def run(wave):
    with (C.RUN/'dispatch.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        ctx=C.gate(wave);jobs=list(ctx['jobs'].values());dispatcher=C.base.Dispatcher(C.RUN,C.ROOT)
        C.B.require(not dispatcher.stopped(),'Preserved STOP blocks further dispatch')
        C.B.require(not any((C.RUN/'results'/j['id']/'attempt-001').exists() for j in jobs),'Existing attempts are never relaunched')
        # The exact command, native validators, output schema, stop handling and
        # ChatGPT subscription environment are the unchanged frozen V4 code.
        started=C.base.now();finished=[]
        def snapshot(status):
            C.base.replace_status(C.RUN/('process-'+wave+'.json'),{'status':status,'pid':os.getpid(),
                'wave':wave,'started_at':started,'updated_at':C.base.now(),'workers':3,
                'selected_ids':[j['id'] for j in jobs],'finished':finished,
                'input_event_id':ctx['start']['event_id'],'scientific_retries':False,
                'transport_profile':'no_tools'})
        snapshot('RUNNING')
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            futures={pool.submit(dispatcher.run_one,j):j for j in jobs}
            for future in concurrent.futures.as_completed(futures):
                result=future.result();finished.append(result)
                print(json.dumps(result),flush=True);snapshot('RUNNING' if len(finished)<3 else 'TERMINAL_LOCAL_PENDING_ARCHIVE')
        snapshot('STOPPED_PRESERVED' if dispatcher.stopped() else 'COMPLETE_LOCAL_PENDING_ARCHIVE')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('wave',choices=('authors','critics'));p.add_argument('--check',action='store_true')
    a=p.parse_args()
    if a.check:
        c=C.gate(a.wave);print(json.dumps({'status':'CANONICAL_WAVE_GATE_PASS','roles':sorted(c['jobs']),'provider_calls':0}))
    else:run(a.wave)
