# Three revisions followed by three independent checks

This is the existing preselection sequence using the already reviewed V4
no-tool execution/native validator, standard canonical capture and essay_lineage.
It does not reuse old scientific roles or alter old source, manuscripts or logs.
All six new roles request Astra / ultra / Standard through ChatGPT subscription.

`role=argument` is only the frozen transport's no-tool profile. Every job and
new scientific event separately records `scientific_role=author|critic`,
`transport_profile=no_tools`, and its own `essay_id`. No author is represented
as an argument reviewer. The original V4 command, native configuration/prompt
checks, final/schema checks, parse-gap accounting and stop policy stay unchanged.

## Inputs and isolation

The author queue is `jobs-authors.json`, exactly E050-author, E012-author and
E051-author. Each prompt embeds only its neutral instructions/tasks, original
manuscript, own source context/primary passages and required JSON schema.
`inline_inputs` holds exact file descriptors plus UTF-8 `prompt_byte_start` and
`prompt_byte_length`; all slices and nonoverlap are checked. The selected original
hash/length must occur in its own author packet. Tools, global project docs and
memory are disabled by the unchanged command; strict native replay checks the
actual fresh prompt, environment, configuration, one final and no tool calls.

`LINEAGE_INPUTS.json` identifies the exact existing manuscript ancestors.
Before any author launch the ordinary audited writer verifies their canonical
entry IDs, entities, artifact objects and the previously accepted revision plan.
The actual human request is native line34736; the AI question is the exact
reviewed coordinator call/result selected by technical/QUESTION_CAPTURE.json.
The standard question stage and three unchanged-base selection entries precede
AUTHORS_START_RECEIPT.json. They are assignments, not fictional author revisions.

Root freezes INPUT_MANIFEST.json after review. Include all current text/code
inputs, own packet files and the runtime dependencies required by common.inputs.
Include old accepted plan receipt/plan and original manuscript paths referenced
by LINEAGE_INPUTS, as well as the three source packet/PASSAGES manifests.
Public PDFs, page images and raw HTML stay local with hash commitments in source
manifests; only approved clean extracted text, metadata and snapshots are in this
canonical text package. No arbitrary binary or hidden/native envelope is accepted.

## Root execution

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/technical -p test_technical.py -q
python3 -B runs/submission-revision-20261101/technical/archive.py inputs --check
python3 -B runs/submission-revision-20261101/technical/archive.py inputs --apply
python3 -B runs/submission-revision-20261101/technical/runner.py authors --check
python3 -B runs/submission-revision-20261101/technical/runner.py authors
python3 -B runs/submission-revision-20261101/technical/archive.py authors --check
python3 -B runs/submission-revision-20261101/technical/archive.py authors --apply
```

Do not use author outputs dependently before AUTHORS_ARCHIVE_RECEIPT.json.
Acceptance independently replays each exact completed native prefix and records
bounded visible messages. It extracts `manuscript_markdown` from accepted JSON
without modifying text or adding a newline, creates a mechanical unified diff,
and records source-field derivation metadata. Files are under
results/ESSAY-author/derived/{revision.md,changes.diff,DERIVATION.json}. The original
execution files and original manuscript remain unchanged. Each accepted revision
gets its own AI-author lineage entry before a critic packet may use it.

Root then creates `jobs-critics.json` and `CRITIC_INPUT_MANIFEST.json`, exactly
E050-critic, E012-critic and E051-critic. Each packet contains original manuscript
(an exact same-byte copy is allowed), exact accepted revision and mechanical diff,
neutral review instructions, own PRIMARY_PASSAGES and SOURCE_ACCESS_NOTES, and
schema. It excludes old verdicts, the author's change log and other essays.
Revision/diff paths and hashes must match the canonical author receipt exactly.
The critic manifest binds the previous AUTHORS_START_RECEIPT and
AUTHORS_ARCHIVE_RECEIPT as well as its code/input dependencies.

```sh
python3 -B runs/submission-revision-20261101/technical/archive.py critic-inputs --check
python3 -B runs/submission-revision-20261101/technical/archive.py critic-inputs --apply
python3 -B runs/submission-revision-20261101/technical/runner.py critics --check
python3 -B runs/submission-revision-20261101/technical/runner.py critics
python3 -B runs/submission-revision-20261101/technical/archive.py critics --check
python3 -B runs/submission-revision-20261101/technical/archive.py critics --apply
```

The dispatcher launches exactly three concurrent fresh roles per wave, with a
single dispatch lock. Any existing attempt or preserved stop blocks relaunch;
there is no automatic retry. All three critics must have distinct sessions,
different from the root and every author session. Their exact current review
target and accepted parent lineage are checked before dependent decisions.

## One writer per stage, no repeated derived refresh

The public administrative API is:

```python
ctx, results = archive.prepare(mode)  # read-only preflight
with B.Archive(ROOT / 'research/archive').writer() as writer:
    receipt = archive.finish(mode, ctx, writer, results)
```

`finish` repeats local checks after ordinary audit/lock acquisition. Root may
retain that same writer briefly between author acceptance and newly prepared
critic input acceptance; no models should be launched or awaited under it.
Every actual append/object write uses the standard writer. Direct dispatch gate
reads are bounded to the exact canonical receipt event sequence/SHA/selfhash;
they do not replace the archive writer's ordinary full integrity audit.

Scientific events are `research.revision.role.accepted`, with status
SUBMISSION_REVISION_ROLE_ARCHIVED, actual author SID, scientific_role, exact
receipt/native proof/files and explicit stdout coverage boundary. Per-role
ARCHIVE_RECEIPT.json links its critique/revision lineage. The three-role wave
event and AUTHORS_ARCHIVE_RECEIPT or CRITICS_ARCHIVE_RECEIPT bind those identities.

These helpers never render global views, biographies or checkpoints. Final
coordinator decision/selection, typed stages, one administrative checkpoint and
one derived refresh are a separately bound closure after all six accepted roles.
No submission, publication, further revision cycle or complete-provider-capture
claim follows from these finite technical receipts. Root controls collector
maintenance/restart; these scripts have no service control.
