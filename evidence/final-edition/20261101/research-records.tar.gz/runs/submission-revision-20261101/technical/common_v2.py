"""Shared finite-wave gates; reuse the frozen no-tool V4 transport unchanged."""
from pathlib import Path
import hashlib
import importlib.util
import sys
sys.dont_write_bytecode = True
LANE=Path(__file__).resolve().parent; RUN=LANE.parent; ROOT=RUN.parents[1]
SID='01a190b5-03e2-70d0-8fcf-b4a1e67148d0'
ESSAYS={'E050','E012','E051'}
BASE=ROOT/'runs/deep-verification-20261031/archive_progress_v4.py'
if hashlib.sha256(BASE.read_bytes()).hexdigest()!='e05c400d70f1eeddbdff81cb6d8bf519bfbbfa76ef5d3c3d33f6ea6d6b1ba607':
    raise ValueError('Frozen validation implementation changed')
spec=importlib.util.spec_from_file_location('revision_frozen_archive',BASE)
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
base=B.import_runner(ROOT/'runs/deep-verification-20261031/runner_v4.py',ROOT)
import research_archive as AR

STATUSES={'authors':'SUBMISSION_REVISION_INPUTS_ARCHIVED','critics':'SUBMISSION_REVISION_CRITIC_INPUTS_ARCHIVED'}
KINDS={'authors':'research.revision.inputs.accepted','critics':'research.revision.critic_inputs.accepted'}
STAGES=['question','sources','contribution','critique','decision']
OLD_MANIFEST_SHA='b04cc773b2fe44cab5fc21a6751c9f91fafd70a1f81a2224303c4de51b0c3f46'

def method_amendment(run=RUN,root=ROOT):
    old_ref=B.descriptor(run/'INPUT_MANIFEST.json',root)
    B.require(old_ref['sha256']==OLD_MANIFEST_SHA,
              'Original frozen input manifest changed')
    old=B.strict_json(B.bound(old_ref,root))
    for ref in old['files']:B.bound(ref,root)
    previous=B.load(run/'METHOD.json',root);current=B.load(run/'METHOD-v2.json',root)
    expected=dict(previous,id=run.name,stages=STAGES)
    B.require(previous.get('run_id')==run.name and 'id' not in previous and 'stages' not in previous
              and current==expected,'Only missing protocol id/stages may be added')
    amendment=B.load(run/'METHOD_AMENDMENT.json',root)
    B.require(amendment.get('status')=='METHOD_PROTOCOL_REGISTRATION_REPAIR_PREPARED'
              and amendment.get('previous_manifest')==old_ref
              and amendment.get('old_method')==B.descriptor(run/'METHOD.json',root)
              and amendment.get('new_method')==B.descriptor(run/'METHOD-v2.json',root)
              and amendment.get('failure_log')==B.descriptor(run/'inputs-archive.log',root)
              and amendment.get('scientific_inputs_changed') is False
              and amendment.get('provider_calls_before_failure')==0,'Exact preserved method repair required')
    return old_ref,old['files']

def names(wave):
    B.require(wave in STATUSES,'Unknown finite wave')
    return ('INPUT_MANIFEST-v2.json','AUTHORS_START_RECEIPT.json') if wave=='authors' else ('CRITIC_INPUT_MANIFEST.json','CRITICS_START_RECEIPT.json')

def safe_file(ref,root=ROOT):
    raw=B.bound(ref,root);suffix=Path(ref['path']).suffix
    B.require(suffix in {'.json','.jsonl','.txt','.md','.py','.cjs','.diff','.toml'}
              or ref['path']=='runs/submission-revision-20261101/inputs-archive.log',
              'Only explicit UTF-8 evidence/code formats are accepted')
    if suffix=='.json':value=B.strict_json(raw)
    elif suffix=='.jsonl':value=[B.strict_json(x) for x in raw.splitlines() if x]
    else:value=raw.decode()
    B.safe(value,ref['path']);return raw

def inputs(wave,run=RUN,root=ROOT):
    manifest_name,_=names(wave);manifest_ref=B.descriptor(run/manifest_name,root)
    manifest=B.strict_json(safe_file(manifest_ref,root));rows=manifest['files']
    indexed={r['path']:r for r in rows}
    B.require(len(indexed)==len(rows) and manifest_ref['path'] not in indexed,'Duplicate/self-referential manifest input')
    old_ref,old_rows=method_amendment(run,root)
    B.require(indexed.get(old_ref['path'])==old_ref and all(indexed.get(r['path'])==r for r in old_rows),
              'Successor must preserve every original frozen input')
    for row in rows:safe_file(row,root)
    required=[run/'technical'/n for n in ('common.py','runner.py','archive.py','test_technical.py','README.md')]
    required += [run/'technical'/n for n in ('common_v2.py','runner_v2.py','archive_v2.py','test_method_v2.py','README_METHOD_V2.md')]
    required += [run/n for n in ('METHOD-v2.json','METHOD_AMENDMENT.json','inputs-archive.log')]
    required += [run/n for n in ('METHOD.json','LINEAGE_INPUTS.json','technical/AUTHORIZATION_SOURCE.json','technical/USER_REQUEST.txt','jobs-'+wave+'.json')]
    required += [root/'runs/deep-verification-20261031'/n for n in ('runner_v4.py','archive_progress_v4.py','codex_rollout.py','web_transport_v2.py','web_transport_v3.py','web_transport_v4.py')]
    required += [root/'scripts'/n for n in ('research_archive.py','philosophy_round.py','essay_lineage.py','capture_codex.py','codex_rollout.py','collector_safety.py')]
    if wave=='critics':required += [run/'AUTHORS_ARCHIVE_RECEIPT.json',run/'AUTHORS_START_RECEIPT.json']
    B.require(all(str(p.relative_to(root)) in indexed for p in required),'Required frozen runtime/method unbound')
    jobs=B.load(run/('jobs-'+wave+'.json'),root)['jobs'];role='author' if wave=='authors' else 'critic'
    B.require(len(jobs)==3 and {j['id'] for j in jobs}=={e+'-'+role for e in ESSAYS},'Exact three new roles required')
    for job in jobs:
        B.require(job.get('essay_id') in ESSAYS and job['id']==job['essay_id']+'-'+role
                  and job.get('scientific_role')==role and job.get('transport_profile')=='no_tools'
                  and job.get('role')=='argument' and job.get('web_search')=='disabled',
                  'Scientific author/critic and transport profile must be explicit')
        prompt,_=base.check_inputs(job,root)
        for key in ('prompt','schema'):
            B.require(indexed.get(job[key+'_file'],{}).get('sha256')==job[key+'_sha256'],'Prompt/schema not manifest-bound')
        inline=job.get('inline_inputs');B.require(isinstance(inline,list) and inline,'Explicit inline input slices required')
        seen=set();ranges=[]
        for row in inline:
            ref={k:row[k] for k in ('path','sha256','bytes')};raw=B.bound(ref,root)
            B.require(row['path'] not in seen and indexed.get(row['path'])==ref,'Duplicate/unbound worker input')
            seen.add(row['path']);start=row['prompt_byte_start'];length=row['prompt_byte_length']
            B.require(type(start) is int and type(length) is int and start>=0 and length==len(raw)
                      and prompt[start:start+length]==raw,'Exact inline source bytes differ')
            ranges.append((start,start+length))
        ranges.sort();B.require(all(a[1]<=b[0] for a,b in zip(ranges,ranges[1:])),'Overlapping inline input ranges')
        if wave=='authors':
            original=B.load(run/'LINEAGE_INPUTS.json',root)['essays'][job['essay_id']]['manuscript']
            B.require(any(row['sha256']==original['sha256'] and row['bytes']==original['bytes'] for row in inline)
                      and job.get('manuscript_sha256')==original['sha256']
                      and job.get('expected_output',{}).get('manuscript_sha256')==original['sha256'],
                      'Author must receive its exact selected original manuscript')
    return {'root':root,'run':run,'wave':wave,'manifest':manifest,'manifest_ref':manifest_ref,
            'indexed':indexed,'files':rows+[manifest_ref],'jobs':{j['id']:j for j in jobs},'runner':base}

def direct_event(receipt,root=ROOT):
    sequence=receipt.get('event_sequence')
    B.require(type(sequence) is int and sequence>0 and B.HEX.fullmatch(receipt.get('event_sha256','')),'Exact canonical event commitment required')
    event=B.load(root/'research/archive/events'/f'{sequence:012d}.json',root)
    AR._check_event(event)
    B.require(event['sequence']==sequence and event['id']==receipt.get('event_id')
              and event['sha256']==receipt['event_sha256'],'Local receipt/canonical event mismatch')
    return event

def gate(wave,run=RUN,root=ROOT):
    ctx=inputs(wave,run,root);_,name=names(wave);receipt=B.load(run/name,root)
    B.require(receipt.get('status')==STATUSES[wave] and receipt.get('files')==ctx['files'],'Exact canonical input receipt required')
    event=direct_event(receipt,root)
    B.require(event['kind']==KINDS[wave] and event['run_id']==run.name
              and event['payload'].get('status')==STATUSES[wave]
              and event['payload'].get('files')==ctx['files'] and event['bindings']==receipt.get('bindings'),
              'Input receipt differs from canonical acceptance')
    ctx['start']=receipt
    if wave=='critics':
        previous=B.load(run/'AUTHORS_ARCHIVE_RECEIPT.json',root);accepted=direct_event(previous,root)
        B.require(previous.get('status')=='SUBMISSION_AUTHORS_ARCHIVED' and accepted['id'] in event['parents']
                  and accepted['payload'].get('roles')==previous.get('roles'),'Critics require canonical revisions and lineages')
    return ctx

def event_receipt(event):
    return {'status':event['payload']['status'],'event_id':event['id'],'event_sequence':event['sequence'],
            'event_sha256':event['sha256'],'files':event['payload'].get('files',[]),
            'bindings':event['bindings'],'roles':event['payload'].get('roles',[])}
