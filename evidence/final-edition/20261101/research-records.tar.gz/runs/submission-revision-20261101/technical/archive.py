#!/usr/bin/env python3
"""Finite staged acceptance: inputs, three revisions, critic inputs, three critiques.

Only --apply uses an ordinary audited writer. No provider/service action and no
derived refresh occur here. Final coordinator closure/checkpoint is separate.
"""
from pathlib import Path
import argparse
import difflib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('revision_archive_common',Path(__file__).with_name('common.py'))
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C);B=C.B
from philosophy_round import start,record
from capture_codex import regular_file,classify
import essay_lineage as L


def lineage_inputs(ctx):
    data=B.load(ctx['run']/'LINEAGE_INPUTS.json',ctx['root'])
    B.require(data.get('schema')=='submission-revision-lineage.v1' and set(data.get('essays',{}))==C.ESSAYS,'Exact three base versions required')
    for row in data['essays'].values():B.bound(row['manuscript'],ctx['root'])
    B.bound(data['prior_plan_receipt'],ctx['root']);B.bound(data['prior_plan'],ctx['root'])
    return data

def canonical_bases(ctx,w):
    data=lineage_inputs(ctx);events={e['id']:e for e in w._state['records']};known=L.index(events.values())
    final=B.strict_json(B.bound(data['prior_plan_receipt'],ctx['root']));old=events.get(final.get('event_id'))
    B.require(old is not None and old['id']==data['prior_plan_event_id']
              and old['kind']=='research.verification.completed'
              and old['payload']=={k:v for k,v in final.items() if k!='event_id'}
              and final.get('status')=='TRIO_VERIFICATION_AND_PLAN_COMPLETE_BOUNDED'
              and final.get('plan')==data['prior_plan'],'Exact accepted revision plan required')
    B.require(w.get(data['prior_plan']['sha256'])==B.bound(data['prior_plan'],ctx['root']),'Accepted plan object differs')
    for eid,row in data['essays'].items():
        old=known.get(row['parent_entry']);B.require(old is not None and old['id']==row['parent_event'],'Canonical base lineage missing')
        entry=old['payload']['entry']
        B.require(entry['entity']==row['entity'] and any(a['sha256']==row['manuscript']['sha256'] for a in entry['artifacts']),
                  'Base lineage/version differs')
        B.require(w.get(row['manuscript']['sha256'])==B.bound(row['manuscript'],ctx['root']),'Base manuscript object differs')
    return data,events,known

def store(ctx,w,refs):
    for ref in refs:B.require(w.put(C.safe_file(ref,ctx['root']))==ref['sha256'],'Canonical object mismatch')

def authorization(ctx):
    auth=B.load(ctx['run']/'technical/AUTHORIZATION_SOURCE.json',ctx['root']);line=auth['source_line']
    B.require(auth.get('origin')=='HUMAN' and auth.get('session_id')==C.SID and line==34736
              and auth['raw_sha256']=='9c8e959e4f2c07f61af3893d4376f66c51ce6e5cc56def46df65ca196043e640'
              and auth['capture']=={'start_line':line,'end_line':line,'max_bytes':512*1024*1024},'Exact current request required')
    source=B.resolve_session(C.SID,ctx['root']);selected=None
    with regular_file(source) as f:
        import os
        B.require(os.fstat(f.fileno()).st_size<=auth['capture']['max_bytes'],'Root source exceeds fixed bound')
        for n,raw in enumerate(f,1):
            if n==line:selected=raw;break
    B.require(selected is not None and B.sha(selected)==auth['raw_sha256'] and len(selected)==auth['raw_bytes'],'Original user line changed')
    obj=B.strict_json(selected);B.require(classify(obj,line,set(),set()) is None and obj['payload']['role']=='user','Not visible human authorization')
    text='\n'.join(x['text'] for x in obj['payload']['content']).encode()
    B.require(text==B.bound(auth['request'],ctx['root']),'Exact human request text differs')
    return auth,source

def prepare_inputs(root=C.ROOT,run=C.RUN):
    ctx=C.inputs('authors',run,root);lineage_inputs(ctx);authorization(ctx)
    for name in ('QUESTION_RU.txt','technical/QUESTION_CAPTURE.json'):
        B.require(str((run/name).relative_to(root)) in ctx['indexed'],'Question/provenance not input-bound')
    return ctx

def accept_inputs(ctx,w):
    data,events,known=canonical_bases(ctx,w);auth,source=authorization(ctx)
    first=start(ctx['root'],w,ctx['run'].name,C.SID,'research',str((ctx['run']/'METHOD.json').relative_to(ctx['root'])),
        [str((ctx['run']/p).relative_to(ctx['root'])) for p in ('INPUT_MANIFEST.json','technical/AUTHORIZATION_SOURCE.json','technical/USER_REQUEST.txt','LINEAGE_INPUTS.json')],
        stage_id='SUBMISSION_REVISION',selection_round_id='USER_SELECTED_TRIO')
    ctx['start']={'event_id':first['id'],'bindings':first['bindings']}
    scope=B.SessionWriter(w,C.SID,ctx['run'].name)
    previous=B.existing(w,ctx['run'].name+':author-inputs:v1')
    if previous:
        B.require(previous['kind']==C.KINDS['authors'] and previous['payload']['files']==ctx['files'],'Input retry conflict')
        B.verify_event_files(ctx,w,previous);receipt=C.event_receipt(previous)
        B.save_new(ctx['run']/'AUTHORS_START_RECEIPT.json',receipt);return receipt
    cap=B.capture(ctx['root']/'research/archive',source,C.SID,ctx['root'],start_line=34736,end_line=34736,
        max_bytes=512*1024*1024,run_id=ctx['run'].name,archive_writer=scope)
    B.require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==1
              and cap['raw_records'][0]['sha256']==auth['raw_sha256'],'Authorization capture differs')
    selection=B.load(ctx['run']/'technical/QUESTION_CAPTURE.json',ctx['root'])
    lines=selection['reviewed_tool_lines']
    B.require(selection['session_id']==C.SID and len(lines)==2 and lines==sorted(set(lines))
              and selection['start_line']==lines[0] and selection['end_line']==lines[1]
              and selection['max_bytes']==512*1024*1024 and lines[0]>34736,'Exact question call/result selection required')
    qcap=B.capture(ctx['root']/'research/archive',source,C.SID,ctx['root'],start_line=lines[0],end_line=lines[1],
        reviewed_tool_lines=lines,max_bytes=512*1024*1024,run_id=ctx['run'].name,archive_writer=scope)
    B.require(qcap['status']=='BOUNDED_COMPLETE' and qcap['captured_records']==2 and len(qcap['tool_link_ids'])==1
              and {r['source_line']:r['sha256'] for r in qcap['raw_records']}=={r['source_line']:r['sha256'] for r in selection['raw_records']},'Question capture differs')
    question=record(ctx['root'],scope,ctx['run'].name,'question',str((ctx['run']/'QUESTION_RU.txt').relative_to(ctx['root'])),C.SID,qcap['raw_event_ids'],
        source_note='Exact AI coordinator tool call creates the question and neutral method. Human authorization is captured separately.')
    store(ctx,w,ctx['files']);assigned=[]
    events.update({e['id']:e for e in w._state['records'] if e['id'] not in events})
    for eid,row in data['essays'].items():
        entry=L.base_entry(ctx['run'].name+':'+eid+':assigned',row['entity'],'selection','Exact existing manuscript assigned for the user-authorized revision; no new manuscript yet.')
        entry.update(parents=[row['parent_entry']],artifacts=[dict(row['manuscript'],role='unchanged_revision_base')],
            evidence=[first['id'],data['prior_plan_event_id'],question['id']],actor={'role':'tool','id':'revision-archive-adapter'},
            workflow={'run_id':ctx['run'].name,'essay_id':eid},decision={'status':'ASSIGNED_UNCHANGED_BASE','origin':'HUMAN_AUTHORIZED'},
            gaps=['Assignment is not a new author result or endorsement.'])
        assigned.append(L.append(w,entry,C.SID,known,events)['id'])
    payload={'status':C.STATUSES['authors'],'files':ctx['files'],'scientific_roles':3,'scientific_role':'author',
        'transport_profile':'no_tools','transport_role':'argument','assigned_lineage_event_ids':assigned,
        'question_stage_event_id':question['id'],'authorization_coverage_event_id':cap['coverage_event_id'],
        'question_coverage_event_id':qcap['coverage_event_id'],'old_roles_repeated':0,'derived_refresh':False}
    event=w.append(B.request(ctx,C.KINDS['authors'],C.SID,'author-inputs-v1',
        [first['id'],data['prior_plan_event_id'],cap['coverage_event_id'],question['id']]+assigned,ctx['files'],payload),ctx['run'].name+':author-inputs:v1')
    receipt=C.event_receipt(event);B.save_new(ctx['run']/'AUTHORS_START_RECEIPT.json',receipt);return receipt

def terminal_results(ctx):
    results={};sids=set()
    for jid,job in ctx['jobs'].items():
        path=ctx['run']/'results'/jid/'attempt-001/receipt.json';result=B.validate_terminal(ctx,jid,path)
        B.require(not result['receipt'].get('disposition') and not result['web'],'Only original completed no-tool executions accepted')
        B.require(result['session_id'] not in sids|{C.SID},'Fresh distinct role sessions required');sids.add(result['session_id'])
        outputs=result['receipt']['outputs'];actual={str(p.relative_to(ctx['root'])):B.sha(B.read(p,ctx['root'])) for p in path.parent.iterdir() if p.name!='receipt.json'}
        B.require(outputs==actual,'Exact original attempt inventory required')
        results[jid]=result
    return results

def materialize_revision(ctx,result,base_ref):
    text=result['value'].get('manuscript_markdown');B.require(isinstance(text,str) and text.strip(),'Complete revised manuscript required')
    raw=text.encode();B.safe(text,'revised manuscript');old=B.bound(base_ref,ctx['root'])
    diff=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),text.splitlines(keepends=True),
        fromfile='preserved-original.md',tofile='proposed-revision.md')).encode()
    directory=ctx['run']/'results'/result['job']['id']/'derived'
    B.require(all(not p.is_symlink() for p in [directory,*directory.parents] if p.is_relative_to(ctx['root'])),'Derived path symlink forbidden')
    directory.mkdir(exist_ok=True);B.require({p.name for p in directory.iterdir()}<={'revision.md','changes.diff','DERIVATION.json'},'Foreign derived output')
    for name in ('revision.md','changes.diff','DERIVATION.json'):B.require(not (directory/name).is_symlink(),'Derived child symlink forbidden')
    for name,data in (('revision.md',raw),('changes.diff',diff)):
        p=directory/name
        if p.exists():B.require(p.read_bytes()==data,'Derived content changed')
        else:
            import os
            with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    revision=B.descriptor(directory/'revision.md',ctx['root']);difference=B.descriptor(directory/'changes.diff',ctx['root'])
    source=B.descriptor(result['receipt_path'].parent/'response.json',ctx['root'])
    B.save_new(directory/'DERIVATION.json',{'schema':'exact-manuscript-field-extraction.v1','source':source,
        'field':'manuscript_markdown','encoding':'UTF-8; no newline or text normalization','original':base_ref,
        'revision':revision,'diff':difference,'diff_method':'Python difflib.unified_diff; preserved original versus exact proposed text'})
    return {'revision':revision,'diff':difference,'files':[revision,difference,B.descriptor(directory/'DERIVATION.json',ctx['root'])]}

def accept_wave(ctx,w,results):
    data,events,known=canonical_bases(ctx,w);entry=B.canonical_event(w,ctx['start']['event_id'])
    B.require(entry['kind']==C.KINDS[ctx['wave']] and entry['payload'].get('files')==ctx['files'],'Canonical wave input differs')
    B.verify_event_files(ctx,w,entry);roles=[];old_authors={}
    if ctx['wave']=='critics':old_authors={x['essay_id']:x for x in B.load(ctx['run']/'AUTHORS_ARCHIVE_RECEIPT.json',ctx['root'])['roles']}
    for jid,result in results.items():
        job=result['job'];eid=job['essay_id'];role=job['scientific_role'];sid=result['session_id'];parent=ctx['run'].name+':'+eid+':assigned'
        extra=materialize_revision(ctx,result,data['essays'][eid]['manuscript']) if role=='author' else {'files':[]}
        if role=='critic':
            B.require(sid not in {x['session_id'] for x in old_authors.values()},'Critic reused an author session')
            parent=old_authors[eid]['lineage_entry_id']
        files=result['files']+extra['files'];key=ctx['run'].name+':accepted:'+jid;event=B.existing(w,key)
        if event:
            B.require(event['kind']=='research.revision.role.accepted' and event['payload'].get('files')==files
                      and event['session_id']==sid and event['payload'].get('scientific_role')==role,'Existing role acceptance differs')
            B.verify_event_files(ctx,w,event)
        else:
            scope=B.SessionWriter(w,sid,ctx['run'].name);source=B.resolve_session(sid,ctx['root']);caps=[]
            for msg in result['messages']:
                cap=B.capture(ctx['root']/'research/archive',source,sid,ctx['root'],start_line=msg['line'],end_line=msg['line'],
                    run_id=ctx['run'].name,archive_writer=scope)
                B.require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==1 and cap['raw_records'][0]['sha256']==msg['record_sha256'],'Exact visible role capture differs')
                caps.append(cap['coverage_event_id'])
            store(ctx,w,files);B.require(parent in known,'Exact role lineage parent missing')
            payload={'status':'SUBMISSION_REVISION_ROLE_ARCHIVED','job_id':jid,'essay_id':eid,'scientific_role':role,
                'transport_profile':'no_tools','transport_role':'argument','receipt':B.descriptor(result['receipt_path'],ctx['root']),
                'native_check':B.descriptor(result['receipt_path'].parent/'native-check.json',ctx['root']),
                'files':files,'capture_event_ids':caps,'scientific':True,'independence_verified':True,
                'stdout_boundary':result['stdout_boundary'],'old_roles_repeated':0,'derived_refresh':False}
            event=w.append(B.request(ctx,'research.revision.role.accepted',sid,jid,[entry['id'],known[parent]['id']]+caps,files,payload),key)
        events[event['id']]=event
        ident=ctx['run'].name+':'+eid+':'+role+':v1'
        line=L.base_entry(ident,data['essays'][eid]['entity'],'revision' if role=='author' else 'critique',
            'Fresh AI '+role+' on its exact single-essay packet; accepted original report and limitations retained.')
        artifacts=extra['files'] if role=='author' else [B.descriptor(result['receipt_path'].parent/'response.json',ctx['root'])]
        line.update(parents=[parent],artifacts=[dict(a,role='proposed_manuscript' if a['path'].endswith('/revision.md') else 'role_evidence') for a in artifacts],
            evidence=[event['id']],occurred_at=result['receipt'].get('completed_at','UNKNOWN'),actor={'role':'AI','session_id':sid},
            configuration={'requested':{'model':'gpt-6-astra','effort':'ultra','service_tier':'default'},'observed':result['proof'].get('configurations',[])},
            workflow={'run_id':ctx['run'].name,'essay_id':eid,'scientific_role':role,'job_id':jid},
            gaps=['Independent context and exact inputs are recorded; no claim of philosophical novelty certification.'])
        lev=L.append(w,line,sid,known,events)
        item={'job_id':jid,'essay_id':eid,'scientific_role':role,'session_id':sid,'event_id':event['id'],
              'lineage_event_id':lev['id'],'lineage_entry_id':ident,'receipt':B.descriptor(result['receipt_path'],ctx['root'])}
        if role=='author':item.update(revision=extra['revision'],diff=extra['diff'])
        roles.append(item);B.save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',dict(C.event_receipt(event),**item))
    status='SUBMISSION_AUTHORS_ARCHIVED' if ctx['wave']=='authors' else 'SUBMISSION_CRITICS_ARCHIVED'
    event=w.append(B.request(ctx,'research.revision.wave.accepted',C.SID,ctx['wave'],
        [entry['id']]+[i[k] for i in roles for k in ('event_id','lineage_event_id')],[],
        {'status':status,'roles':roles,'scientific_results_accepted':3,'derived_refresh':False}),ctx['run'].name+':wave:'+ctx['wave'])
    receipt=C.event_receipt(event);B.save_new(ctx['run']/(ctx['wave'].upper()+'_ARCHIVE_RECEIPT.json'),receipt);return receipt

def critic_binding(ctx,w):
    receipt=B.load(ctx['run']/'AUTHORS_ARCHIVE_RECEIPT.json',ctx['root']);event=B.canonical_event(w,receipt['event_id'])
    B.require(event['kind']=='research.revision.wave.accepted' and event['payload'].get('status')=='SUBMISSION_AUTHORS_ARCHIVED'
              and event['payload'].get('roles')==receipt.get('roles') and len(receipt['roles'])==3,'Exactly three canonical author results required')
    roles={x['essay_id']:x for x in receipt['roles']};B.require(set(roles)==C.ESSAYS,'Author trio differs')
    data,events,known=canonical_bases(ctx,w)
    for job in ctx['jobs'].values():
        eid=job['essay_id'];row=roles[eid];author=events[row['event_id']];lineage=known.get(row['lineage_entry_id'])
        B.require(author['kind']=='research.revision.role.accepted' and author['session_id']==row['session_id']
                  and author['payload'].get('scientific_role')=='author' and lineage is not None
                  and lineage['id']==row['lineage_event_id'] and author['id'] in lineage['parents'],'Exact author/lineage linkage differs')
        B.verify_event_files(ctx,w,author)
        required=[data['essays'][eid]['manuscript'],row['revision'],row['diff']]
        for index,ref in enumerate(required):
            fields=('sha256','bytes') if index==0 else ('path','sha256','bytes')
            B.require(any(all(x.get(k)==ref[k] for k in fields) for x in job['inline_inputs']),
                      'Critic must receive exact original, accepted revision and mechanical diff')
            B.require(w.get(ref['sha256'])==B.bound(ref,ctx['root']),'Critic source object differs')
        allowed={row['revision']['path'],row['diff']['path']}
        for ref in job['inline_inputs']:
            if ref['path'].startswith(str((ctx['run']/'results').relative_to(ctx['root']))+'/'):
                B.require(ref['path'] in allowed,'Critic may not receive author log/report or another essay result')
    return event

def accept_critic_inputs(ctx,w):
    author=critic_binding(ctx,w);start_receipt=B.load(ctx['run']/'AUTHORS_START_RECEIPT.json',ctx['root'])
    first=B.canonical_event(w,start_receipt['event_id']);ctx['start']=start_receipt
    store(ctx,w,ctx['files'])
    event=w.append(B.request(ctx,C.KINDS['critics'],C.SID,'critic-inputs-v1',[first['id'],author['id']],ctx['files'],
        {'status':C.STATUSES['critics'],'files':ctx['files'],'scientific_role':'critic','scientific_roles':3,
         'transport_profile':'no_tools','transport_role':'argument','author_wave_event_id':author['id'],'derived_refresh':False}),
        ctx['run'].name+':critic-inputs:v1')
    receipt=C.event_receipt(event);B.save_new(ctx['run']/'CRITICS_START_RECEIPT.json',receipt);return receipt

def prepare(mode,root=C.ROOT,run=C.RUN):
    if mode=='inputs':return prepare_inputs(root,run),None
    if mode=='critic-inputs':return C.inputs('critics',run,root),None
    ctx=C.gate(mode,run,root);return ctx,terminal_results(ctx)

def finish(mode,ctx,w,results=None):
    w._ensure_audited();ctx,results=prepare(mode,ctx['root'],ctx['run'])
    if mode=='inputs':return accept_inputs(ctx,w)
    if mode=='critic-inputs':return accept_critic_inputs(ctx,w)
    return accept_wave(ctx,w,results)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('inputs','authors','critic-inputs','critics'));p.add_argument('--apply',action='store_true');p.add_argument('--check',action='store_true')
    a=p.parse_args();B.require(not(a.apply and a.check),'Choose check or apply');ctx,results=prepare(a.mode)
    if not a.apply:print(json.dumps({'status':'READ_ONLY_PREFLIGHT_PASS','mode':a.mode,'archive_writes':0,'provider_calls':0}))
    else:
        with B.Archive(C.ROOT/'research/archive').writer() as w:answer=finish(a.mode,ctx,w,results)
        print(json.dumps(answer))
