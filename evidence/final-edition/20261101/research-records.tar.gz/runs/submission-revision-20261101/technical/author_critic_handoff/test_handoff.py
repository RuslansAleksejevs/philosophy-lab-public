"""Bounded orchestration fixtures; no provider or real archive operations."""
from pathlib import Path
import contextlib
import importlib.util
import tempfile
import unittest
from unittest.mock import Mock,patch

spec=importlib.util.spec_from_file_location('tested_handoff',Path(__file__).with_name('handoff.py'))
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)

class Handoff(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.temp.name)
        self.run=self.root/'runs/submission-revision-20261101';self.run.mkdir(parents=True)
    def tearDown(self):self.temp.cleanup()
    def test_readiness_exact_author_and_manifest_and_no_symlink(self):
        manifest=self.run/'CRITIC_INPUT_MANIFEST.json';manifest.write_text('{"files":[]}')
        value={'status':'CRITIC_INPUTS_READY','author_wave_event_id':'author-event','manifest':H.B.descriptor(manifest,self.root)}
        marker=self.run/'CRITIC_READY.json';marker.write_bytes(H.B.encoded(value))
        self.assertEqual(H.wait_for_ready(self.run,self.root,'author-event'),value)
        with self.assertRaisesRegex(ValueError,'exact accepted'):H.ready_value(self.run,self.root,'wrong-author')
        manifest.write_text('{"files":[1]}')
        with self.assertRaisesRegex(ValueError,'exact accepted'):H.ready_value(self.run,self.root,'author-event')
        other=self.run/'other.json';other.write_bytes(marker.read_bytes());marker.unlink();marker.symlink_to(other)
        with self.assertRaises(ValueError):H.ready_value(self.run,self.root,'author-event')
    def exercise(self,timeout=False,unfinished=False):
        calls=[];writer=Mock();writer._ensure_audited.side_effect=lambda:calls.append('audit')
        writer.append.return_value={'id':'complete-event'}
        @contextlib.contextmanager
        def owned():
            calls.append('lock')
            try:yield writer
            finally:calls.append('release')
        archive=Mock();archive.writer.side_effect=owned
        ctx={'root':self.root,'run':self.run,'start':{'event_id':'input','bindings':{}},'manifest_ref':{'fixture':True}}
        def prepare(mode,*unused):
            calls.append('prepare:'+mode)
            if unfinished:raise ValueError('No completed terminal')
            return ({k:v for k,v in ctx.items() if k!='start'} if mode=='critic-inputs' else ctx),{}
        def finish(mode,received,w,*unused):
            self.assertIs(w,writer);calls.append('finish:'+mode)
            return {'status':'accepted','event_id':mode,'bindings':{}}
        def wait(*unused):
            calls.append('wait')
            if timeout:
                ticks=iter([0,600])
                return H.wait_for_ready_original(self.run,self.root,'authors',clock=lambda:next(ticks),sleep=lambda _:self.fail('No sleep expected'))
            return {'manifest':ctx['manifest_ref']}
        with patch.object(H,'preparation',return_value=[]),patch.object(H.A,'prepare',side_effect=prepare),patch.object(H.A,'finish',side_effect=finish),patch.object(H.B,'Archive',return_value=archive),patch.object(H,'bind_preparation',return_value={'id':'provenance'}),patch.object(H,'wait_for_ready',side_effect=wait),patch.object(H,'ready_value'),patch.object(H.A,'store'),patch.object(H.B,'descriptor',return_value={'sha256':'0'*64}),patch.object(H.C,'event_receipt',return_value={}),patch.object(H.B,'save_new'):
            if timeout or unfinished:
                with self.assertRaises(TimeoutError if timeout else ValueError):H.conduct(self.run,self.root)
            else:H.conduct(self.run,self.root)
        return calls
    def test_one_writer_accepts_authors_before_wait_and_releases_before_dispatch(self):
        calls=self.exercise()
        self.assertEqual(calls,['prepare:authors','lock','audit','prepare:authors','finish:authors','wait','prepare:critic-inputs','finish:critic-inputs','release'])
    def test_timeout_releases_writer_preserving_author_acceptance(self):
        calls=self.exercise(timeout=True)
        self.assertEqual(calls[-3:],['finish:authors','wait','release'])
        self.assertNotIn('finish:critic-inputs',calls)
    def test_unfinished_models_never_acquire_writer(self):
        self.assertEqual(self.exercise(unfinished=True),['prepare:authors'])

H.wait_for_ready_original=H.wait_for_ready
if __name__=='__main__':unittest.main()
