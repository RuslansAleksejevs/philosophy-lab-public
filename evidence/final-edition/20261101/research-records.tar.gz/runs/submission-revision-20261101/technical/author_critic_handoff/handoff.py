"""One ordinary audited writer for completed authors and subsequent critic inputs."""
from pathlib import Path
import argparse
import importlib.util
import json
import time

LANE=Path(__file__).resolve().parent;RUN=LANE.parents[1];ROOT=RUN.parents[1]
spec=importlib.util.spec_from_file_location('revision_handoff_acceptance',LANE.parent/'archive_v2.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A);C=A.C;B=C.B
LIMIT=600

def preparation(run=RUN,root=ROOT):
    lane=run/'technical/author_critic_handoff'
    names=['handoff.py','test_handoff.py','README.md','CHECKS.json','INDEPENDENT_REVIEW_HEALTH.json']
    refs=[B.descriptor(lane/n,root) for n in names]
    refs += [B.descriptor(run/'technical'/n,root) for n in ('common_v2.py','archive_v2.py','runner_v2.py')]
    refs += [B.descriptor(run/'INPUT_MANIFEST-v2.json',root)]
    manifest=B.descriptor(lane/'MANIFEST.json',root)
    value=B.strict_json(C.safe_file(manifest,root))
    B.require(value=={'status':'AUTHOR_CRITIC_HANDOFF_PREPARED','files':refs,'max_wait_seconds':LIMIT,
        'wait_for_models_under_lock':False,'provider_actions':False},'Exact conductor manifest differs')
    for ref in refs:C.safe_file(ref,root)
    return refs+[manifest]

def bind_preparation(ctx,w,refs):
    A.store(ctx,w,refs)
    payload={'status':'AUTHOR_CRITIC_HANDOFF_ARCHIVED','files':refs,'max_wait_seconds':LIMIT,
        'wait_for_models_under_lock':False,'provider_actions':False,'derived_refresh':False}
    event=w.append(B.request(ctx,'research.revision.wave_handoff.prepared',C.SID,'author-critic-handoff',
        [ctx['start']['event_id']],refs,payload),ctx['run'].name+':author-critic-handoff:prepared:v1')
    return event

def ready_value(run,root,author_event_id):
    marker=run/'CRITIC_READY.json';value=B.load(marker,root)
    ref=B.descriptor(run/'CRITIC_INPUT_MANIFEST.json',root)
    B.require(value=={'status':'CRITIC_INPUTS_READY','author_wave_event_id':author_event_id,'manifest':ref},
        'Critic readiness must bind the exact accepted authors and manifest')
    C.safe_file(ref,root)
    return value

def wait_for_ready(run,root,author_event_id,clock=time.monotonic,sleep=time.sleep):
    end=clock()+LIMIT
    while True:
        if (run/'CRITIC_READY.json').exists():return ready_value(run,root,author_event_id)
        if clock()>=end:
            raise TimeoutError('Authors remain accepted; critic packets not ready within 600 seconds. Writer released; do not rerun authors.')
        sleep(min(0.5,max(0,end-clock())))

def conduct(run=RUN,root=ROOT):
    preparation(run,root)
    # Any unfinished/missing terminal fails before acquiring the archive lock.
    ctx,results=A.prepare('authors',root,run)
    print('THREE_COMPLETED_AUTHORS_VALIDATED_WAITING_FOR_ARCHIVE',flush=True)
    with B.Archive(root/'research/archive').writer() as w:
        w._ensure_audited()
        refs=preparation(run,root)
        ctx,results=A.prepare('authors',root,run)
        provenance=bind_preparation(ctx,w,refs)
        authors=A.finish('authors',ctx,w,results)
        print(json.dumps({'status':authors['status'],'event_id':authors['event_id'],
            'critic_packet_preparation_ready':True,'wait_seconds':LIMIT}),flush=True)
        ready=wait_for_ready(run,root,authors['event_id'])
        critics,_=A.prepare('critic-inputs',root,run)
        B.require(critics['manifest_ref']==ready['manifest'],'Prepared critic manifest differs from readiness')
        ready_value(run,root,authors['event_id'])
        accepted=A.finish('critic-inputs',critics,w)
        critics=dict(critics,start=accepted)
        ready_ref=B.descriptor(run/'CRITIC_READY.json',root)
        A.store(critics,w,[ready_ref])
        files=refs+[ready_ref]
        done=w.append(B.request(critics,'research.revision.wave_handoff.completed',C.SID,'author-critic-handoff-complete',
            [provenance['id'],authors['event_id'],accepted['event_id']],files,
            {'status':'AUTHOR_CRITIC_HANDOFF_COMPLETE','files':files,'authors_event_id':authors['event_id'],
             'critic_inputs_event_id':accepted['event_id'],'provider_calls':0,'derived_refresh':False}),
            run.name+':author-critic-handoff:completed:v1')
        B.save_new(run/'AUTHOR_CRITIC_HANDOFF_RECEIPT.json',C.event_receipt(done))
    print(json.dumps({'status':'AUTHOR_CRITIC_HANDOFF_COMPLETE','writer_released':True,
        'critic_inputs_event_id':accepted['event_id'],'critic_dispatch_performed':False}),flush=True)
    return accepted

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--apply',action='store_true');p.add_argument('--check',action='store_true')
    args=p.parse_args();B.require(not(args.apply and args.check),'Choose check or apply')
    if args.apply:conduct()
    else:
        preparation();A.prepare('authors')
        print(json.dumps({'status':'HANDOFF_READ_ONLY_PREFLIGHT_PASS','archive_writes':0,'provider_calls':0}))
