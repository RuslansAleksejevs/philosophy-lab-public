# One writer: accepted authors to critic inputs

This additive conductor preserves all 112 frozen V2 inputs. It has no provider,
dispatcher, service action or derived refresh. Its own exact manifest and code
are stored in a canonical preparation event before author acceptance. The frozen
archive_v2 prepare/finish functions perform the existing native, canonical and
lineage checks unchanged, including fresh preparations inside the ordinary writer.

Root launches it only when all three author terminal receipts exist:

```sh
python3 -B runs/submission-revision-20261101/technical/author_critic_handoff/handoff.py --check
python3 -B runs/submission-revision-20261101/technical/author_critic_handoff/handoff.py --apply
```

After AUTHORS_ARCHIVE_RECEIPT.json appears, root runs the already-bound
prepare_critics.py and freezes CRITIC_INPUT_MANIFEST.json. That manifest retains
all V2 input files and its manifest, and adds accepted author receipts, revisions,
diffs, and the new jobs/critic prompts. Publish CRITIC_READY.json atomically LAST:

```json
{
  "status": "CRITIC_INPUTS_READY",
  "author_wave_event_id": "exact AUTHORS_ARCHIVE_RECEIPT event_id",
  "manifest": {
    "path": "runs/submission-revision-20261101/CRITIC_INPUT_MANIFEST.json",
    "sha256": "exact SHA-256",
    "bytes": 0
  }
}
```

The byte count must be the actual manifest size. Readiness binds the exact author
wave, never an unaccepted manuscript or model that is still running. Wait limit
is 600 seconds from author acceptance. Timeout or failure closes the writer and
leaves accepted authors durable; no role is rerun. Root can later use the frozen
archive_v2.py critic-inputs --apply as a separate audited recovery step.

On success the conductor canonically binds readiness and both accepted waves,
writes AUTHOR_CRITIC_HANDOFF_RECEIPT.json and releases the writer. Root launches
runner_v2.py critics only after this process exits successfully. It must never
start critic models merely because READY was published. Collector restart remains
root's responsibility. There is no model waiting under the lock.

Tests use synthetic orchestration and temporary readiness files only:

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/technical/author_critic_handoff -p 'test_*.py' -q
```
