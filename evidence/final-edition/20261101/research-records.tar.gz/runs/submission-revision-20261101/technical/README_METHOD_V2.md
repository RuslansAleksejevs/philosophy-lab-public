# Protocol registration repair

The first input acceptance stopped at `philosophy_round.start` because METHOD.json
omitted the required nonempty `id` and ordered five `stages`. This happened before
the first archive object or event write and before any provider job. The original
101 input files, manifest and failure log remain unchanged.

METHOD-v2.json adds exactly those two administrative fields. INPUT_MANIFEST-v2.json
retains every original descriptor and binds the additive code, amendment and
failure evidence. common_v2.py checks the exact old manifest SHA and every old
file; any other method change fails. Only the exact preserved failure-log path
is additionally accepted as UTF-8 text and passed through the existing privacy
scanner. The runner and acceptance code differ only in their module/method/
manifest routing. Scientific jobs, prompts, schemas and source bytes are unchanged.

Root executes these commands from the project root after independent review:

```sh
python3 -B runs/submission-revision-20261101/technical/archive_v2.py inputs --check
python3 -B runs/submission-revision-20261101/technical/archive_v2.py inputs --apply
python3 -B runs/submission-revision-20261101/technical/runner_v2.py authors --check
python3 -B runs/submission-revision-20261101/technical/runner_v2.py authors
```

Later use archive_v2.py for `authors`, `critic-inputs`, `critics` and runner_v2.py
for `critics`. The critic manifest must preserve the complete original input
manifest and all V2 inputs, adding the exact accepted author outputs and fresh
critic packets. Public prepare/finish APIs and receipt schemas are unchanged.
The separate final closure must import archive_v2/common_v2 and bind those sources.
Every real archive acceptance still takes the ordinary audited writer. The
collector restart remains root's responsibility after canonical writes finish.

Synthetic checks (temporary archives only; no provider/service/canonical action):

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/technical -p 'test_*.py' -q
```

The new regression calls the actual production start function: the old method
fails before put, each missing field fails, the corrected method creates an
epoch and one start, and a retry after a new audit returns the same event.
