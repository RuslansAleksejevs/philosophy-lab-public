"""Real start/retry on a temporary archive only; no native/provider/service IO."""
from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('revision_v2_test',Path(__file__).with_name('archive_v2.py'))
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A);C=A.C;B=C.B

class MethodRepair(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir='/private/tmp');self.root=Path(self.temp.name).resolve()
        self.run=self.root/'runs/submission-revision-20261101';self.run.mkdir(parents=True)
        self.old=B.load(C.RUN/'METHOD.json',C.ROOT)
        self.write(self.run/'METHOD.json',self.old)
        self.write(self.run/'METHOD-v2.json',dict(self.old,id=self.run.name,stages=C.STAGES))
        self.write(self.root/'LAB_PROFILE.json',{'lab':{'kind':'PHILOSOPHY_PROGRAM'}})
        self.write(self.root/'.lab/philosophy.json',{'synthetic':True})
        for name in ('AGENTS.md','AGENT_POLICY.md','USER_PREFERENCES.md','workflows/ROUND.md','.codex/config.toml'):
            p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# synthetic configuration\n')
        (self.run/'inputs-archive.log').write_text('Synthetic original registration failure; no model call.\n')
        self.old_rows=[B.descriptor(self.run/'METHOD.json',self.root)]
        self.write(self.run/'INPUT_MANIFEST.json',{'files':self.old_rows})
        self.pin=patch.object(C,'OLD_MANIFEST_SHA',B.descriptor(self.run/'INPUT_MANIFEST.json',self.root)['sha256']);self.pin.start()
        self.amendment={'status':'METHOD_PROTOCOL_REGISTRATION_REPAIR_PREPARED',
            'previous_manifest':B.descriptor(self.run/'INPUT_MANIFEST.json',self.root),
            'old_method':B.descriptor(self.run/'METHOD.json',self.root),
            'new_method':B.descriptor(self.run/'METHOD-v2.json',self.root),
            'failure_log':B.descriptor(self.run/'inputs-archive.log',self.root),
            'scientific_inputs_changed':False,'provider_calls_before_failure':0}
        self.write(self.run/'METHOD_AMENDMENT.json',self.amendment)
        self.archive=B.Archive(self.root/'research/archive').init()
    def tearDown(self):self.pin.stop();self.temp.cleanup()
    def write(self,path,value):
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(B.encoded(value))
    def start(self,w,name):
        return A.start(self.root,w,self.run.name,'synthetic-root','research',str((self.run/name).relative_to(self.root)),
            [str((self.run/'INPUT_MANIFEST.json').relative_to(self.root))],
            stage_id='SUBMISSION_REVISION',selection_round_id='USER_SELECTED_TRIO')
    def test_old_protocol_fails_before_any_put_or_event(self):
        with self.archive.writer() as w,patch.object(w,'put',wraps=w.put) as put:
            with self.assertRaisesRegex(C.AR.ArchiveError,'five supported'):self.start(w,'METHOD.json')
            put.assert_not_called();self.assertEqual(w.events(),[])
    def test_each_required_field_is_checked_by_real_start(self):
        for value in (dict(self.old,id=self.run.name),dict(self.old,stages=C.STAGES)):
            self.write(self.run/'bad.json',value)
            with self.archive.writer() as w,patch.object(w,'put',wraps=w.put) as put:
                with self.assertRaises(C.AR.ArchiveError):self.start(w,'bad.json')
                put.assert_not_called()
    def test_new_protocol_real_epoch_start_and_fresh_audit_retry(self):
        C.method_amendment(self.run,self.root)
        with self.archive.writer() as w:first=self.start(w,'METHOD-v2.json')
        with self.archive.writer() as w:
            second=self.start(w,'METHOD-v2.json')
            self.assertEqual(first,second)
            self.assertEqual([e['kind'] for e in w.events()],['lab.epoch','operation.started'])
            self.assertEqual(second['payload']['purpose'],'research')
            self.assertEqual(second['payload']['stage_id'],'SUBMISSION_REVISION')
            self.assertEqual(second['payload']['selection_round_id'],'USER_SELECTED_TRIO')
            self.assertEqual(second['payload']['stage_order'],C.STAGES)
    def test_scientific_delta_rejected_even_with_updated_amendment_hash(self):
        value=B.load(self.run/'METHOD-v2.json',self.root);value['scope']='changed scientific scope'
        self.write(self.run/'METHOD-v2.json',value)
        self.amendment['new_method']=B.descriptor(self.run/'METHOD-v2.json',self.root)
        self.write(self.run/'METHOD_AMENDMENT.json',self.amendment)
        with self.assertRaisesRegex(ValueError,'Only missing'):C.method_amendment(self.run,self.root)
    def test_original_manifest_tamper_rejected(self):
        self.write(self.run/'INPUT_MANIFEST.json',{'files':[]})
        with self.assertRaisesRegex(ValueError,'Original frozen'):C.method_amendment(self.run,self.root)
    def test_original_bound_bytes_tamper_rejected(self):
        self.write(self.run/'METHOD.json',dict(self.old,scope='changed'))
        with self.assertRaisesRegex(ValueError,'Bound file changed'):C.method_amendment(self.run,self.root)
    def test_failure_log_change_rejected(self):
        (self.run/'inputs-archive.log').write_text('different')
        with self.assertRaisesRegex(ValueError,'preserved method'):C.method_amendment(self.run,self.root)
    def test_runner_and_archive_have_only_declared_routing_changes(self):
        lane=Path(__file__).parent
        expected=(lane/'runner.py').read_text().replace("with_name('common.py')","with_name('common_v2.py')")
        self.assertEqual((lane/'runner_v2.py').read_text(),expected)
        expected=(lane/'archive.py').read_text().replace("with_name('common.py')","with_name('common_v2.py')").replace("ctx['run']/'METHOD.json'","ctx['run']/'METHOD-v2.json'").replace("for p in ('INPUT_MANIFEST.json','technical/AUTHORIZATION_SOURCE.json'","for p in ('INPUT_MANIFEST-v2.json','technical/AUTHORIZATION_SOURCE.json'")
        self.assertEqual((lane/'archive_v2.py').read_text(),expected)

if __name__=='__main__':unittest.main()
