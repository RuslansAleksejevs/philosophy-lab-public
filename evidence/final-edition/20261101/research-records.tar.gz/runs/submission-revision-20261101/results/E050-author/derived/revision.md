# What Holding Cannot Tell Us About Letting Go

An intervention may keep a system in a desired condition while it remains in place. Whether that condition survives withdrawal is a further question. Temporary control succeeds when it leaves the system able to maintain the desired outcome after support ends.

Consider an unusually rich body of evidence about maintained conditions. For every nonempty selection of variables, every constant setting, and every initial state of the free variables, we know the limiting outcome when the selected variables are held fixed indefinitely. We also know a baseline trajectory and all equilibria with their qualitative stability. Does this identify what happens when a particular prepared state is released?

It need not. Two smooth systems can agree on this entire collection of evidence yet approach opposite stable equilibria after the same release. The limitation concerns both the intervention menu and its readout: persistent coordinate clamps are observed through their limiting outcomes. Complete coverage within that menu does not establish the outcome of withdrawal.

The example also separates failure to identify one procedure's outcome from inability to choose a reliable alternative. Simultaneous withdrawal has an unidentified outcome, but one order of release guarantees the desired limiting outcome throughout the stipulated family. Reversing that order leaves disagreement after every fixed finite wait. The guarantee requires a known dynamical form and time scale; the endpoint evidence alone does not supply them.

## The question and its scope

The distinction between holding and releasing is already established. Weinberger's *Intervening and Letting Go* discusses a gas with a movable piston and the models appropriate when its volume is fixed or free. Removing a constraint is an action against which a model's adequacy can be assessed (Weinberger 2023, §5, especially pp. 2480–2482). The question here is narrower: what does an exhaustive collection of specified holding outcomes establish about release?

Initial-state dependence is also familiar. Blom, Bongers, and Mooij's causal constraints models can incorporate equilibrium outcome maps for intervention targets including the empty target (2020, §§1.1, 2.2, and 3.4, Theorem 2 and proof, PDF p. 7). A formalism's ability to represent these maps does not make one map inferable from the others. Here the missing information is the unclamped outcome from a particular prepared state.

A closer antecedent concerns hidden relative speeds. Bongers, Blom, and Mooij show that a dynamical causal model cannot generally be recovered uniquely from its equilibration (2022, arXiv:1803.08784v4, §4.6, Example 4.21, pp. 36–37). Their linear example places an invertible diagonal matrix before the time derivative. The equilibrium equations remain the same, as do intervened equilibrium states under the stated invertibility condition for the remaining subsystem. Positive diagonal choices illustrate how relative speeds can disappear from equilibrium descriptions. The paragraph following the example explicitly warns that solutions of both systems need not actually converge.

That example establishes an antecedent for the mechanism used here. The present construction adds a specific combination of results: all stipulated clamp endpoint data, including the baseline, agree; convergence to opposite stable endpoints after simultaneous release is proved; and one release order works for every member of the family while the reverse order has no uniform finite wait. Within this restricted intervention menu, agreement of proved limiting outcomes supplies more information than equality of equilibrium equations alone. The additional conclusions are not attributed to the linear example.

Dash's discussion of manipulation and equilibration likewise shows why temporal structure can matter to causal inference (2005, §§5–6, especially PDF p. 7). The distinction between a change at a particular time and a sustained intervention also appears in the available search excerpts for Ryan and Dablander (2025). Their full text was unavailable for this comparison, so no section-level attribution or detailed assessment of their argument is made.

These comparisons locate the argument without establishing priority. None of these authors is being charged with inferring release outcomes from the restricted evidence considered below. The mathematical argument is self-contained; its relation to robust switching under parameter uncertainty will become clear after the release procedures are defined.

## Systems and evidence

Let two observed real-valued quantities obey

\[
\dot x=x-x^3+y,\qquad \dot y=-ky,\qquad k>0.
\tag{1}
\]

Write \(\mathcal C\) for this family. Its members differ only in the positive constant \(k\). When \(y=0\), the scalar \(x\) dynamics have stable equilibria at \(-1\) and \(1\), separated by an unstable equilibrium at \(0\). Positive \(y\) supplies an upward influence whose duration depends on \(k\).

These are mathematical systems, not fitted models of a treatment or apparatus. Their possible relevance is structural: a variable with two self-maintaining states receives temporary support. The equations carry the argument. They are smooth and have unique solutions for all future times. Indeed, \(y\) decays exponentially, and the negative cubic term bounds \(x\): for sufficiently large absolute \(x\), the vector field points inward despite the bounded input \(y\).

A *persistent coordinate clamp* replaces the equation for each selected coordinate with the requirement that it remain at a specified constant. The free coordinates retain their equations and specified initial values. The readout is the limiting pair \((x,y)\).

Let the evidence \(E\) contain:

- Every limiting outcome under an \(x\) clamp, for every clamp value and initial \(y\).
- Every limiting outcome under a \(y\) clamp, for every clamp value and initial \(x\).
- Every limiting outcome under a joint clamp, at every pair of values.
- The uncontrolled baseline trajectory from \((-1,0)\).
- The complete unclamped and clamped equilibrium catalogues, with qualitative stability classifications.

The first three items exhaust the nonempty persistent coordinate clamps. They include dependence on initial states; they do not assume that every clamp has a unique attracting equilibrium. The baseline trajectory is constant. Arbitrary uncontrolled trajectories and their endpoints are excluded, since knowing the uncontrolled endpoint from every initial state would already supply the release outcome at issue.

**Every member of \(\mathcal C\) agrees on \(E\).** To prove this, first clamp \(x=a\). The free equation is \(\dot y=-ky\), so the limiting pair is \((a,0)\), independently of \(k\) and the initial \(y\).

Next clamp \(y=b\). The remaining equation is

\[
\dot x=x-x^3+b.
\tag{2}
\]

It contains no \(k\), so the entire free trajectory is identical across the family for any specified initial \(x\). Every trajectory has a limit. The cubic points inward for large absolute \(x\), and its sign is constant between consecutive roots. A solution starting away from a root moves monotonically toward a root and cannot cross it, by uniqueness. A solution starting at a root stays there. Multiple roots and one-sided attraction do not affect agreement because the scalar equation is identical.

A joint clamp fixes the pair by stipulation. The baseline \((-1,0)\) is an equilibrium for every \(k\).

Finally, the unclamped equilibria are exactly

\[
(-1,0),\qquad (0,0),\qquad (1,0).
\]

Their Jacobians are triangular, with eigenvalues \(1-3x^2\) and \(-k\). Thus the outer equilibria are asymptotically stable and the middle one is a saddle for every \(k>0\). Under an \(x\) clamp, the free coordinate decays to zero. Under a \(y\) clamp, the scalar equation is identical across the family. A joint clamp leaves no free dynamics. The clamped equilibrium and qualitative stability catalogues therefore agree too, including the nonhyperbolic cases of (2). Numerical eigenvalues and relaxation rates are not part of \(E\).

The information loss has a precise location. Clamping \(y\) removes the equation containing \(k\). Clamping only \(x\) leaves that equation active, but the endpoint readout discards its rate. Clamping both removes both equations. The baseline reveals no motion. No experiment in this menu both allows the two equations to interact away from baseline and retains information about that interaction. Exhaustiveness over targets and settings does not restore what the procedures and readouts remove.

## The same release, opposite endpoints

Prepare each system by jointly clamping

\[
x=-\tfrac12,\qquad y=1.
\]

At time zero remove both clamps. Then \(y(t)=e^{-kt}\). Compare \(k=1/100\) with \(k=100\).

**Slow decay.** For \(k=1/100\), while \(x\in[-1/2,0]\),

\[
x-x^3\geq-\frac{2}{3\sqrt3}>-0.385.
\]

During the first unit of time, \(y(t)\geq e^{-0.01}>0.990\). Hence \(\dot x>0.605\) while \(x\) lies in that interval. The trajectory cannot leave through \(-1/2\) during this period and must cross zero in less than

\[
\frac{0.5}{0.605}<0.827
\]

time units.

At \(x=0\), the derivative is \(y(t)>0\) at every finite time, so \(x\) cannot subsequently cross back into negative values. Choose a time \(s\) just after the crossing, with \(0<x(s)<1\), and compare \(x\) with

\[
\dot z=z-z^3,\qquad z(s)=x(s).
\]

Scalar comparison gives \(x(t)\geq z(t)\) for \(t\geq s\), since the additional input \(y\) is positive. As \(z(t)\to1\), we have \(\liminf_{t\to\infty}x(t)\geq1\).

For any \(\varepsilon>0\), once \(y\) is sufficiently small, \(\dot x\) is bounded above by a strictly negative constant whenever \(x\geq1+\varepsilon\). This follows because \(x-x^3\) is decreasing there and is negative at \(1+\varepsilon\). Boundedness and this derivative bound force eventual entry below that level; the vector field prevents upward recrossing. Thus \(\limsup_{t\to\infty}x(t)\leq1\). The released system converges to \((1,0)\).

**Fast decay.** For \(k=100\), the total upward input is

\[
\int_0^\infty y(t)\,dt=0.01.
\]

Before any hypothetical first crossing of zero, \(x\geq-1\), because its derivative at \(-1\) is positive. On \([-1,0]\), we have \(x-x^3\leq0\). Integration therefore gives

\[
x(t)\leq-\tfrac12+\int_0^t y(u)\,du\leq-0.49.
\]

This contradicts a first crossing of zero. Consequently,

\[
-1\leq x(t)\leq-0.49
\]

for all time.

For any \(0<\varepsilon<0.51\), the continuous function \(-(x-x^3)\) has a strictly positive minimum \(m\) on \([-1+\varepsilon,-0.49]\). Eventually \(y<m/2\), so thereafter \(\dot x<-m/2\) throughout that interval. The trajectory must enter \([-1,-1+\varepsilon]\), and the negative derivative at its upper boundary prevents upward exit. Since \(\varepsilon\) can be arbitrarily small, \(x(t)\to-1\). The limiting pair is \((-1,0)\).

The same estimates establish the positive outcome for every \(0<k\leq1/100\) and the negative outcome for every \(k\geq100\). These are sufficient ranges, not an exact dividing threshold.

We have proved:

> Over \(\mathcal C\), the limiting outcome of simultaneous release from \((-1/2,1)\) is not identified by \(E\). The same nonidentification holds over any larger admissible class containing the displayed pair.

Any rule assigning a unique release endpoint from \(E\) alone must assign the same answer to both systems and therefore fail for at least one. This is a limitation on what the specified evidence entails. Further assumptions or evidence may support a prediction.

## What the basin explanation must say

The slow system's crossing of \(x=0\) is not a crossing of that autonomous system's basin boundary.

For a fixed \(k\), a basin of attraction consists of full states \((x,y)\) whose future trajectories converge to the relevant attractor. If a trajectory converges to \((1,0)\), every later state along it has that same limiting outcome. It remains in the basin throughout its autonomous evolution. Thus \((-1/2,1)\) already belongs to the positive equilibrium's basin in the slow system. The same coordinate pair belongs to the negative equilibrium's basin in the fast system.

The sign of \(x\) alone does not classify full-system basin membership when \(y\ne0\). With \(y=0\), zero separates the two attracting outcomes of the scalar \(x\) dynamics. With positive \(y\), the line \(x=0\) is not invariant: there \(\dot x=y>0\). Crossing this line supplies a useful sufficient condition for the positive outcome in the proof. It does not mark passage between basins of the same released system.

The contrast is between two vector fields and their different basin assignments. Slow decay permits \(x\) to become positive while the upward influence persists; comparison then establishes convergence to \(1\). Fast decay supplies too little total input, leaving \(x\) bounded away from zero on the negative side. These inequalities explain the different outcomes without misdescribing either trajectory.

A basin description could state the relevant difference without specifying an exact rate. The result does not require every adequate explanation to mention \(k\). It establishes that equilibrium locations, qualitative stability, and the stipulated clamp outcomes do not determine the needed basin assignment.

## Choosing the order of withdrawal

Suppose the objective is a lasting transition to \((1,0)\) from the jointly prepared state \((-1/2,1)\). Assume that the functional form and time scale of (1) are independently justified, while \(k>0\) remains unknown. The following guarantees concern \(\mathcal C\); they do not extend automatically to every system compatible with \(E\).

Simultaneous release cannot be certified as successful throughout \(\mathcal C\). A staged procedure can. It uses the same prepared state and removes the same two clamps:

1. Release \(x\), keeping \(y=1\) for one time unit.
2. Release \(y\) as well.

During the first stage,

\[
\dot x=x-x^3+1,
\]

independently of \(k\). While \(x\in[-1/2,0]\),

\[
\dot x\geq c:=1-\frac{2}{3\sqrt3}>0.615.
\]

The trajectory therefore crosses zero within at most \(1/(2c)<0.814\) time units. It cannot return through zero while \(y=1\), because its derivative there is \(1\). At the second release, \(x>0\) and \(y=1\) for every member of the family.

Any released state with \(x>0\) and \(y\geq0\) converges to \((1,0)\) in this family. To verify this, compare its \(x\) trajectory with the unforced equation \(\dot z=z-z^3\) from the same positive initial value. That solution tends to \(1\), whether it starts above or below \(1\), and scalar comparison gives \(x\geq z\). Hence \(\liminf x\geq1\). Since \(y\to0\), the upper-bound argument from the slow-decay proof gives \(\limsup x\leq1\). The staged procedure therefore succeeds for every \(k>0\).

The one-unit wait concerns only the first stage. After the second release, convergence to the target is asymptotic. There is no common finite settling time over all \(k>0\), even for a fixed small tolerance. Writing \(t\) for time since the second release, we have \(y(t)=e^{-kt}\). For any \(0<\delta<1\), the necessary condition \(y(t)\leq\delta\) for being within distance \(\delta\) of \((1,0)\) requires

\[
t\geq\frac{\log(1/\delta)}{k}.
\]

This bound diverges as \(k\) approaches zero. Uniformity concerns the first-stage wait and the limiting endpoint; the time to approach that endpoint still depends on \(k\).

Now reverse the order. Release \(y\) first, keep \(x=-1/2\) for a fixed finite time \(T\geq0\), and then release \(x\). At the final release the state is

\[
\left(-\tfrac12,e^{-kT}\right).
\]

Writing \(t\) for time since that release, the remaining input is \(y(t)=e^{-k(T+t)}\).

For every fixed finite \(T\), sufficiently slow members still converge to \((1,0)\). In particular, if

\[
0<k\leq\frac{0.01}{T+1},
\]

then \(y(t)\geq e^{-0.01}>0.990\) for the first unit of released time. The slow-decay proof applies unchanged.

For \(k\geq100\), however,

\[
\int_0^\infty y(t)\,dt=\frac{e^{-kT}}{k}\leq0.01.
\]

The fast-decay proof applies, and the endpoint is \((-1,0)\). Thus every fixed finite wait in the reverse order leaves both outcomes possible across \(\mathcal C\). No such wait guarantees the desired transition throughout the family.

The successful procedure uses no additional measurements to estimate \(k\). Its guarantee follows from the shared dynamics while \(y\) is clamped and the convergence result for positive \(x\). The one-unit duration is a sufficient bound in the known units of (1), not an optimal duration or a bound warranted for an arbitrary physical system. These dynamical assumptions are not consequences of \(E\). Enlarging the admissible class preserves nonidentification whenever it retains the two counterexample systems, but it need not preserve the staged procedure's guarantee.

### Relation to robust switching

Successful temporary control under parameter uncertainty is an established aim. Sootla, Oyarzún, Angeli, and Stan study finite pulses that switch a bistable system to an enduring unforced attractor (2016; author preprint dated 5 October 2015, §2.1, p. 3). Their Theorem 7 (preprint p. 5) bounds non-switching sets using monotone lower and upper systems, subject to assumptions A1–A4 and additional basin and ordering conditions. Corollary 9 (preprint p. 6, conditions (11)–(13) and inclusion (14)) gives corresponding bounds across a compact parameter set. It requires the stated regularity and bistability assumptions, monotone bounding systems, and basin and equilibrium-order conditions. Robust switching is therefore not introduced by the present example.

Sootla and Ernst likewise estimate control and convergence quantities without knowing exact parameter values, using known parameter-interval bounds. In the cited arXiv:1708.00232v1 preprint of their 2018 article, §III.B, Propositions 4–5 (pp. 3–4), relies on assumptions A1–A5 and monotonicity with respect to parameter changes as well as states and inputs. Those assumptions include regularity, an exponentially stable target equilibrium, and conditions on a Koopman eigenfunction. Problem 2 in §III.C, p. 5, asks for a pulse that switches a genetic toggle for every parameter in the interval. The accompanying discussion explains that convergence estimates can be conservative and depend on the chosen tolerance.

These results establish the broader robust-control aim under their own assumptions. They do not automatically prove a guarantee over the whole family \(k>0\), which is neither compact nor bounded away from zero. The elementary inequalities above establish that guarantee for this particular family and preparation. The contribution is the connection: the same family has identical stipulated clamp endpoint evidence, opposite stable outcomes under simultaneous release, and a uniform successful release order whose reverse leaves disagreement after every finite fixed wait. The comparison also reinforces the distinction between a common limiting outcome and a common deadline for approaching it.

## What experimental completeness amounts to

One might object that the example merely loses timing information at equilibrium. That is part of the mechanism, but losing timing information does not always lose endpoints. Multiplying both equations of an autonomous system by the same positive constant changes its clock while preserving its state-space paths and limiting outcomes. Here a relative rate changes the final attractor while remaining invisible to every experiment in the stipulated menu.

The problem is not a shortage of clamp settings. Every target, value, and initial state allowed by that menu is covered. Both coordinates are read out, joint clamps are included, and all equilibrium locations and qualitative stability classifications are supplied. More coverage along those dimensions cannot distinguish the systems.

Excluding arbitrary uncontrolled initial states is essential. If their endpoints were known, the disputed release outcome would already be known. But the ability to prepare a state does not imply that every procedure following preparation has been observed. Preparing a state and maintaining a clamp is one experiment; preparing it and leaving both coordinates free is another. The result concerns inference between them.

A sufficiently rich dynamical or initial-state-sensitive equilibrium model can represent the missing outcome. Representational adequacy does not establish identification from the available evidence. The two systems agree on the supplied outcome maps while disagreeing on the relevant unclamped map.

The philosophical point is therefore specific. Equivalence relative to an experimental menu licenses substitution only for questions that this equivalence preserves. Here it does not license substituting one model for the other when evaluating simultaneous withdrawal. Calling the intervention catalogue complete cannot repair this gap: completeness is indexed to procedures and readouts.

The release-order result shows why the distinction matters for action. Within a justified family, one may be unable to certify a proposed withdrawal yet still be able to certify an alternative. Identifying an unknown parameter, identifying one procedure's outcome, and choosing a successful procedure are different tasks. This example connects those tasks without making the general idea of robust temporary control new.

Further evidence can change the answer. A decay trace under an \(x\) clamp reveals \(k\); a release experiment directly measures the disputed outcome; justified rate bounds or basin information may settle it without an exact parameter estimate. These go beyond the restricted evidence menu rather than expanding its already exhaustive target-and-value coverage.

The result establishes neither a general failure of equilibrium causal modeling nor a universal need for temporal measurements. It does not locate the exact transition between release outcomes as \(k\) varies, characterize every basin, or establish empirical applicability. Its conclusions concern a fixed preparation, a specified family with a known time scale, and a restricted body of evidence. Within those bounds, clamp endpoints fail to identify simultaneous release, while a suitable release order guarantees the desired asymptotic outcome without identifying the hidden rate.

## Bibliography

Blom, Tineke, Stephan Bongers, and Joris M. Mooij. 2020. “Beyond Structural Causal Models: Causal Constraints Models.” *Proceedings of the 35th Conference on Uncertainty in Artificial Intelligence (UAI 2019)*, PMLR 115: 585–594. [Paper](https://proceedings.mlr.press/v115/blom20a/blom20a.pdf).

Bongers, Stephan, Tineke Blom, and Joris M. Mooij. 2022. “Causal Modeling of Dynamical Systems.” arXiv:1803.08784v4, 27 March 2022. Cited passage: §4.6, Example 4.21 and following paragraph, pp. 36–37. [Version cited](https://staff.fnwi.uva.nl/j.m.mooij/articles/1803.08784v4.pdf).

Dash, Denver. 2005. “Restructuring Dynamic Causal Systems in Equilibrium.” *Proceedings of the Tenth International Workshop on Artificial Intelligence and Statistics*, PMLR R5: 81–88. [Paper](https://proceedings.mlr.press/r5/dash05a/dash05a.pdf).

Ryan, Oisín, and Fabian Dablander. 2025. “Equilibrium Causal Models: Connecting Dynamical Systems Modeling and Cross-Sectional Data Analysis.” *Multivariate Behavioral Research*. [Publisher record](https://doi.org/10.1080/00273171.2025.2522733). Comparison limited to available search excerpts and bibliographic records; full text unavailable.

Sootla, Aivar, Diego Oyarzún, David Angeli, and Guy-Bart Stan. 2016. “Shaping Pulses to Control Bistable Systems: Analysis, Computation and Counterexamples.” *Automatica* 63: 254–264. [Author preprint dated 5 October 2015](https://orbi.uliege.be/bitstream/2268/191987/1/border_final.pdf). Citations above use preprint pagination: §2.1, p. 3; Theorem 7, p. 5; Corollary 9, p. 6.

Sootla, Aivar, and Damien Ernst. 2018. “Pulse-Based Control Using Koopman Operator Under Parametric Uncertainty.” *IEEE Transactions on Automatic Control* 63(3): 791–796. Version cited: arXiv:1708.00232v1, 1 August 2017, §§III.B–III.C, pp. 3–5. [Author preprint, v1](https://arxiv.org/pdf/1708.00232v1).

Weinberger, Naftali. 2023 [online 2021]. “Intervening and Letting Go: On the Adequacy of Equilibrium Causal Models.” *Erkenntnis* 88: 2467–2491. [Article](https://doi.org/10.1007/s10670-021-00463-0).