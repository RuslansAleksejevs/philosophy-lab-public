"""Bind already accepted revisions and exact neutral critic packets; no models."""
from pathlib import Path
import hashlib,json
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1]
def ref(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def main():
 previous=json.loads((RUN/'INPUT_MANIFEST-v2.json').read_text());rows={x['path']:x for x in previous['files']}
 def add(p):
  item=ref(p)
  if item['path'] in rows:assert rows[item['path']]==item,'Frozen input drift'
  rows[item['path']]=item
 for item in list(rows.values()):assert ref(ROOT/item['path'])==item,'Frozen input drift'
 accepted=json.loads((RUN/'AUTHORS_ARCHIVE_RECEIPT.json').read_text());assert accepted['status']=='SUBMISSION_AUTHORS_ARCHIVED'
 jobs=json.loads((RUN/'jobs-critics.json').read_text());assert jobs['author_wave_event_id']==accepted['event_id']
 for name in ['INPUT_MANIFEST-v2.json','AUTHORS_START_RECEIPT.json','AUTHORS_ARCHIVE_RECEIPT.json','jobs-critics.json','prepare_critic_manifest.py']:
  add(RUN/name)
 for job in jobs['jobs']:
  add(ROOT/job['prompt_file']);add(ROOT/job['schema_file'])
  for item in job['inline_inputs']:
   p=ROOT/item['path'];assert all(ref(p)[k]==item[k] for k in ['path','sha256','bytes']);add(p)
 for role in accepted['roles']:
  p=RUN/'results'/role['job_id']/'ARCHIVE_RECEIPT.json';add(p)
  report=json.loads(p.read_text())
  for item in report['files']:add(ROOT/item['path'])
 result={'schema':'submission-revision-critic-inputs.v1','status':'PREPARED_NOT_DISPATCHED','run_id':RUN.name,'author_wave_event_id':accepted['event_id'],'files':[rows[k] for k in sorted(rows)],'scope':'Exactly three fresh critics; source material and author outputs are administratively bound, but worker prompts contain only their stated isolated inline inputs.','worker_exclusions':['author self-assessment and change-log JSON','previous review verdicts','other essays','global project history'],'public_raw_source_boundary':previous.get('public_raw_source_boundary',previous.get('source_exclusions','Public PDF/PNG/rawHTML retained locally with commitments; exact clean text is bound.'))}
 p=RUN/'CRITIC_INPUT_MANIFEST.json'
 with p.open('x') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':'CRITIC_INPUT_MANIFEST_PREPARED','manifest':ref(p),'files':len(rows)}))
if __name__=='__main__':main()
