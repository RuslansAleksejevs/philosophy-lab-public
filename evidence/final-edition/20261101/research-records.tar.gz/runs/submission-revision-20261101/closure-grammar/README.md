# Приёмка редакций с одной отдельно проверенной правкой E050

Отдельное дополнение к неизменному `../closure/close_revisions.py`.
Старый helper по-прежнему требует три полнотекстовых `READY`; его условия,
manifest и файлы не меняются. Этот helper принимает конкретное исправление
E050 после отдельной независимой проверки. Другие изменения не разрешены.

## Что именно считается завершённым

- Сохраняются три принятых авторских редакции и три полнотекстовых отзыва.
- E012 и E051 требуют прежних `READY` и подтверждения чтения обеих версий.
- E050 сохраняет полнотекстовый вердикт `MINOR_FIXES` и единственное замечание
  `F1` уровня `minor`. Его нельзя переименовать в `READY` задним числом.
- Отдельный свежий `E050-grammar-check` должен иметь каноническую приёмку,
  решение `READY`, пустой список findings и все шесть true-флагов:
  `read_before_complete`, `read_after_complete`, `read_diff_complete`,
  `only_intended_change`, `meaning_preserved`, `grammar_correct`.
- Область нового отзыва строго `EXACT_GRAMMAR_CHANGE_ONLY`. Он не повторяет
  научную оценку всего текста, литературы или новизны.
- Выбранный E050 побайтно равен `grammar-repair/E050-corrected.md`; E012 и
  E051 — принятым авторским `derived/revision.md`.

Замороженный grammar adapter проверяет ровно одну замену из `EDIT.json`:
исходный SHA `8c50e9c8e0973bd1383be050b7be6acb762f8e476b8731c457d52c813dd65ff3`,
исправленный SHA `451823414dc95441657d7b0b8fccf1e415823f3f55d1cb6efdee7f4f5a770eaa`.
Прочие байты неизменны. Он связывает принятую исходную редакцию, прежний
полный отзыв, фактический AI coordinator edit, точный diff, новый отзыв и
две новые записи lineage. Closure использует только read-only
`gate(root, run)` и `validate_accepted(ctx, writer, require_ready=True)`.

Итоговый статус остаётся `SUBMISSION_REVISIONS_VERIFIED_BOUNDED`, только
готовность содержания. В нём отдельно записаны шесть исходных ролей,
один scoped checker, исходные решения `MINOR_FIXES/READY/READY` и разрешение
только `E050/F1`. Анонимный пакет, публикация и подача не выполнены.

## REQUEST и файлы координатора

Сохраняется [исходный контракт](../closure/README.md) пяти coordinator
artifacts, точных `selected` файлов, двух wave receipts, шести role receipts
и фактической пары root call/result в `CAPTURE_SELECTION.json`.
Поля этих документов создаются root только после фактической приёмки.

Новый запрос находится в `closure-grammar/REQUEST.json` и отличается так:

```json
{
  "schema": "submission-revisions-scoped-closure.v1",
  "grammar_check": {
    "path": "runs/submission-revision-20261101/grammar-repair/ARCHIVE_RECEIPT.json",
    "sha256": "ACTUAL_ACCEPTED_RECEIPT_SHA256",
    "bytes": 0
  }
}
```

Это только добавляемые поля; остальные обязательные поля прежнего REQUEST
сохраняются. SHA и размер в примере — placeholders, не реальные значения.

В `coordinator/DECISIONS.json` только строка E050 получает:

```json
{
  "essay_id": "E050",
  "selected_manuscript": "descriptor of selected/E050.md: exact corrected bytes",
  "author_event_id": "original accepted author event",
  "critic_event_id": "original accepted full critic event",
  "critic_decision": "MINOR_FIXES",
  "coordinator_decision": "USE_CORRECTED_REVISION",
  "scoped_checker_decision": "READY",
  "resolved_findings": ["F1"],
  "correction_event_id": "actual accepted grammar correction event",
  "scoped_checker_event_id": "actual accepted scoped checker event",
  "reason": "Причина выбора точной исправленной версии.",
  "limitations": ["Область нового отзыва ограничена одной правкой."]
}
```

E012/E051 сохраняют `critic_decision: READY` и
`coordinator_decision: USE_REVISION`. В source ledger отдельно сослаться
на старый полный отзыв E050 и новую scoped-проверку. Подсчёт слов должен
относиться к фактически выбранной исправленной копии. Поздние решения,
сводка, подсчёты и source ledger остаются работой координатора, не объектом
уже завершённых независимых отзывов.

## Заморозка, API и повтор

`closure-grammar/MANIFEST.json` имеет статус
`SUBMISSION_REVISION_SCOPED_CLOSURE_PREPARED` и ровно 16 implementation
descriptors: три файла этого каталога, четыре неизменных файла прежней
closure (`close_revisions.py`, `test_close_revisions.py`, `README.md`,
`MANIFEST.json`), `grammar-repair/technical/grammar.py`, три technical v2
файла и пять production dependencies из прежнего контракта.
Grammar input manifest, START receipt, ARCHIVE receipt и EDIT входят в
точные конечные входы дополнительно. Исходные 112/156 и grammar181 не меняются.

```sh
python3 -B runs/submission-revision-20261101/closure-grammar/close_revisions.py --check
```

Под уже открытым и полностью проверенным writer, без второго аудита:

```python
ctx, refs = close_revisions.prepare(request_path)
receipt = close_revisions.finish(ctx, writer, refs,
    allow_checkpoint_derived_updates=True)
```

Отдельный разрешённый root запуск использует `--apply
--allow-checkpoint-derived-updates`. Helper не вызывает провайдеров, службу
или дополнительные исследования. Сначала проверяет принятие всех шести
прежних ролей, затем scoped acceptance, точные байты и решение координатора.
После этого выполняется прежняя процедура: exact root capture, четыре
атрибутированных stage indexes, три selection lineage, один стандартный
checkpoint/derived refresh и `FINAL_RECEIPT.json`.
Административные `INCOMPLETE` и `NOT_CERTIFIED` сохраняются.

У E050 selected lineage имеет родителей: corrected revision, исходный
полнотекстовый critique и новый scoped critique. Повтор использует
отдельные delivery keys этой closure; одноимённые старые результаты не
перезаписываются. При сбое внутри checkpoint может повториться только
derived rendering, не сам канонический checkpoint. После приёмки сводка
проекта должна говорить о двух полнотекстовых `READY` и отдельно закрытом
F1, а не о трёх полнотекстовых `READY`.

```sh
python3 -B -m unittest discover -s runs/submission-revision-20261101/closure-grammar -p test_close_revisions.py
```

Тесты используют временные синтетические файлы и fake writer; проверяют
настоящий read-only grammar validation API с синтетической идентичностью
исходного текста. Реальный native replay, archive writer, модели и служба
не запускаются. Исходные 23 теста closure остаются отдельными и неизменными.
