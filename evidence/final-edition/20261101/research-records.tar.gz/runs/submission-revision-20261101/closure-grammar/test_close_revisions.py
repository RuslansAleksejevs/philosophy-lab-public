"""Synthetic successor integration; original closure tests/files remain immutable."""
from pathlib import Path
import importlib.util
import unittest
from unittest.mock import patch

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
HERE=Path(__file__).resolve().parent
M=module('scoped_close',HERE/'close_revisions.py')
OLD=module('old_closure_fixture',HERE.parent/'closure/test_close_revisions.py')

class ScopedClosure(unittest.TestCase):
    def setUp(self):
        self.f=OLD.Closure('runTest');self.f.setUp();f=self.f;root,run=f.root,f.run;g=run/'grammar-repair'
        source=f.roles['E050-author']['revision'];self.source=source
        f.contexts['critics']['jobs']['E050-critic']['expected_output']['manuscript_sha256']=source['sha256']
        f.change_response('E050-critic',decision='MINOR_FIXES',findings=[{'id':'F1','severity':'minor'}],manuscript_sha256=source['sha256'])
        self.corrected=f.save(g/'E050-corrected.md',b'Revised E050 with one synthetic grammar fix\n')
        self.diff=f.save(g/'changes.diff',b'Synthetic exact diff\n')
        self.old_response=M.B.descriptor(f.responses['E050-critic'],root)
        self.edit={'source':source,'corrected':self.corrected,'diff':self.diff,'prior_critic_event_id':f.roles['E050-critic']['event_id'],'prior_critic_response':self.old_response}
        edit_ref=f.save(g/'EDIT.json',self.edit)
        correction=f.event('grammar-correction','research.revision.grammar.corrected',{'status':'EXACT_AI_GRAMMAR_CORRECTION_ARCHIVED','files':[edit_ref,self.corrected,self.diff]},parents=[f.roles['E050-author']['event_id'],f.roles['E050-critic']['event_id']])
        corr_id=run.name+':E050:grammar-correction:v1'
        cl=f.lineage(corr_id,'entity/E050','revision',[f.roles['E050-author']['lineage_entry_id']],[correction['id'],f.roles['E050-critic']['event_id']],[self.corrected],M.C.SID)
        self.details={'corrected_revision':self.corrected,'original_revision':source,'diff':self.diff,'old_full_critic':self.old_response,
          'old_full_critic_event_id':f.roles['E050-critic']['event_id'],'correction_event_id':correction['id'],'correction_lineage_entry_id':corr_id,'correction_lineage_event_id':cl['id']}
        manifest=f.save(g/'INPUT_MANIFEST.json',{'files':[edit_ref,self.corrected,self.diff]})
        inputs=f.event('grammar-input',M.G.INPUT_KIND,{'status':'E050_GRAMMAR_INPUTS_ARCHIVED','files':[edit_ref,self.corrected,self.diff,manifest],'correction':self.details},parents=[correction['id'],cl['id'],f.waves['critics']['id']])
        start=dict(f.receipt(inputs),**self.details);f.save(g/'START_RECEIPT.json',start)
        expected={'job_id':M.G.JOB,'essay_id':'E050','scientific_role':'grammar_checker','manuscript_sha256':self.corrected['sha256'],'scope':M.G.SCOPE}
        prompt=f.save(g/'prompt.txt',b'Synthetic checker prompt\n');schema=f.save(g/'schema.json',{'type':'object'})
        job=dict(expected,id=M.G.JOB,model='gpt-6-astra',effort='ultra',service_tier='default',prompt_file=prompt['path'],prompt_sha256=prompt['sha256'],schema_file=schema['path'],schema_sha256=schema['sha256'],expected_output=expected)
        self.value=dict(expected,decision='READY',findings=[],read_before_complete=True,read_after_complete=True,read_diff_complete=True,only_intended_change=True,meaning_preserved=True,grammar_correct=True)
        self.response_path=g/'results'/M.G.JOB/'attempt-001/response.json';response=f.save(self.response_path,self.value)
        proof=f.save(self.response_path.parent/'native-check.json',{'synthetic':True})
        sid='synthetic-fresh-grammar-session'
        terminal=f.save(self.response_path.parent/'receipt.json',dict(status=M.B.COMPLETE,job_id=M.G.JOB,session_id=sid,prompt_sha256=prompt['sha256'],schema_sha256=schema['sha256'],requested_model=job['model'],requested_effort=job['effort'],requested_service_tier=job['service_tier'],outputs={response['path']:response['sha256'],proof['path']:proof['sha256']}))
        self.ge=f.event('grammar-check',M.G.RESULT_KIND,{'status':'E050_GRAMMAR_CHECK_ARCHIVED','files':[response,proof,terminal],'checker_report':response,'terminal_receipt':terminal,'ready_for_exact_change':True,'scope':M.G.SCOPE,'scientific_role':'grammar_checker'},sid=sid,parents=[inputs['id'],cl['id']])
        line_id=run.name+':E050:grammar-check:v1';line=f.lineage(line_id,'entity/E050','critique',[corr_id],[self.ge['id']],[response],sid,job=M.G.JOB)
        self.receipt=dict(f.receipt(self.ge),**self.details,checker_report=response,checker_session_id=sid,checker_lineage_entry_id=line_id,checker_lineage_event_id=line['id'],scope=M.G.SCOPE,ready_for_exact_change=True)
        f.request['grammar_check']=f.save(g/'ARCHIVE_RECEIPT.json',self.receipt)
        self.gctx=dict(f.contexts['critics'],grammar=g,edit=self.edit,waves={x:f.receipt(e) for x,e in f.waves.items()},jobs={M.G.JOB:job},manifest_ref=manifest,start=start,files=start['files'])
        f.request['schema']='submission-revisions-scoped-closure.v1'
        f.selected['E050']=f.save(run/'selected/E050.md',M.B.bound(self.corrected,root))
        decision=M.B.load(root/f.arts['decisions']['path'],root);row=next(x for x in decision['decisions'] if x['essay_id']=='E050')
        row.update(selected_manuscript=f.selected['E050'],critic_decision='MINOR_FIXES',coordinator_decision='USE_CORRECTED_REVISION',scoped_checker_decision='READY',resolved_findings=['F1'],correction_event_id=correction['id'],scoped_checker_event_id=self.ge['id'])
        f.arts['decisions']=f.save(root/f.arts['decisions']['path'],decision)
        files=[]
        for p in M.implementation_paths(root,run):
            if not p.exists():f.save(p,{} if p.suffix=='.json' else b'# synthetic frozen implementation\n')
            files.append(M.B.descriptor(p,root))
        f.save(run/'closure-grammar/MANIFEST.json',{'status':'SUBMISSION_REVISION_SCOPED_CLOSURE_PREPARED','files':files})
        f.request_path=run/'closure-grammar/REQUEST.json';f.rewrite_request();f.w=OLD.Writer(f.events,f.objects)
        self.patches=[patch.object(M.C,'gate',side_effect=lambda wave,run,root:f.contexts[wave]),patch.object(M.G,'gate',return_value=self.gctx),patch.object(M.G,'SOURCE_SHA',source['sha256']),patch.object(M.G,'FIXED_SHA',self.corrected['sha256'])]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.f.tearDown()
    def data(self):return M.local_check(self.f.request_path,self.f.root,self.f.run)
    def check(self):return M.canonical_check(self.data(),self.f.w)
    def rewrite_decision(self,**updates):
        f=self.f;p=f.root/f.arts['decisions']['path'];v=M.B.load(p,f.root);next(r for r in v['decisions'] if r['essay_id']=='E050').update(updates)
        f.arts['decisions']=f.save(p,v);f.rewrite_request()
    def rewrite_checker(self,**updates):
        f=self.f;old=M.B.descriptor(self.response_path,f.root);self.value.update(updates);new=f.save(self.response_path,self.value)
        files=self.ge['payload']['files'];files[files.index(old)]=new;self.ge['payload']['checker_report']=new;self.receipt['checker_report']=new
        self.ge['payload']['ready_for_exact_change']=M.G.ready(self.value);self.receipt['ready_for_exact_change']=M.G.ready(self.value)
        le=next(e for e in f.events if e['id']==self.receipt['checker_lineage_event_id']);le['payload']['entry']['artifacts'][0].update(sha256=new['sha256'],bytes=new['bytes'])
        f.request['grammar_check']=f.save(f.run/'grammar-repair/ARCHIVE_RECEIPT.json',self.receipt);f.rewrite_request()
    def test_exact_scoped_acceptance_preserves_full_minor_verdict(self):
        result=self.check();e050=result['selected'][0]
        self.assertEqual(e050['critic_decision'],'MINOR_FIXES');self.assertEqual(e050['scoped_checker_decision'],'READY')
        self.assertEqual(len(result['reports']),6);self.assertFalse(result['grammar_report']['whole_text_review_repeated'])
    def test_missing_scoped_acceptance_fails_before_checker_response_read(self):
        self.f.w._state['seen'].pop(self.ge['id']);reads=[];old=M.G.B.bound
        def bound(ref,root):
            if ref['path']==str(self.response_path.relative_to(root)):reads.append(ref['path'])
            return old(ref,root)
        with patch.object(M.G.B,'bound',side_effect=bound),self.assertRaises(ValueError):self.check()
        self.assertEqual(reads,[])
    def test_checker_not_ready_fails(self):
        self.rewrite_checker(decision='NOT_READY')
        with self.assertRaisesRegex(ValueError,'not READY'):self.check()
    def test_diff_read_required(self):
        self.rewrite_checker(read_diff_complete=False)
        with self.assertRaisesRegex(ValueError,'not READY'):self.check()
    def test_meaning_preserved_required(self):
        self.rewrite_checker(meaning_preserved=False)
        with self.assertRaisesRegex(ValueError,'not READY'):self.check()
    def test_whole_review_claim_instead_of_scope_rejected(self):
        self.rewrite_checker(scope='FULL_SCIENTIFIC_REVIEW')
        with self.assertRaisesRegex(ValueError,'decision consistency'):self.check()
    def test_old_full_ready_cannot_be_fabricated_in_coordinator(self):
        self.rewrite_decision(critic_decision='READY')
        with self.assertRaisesRegex(ValueError,'preserve MINOR_FIXES'):self.check()
    def test_unresolved_extra_finding_cannot_be_claimed(self):
        self.rewrite_decision(resolved_findings=['F1','F2'])
        with self.assertRaisesRegex(ValueError,'resolve only F1'):self.check()
    def test_wrong_checker_event_in_decision_rejected(self):
        self.rewrite_decision(scoped_checker_event_id='other')
        with self.assertRaisesRegex(ValueError,'Scoped coordinator'):self.check()
    def test_uncorrected_selected_copy_rejected(self):
        f=self.f;f.selected['E050']=f.save(f.run/'selected/E050.md',M.B.bound(self.source,f.root));self.rewrite_decision(selected_manuscript=f.selected['E050'])
        with self.assertRaisesRegex(ValueError,'exact accepted revision copy'):self.check()
    def test_checker_session_cannot_reuse_whole_critic(self):
        sid=self.f.roles['E050-critic']['session_id'];self.receipt['checker_session_id']=sid;self.ge['session_id']=sid
        self.f.request['grammar_check']=self.f.save(self.f.run/'grammar-repair/ARCHIVE_RECEIPT.json',self.receipt);self.f.rewrite_request()
        with self.assertRaisesRegex(ValueError,'Canonical scoped checker'):self.check()
    def test_e012_minor_is_not_covered_by_e050_fix(self):
        self.f.change_response('E012-critic',decision='MINOR_FIXES');self.gctx['waves']={x:self.f.receipt(e) for x,e in self.f.waves.items()}
        with self.assertRaisesRegex(ValueError,'Other whole-text'):self.check()
    def test_retry_one_checkpoint_and_honest_final_counts(self):
        f=self.f;d=self.data();calls=[]
        def cp(root,w,run,path,coverage,incomplete):
            calls.append(True);e=w.append({'kind':'checkpoint','run_id':run,'payload':{'capture_status':'INCOMPLETE','truth_status':'NOT_CERTIFIED','summary':f.summary},'outputs':[d['artifacts']['checkpoint']['sha256']]},'synthetic-checkpoint')
            w.append({'kind':'operation.interrupted','run_id':run,'payload':{'checkpoint':e['id']}},'synthetic-terminal');return e
        cap={'status':'BOUNDED_COMPLETE','captured_records':2,'tool_link_ids':['link'],'raw_records':f.selection['raw_records'],'coverage_event_id':'synthetic-capture-coverage','raw_event_ids':['synthetic-call','synthetic-result']}
        with patch.object(M.B,'resolve_session',return_value=f.root/'synthetic-native'),patch.object(M.B,'SessionWriter',return_value=f.w),patch.object(M.B,'capture',return_value=cap) as capture:
            first=M.close_with_writer(d,f.w,cp);second=M.close_with_writer(d,f.w,cp)
        self.assertEqual(first,second);self.assertEqual(calls,[True]);self.assertEqual(capture.call_count,1)
        self.assertEqual(first['whole_text_critic_decisions'],{'E050':'MINOR_FIXES','E012':'READY','E051':'READY'})
        self.assertEqual(first['scientific_results_accepted'],6);self.assertEqual(first['scoped_checks_accepted'],1)
        selected=next(e for e in f.events if e['id']==first['selected_lineage_event_ids'][0])
        self.assertEqual(selected['payload']['entry']['parents'],[self.details['correction_lineage_entry_id'],f.roles['E050-critic']['lineage_entry_id'],self.receipt['checker_lineage_entry_id']])

if __name__=='__main__':unittest.main()
