Submission package — revised prose, E050 / E012 / E051

This package supersedes the earlier PDFs. The three essays have been rewritten for clearer, more natural prose and separately checked for preservation of meaning and rigor. E050 has a structured mathematical appendix within the essay PDF and clickable references from the main text. Methodology reports and form abstracts have been updated for this editorial round.

Use three separate OpenReview entries. In each, upload the matching essay PDF to PDF and its methodology PDF to Methodology Report. Do not upload this convenience ZIP as the essay or report. The form text files contain the matching title, abstract, keywords, TL;DR and model disclosures. Personal choices and declarations remain for the submitter.

Deadline: 1 November 2026, 03:59 PST San Francisco / 11:59 UTC.

Each LaTeX folder contains main.tex and body.tex. Compile main.tex from that folder using Tectonic or XeLaTeX and the packages/fonts declared in its preamble. All PDFs are anonymous. No entry has been submitted by this preparation step.
