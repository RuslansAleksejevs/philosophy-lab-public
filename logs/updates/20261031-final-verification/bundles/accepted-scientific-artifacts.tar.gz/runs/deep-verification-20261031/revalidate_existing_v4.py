"""Revalidate completed technical L3 only; never call a model or alter its attempt."""
from pathlib import Path
import argparse
import json
import runner_v4 as r


def revalidate(job_id, run_dir=r.RUN, root=r.ROOT):
    receipt, jobs = r.gate(run_dir, root)
    if job_id != 'SMOKE-L3': raise ValueError('V4 mechanical repair is only the completed L3 technical attempt')
    matches = [job for job in jobs if job['id']==job_id]
    if len(matches)!=1: raise ValueError('Technical job not bound')
    job=matches[0];attempt=run_dir/'results'/job_id/'attempt-001';destination=attempt.parent/'revalidation-v4'
    if destination.exists(): raise ValueError('Preserve existing technical revalidation')
    before={str(p.relative_to(root)):r.digest(r.regular(p,root).read_bytes()) for p in sorted(attempt.iterdir()) if p.is_file()}
    original=r.strict_json(r.regular(attempt/'failure.json',root).read_bytes());state=original.get('process_state',{})
    if original.get('job_id')!=job_id or original.get('status')!=r.FAILED or original.get('error')!='Public text exceeds capture bound' or state.get('exit_code')!=0 or not state.get('process_stopped') or not state.get('stderr_drained'):
        raise ValueError('Original technical attempt is not the exact completed type-validation failure')
    for key,source in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
        if original.get(key)!=job[source]: raise ValueError('Original technical inputs/configuration changed')
    preflight=r.strict_json(r.run_file('transport-repair-v4/ACTUAL_L3_PREFLIGHT.json',run_dir).read_bytes())
    if preflight.get('session_id')!=original['session_id'] or preflight.get('status')!='ACTUAL_L3_FULL_PREFLIGHT_PASS':
        raise ValueError('Actual reviewed L3 native prefix missing')
    prompt,schema=r.check_inputs(job,root)
    proof,visible,finals=r.inspect_native(original['session_id'],prompt.decode(),job,root,cutoff=preflight['native_source_prefix'])
    if proof['isolation_failures']:raise ValueError('Technical native proof failed')
    events=[r.strict_json(x) for x in r.regular(attempt/'visible-events.jsonl',root).read_bytes().splitlines()]
    stderr=r.strict_json(r.regular(attempt/'stderr.json',root).read_bytes())
    completed=sum(x['type']=='turn.completed' for x in events)==1
    errors=[x['message'] for x in events if x['type'] in {'error','turn.failed'}]
    status,flags,value=r.classify(finals,stderr['lines'],r.regular(attempt/'final.txt',root).read_text(),schema,errors,completed,0,job)
    if status!=r.COMPLETE:raise ValueError('Technical final/schema/completion still fails: '+str(flags))
    source=attempt/'structural-diagnostics.jsonl';raw=r.regular(source,root).read_bytes()
    old_rows=[r.strict_json(line) for line in raw.splitlines()]
    rows=[];policy=r.web_v2.STDOUT_POLICY
    for row in old_rows:
        if set(row)!={'line_sha256','line_bytes','exact_json_null','error_class'} or row['error_class']!='ValueError' or row['exact_json_null'] is not False or type(row['line_bytes']) is not int or not 0<row['line_bytes']<=policy['max_gap_line_bytes'] or not r.re.fullmatch('[a-f0-9]{64}',row['line_sha256']):
            raise ValueError('Unexpected original technical stdout diagnostic')
        rows.append({**row,'error_category':policy['legacy_l3_category'],'stage':'json_parse'})
    if not 0<len(rows)<=policy['max_gap_lines'] or sum(x['line_bytes'] for x in rows)>policy['max_gap_total_bytes']:
        raise ValueError('Original stdout gaps exceed bound')
    for path,digest in before.items():
        if r.digest(r.bound_path(path,root).read_bytes())!=digest:raise ValueError('Original attempt changed during replay')
    evidence={'schema':'stdout-gap-evidence.v4','policy':policy['id'],
              'original':{'path':str(source.relative_to(root)),'sha256':r.digest(raw),'bytes':len(raw)},
              'rows':rows,'count':len(rows),'total_bytes':sum(x['line_bytes'] for x in rows)}
    destination.mkdir(exist_ok=False)
    for name,data in [('native-check.json',proof),('native-visible.json',{'session_id':original['session_id'],'records':visible}),
                      ('response.json',value),('stdout-gap-evidence.json',evidence)]:r.save_new(destination/name,data)
    outputs={**before,**{str(p.relative_to(root)):r.digest(p.read_bytes()) for p in destination.iterdir()}}
    failure_path=attempt/'failure.json'
    result={**{key:original[key] for key in ('job_id','prompt_sha256','schema_sha256','requested_model','requested_effort','requested_service_tier','session_id')},
            'status':r.COMPLETE,'transport_version':4,'disposition':'MECHANICAL_REVALIDATION_NO_MODEL_RERUN',
            'original_attempt_receipt':{'path':str(failure_path.relative_to(root)),'sha256':before[str(failure_path.relative_to(root))]},
            'input_event_id':receipt['event_id'],'quality_flags':[],'outputs':outputs,'completed_at':r.now(),'additional_model_calls':0,
            'stdout_parse_gap_policy':policy['id'],'native_replay_authoritative':True,'stdout_projection_complete':False,
            'stdout_diagnostic_gap_count':len(rows),'stdout_gap_total_bytes':evidence['total_bytes'],'stdout_turn_completed':completed,
            'archive_boundary':'Local same-session technical validation; original failure/gaps retained; canonical acceptance required.'}
    r.save_new(destination/'receipt.json',result)
    return {'job_id':job_id,'status':r.COMPLETE,'receipt':str((destination/'receipt.json').relative_to(root)),'additional_model_calls':0}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--ids',nargs='+',required=True);args=parser.parse_args()
    for job_id in args.ids:print(json.dumps(revalidate(job_id)),flush=True)
