"""Accept frozen verification inputs before any independent review is launched."""
from pathlib import Path
import datetime,hashlib,json,os,sys,time

D=Path(__file__).resolve().parent;R=D.parents[1]
sys.path.insert(0,str(R/'scripts'))
from research_archive import Archive
from capture_codex import capture,resolve_session
from philosophy_round import start,record

def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,value):
    with (D/name).open('x') as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n');f.flush();os.fsync(f.fileno())

assert not (D/'START_RECEIPT.json').exists()
print('INPUT_ARCHIVE_AUDIT_STARTED',flush=True)
with Archive(R/'research/archive').writer() as w:
    w._ensure_audited()
    print('INPUT_ARCHIVE_AUDIT_COMPLETE_WAITING_FOR_FROZEN_INPUTS',flush=True)
    deadline=time.monotonic()+3600
    while not (D/'ARCHIVE_READY.json').exists():
        if time.monotonic()>=deadline:raise TimeoutError('Inputs not ready; no round started')
        time.sleep(2)
    ready=json.loads((D/'ARCHIVE_READY.json').read_text())
    assert ready['status']=='READY_FOR_CANONICAL_INPUT_ACCEPTANCE'
    raw=(D/'INPUT_MANIFEST.json').read_bytes()
    assert sha(raw)==ready['input_manifest_sha256']
    files=json.loads(raw)['files']
    for row in files:
        p=R/row['path'];assert p.is_relative_to(R) and '..' not in Path(row['path']).parts
        assert not p.is_symlink() and sha(p.read_bytes())==row['sha256'],row['path']
    auth=json.loads((D/'AUTHORIZATION.json').read_text())
    sid=auth['source']['session_id'];source=resolve_session(sid,R)
    st=start(R,w,D.name,sid,'research',str((D/'METHOD.json').relative_to(R)),
             [str((D/n).relative_to(R)) for n in ['AUTHORIZATION.json','INPUT_MANIFEST.json','MANIFEST.json','TRANSPORT_INPUTS.json']],
             stage_id='DEEP_VERIFICATION',selection_round_id='TEN_TO_THREE_PLUS_TWO')
    caps={}
    for label,line in [('authorization',auth['source']['matched_records'][0]['source_line']),
                       ('question',ready['question_source_line'])]:
        cap=capture(R/'research/archive',source,sid,R,start_line=line,end_line=line,
                    run_id=D.name,archive_writer=w)
        assert cap['status']=='BOUNDED_COMPLETE',cap
        caps[label]=cap
    save('CAPTURE_START.json',caps)
    outputs=[]
    for row in files:
        assert w.put((R/row['path']).read_bytes())==row['sha256'];outputs.append(row['sha256'])
    outputs.append(w.put(raw))
    ev=w.append({'kind':'research.verification.inputs.accepted','actor':{'id':sid,'role':'AI'},
        'session_id':sid,'run_id':D.name,'operation_id':D.name,'attempt_id':'preparation-v1',
        'parents':[st['id'],'event-7358790dac874fc78e327b60a3fbe014']+[c['coverage_event_id'] for c in caps.values()],
        'bindings':st['bindings'],'outputs':outputs,
        'payload':{'status':'DEEP_VERIFICATION_INPUTS_ARCHIVED','scientific_roles':20,
                   'technical_smoke_roles':1,'frozen_manuscripts':10,'files':files,
                   'boundary':'Current explicit authorization, immutable anonymous inputs, transport and method. No scientific result or provider-complete capture is asserted.'}},
        D.name+':inputs:v1')
    question=record(R,w,D.name,'question',str((D/'QUESTION_RU.txt').relative_to(R)),sid,caps['question']['raw_event_ids'])
    save('START_RECEIPT.json',{'status':'DEEP_VERIFICATION_INPUTS_ARCHIVED','event_id':ev['id'],
        'run_start_event':st['id'],'bindings':st['bindings'],'question_stage_event':question['id'],
        'capture_events':[c['coverage_event_id'] for c in caps.values()],'files':files,
        'accepted_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(json.dumps({'status':'DEEP_VERIFICATION_INPUTS_ARCHIVED','event_id':ev['id']}),flush=True)
