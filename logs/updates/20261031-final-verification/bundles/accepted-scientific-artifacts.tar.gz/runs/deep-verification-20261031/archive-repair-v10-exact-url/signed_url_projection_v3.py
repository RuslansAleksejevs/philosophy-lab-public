"""One exact completed V10-L public URL; all other cases retain frozen V2."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,re
from urllib.parse import urlsplit,parse_qsl,unquote
HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/'archive-repair-v4-sigv4/signed_url_projection_v2.py'
if hashlib.sha256(PREVIOUS.read_bytes()).hexdigest()!='62ebe50dadc4c7cdb48e660a67d2c062d0ebb08c58e8fb2cab1b7a9edc73465c':raise ValueError('Frozen V2 policy changed')
s=importlib.util.spec_from_file_location('v10_previous_url_policy',PREVIOUS);V2=importlib.util.module_from_spec(s);s.loader.exec_module(V2)
RULE=json.loads((HERE/'EXACT_URL_RULE.json').read_bytes())
POLICY_ID='SIGNED_S3_V10_EXACT_URL_OMISSION_V3';VARIANT='SIGV4_V10_EXACT_PUBLIC_URL'
require=V2.require;sha=V2.sha;contains_credential=V2.contains_credential

def exact_url(value):
 require(len(value.encode())==RULE['url_bytes'] and sha(value.encode())==RULE['url_sha256'],'Exact URL bytes changed')
 require(value.isascii() and not re.search(r'[\x00-\x20\x7f]|%(?![0-9a-fA-F]{2})',value),'Exact URL encoding')
 parts=urlsplit(value)
 require(parts.scheme=='https' and parts.netloc==parts.hostname==RULE['hostname'] and parts.username is None and parts.password is None and parts.port is None and not parts.fragment,'Exact endpoint changed')
 path=unquote(parts.path);require(path.startswith('/') and path.endswith('.pdf') and not re.search(r'[\x00-\x1f\x7f]',path) and not any(x in {'.','..'} for x in path.split('/')),'Exact PDF path shape')
 pairs=parse_qsl(parts.query,keep_blank_values=True,strict_parsing=True,max_num_fields=10);query=dict(pairs)
 require(len(pairs)==len(query)==10 and set(query)==set(RULE['query_keys']),'Exact unique query fields')
 require(query['X-Amz-Algorithm']=='AWS4-HMAC-SHA256' and query['X-Amz-Content-Sha256']=='UNSIGNED-PAYLOAD' and query['X-Amz-SignedHeaders']=='host' and query['x-id']=='GetObject','Exact signing metadata')
 scope=query['X-Amz-Credential'].split('/')
 require(len(scope)==5 and re.fullmatch(r'ASIA[A-Z0-9]{16}',scope[0]) and re.fullmatch(r'[0-9]{8}',scope[1]) and scope[2:]==['us-east-1','s3','aws4_request'],'Exact temporary identity scope')
 date=query['X-Amz-Date'];require(re.fullmatch(r'[0-9]{8}T[0-9]{6}Z',date) and date[:8]==scope[1],'Exact signing date');datetime.datetime.strptime(date,'%Y%m%dT%H%M%SZ')
 require(re.fullmatch(r'[1-9][0-9]{0,5}',query['X-Amz-Expires']) and int(query['X-Amz-Expires'])<=604800 and re.fullmatch(r'[a-f0-9]{64}',query['X-Amz-Signature']),'Exact expiry/signature shape')
 token=query['X-Amz-Security-Token'];require(20<=len(token)<=4096 and re.fullmatch(r'[A-Za-z0-9+/=]+',token),'Exact temporary token shape')
 disposition=query['response-content-disposition'];require(0<len(disposition)<=512 and not re.search(r'[\x00-\x1f\x7f]',disposition),'Exact disposition shape')
 require(not contains_credential(path) and not any(contains_credential(v) for k,v in query.items() if k!='X-Amz-Credential') and V2.strict_components_safe(value,'X-Amz-Credential'),'Other credential inside exact URL')

def project_output(text,job_id,session_id,source_line,source_record_sha256,call_id):
 require(job_id==RULE['job_id'] and session_id==RULE['session_id'],'Exact V10 job/session required')
 if source_line!=RULE['source_line']:return V2.project_text(text)
 require(source_record_sha256==RULE['source_record_sha256'] and call_id==RULE['call_id']
   and isinstance(text,str) and len(text.encode())==RULE['source_text_bytes'] and sha(text.encode())==RULE['source_text_sha256'],'Exact public output identity changed')
 pieces=[];omissions=[];cursor=0;special=0
 for match in V2.URL.finditer(text):
  url=match.group();raw=url.encode();offset=len(text[:match.start()].encode())
  if sha(raw)==RULE['url_sha256']:
   require(offset==RULE['source_utf8_start'],'Exact URL moved');exact_url(url);variant=VARIANT;special+=1
  elif V2.V1.signed_s3_url(url) and V2.strict_components_safe(url,'AWSAccessKeyId'):variant='SIGV2_REGIONAL_TEMPORARY'
  elif V2.signed_s3_sigv4_url(url):variant='SIGV4_PATH_STYLE_PDF'
  else:continue
  marker='[SIGNED PUBLIC URL EXCLUDED; sha256='+sha(raw)+'; bytes='+str(len(raw))+']'
  omissions.append({'reason':'SIGNED_PUBLIC_URL_QUERY_CREDENTIALS','variant':variant,'url_sha256':sha(raw),'url_bytes':len(raw),'source_utf8_start':offset,'replacement':marker})
  pieces.extend([text[cursor:match.start()],marker]);cursor=match.end()
 pieces.append(text[cursor:]);projected=''.join(pieces)
 require(special==1 and len(omissions)==3 and sum(x['variant']=='SIGV2_REGIONAL_TEMPORARY' for x in omissions)==2,'Exact one new URL and two existing URLs required')
 require(not contains_credential(projected),'Credential outside exact public URL');V2.STRICT.credential_safe(projected)
 return projected,omissions
