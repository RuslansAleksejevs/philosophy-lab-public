"""Read-only actual V10 replay; save metadata report only when explicitly asked."""
from pathlib import Path
import argparse,importlib.util,json,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;RUN=HERE.parent;ROOT=RUN.parents[1]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--save',action='store_true');args=parser.parse_args()
 adapter=module('v10_actual_preflight_adapter',RUN/'archive_progress_v7.py');hook=module('v10_actual_preflight_hook',HERE/'native_projection_v3.py')
 ctx=adapter.V6.setup(ROOT,RUN);attempt=RUN/'results/V10-L/attempt-001'
 originals={p.name:adapter.sha(p.read_bytes()) for p in sorted(attempt.iterdir())}
 adapter.require(set(originals)=={'failure.json','launch.json','stderr.json','visible-events.jsonl','structural-diagnostics.jsonl','final.txt'},'Expected exact six failed originals')
 ctx.update(native_hook=hook,native_preflight={'session_id':hook.P.RULE['session_id'],'native_source_prefix':hook.P.RULE['native_source_prefix'],'original_files':originals},
  native_manifest_path=HERE/'EXACT_URL_RULE.json',native_repair=HERE)
 result=adapter.prepared_result(ctx,'V10-L',{'id':'READ_ONLY_SYNTHETIC_POLICY_CONTEXT','sequence':0},write=False)
 adapter.require(originals=={p.name:adapter.sha(p.read_bytes()) for p in sorted(attempt.iterdir())},'Original files changed during preflight')
 adapter.require(not result['receipt_path'].parent.exists(),'Preflight must not create projected result files')
 proof=result['proof'];ledger=proof['public_web_projection']
 report={'status':'ACTUAL_V10L_EXACT_URL_FIXED_PREFIX_REPLAY_PASS','job_id':'V10-L','session_id':result['session_id'],'native_source_prefix':proof['native_source_prefix'],
  'original_files':originals,'final_bytes':(attempt/'final.txt').stat().st_size,'native_final_exact_original':True,'schema_validation':'PASS','classified_complete':True,
  'public_calls':len([x for x in proof['public_web_calls'] if x['type']=='public_web_call']),
  'paired_public_outputs':len([x for x in proof['public_web_calls'] if x['type']=='public_web_output']),
  'isolation_failures':proof['isolation_failures'],'ledger':ledger,
  'safe_public_hashes':{Path(name).name:adapter.sha(raw) for name,raw in result['projection_blobs'].items() if Path(name).name in {'native-check.json','native-visible.json','response.json'}},
  'stdout_boundary':result['stdout_boundary'],
  'sources':[adapter.descriptor(p,ROOT) for p in [RUN/'archive_progress_v7.py',HERE/'signed_url_projection_v3.py',HERE/'native_projection_v3.py',HERE/'EXACT_URL_RULE.json',Path(__file__)]],
  'provider_calls':0,'canonical_writes':0,'projected_files_written':0,
  'boundary':'Strict full native replay and schema/final equality were checked in RAM. Synthetic policy metadata only; this is not canonical acceptance. No original scientific text, native envelope, signed URL or credential body is emitted.'}
 if args.save:adapter.B.save_new(HERE/'ACTUAL_V10L_FINAL_PREFLIGHT.json',report)
 print(json.dumps({k:report[k] for k in ('status','job_id','session_id','public_calls','paired_public_outputs','native_final_exact_original','schema_validation','provider_calls','canonical_writes','projected_files_written')}))

if __name__=='__main__':main()
