# Single completed V10-L exact-URL acceptance

This is a technical acceptance of one already completed model call. No dispatcher, retry or new scientific role is provided. The original six failed-attempt files and all nineteen accepted results remain unchanged. The fixed V4 scientific inputs, configuration, AST allowlist, native identity, public call/output pairs, native final and final-file equality are still checked.

The original failure was caused by one new signed public URL in native public output line186. The exact rule binds job, session, line, record hash, call ID, complete source-text hash, URL hash/length/offset and native prefix. The two other signed URLs in that output already satisfy the frozen V2 policy. All three whole URLs are replaced with hash/length markers. No signed URL, credential or complete native envelope is saved to a public intermediate file. Other jobs and changed source identities do not qualify.

## Root freezes inputs

Create `SAFE_V10_EXACT_URL_PROJECTION_MANIFEST.json` in this directory with:

```text
status: SAFE_V10_EXACT_URL_PROJECTION_PREPARED
files: exact project-relative {path,sha256,bytes} descriptors
preserved_stop: descriptor of runs/deep-verification-20261031/STOP_V4_SIGV4_REPAIR.json
prior_dispatch_snapshot: descriptor of an immutable copy of the fully drained process.json
prior_dispatch_stdout: descriptor of an immutable copy of the last dispatcher log
failed_attempt: descriptor of results/V10-L/attempt-001/failure.json
mechanical_native_preflight: descriptor of this directory's ACTUAL_V10L_FINAL_PREFLIGHT.json
accepted_before: exact nineteen results/JOB/ARCHIVE_RECEIPT.json descriptors, excluding V10-L
exact_rule: descriptor of this directory's EXACT_URL_RULE.json
```

Every scope descriptor, including the nineteen accepted receipts, must be an identical `files` entry. The preserved STOP must identify V10-L and the exact failure reason. The immutable process snapshot must show `STOPPED_PRESERVED`, no active jobs and no pending jobs; do not point to mutable `process.json`.

Include in `files`:

- `archive_progress_v7.py` and `test_archive_progress_v7.py`;
- this directory's exact rule, projector, native hook, `test_native_projection_v3.py`, `preflight.py`, actual preflight, independent review, test reports and this runbook;
- frozen `archive_progress_v6.py` and `archive-repair-v4-sigv4/SAFE_NATIVE_PROJECTION_START_RECEIPT.json`, preserving the prior manifest/input chain;
- the exact six V10-L originals: `failure.json`, `launch.json`, `stderr.json`, `visible-events.jsonl`, `structural-diagnostics.jsonl`, `final.txt`;
- the nineteen accepted receipt files and all immutable scope copies above. Root may retain additional already safe, previously bound inputs; never add raw native envelopes or private URL-bearing source records.

All `files` bytes are hashed and privacy-checked before the first new canonical write. The adapter also validates the full frozen V6 setup. Inside the audited writer, all nineteen prior accepted events and their canonical files are verified before the new policy is accepted. The original V4 transport and accepted V6 policy are parents of the new failure/policy events.

## Root executes one writer only

First confirm the previous sole writer exited. There is no dispatch or service action in this procedure.

```sh
python3 -B runs/deep-verification-20261031/archive_progress_v7.py --check
python3 -u -B runs/deep-verification-20261031/archive_progress_v7.py --wait-ready --timeout-seconds 21600
```

The second command performs one standard canonical audit, then waits without appending events until root creates `SAFE_V10_EXACT_URL_PROJECTION_ARCHIVE_READY.json`:

```text
status: READY_FOR_CANONICAL_V10_EXACT_URL_PROJECTION_ACCEPTANCE
manifest_sha256: exact reviewed new manifest SHA-256
```

The writer preserves the original failure in `research.verification.mechanical_failure.preserved`, accepts the new inputs with `research.verification.native_projection_policy.accepted`, then captures and accepts only V10-L. The new policy status remains `DEEP_VERIFICATION_SAFE_NATIVE_PROJECTION_ARCHIVED`; the policy is distinguished by its exact manifest, rule, parents and V3 projection schema. Runtime transport remains4.

New safe files live under `results/V10-L/native-projection-v3/`: `native-check.json`, `native-visible.json`, derived `response.json`, `PROJECTION.json`, `receipt.json`. The sidecar schema is `archive-native-output-projection.v3`; the proof ledger schema is `native-public-web-projection.v3`. Both identify `SIGNED_S3_V10_EXACT_URL_OMISSION_V3`. The sidecar references the exact rule descriptor, which is bound by the policy event. It truthfully states the original attempt had no complete proof/visible/response files. The original final bytes remain exact.

Acceptance produces `SAFE_V10_EXACT_URL_PROJECTION_START_RECEIPT.json`, the V10-L `FAILED_ATTEMPT_ARCHIVE_RECEIPT.json`, and its standard `ARCHIVE_RECEIPT.json`. The final stdout status reports20 accepted results only after verifying the nineteen old results and accepting the twentieth. Any new validation failure creates `STOP_V10_EXACT_URL_REPAIR.json`; old STOP files are preserved. An administrative `ARCHIVE_PROGRESS_V7_STOP_REQUEST.json` with `status: STOP_AFTER_CURRENT_ACCEPTANCE`, the run ID and a reason stops at a safe boundary and releases the writer.

The final exporter and standalone verifier require an explicit V3 branch before the final repository update. That preparation does not delay canonical acceptance of this already completed result. No final log export is performed here.
