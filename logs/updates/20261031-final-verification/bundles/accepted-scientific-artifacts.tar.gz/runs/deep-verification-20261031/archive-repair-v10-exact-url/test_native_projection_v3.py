"""Synthetic exact-V10 policy/native regressions. No account reads or model calls."""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

HERE = Path(__file__).resolve().parent
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
N = module('test_v10_native', HERE/'native_projection_v3.py')
P = N.P
F = module('test_v10_base_fixtures', HERE.parent/'test_runner_v4.py')
R = F.r

def sigv2():
    q = {'AWSAccessKeyId':'ASIA'+'A'*16, 'Expires':'1772249332', 'Signature':'YWFhYWFhYWFhYWFhYWFhYWFhYWE=', 'x-amz-security-token':'YWFh'*30}
    return 'https://synthetic-bucket.s3.eu-west-1.amazonaws.com/preview.pdf?'+urlencode(q)

def exact_url(query=None, host='substack-post-media.s3.us-east-1.amazonaws.com'):
    q = {'X-Amz-Algorithm':'AWS4-HMAC-SHA256', 'X-Amz-Content-Sha256':'UNSIGNED-PAYLOAD', 'X-Amz-Credential':'ASIA'+'A'*16+'/20261031/us-east-1/s3/aws4_request', 'X-Amz-Date':'20261031T120000Z', 'X-Amz-Expires':'86400', 'X-Amz-Security-Token':'YWFh'*30, 'X-Amz-Signature':'a'*64, 'X-Amz-SignedHeaders':'host', 'response-content-disposition':'inline; filename=preview.pdf', 'x-id':'GetObject'}
    if query: q.update(query)
    return 'https://'+host+'/synthetic/preview.pdf?'+urlencode(q)

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        self.job = F.job(); self.job.update(id='V10-L', role='literature', web_search='live')
        self.prompt = 'Frozen input\n'
        self.url = exact_url()
        self.text = 'Источник ('+self.url+'). Earlier ('+sigv2()+') and ('+sigv2()+'). Public remainder.'
        self.call = F.line('response_item', {'type':'custom_tool_call', 'name':'exec', 'call_id':'c1', 'input':'const result = await tools.web__run({open:[{ref_id:"https://example.org/paper"}]}); text(result);'})
        self.output = F.line('response_item', {'type':'custom_tool_call_output', 'call_id':'c1', 'output':[{'type':'input_text','text':self.text}]})
        self.rows = F.native(self.root); self.rows[-1:-1] = [self.call, self.output]
        self.rule = copy.deepcopy(P.RULE)
        self.rule.update(session_id=F.SID, source_line=self.rows.index(self.output)+1, source_record_sha256=P.sha(self.output), call_id='c1', source_text_sha256=P.sha(self.text.encode()), source_text_bytes=len(self.text.encode()), url_sha256=P.sha(self.url.encode()), url_bytes=len(self.url.encode()), source_utf8_start=len('Источник ('.encode()))
        self.patch = patch.object(P, 'RULE', self.rule); self.patch.start()

    def tearDown(self):
        self.patch.stop(); self.tmp.cleanup()

    def project(self, text=None, **changes):
        args = dict(job_id='V10-L', session_id=F.SID, source_line=self.rule['source_line'], source_record_sha256=P.sha(self.output), call_id='c1')
        args.update(changes)
        return P.project_output(self.text if text is None else text, **args)

    def replay(self, rows=None, job=None, sid=None):
        return N.native_records(R, self.rows if rows is None else rows, F.SID if sid is None else sid, self.prompt, self.job if job is None else job, self.root)

    def test_one_exact_url_two_old_urls_unicode_ledger(self):
        out, ledger = self.project()
        self.assertEqual(len(ledger), 3)
        self.assertEqual([x['variant'] for x in ledger].count(P.VARIANT), 1)
        self.assertEqual([x['variant'] for x in ledger].count('SIGV2_REGIONAL_TEMPORARY'), 2)
        self.assertEqual(ledger[0]['source_utf8_start'], len('Источник ('.encode()))
        self.assertEqual(ledger[0]['url_sha256'], P.sha(self.url.encode()))
        self.assertNotIn(self.url, out)
        self.assertTrue(out.endswith('. Public remainder.'))
        self.assertFalse(P.contains_credential(out))

    def test_job_sid_record_call_text_and_line_are_exact(self):
        for values in [{'job_id':'V09-L'}, {'session_id':'other'}, {'source_record_sha256':'b'*64}, {'call_id':'other'}, {'source_line':self.rule['source_line']+1}]:
            with self.subTest(values=tuple(values)), self.assertRaises(ValueError): self.project(**values)
        with self.assertRaises(ValueError): self.project(self.text+'changed')

    def test_rule_offset_hash_and_length_are_required(self):
        for field, value in [('source_utf8_start', 0), ('url_sha256', 'b'*64), ('url_bytes', 1), ('source_text_sha256', 'c'*64), ('source_text_bytes', 1)]:
            rule = dict(self.rule, **{field:value})
            with patch.object(P, 'RULE', rule), self.subTest(field=field), self.assertRaises(ValueError): self.project()

    def test_same_host_different_url_is_not_a_general_exception(self):
        changed = exact_url({'X-Amz-Signature':'b'*64})
        with self.assertRaises(ValueError): self.project(self.text.replace(self.url, changed))
        with self.assertRaises(ValueError): P.exact_url(changed)

    def test_url_shape_negative_even_with_synthetic_identity_binding(self):
        for url in [exact_url(host='evil.example'), exact_url({'X-Amz-Algorithm':'other'}), exact_url({'X-Amz-Credential':'ASIA'+'A'*16+'/20261031/us-west-1/s3/aws4_request'}), exact_url({'X-Amz-Date':'20261030T120000Z'}), exact_url({'X-Amz-Expires':'604801'}), exact_url({'X-Amz-Security-Token':'invalid token'}), self.url+'&x-id=GetObject']:
            rule = dict(self.rule, url_sha256=P.sha(url.encode()), url_bytes=len(url.encode()))
            with patch.object(P, 'RULE', rule), self.subTest(), self.assertRaises(ValueError): P.exact_url(url)

    def test_other_bearer_jwt_or_key_inside_url_is_not_hidden(self):
        for secret in ['Bearer '+'b'*30, 'eyJ'+'a'*20+'.'+'b'*20+'.'+'c'*20, 'sk-'+'Z'*30]:
            url = exact_url({'response-content-disposition':secret})
            with patch.object(P, 'RULE', dict(self.rule, url_sha256=P.sha(url.encode()), url_bytes=len(url.encode()))), self.subTest(), self.assertRaises(ValueError): P.exact_url(url)

    def test_other_output_uses_old_policy_without_exception(self):
        out, ledger = self.project(sigv2(), source_line=self.rule['source_line']+1)
        self.assertEqual(len(ledger), 1); self.assertNotEqual(out, sigv2())
        with self.assertRaises(ValueError): self.project(self.url, source_line=self.rule['source_line']+1)

    def test_full_native_replay_preserves_exact_final_and_raw_hash(self):
        before = copy.deepcopy(self.rows); old = R.web_v2.normalize_output
        with self.assertRaises(ValueError): N.V2.native_records(R, self.rows, F.SID, self.prompt, self.job, self.root)
        proof, visible, finals = self.replay()
        self.assertEqual(self.rows, before); self.assertIs(R.web_v2.normalize_output, old)
        self.assertFalse(proof['isolation_failures']); self.assertEqual(proof['public_web_completed_call_ids'], ['c1'])
        self.assertEqual(finals[0]['text'], json.dumps(F.ANSWER))
        row = proof['public_web_projection']['records'][0]
        self.assertEqual(row['source_record_sha256'], P.sha(self.output))
        self.assertEqual(row['source_text_sha256'], P.sha(self.text.encode()))
        self.assertEqual(row['projection_copies'], 2)
        self.assertEqual([x for x in proof['public_web_calls'] if x['type']=='public_web_output'], [x for x in visible if x.get('type')=='public_web_output'])
        self.assertNotIn('SECRET_REASONING', json.dumps([proof, visible]))

    def test_wrong_job_role_sid_or_prefix_stops_before_original_inspection(self):
        for job in [dict(self.job, id='V09-L'), dict(self.job, role='argument')]:
            with self.assertRaises(ValueError): self.replay(job=job)
        with self.assertRaises(ValueError): self.replay(sid='different')
        with patch.object(R, 'inspect_native', side_effect=AssertionError('must not inspect')):
            with self.assertRaises(ValueError): N.inspect_native(R, F.SID, self.prompt, self.job, self.root, cutoff=None)

    def test_assistant_user_final_query_context_never_gets_exception(self):
        for rows in [self.rows+[F.message('assistant', self.url, 'commentary')], self.rows+[F.message('assistant', self.url, 'final')], self.rows+[F.message('user', self.url)]]:
            with self.subTest(), self.assertRaises(ValueError): self.replay(rows)
        bad = F.line('response_item', {'type':'custom_tool_call', 'name':'exec', 'call_id':'c1', 'input':'const result = await tools.web__run({open:[{ref_id:'+json.dumps(self.url)+'}]}); text(result);'})
        with self.assertRaises(ValueError): self.replay([bad if x==self.call else x for x in self.rows])

    def test_model_other_input_duplicate_unpaired_unknown_tool_rejected(self):
        bad_model = copy.deepcopy(self.rows); bad_model[1] = F.line('turn_context', {'model':'gpt-6-luna','effort':'ultra','service_tier':'default'})
        cases = [bad_model, self.rows+[F.message('user','injected context')], self.rows+[self.output], [x for x in self.rows if x!=self.call], self.rows+[F.line('response_item', {'type':'function_call','name':'shell','call_id':'forbidden','arguments':'{}'})]]
        for rows in cases:
            with self.subTest(), self.assertRaises(ValueError): self.replay(rows)

    def test_extra_credential_outside_exact_url_stops(self):
        text = self.text+' Bearer '+'b'*30
        with patch.object(P, 'RULE', dict(self.rule, source_text_sha256=P.sha(text.encode()), source_text_bytes=len(text.encode()))):
            with self.assertRaises(ValueError): self.project(text)

if __name__ == '__main__':
    unittest.main()
