"""Strict native replay with one identity-bound public-output exception only."""
from pathlib import Path
import hashlib,importlib.util
HERE=Path(__file__).resolve().parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
P=module('v10_exact_policy',HERE/'signed_url_projection_v3.py')
OLD=HERE.parent/'archive-repair-v4-sigv4/native_projection.py'
if hashlib.sha256(OLD.read_bytes()).hexdigest()!='27766a635fa03ebab96a83093e5daec7ec5cd021208272e91fb811f5a2806d5f':raise ValueError('Frozen native hook changed')
V2=module('v10_previous_native_hook',OLD)

def native_records(base,lines,sid,prompt,job,root):
 V2.require_base(base);P.require(job.get('id')==P.RULE['job_id'] and job.get('role')=='literature' and sid==P.RULE['session_id'],'Single completed V10-L only')
 outputs=[];pending=set()
 for number,raw in enumerate(lines,1):
  obj=base.strict_json(raw);payload=obj.get('payload',{})
  if obj.get('type')!='response_item' or not isinstance(payload,dict):continue
  if payload.get('type')=='custom_tool_call' and payload.get('name')=='exec':pending.add(payload.get('call_id'))
  if payload.get('type')=='custom_tool_call_output' and payload.get('call_id') in pending:
   outputs.append({'line':number,'record_sha256':P.sha(raw),'call_id':payload['call_id'],'original_output':payload.get('output')})
 normalizations=[]
 def normalize_output(value):
  P.require(len(normalizations)<len(outputs),'Extra output normalization');source=outputs[len(normalizations)]
  P.require(value==source['original_output'],'Output normalization source differs')
  if isinstance(value,str):text=value
  else:
   P.require(isinstance(value,list) and 1<=len(value)<=16 and all(isinstance(x,dict) and set(x)=={'type','text'} and x['type']=='input_text' and isinstance(x['text'],str) for x in value),'Unsupported public output shape')
   text='\n'.join(x['text'] for x in value)
  projected,omissions=P.project_output(text,job['id'],sid,source['line'],source['record_sha256'],source['call_id']);base.web_v2.credential_safe(projected)
  normalizations.append({'source_text_sha256':P.sha(text.encode()),'source_text_bytes':len(text.encode()),'projected_text_sha256':P.sha(projected.encode()),'projected_text_bytes':len(projected.encode()),'omissions':omissions,'omission_count':len(omissions)})
  return projected
 class WebProxy:
  def __getattr__(self,name):return normalize_output if name=='normalize_output' else getattr(base.web_v2,name)
 proof,visible,finals=V2.clone(base.native_records,web_v2=WebProxy())(lines,sid,prompt,job,root)
 P.require(not proof['isolation_failures'],'Original native isolation failed')
 projected_outputs=[x for x in proof['public_web_calls'] if x.get('type')=='public_web_output'];ledger=[]
 P.require(len(projected_outputs)==len(normalizations)==len(outputs),'Public normalization coverage differs')
 for out,source,row in zip(projected_outputs,outputs,normalizations):
  P.require(all(out[k]==source[k] for k in ('line','record_sha256','call_id')) and P.sha(out['text'].encode())==row['projected_text_sha256'],'Projected output identity/text differs')
  if row['omissions']:ledger.append(dict(source_line=out['line'],source_record_sha256=out['record_sha256'],call_id=out['call_id'],projection_copies=2,**row))
 exact=[(r,o) for r in ledger for o in r['omissions'] if o['variant']==P.VARIANT]
 P.require(len(exact)==1 and exact[0][0]['source_line']==P.RULE['source_line'] and exact[0][1]['url_sha256']==P.RULE['url_sha256'],'Exact exception not consumed once')
 P.require(not P.contains_credential(proof) and not P.contains_credential(visible) and not P.contains_credential(finals),'Credential outside approved public response context')
 proof['public_web_projection']={'schema':'native-public-web-projection.v3','policy_id':P.POLICY_ID,'session_id':sid,'source_output_records':len(ledger),'omitted_url_count':sum(r['omission_count'] for r in ledger),'records':ledger,'exact_rule':P.RULE,
  'original_native_record_hashes_retained':True,'scientific_text_unchanged':True,'unsafe_intermediate_files_written':False,
  'boundary':'Frozen V4 input/configuration/AST/call-pairing/final gates retained. The one V10-L URL is bound by exact job/session/record/text/URL identities; other outputs retain frozen V2 policy. No unsafe intermediate files.'}
 proof['capture_boundary']+=' Explicit native-public-web-projection.v3 ledger qualifies public output copies.'
 return proof,visible,finals

def inspect_native(base,sid,prompt,job,root,cutoff=None):
 V2.require_base(base);P.require(cutoff==P.RULE['native_source_prefix'],'Exact reviewed native prefix required')
 def selected(lines,sid,prompt,job,root):return native_records(base,lines,sid,prompt,job,root)
 return V2.clone(base.inspect_native,native_records=selected)(sid,prompt,job,root,cutoff=cutoff)
