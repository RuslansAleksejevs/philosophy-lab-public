#!/usr/bin/env python3
"""Versioned safe-output projection adapter; original V4 runtime stays frozen.

--check replays complete originals in memory without writes. Normal mode holds
one audited writer, accepts an exact policy/resumption amendment, then archives
safe originals or explicitly labelled derived public copies. Never dispatches.
"""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, sys, time
sys.dont_write_bytecode=True
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1];REPAIR=RUN/'archive-repair-v4'
BASE_SHA='e05c400d70f1eeddbdff81cb6d8bf519bfbbfa76ef5d3c3d33f6ea6d6b1ba607'
base_path=RUN/'archive_progress_v4.py'
if hashlib.sha256(base_path.read_bytes()).hexdigest()!=BASE_SHA:raise ValueError('Frozen V4 adapter changed')
sys.path.insert(0,str(RUN));import archive_progress_v4 as B
require=B.require;sha=B.sha;encoded=B.encoded;canon=B.canon;read=B.read;load=B.load;bound=B.bound;descriptor=B.descriptor
STATUS='DEEP_VERIFICATION_SAFE_WEB_PROJECTION_ARCHIVED'
EVENT='research.verification.web_projection_policy.accepted'
STOP_REQUEST='ARCHIVE_PROGRESS_V5_STOP_REQUEST.json'
NEW_STOP='STOP_V4_ARCHIVE_REPAIR.json'
EXPECTED_RESUME_IDS=[f'V{i:02d}-{role}' for i in range(5,11) for role in ('A','L')]
LIVE_MODE=False

def safe_file(raw,name):
 suffix=Path(name).suffix
 if suffix=='.json':value=B.strict_json(raw)
 elif suffix=='.jsonl':value=[B.strict_json(x) for x in raw.splitlines() if x]
 else:value=raw.decode()
 B.safe(value,name)

def setup(root=ROOT,run=RUN):
 ctx=B.setup(root,run);repair=run/'archive-repair-v4';manifest_path=repair/'SAFE_WEB_PROJECTION_MANIFEST.json';manifest_raw=read(manifest_path,root);safe_file(manifest_raw,manifest_path.name);manifest=B.strict_json(manifest_raw)
 require(manifest.get('status')=='SAFE_WEB_PROJECTION_PREPARED','Projection manifest not prepared')
 indexed={}
 for row in manifest['files']:
  raw=bound(row,root);require(row['path'] not in indexed,'Duplicate projection input');safe_file(raw,row['path']);indexed[row['path']]=row
 required=('archive_progress_v5.py','test_archive_progress_v5.py','archive_progress_v4.py','TRANSPORT_V4_START_RECEIPT.json',
   'resume_v4.py','test_resume_v4.py','archive-repair-v4/signed_url_projection.py','archive-repair-v4/test_signed_url_projection.py',
   'archive-repair-v4/SIGNED_URL_POLICY.json','archive-repair-v4/SAFE_DIAGNOSIS.json')
 for name in required:require(str((run/name).relative_to(root)) in indexed,'Missing reviewed projection source: '+name)
 require(indexed[str((run/'archive_progress_v4.py').relative_to(root))]['sha256']==BASE_SHA,'Unbound frozen V4 adapter')
 for key in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout'):
  ref=manifest[key];require(ref['path'] in indexed and indexed[ref['path']]['sha256']==ref['sha256'],'Unbound stopped-dispatch evidence');bound(ref,root)
 require(manifest['preserved_stop']['path']==str((run/'STOP_V4.json').relative_to(root)),'Wrong prior STOP file')
 pending=manifest['resume_never_started_ids'];require(pending==EXPECTED_RESUME_IDS,'Invalid finite twelve-job resumption scope')
 snapshot=load(root/manifest['prior_dispatch_snapshot']['path'],root)
 require(snapshot.get('status')=='STOPPED_PRESERVED' and snapshot.get('active_ids')==[] and snapshot.get('pending_ids')==pending,'Prior dispatcher is not drained at the exact pending set')
 policy=B.import_runner(repair/'signed_url_projection.py',root)
 transport_receipt=load(run/'TRANSPORT_V4_START_RECEIPT.json',root)
 require(transport_receipt.get('status')=='DEEP_VERIFICATION_TRANSPORT_V4_ARCHIVED','V4 runtime acceptance absent')
 ctx.update(projection_manifest=manifest,projection_manifest_path=manifest_path,projection_indexed=indexed,
   projection_policy=policy,repair=repair,runtime_receipt=transport_receipt)
 return ctx

def original_result(ctx,jid,path):
 """Use V4 unchanged for safe jobs; narrowly replay unsafe web originals first."""
 root,run,runner=ctx['root'],ctx['run'],ctx['runner'];job=ctx['jobs'][jid];receipt=load(path,root);B.safe(receipt,'original terminal receipt')
 require(receipt.get('status')==B.COMPLETE and receipt.get('job_id')==jid,'Incomplete original terminal')
 outputs=receipt.get('outputs');require(isinstance(outputs,dict) and outputs,'Missing original output bindings')
 unsafe=set();files=[]
 for name,digest in outputs.items():
  p=B.regular(name,root);require(p.is_relative_to(run/'results'/jid),'Output outside own job');raw=read(p,root);require(sha(raw)==digest,'Original output changed')
  if p.suffix=='.json':value=B.strict_json(raw)
  elif p.suffix=='.jsonl':value=[B.strict_json(x) for x in raw.splitlines() if x]
  elif p.suffix in {'.txt','.md'}:value=raw.decode()
  else:raise ValueError('Unsupported original output extension')
  require(not B.forbidden(value),'Native/hidden original output is not eligible for URL projection')
  if B.contains_credential(value):unsafe.add(name)
  files.append(descriptor(p,root))
 if not unsafe:return B.validate_terminal(ctx,jid,path),None
 expected={str((path.parent/name).relative_to(root)) for name in ('native-check.json','native-visible.json')}
 require(job.get('role')=='literature' and jid in ctx['scientific_ids'] and path.parent.name=='attempt-001' and unsafe==expected,
   'Credential outside the paired public web proof/visible files; preserve and stop')
 runner.check_inputs(job,root)
 for recorded,requested in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
  require(receipt.get(recorded)==job[requested],'Original requested configuration/input mismatch')
 require(receipt.get('transport_version')==4 and type(receipt.get('cli_exit_code')) is int and receipt['cli_exit_code']==0
         and receipt.get('visible_final_count')==1 and not receipt.get('quality_flags'),'Original result was not a clean completed V4 final')
 sid=receipt.get('session_id');require(isinstance(sid,str) and B.re.fullmatch('[A-Za-z0-9_-]{8,100}',sid),'Invalid original SID')
 proof=load(path.parent/'native-check.json',root);visible=load(path.parent/'native-visible.json',root)
 require(proof.get('session_id')==sid and visible.get('session_id')==sid and not proof.get('isolation_failures'),'Original native isolation failed')
 cutoff=proof.get('native_source_prefix');require(isinstance(cutoff,dict) and type(cutoff.get('bytes')) is int and cutoff['bytes']>0
   and type(cutoff.get('records')) is int and cutoff['records']>0 and B.HEX.fullmatch(cutoff.get('sha256','')) and cutoff.get('newline_terminated') is True,'Original exact native prefix missing')
 actual,records,finals=runner.inspect_native(sid,read(job['prompt_file'],root).decode(),job,root,cutoff=cutoff)
 require(canon(actual)==canon(proof) and canon(records)==canon(visible.get('records')),'Original native replay differs before projection')
 require(str((path.parent/'response.json').relative_to(root)) in outputs,'Original scientific response is not bound by terminal outputs')
 value=load(path.parent/'response.json',root);runner.validate(value,load(job['schema_file'],root))
 require(len(finals)==1 and canon(B.strict_json(finals[0]['text']))==canon(value),'Original schema result differs from native final')
 final_file=run/'results'/jid/'attempt-001/final.txt';require(str(final_file.relative_to(root)) in outputs
   and canon(B.strict_json(read(final_file,root)))==canon(value),'Original final output file differs')
 stdout=B.native_stdout_boundary(ctx,path,receipt)
 safeproof,safevisible,ledger=ctx['projection_policy'].project_pair(proof,visible,job)
 require(ledger.get('omitted_url_count',0)>0,'Unsafe original has no permitted signed public URL omission')
 for name,item in [('projected proof',safeproof),('projected visible',safevisible),('projection ledger',ledger)]:B.safe(item,name)
 messages=[];web=[];original_web={}
 for record in records:
  if record.get('role')=='tool':original_web[record['line']]=record;continue
  require(record.get('role') in {'user','assistant'} and isinstance(record.get('text'),str),'Unknown original visible record')
  if record['role']=='assistant':require(record.get('phase') in {'commentary','final','final_answer'},'Hidden phase')
  require(type(record.get('line')) is int and B.HEX.fullmatch(record.get('record_sha256','')),'Visible source identity missing')
  B.safe(record,'unchanged original visible message');messages.append(record)
 require(messages and any(m['role']=='user' for m in messages) and any(m.get('phase') in {'final','final_answer'} for m in messages),'Original prompt/final not both present')
 for record in safevisible['records']:
  if record.get('role')=='tool':web.append(B.safe_web(record))
 require([m for m in safevisible['records'] if m.get('role')!='tool']==messages,'Projection changed scientific/user text')
 files.append(descriptor(path,root))
 result={'job':job,'receipt':receipt,'receipt_path':path,'session_id':sid,'files':files,'proof':proof,'messages':messages,
   'web':web,'value':value,'stdout_boundary':stdout,'original_web':original_web}
 return result,{'proof':safeproof,'visible':safevisible,'ledger':ledger,'withheld':[row for row in files if row['path'] in unsafe]}

def project_result(ctx,jid,path,policy_event,write=False):
 result,projection=original_result(ctx,jid,path)
 if projection is None:return result
 root=ctx['root'];directory=ctx['run']/'results'/jid/'archive-projection-v1'
 def ref(name,raw):return {'path':str((directory/name).relative_to(root)),'sha256':sha(raw),'bytes':len(raw)}
 proof_raw=encoded(projection['proof']);visible_raw=encoded(projection['visible']);proof_ref=ref('native-check.json',proof_raw);visible_ref=ref('native-visible.json',visible_raw)
 ledger=projection['ledger'];sidecar={'schema':'archive-safe-output-projection.v1','policy_id':ctx['projection_policy'].POLICY_ID,
   'policy_event_id':policy_event['id'],'policy_manifest_sha256':sha(read(ctx['projection_manifest_path'],root)),
   'job_id':jid,'session_id':result['session_id'],'native_source_prefix':result['proof']['native_source_prefix'],
   'original_terminal_receipt':descriptor(path,root),'withheld_originals':projection['withheld'],
   'public_files':[proof_ref,visible_ref],'ledger':ledger,'scientific_response_unchanged':True,'originals_written':False,
   'boundary':'Original full native replay passed before projection. Complete signed public response URLs alone omitted from public proof/visible copies. Original local bytes are preserved but not stored/exported by this acceptance.'}
 sidecar_raw=encoded(sidecar);sidecar_ref=ref('PROJECTION.json',sidecar_raw)
 withheld={row['path'] for row in projection['withheld']};files=[row for row in result['files'] if row['path'] not in withheld]+[proof_ref,visible_ref,sidecar_ref]
 public_receipt=copy.deepcopy(result['receipt']);public_receipt['outputs']={row['path']:row['sha256'] for row in files}
 public_receipt['archive_projection']={'schema':'archive-safe-output-projection.v1','policy_event_id':policy_event['id'],
   'manifest_sha256':sidecar['policy_manifest_sha256'],'evidence':sidecar_ref,'original_terminal_receipt':sidecar['original_terminal_receipt'],
   'withheld_originals':projection['withheld'],'scientific_response_unchanged':True}
 receipt_raw=encoded(public_receipt);receipt_ref=ref('receipt.json',receipt_raw)
 for name,value in [('projection evidence',sidecar),('public receipt',public_receipt)]:B.safe(value,name)
 if write:
  directory.mkdir(exist_ok=True)
  require(not directory.is_symlink(),'Projection output directory is a symlink')
  prepared=[('native-check.json',projection['proof']),('native-visible.json',projection['visible']),('PROJECTION.json',sidecar),('receipt.json',public_receipt)]
  for name,value in prepared:require(not (directory/name).is_symlink(),'Projection output file is a symlink')
  for name,value in prepared:B.save_new(directory/name,value)
 result.update(receipt=public_receipt,receipt_path=directory/'receipt.json',proof=projection['proof'],files=files+[receipt_ref],
   projection=sidecar,projection_ref=sidecar_ref,projection_blobs={proof_ref['path']:proof_raw,visible_ref['path']:visible_raw,sidecar_ref['path']:sidecar_raw,receipt_ref['path']:receipt_raw})
 return result

def accept_policy(ctx,w):
 prior=B.canonical_event(w,ctx['runtime_receipt']['event_id']);require(prior['kind']=='research.verification.transport_v4.accepted'
   and prior['payload']['files']==ctx['runtime_receipt']['files'],'V4 runtime canonical event differs');B.verify_event_files(ctx,w,prior)
 manifest=ctx['projection_manifest'];key=ctx['run'].name+':safe-web-projection-policy:v1';existing=B.existing(w,key)
 files=list(manifest['files'])+[descriptor(ctx['projection_manifest_path'],ctx['root'])]
 if existing:
  require(existing['kind']==EVENT and existing['payload']['files']==files,'Existing projection policy differs');B.verify_event_files(ctx,w,existing);event=existing
 else:
  for jid in manifest['resume_never_started_ids']:require(not (ctx['run']/'results'/jid/'attempt-001').exists(),'A declared never-started job already has an attempt')
  for row in files:
   raw=bound(row,ctx['root']);require(w.put(raw)==row['sha256'],'Projection policy object mismatch')
  payload={'status':STATUS,'files':files,'manifest_sha256':sha(read(ctx['projection_manifest_path'],ctx['root'])),
    **{k:manifest[k] for k in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids')},
    'runtime_unchanged':True,'scientific_retries':False,'boundary':'Exact signed-public-response URL projection policy and finite never-started resumption only; original scientific outputs remain unchanged.'}
  event=w.append(B.request(ctx,EVENT,ctx['start'].get('session_id',prior['session_id']),'safe-web-projection-v1',[prior['id']],files,payload),key)
 value={'status':STATUS,'event_id':event['id'],'event_sequence':event['sequence'],'event_sha256':event['sha256'],
   **{k:event['payload'][k] for k in ('files','manifest_sha256','preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids')}}
 B.save_new(ctx['repair']/'SAFE_WEB_PROJECTION_START_RECEIPT.json',value);return prior,event

def accept_job(ctx,w,transport,policy,jid,path):
 prior=B.existing(w,ctx['run'].name+':accepted-result:'+jid)
 if prior:
  effective=ctx['root']/prior['payload']['receipt']['path'];B.verify_accepted(ctx,w,prior,jid,effective)
  B.save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',B.receipt_from_event(prior));return prior
 require(jid not in {'V01-A','V02-A'},'Original accepted arguments must never be recreated')
 B.require_smoke(ctx,w);B.require_original_arguments(ctx,w)
 result=project_result(ctx,jid,path,policy,write=True);sid=result['session_id'];scope=B.SessionWriter(w,sid,ctx['run'].name)
 for row in result['files']:require(w.put(bound(row,ctx['root']))==row['sha256'],'Safe result object mismatch')
 captures=[];web_ids=[]
 for message in result['messages']:
  coverage=B.capture(ctx['root']/'research/archive',B.resolve_session(sid,ctx['root']),sid,ctx['root'],start_line=message['line'],end_line=message['line'],run_id=ctx['run'].name,archive_writer=scope)
  require(coverage['status']=='BOUNDED_COMPLETE' and coverage['captured_records']==1 and coverage['raw_records'][0]['sha256']==message['record_sha256'],'Visible source capture failed')
  captures.append(coverage['coverage_event_id'])
 for record in result['web']:
  digest=w.put(encoded(record));payload={'status':'ACCEPTED_NORMALIZED_PUBLIC_WEB_EVIDENCE','job_id':jid,'fragment_sha256':digest,
   'source_line':record['line'],'source_record_sha256':record['record_sha256'],'type':record['type'],
   'boundary':'Normalized public web evidence; explicit signed URL omissions are separately bound, never an exact original-body claim.'}
  if result.get('projection'):
   payload.update(archive_projection=result['projection_ref'],original_fragment_sha256=sha(encoded(result['original_web'][record['line']])),
     signed_urls_omitted=any(r['source_line']==record['line'] for r in result['projection']['ledger']['records']))
  request=B.request(ctx,'research.verification.public_web_fragment',sid,jid+':web',[transport['id'],policy['id']],[{'sha256':digest}],payload)
  if result.get('projection'):request['inputs']=[result['projection_ref']['sha256']]
  key=ctx['run'].name+':web:'+sid+':'+str(record['line'])+':'+record['record_sha256']+':safe-projection-v1'
  web=w.append(request,key);web_ids.append(web['id'])
 payload={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':jid,'receipt':descriptor(result['receipt_path'],ctx['root']),
  'native_check':descriptor(result['receipt_path'].parent/'native-check.json',ctx['root']),'files':result['files'],
  'capture_event_ids':captures,'web_event_ids':web_ids,'scientific':True,'independence_verified':True,'whole_provider_capture':False,
  'stdout_boundary':result['stdout_boundary'],'boundary':'Original V4 native replay, schema and unchanged scientific final verified before safe public projection. Exact original source hashes and any URL omissions remain explicit.'}
 if result.get('projection'):payload['archive_projection']=result['projection_ref']
 event=w.append(B.request(ctx,'research.verification.result.accepted',sid,jid+':accepted',[ctx['start']['event_id'],transport['id'],policy['id']]+captures+web_ids,result['files'],payload),ctx['run'].name+':accepted-result:'+jid)
 B.save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',B.receipt_from_event(event));return event

def stop_requested():
 path=RUN/STOP_REQUEST
 if not path.exists():return False
 value=load(path);require(set(value)=={'status','run_id','reason'} and value['status']=='STOP_AFTER_CURRENT_ACCEPTANCE' and value['run_id']==RUN.name
   and isinstance(value['reason'],str) and 0<len(value['reason'])<=2000,'Malformed administrative stop request');B.safe(value,'stop request');return True

def main(argv=None):
 global LIVE_MODE
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');p.add_argument('--wait-ready',action='store_true')
 p.add_argument('--until',type=int,default=20);p.add_argument('--timeout-seconds',type=int,default=21600);p.add_argument('--poll-seconds',type=int,default=5);args=p.parse_args(argv)
 require(not(args.check and args.wait_ready) and 0<=args.until<=20 and 1<=args.poll_seconds<=30 and 1<=args.timeout_seconds<=43200,'Invalid bounded command')
 if args.check:
  ctx=setup();reports=[]
  for jid in sorted(ctx['scientific_ids']):
   path=B.terminal_path(ctx,jid)
   if path:
    result=project_result(ctx,jid,path,{'id':'UNCOMMITTED_READ_ONLY_PREFLIGHT'},write=False)
    reports.append({'job_id':jid,'session_id':result['session_id'],'omitted_urls':result.get('projection',{}).get('ledger',{}).get('omitted_url_count',0),'originals_changed':False})
  print(json.dumps({'status':'READ_ONLY_PROJECTION_CHECK_PASS','results':reports,'canonical_writes':0,'projection_files_written':0,'provider_calls':0}));return 0
 LIVE_MODE=True
 deadline=time.monotonic()+args.timeout_seconds;selfhash=sha(Path(__file__).read_bytes());accepted=set();ctx=None if args.wait_ready else setup()
 print('ONE_CANONICAL_AUDIT_STARTED',flush=True)
 with B.Archive(ROOT/'research/archive').writer() as writer:
  writer._ensure_audited();print('ONE_CANONICAL_AUDIT_COMPLETE',flush=True)
  if args.wait_ready:
   marker=REPAIR/'SAFE_WEB_PROJECTION_ARCHIVE_READY.json'
   while not marker.exists():
    if stop_requested():print(json.dumps({'status':'ADMINISTRATIVE_STOP_PRESERVED'}),flush=True);return 0
    if time.monotonic()>=deadline:print(json.dumps({'status':'INCOMPLETE_WAITING_FOR_READY_PRESERVED','archive_events_appended':0}),flush=True);return 2
    time.sleep(args.poll_seconds)
   ready=load(marker);require(ready.get('status')=='READY_FOR_CANONICAL_SAFE_WEB_PROJECTION_ACCEPTANCE' and ready.get('manifest_sha256')==sha(read(REPAIR/'SAFE_WEB_PROJECTION_MANIFEST.json')),'Invalid projection ready gate')
   require(sha(Path(__file__).read_bytes())==selfhash,'Running projection adapter changed');ctx=setup()
  if stop_requested():return 0
  require(not (RUN/NEW_STOP).exists(),'New projection/resumption STOP preserved')
  transport,policy=accept_policy(ctx,writer)
  while True:
   for jid in sorted(ctx['scientific_ids']):
    if stop_requested():print(json.dumps({'status':'ADMINISTRATIVE_STOP_PRESERVED','scientific_accepted':len(accepted)}),flush=True);return 0
    require(sha(Path(__file__).read_bytes())==selfhash,'Running projection adapter changed')
    require(not (RUN/NEW_STOP).exists(),'New projection/resumption STOP preserved')
    if jid in accepted:continue
    path=B.terminal_path(ctx,jid)
    if path:
     event=accept_job(ctx,writer,transport,policy,jid,path);accepted.add(jid);print(json.dumps({'status':'ARCHIVED','job_id':jid,'event_id':event['id']}),flush=True)
    elif (RUN/'results'/jid/'attempt-001/failure.json').exists():raise ValueError('Failed scientific attempt preserved: '+jid)
   if len(accepted)>=args.until:print(json.dumps({'status':'BOUNDED_ARCHIVE_TARGET_REACHED','scientific_accepted':len(accepted)}),flush=True);return 0
   if time.monotonic()>=deadline:print(json.dumps({'status':'INCOMPLETE_TIMEOUT_PRESERVED','scientific_accepted':len(accepted)}),flush=True);return 2
   time.sleep(args.poll_seconds)

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as exc:
  message=str(exc)[:1000]
  if B.contains_credential(message):message='Validation failed; credential-shaped details withheld'
  if LIVE_MODE and not (RUN/NEW_STOP).exists():
   B.save_new(RUN/NEW_STOP,{'status':'STOPPED_PRESERVED','job_id':'archive-progress','reason':message,'error_type':type(exc).__name__,'automatic_retry':False})
  print(json.dumps({'status':'ARCHIVE_PROGRESS_STOPPED_PRESERVED','error_type':type(exc).__name__,'error':message,'automatic_retry':False}),flush=True);sys.exit(2)
