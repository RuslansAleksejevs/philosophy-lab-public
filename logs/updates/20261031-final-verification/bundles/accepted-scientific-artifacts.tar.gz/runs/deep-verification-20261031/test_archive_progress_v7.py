"""One completed V10-L acceptance, synthetic temporary archive only."""
from pathlib import Path
import copy,importlib.util,json,types,unittest
from unittest.mock import patch
HERE=Path(__file__).parent
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=mod('v10_adapter_tests',HERE/'archive_progress_v7.py')
F=mod('v10_prior_adapter_fixtures',HERE/'test_archive_progress_v6.py')
N=mod('v10_exact_adapter_hook',HERE/'archive-repair-v10-exact-url/native_projection_v3.py')

class Tests(unittest.TestCase):
 refresh_preflight=F.NativeAdapterTests.refresh_preflight
 failure_change=F.NativeAdapterTests.failure_change
 tearDown=F.NativeAdapterTests.tearDown
 def setUp(self):
  F.NativeAdapterTests.setUp(self)
  old=self.attempt.parent;new=old.with_name('V10-L');old.rename(new);self.attempt=new/'attempt-001'
  job=self.ctx['jobs'].pop('V05-L');job['id']='V10-L';self.ctx['jobs']['V10-L']=job;self.ctx['scientific_ids']={'V10-L'}
  sid=N.P.RULE['session_id'];self.proof['session_id']=sid;self.proof['native_source_prefix']=N.P.RULE['native_source_prefix']
  self.failure.update(job_id='V10-L',session_id=sid,error='Credential outside approved signed public response URL')
  (self.attempt/'failure.json').write_bytes(p.encoded(self.failure))
  (self.attempt/'visible-events.jsonl').write_text(json.dumps({'type':'thread.started','thread_id':sid})+'\n'+json.dumps({'type':'turn.completed'})+'\n')
  self.proof['public_web_projection'].update(schema='native-public-web-projection.v3',policy_id=N.P.POLICY_ID,session_id=sid,exact_rule=N.P.RULE)
  self.ctx['native_hook']=types.SimpleNamespace(P=N.P,inspect_native=lambda *a,**kw:(self.proof,self.visible,[self.visible[-1]]))
  self.ctx['native_repair']=self.ctx['run']/p.LANE;self.ctx['native_repair'].mkdir();(self.ctx['native_repair']/'EXACT_URL_RULE.json').write_bytes(p.encoded(N.P.RULE))
  self.refresh_preflight()
 def prepare(self,write=False):return p.prepared_result(self.ctx,'V10-L',self.policy,write=write)
 def test_mechanical_result_is_honest_and_originals_unchanged(self):
  before={x.name:x.read_bytes() for x in self.attempt.iterdir()};r=self.prepare()
  self.assertEqual(before,{x.name:x.read_bytes() for x in self.attempt.iterdir()});self.assertFalse(r['receipt_path'].parent.exists())
  self.assertEqual(r['projection']['schema'],'archive-native-output-projection.v3');self.assertEqual(r['projection']['mode'],'MECHANICAL_REVALIDATION_FROM_FAILED_ATTEMPT')
  self.assertFalse(r['projection']['original_proof_files_existed']);self.assertEqual(r['receipt']['additional_model_calls'],0)
  self.assertEqual(r['projection']['exact_rule'],p.descriptor(self.ctx['native_repair']/'EXACT_URL_RULE.json',self.root))
 def test_no_other_job_can_use_adapter(self):
  self.ctx['jobs']['V09-L']=dict(self.ctx['jobs']['V10-L'],id='V09-L')
  with self.assertRaisesRegex(ValueError,'Only the completed V10-L'):p.prepared_result(self.ctx,'V09-L',self.policy)
 def test_exact_failure_and_completed_process_required(self):
  for change in (lambda x:x.update(error='Other failure'),lambda x:x.update(automatic_retry=True),lambda x:x['process_state'].update(exit_code=1),lambda x:x['process_state'].update(forced_kill=True)):
   before=copy.deepcopy(self.failure);self.failure_change(change)
   with self.assertRaises(ValueError):self.prepare()
   self.failure=before;self.failure_change(lambda x:None)
 def test_source_rule_or_prefix_drift_fails(self):
  self.proof['public_web_projection']['exact_rule']=dict(N.P.RULE,source_line=187)
  with self.assertRaisesRegex(ValueError,'Exact V10 source rule'):self.prepare()
  self.proof['public_web_projection']['exact_rule']=N.P.RULE;self.proof['native_source_prefix']=dict(N.P.RULE['native_source_prefix'],sha256='0'*64)
  with self.assertRaisesRegex(ValueError,'Exact V10 source rule'):self.prepare()
 def test_original_inventory_or_hash_drift_fails(self):
  (self.attempt/'extra.txt').write_text('unbound')
  with self.assertRaises(ValueError):self.prepare()
  (self.attempt/'extra.txt').unlink();(self.attempt/'stderr.json').write_text('{}')
  with self.assertRaises(ValueError):self.prepare()
 def test_replay_failure_and_final_mismatch_stop_before_writes(self):
  self.ctx['native_hook'].inspect_native=lambda *a,**k:(_ for _ in ()).throw(ValueError('Prefix changed'))
  with self.assertRaises(ValueError):self.prepare(write=True)
  self.ctx['native_hook'].inspect_native=lambda *a,**k:(self.proof,self.visible,[self.visible[-1]])
  (self.attempt/'final.txt').write_text('{"verdict":"different"}');self.refresh_preflight()
  with self.assertRaises(ValueError):self.prepare(write=True)
  self.assertFalse((self.attempt.parent/'native-projection-v3').exists())
 def test_no_invented_original_complete_files(self):
  for name in ('receipt.json','native-check.json','native-visible.json','response.json'):
   f=self.attempt/name;f.write_text('{}')
   with self.assertRaises(ValueError):self.prepare()
   self.assertEqual(f.read_text(),'{}');f.unlink()
 def test_partial_stdout_boundary_remains_explicit(self):
  row={'line_sha256':'a'*64,'line_bytes':100,'exact_json_null':False,'error_class':'ValueError','error_category':'DUPLICATE_KEY','stage':'json_parse'}
  (self.attempt/'structural-diagnostics.jsonl').write_text(json.dumps(row)+'\n');self.refresh_preflight();r=self.prepare()
  self.assertFalse(r['receipt']['stdout_projection_complete']);self.assertEqual(r['receipt']['stdout_diagnostic_gap_count'],1)
 def test_all_children_checked_before_any_write_and_idempotent(self):
  r=self.prepare(write=True);directory=r['receipt_path'].parent;before={x.name:x.read_bytes() for x in directory.iterdir()};self.prepare(write=True)
  self.assertEqual(before,{x.name:x.read_bytes() for x in directory.iterdir()})
  for x in directory.iterdir():x.unlink()
  target=self.ctx['run']/'untouched';target.write_text('unchanged');(directory/'receipt.json').symlink_to(target)
  with patch.object(p.B,'save_new',side_effect=AssertionError('No partial write')):
   with self.assertRaises(ValueError):self.prepare(write=True)
  self.assertEqual(target.read_text(),'unchanged')
 def test_actual_temp_acceptance_stores_safe_copies_once(self):
  archive=p.B.Archive(self.root/'research/archive').init();sid=self.proof['session_id'];stored=[]
  def ev(kind,s='coordinator',payload=None,parents=()):return {'kind':kind,'session_id':s,'run_id':self.ctx['run'].name,'actor':{'id':'fixture','role':'tool'},'operation_id':'test','attempt_id':'test','parents':list(parents),'payload':payload or {}}
  with archive.writer() as w:
   start=w.append(ev('research.verification.inputs.accepted'),'start');runtime=w.append(ev('research.verification.transport_v4.accepted'),'runtime');policy=w.append(ev(p.EVENT),'policy')
   self.ctx['start']={'event_id':start['id'],'bindings':{k:[] for k in ('method','instruction','config','input')}};by={x['line']:x for x in self.visible if x['role']!='tool'}
   def capture(*a,**kw):
    line=kw['start_line'];e=w.append(ev('capture.coverage',sid),'coverage:'+str(line));return {'status':'BOUNDED_COMPLETE','captured_records':1,'raw_records':[{'sha256':by[line]['record_sha256']}],'coverage_event_id':e['id']}
   put=w.put
   def checked_put(raw):stored.append(raw);return put(raw)
   with patch.object(w,'put',side_effect=checked_put),patch.object(p.B,'require_smoke'),patch.object(p.B,'require_original_arguments'),patch.object(p.B,'resolve_session',return_value=Path('unused')),patch.object(p.B,'capture',side_effect=capture):event=p.accept_job(self.ctx,w,runtime,policy)
   self.assertNotIn(self.url.encode(),b''.join(stored));self.assertFalse(any(p.B.contains_credential(x.decode()) for x in stored));count=len(w._state['records'])
   with patch.object(p,'prepared_result',side_effect=AssertionError('No repeated proof/capture')):same=p.accept_job(self.ctx,w,runtime,policy)
   self.assertEqual(event['id'],same['id']);self.assertEqual(len(w._state['records']),count)

if __name__=='__main__':unittest.main()
