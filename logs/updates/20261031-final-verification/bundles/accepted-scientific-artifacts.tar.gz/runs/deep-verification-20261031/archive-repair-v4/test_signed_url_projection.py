from pathlib import Path
import copy,importlib.util,unittest,urllib.parse
s=importlib.util.spec_from_file_location('policy',Path(__file__).with_name('signed_url_projection.py'));p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
class ProjectionTests(unittest.TestCase):
 def setUp(self):
  q={'AWSAccessKeyId':'ASIA'+'A'*16,'Expires':'1772249332','Signature':'YWFhYWFhYWFhYWFhYWFhYWFhYWE=','x-amz-security-token':'YWFh'*30,'response-content-disposition':'attachment; filename="preview.pdf"'}
  self.url='https://synthetic-bucket.s3.eu-west-1.amazonaws.com/book/preview.pdf?'+urllib.parse.urlencode(q);self.q=q
  self.record={'line':19,'record_sha256':'a'*64,'role':'tool','type':'public_web_output','call_id':'c1','status':'completed','text':'Public source ('+self.url+'). Kept body.'}
  self.proof={'session_id':'synthetic-sid','public_web_calls':[self.record],'isolation_failures':[]};self.visible={'session_id':'synthetic-sid','records':[copy.deepcopy(self.record)]};self.job={'role':'literature'}
 def project(self):return p.project_pair(self.proof,self.visible,self.job)
 def test_full_url_omitted_both_copies_without_touching_original(self):
  old=copy.deepcopy((self.proof,self.visible));a,b,m=self.project();self.assertEqual((self.proof,self.visible),old);self.assertEqual(m['omitted_url_count'],1)
  self.assertEqual(a['public_web_calls'][0]['text'],b['records'][0]['text']);self.assertIn('). Kept body.',a['public_web_calls'][0]['text']);self.assertNotIn(self.q['AWSAccessKeyId'],str((a,b,m)));self.assertNotIn(self.q['x-amz-security-token'],str((a,b,m)))
  self.assertEqual(m['records'][0]['omissions'][0]['url_sha256'],p.sha(self.url.encode()));self.assertEqual(m['records'][0]['omissions'][0]['url_bytes'],len(self.url.encode()))
 def test_foreign_host_and_lookalikes_fail_closed(self):
  for host in ('evil.example','synthetic-bucket.s3.eu-west-1.amazonaws.com.evil.example','127.0.0.1','synthetic-bucket.s3.eu-west-1.amazonaws.com@evil.example'):
   url=self.url.replace('synthetic-bucket.s3.eu-west-1.amazonaws.com',host)
   with self.subTest(host=host),self.assertRaises(p.ProjectionError):p.project_text(url)
 def test_unknown_duplicate_or_missing_signed_key_fails(self):
  variants=[self.url+'&unknown=x',self.url+'&Expires=1772249332',self.url.replace('Signature=','OtherSignature=')]
  for url in variants:
   with self.subTest(),self.assertRaises(p.ProjectionError):p.project_text(url)
 def test_http_fragment_auth_port_fail(self):
  for url in (self.url.replace('https:','http:'),self.url+'#frag',self.url.replace('https://','https://user:pass@'),self.url.replace('.com/','.com:443/')):
   with self.subTest(),self.assertRaises(p.ProjectionError):p.project_text(url)
 def test_plain_key_or_other_credential_outside_url_fails(self):
  for text in ('ASIA'+'A'*16,self.url+' '+'sk-'+'Z'*30):
   with self.subTest(),self.assertRaises(p.ProjectionError):p.project_text(text)
 def test_assistant_user_context_and_argument_never_redacted(self):
  for role in ('assistant','user','developer'):
   self.visible['records'].append({'role':role,'type':'message','text':self.url})
   with self.subTest(role=role),self.assertRaises(p.ProjectionError):self.project()
   self.visible['records'].pop()
  self.job['role']='argument'
  with self.assertRaises(p.ProjectionError):self.project()
 def test_proof_visible_mismatch_or_duplicate_fails(self):
  self.visible['records'][0]['text']+='change'
  with self.assertRaises(p.ProjectionError):self.project()
  self.visible['records'][0]['text']=self.record['text'];self.visible['records'].append(copy.deepcopy(self.record))
  with self.assertRaises(p.ProjectionError):self.project()
 def test_nonsecret_urls_untouched(self):
  text='https://example.org/paper?q=argument';out,m=p.project_text(text);self.assertEqual(out,text);self.assertEqual(m,[])
 def test_all_omissions_accounted_with_unicode_offsets(self):
  text='Пример '+self.url+' and '+self.url;out,m=p.project_text(text);self.assertEqual(len(m),2);self.assertEqual(m[0]['source_utf8_start'],len('Пример '.encode()));self.assertNotIn(self.url,out)
 def test_invalid_token_or_signature_shape_fails(self):
  for name in ('Signature','x-amz-security-token'):
   q={**self.q,name:'invalid!'};url=self.url.split('?')[0]+'?'+urllib.parse.urlencode(q)
   with self.subTest(name=name),self.assertRaises(p.ProjectionError):p.project_text(url)
 def test_other_credential_inside_signed_url_is_not_masked(self):
  secret='sk-'+'Z'*30
  variants=[self.url.replace('/book/','/'+secret+'/'),self.url.replace('/book/','/'+urllib.parse.quote(secret,safe='')+'/')]
  q={**self.q,'response-content-disposition':'attachment; filename="'+secret+'"'};variants.append(self.url.split('?')[0]+'?'+urllib.parse.urlencode(q))
  for url in variants:
   with self.subTest(),self.assertRaises(p.ProjectionError):p.project_text(url)
if __name__=='__main__':unittest.main()
