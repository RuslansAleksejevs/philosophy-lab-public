"""Narrow omission of signed S3 response URLs; no changes to scientific text."""
from pathlib import Path
import base64,copy,hashlib,json,re,sys
from urllib.parse import urlsplit,parse_qsl,unquote
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
from collector_safety import contains_credential

POLICY_ID='SIGNED_S3_PUBLIC_RESPONSE_URL_OMISSION_V1'
HOST_SUFFIX='.s3.eu-west-1.amazonaws.com'
REQUIRED={'AWSAccessKeyId','Expires','Signature','x-amz-security-token'}
OPTIONAL={'response-content-disposition'}
URL=re.compile(r'https?://[^\s<>"\x27()\[\]{}]+')
HEX=re.compile(r'[a-f0-9]{64}\Z')
class ProjectionError(ValueError):pass
def require(ok,reason):
 if not ok:raise ProjectionError(reason)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def signed_s3_url(value):
 """Return true only for the observed AWS V2 temporary signed-query shape."""
 try:
  require(isinstance(value,str) and value.isascii() and len(value)<=16384,'URL bound')
  parts=urlsplit(value);host=parts.hostname or ''
  require(parts.scheme=='https' and parts.netloc==host and not parts.username and not parts.password and parts.port is None and not parts.fragment,'URL authority')
  require(host.endswith(HOST_SUFFIX),'AWS endpoint')
  bucket=host[:-len(HOST_SUFFIX)]
  require(3<=len(bucket)<=63 and all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',x) for x in bucket.split('.')),'AWS bucket label')
  require(parts.path.startswith('/') and len(parts.path)>1 and not re.search(r'[\x00-\x20\x7f]',value),'URL path/control')
  require(not contains_credential(unquote(parts.path)),'Other credential in URL path')
  pairs=parse_qsl(parts.query,keep_blank_values=True,strict_parsing=True,max_num_fields=5)
  query=dict(pairs);require(len(query)==len(pairs) and REQUIRED<=set(query)<=REQUIRED|OPTIONAL,'Signed query fields')
  require(re.fullmatch(r'(?:AKIA|ASIA)[A-Z0-9]{16}',query['AWSAccessKeyId']) and re.fullmatch(r'[0-9]{10}',query['Expires']),'Signed query identity/expiry')
  require(not any(contains_credential(v) for k,v in query.items() if k!='AWSAccessKeyId'),'Other credential inside signed URL')
  signature=query['Signature'];token=query['x-amz-security-token']
  require(len(signature)==28 and len(base64.b64decode(signature,validate=True))==20,'Signed query signature shape')
  require(64<=len(token)<=8192 and len(base64.b64decode(token,validate=True))>=32,'Signed query session-token shape')
  disposition=query.get('response-content-disposition','')
  require(len(disposition)<=512 and not re.search(r'[\x00-\x1f\x7f]',disposition),'Disposition bound')
  return True
 except (ProjectionError,ValueError,TypeError,UnicodeError):return False

def project_text(text):
 require(isinstance(text,str) and len(text.encode())<=2*1024*1024,'Public output text exceeds bound')
 omissions=[];pieces=[];cursor=0
 for match in URL.finditer(text):
  url=match.group()
  if not signed_s3_url(url):continue
  raw=url.encode();digest=sha(raw);replacement='[SIGNED PUBLIC URL EXCLUDED; sha256='+digest+'; bytes='+str(len(raw))+']'
  omissions.append({'reason':'SIGNED_PUBLIC_URL_QUERY_CREDENTIALS','url_sha256':digest,'url_bytes':len(raw),
                    'source_utf8_start':len(text[:match.start()].encode()),'replacement':replacement})
  require(len(omissions)<=64,'Signed URL omission count exceeds bound')
  pieces.extend([text[cursor:match.start()],replacement]);cursor=match.end()
 pieces.append(text[cursor:]);projected=''.join(pieces)
 require(not contains_credential(projected),'Credential outside approved signed public response URL')
 return projected,omissions

def identity(record):
 require(isinstance(record,dict) and set(record)=={'line','record_sha256','role','type','call_id','status','text'}
         and type(record.get('line')) is int and record['line']>0 and isinstance(record.get('record_sha256'),str)
         and HEX.fullmatch(record['record_sha256']) and record.get('role')=='tool'
         and record.get('type')=='public_web_output' and record.get('status')=='completed'
         and isinstance(record.get('call_id'),str) and record['call_id'],'Unsupported public output record')
 return record['line'],record['record_sha256'],record['call_id']

def project_pair(proof,visible,job):
 """Caller must first replay original native bytes and compare both originals.

 Return copies with only public_web_output.text spans replaced, plus an exact
 per-source omission ledger. Never edits the inputs, prompts, response/final,
 assistant messages, native envelopes or files. Nothing is written here.
 """
 require(job.get('role')=='literature','Signed URL policy is limited to literature web responses')
 require(isinstance(proof,dict) and isinstance(visible,dict) and set(visible)=={'session_id','records'}
         and proof.get('session_id')==visible['session_id'],'Projection source identity differs')
 outp=copy.deepcopy(proof);outv=copy.deepcopy(visible)
 pmap={};vmap={}
 for rows,target in ((outp.get('public_web_calls',[]),pmap),(outv['records'],vmap)):
  require(isinstance(rows,list),'Invalid projection list')
  for record in rows:
   if record.get('type')!='public_web_output':continue
   key=identity(record);require(key not in target,'Duplicate public output source');target[key]=record
 require(set(pmap)==set(vmap),'Proof/visible public output coverage differs')
 ledger=[]
 for key in sorted(pmap):
  left,right=pmap[key],vmap[key]
  require(canonical(left)==canonical(right),'Proof/visible public output differs')
  text=left['text'];projected,omissions=project_text(text)
  if omissions:
   ledger.append({'source_line':key[0],'source_record_sha256':key[1],'call_id':key[2],
                  'source_text_sha256':sha(text.encode()),'source_text_bytes':len(text.encode()),
                  'projected_text_sha256':sha(projected.encode()),'projected_text_bytes':len(projected.encode()),
                  'omissions':omissions,'omission_count':len(omissions),'projection_copies':2})
   left['text']=projected;right['text']=projected
 require(not contains_credential(outp) and not contains_credential(outv),'Credential outside approved public response context')
 return outp,outv,{'schema':'safe-web-url-projection.v1','policy_id':POLICY_ID,'session_id':proof['session_id'],
                  'source_output_records':len(ledger),'omitted_url_count':sum(x['omission_count'] for x in ledger),'records':ledger,
                  'boundary':'Complete signed public response URLs omitted from public projection only. Original local native proof/visible files remain immutable and are verified before projection; scientific final, response and prompts are unchanged.'}
