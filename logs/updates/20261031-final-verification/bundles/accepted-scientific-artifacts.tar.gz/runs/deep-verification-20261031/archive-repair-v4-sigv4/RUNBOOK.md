# SigV4 native-output repair: root execution only

This is one mechanical revalidation of completed V05-L and exactly seven previously unstarted jobs. Existing V4/V5 sources, STOP files, accepted results and original failed files stay unchanged. The new hook changes only paired public-output normalization before serialization. Original prompt, schema, model, effort, tier, native input/AST/call pairing, quota and final checks remain intact.

The seven fresh slots, in order, are `V07-L, V08-A, V08-L, V09-A, V09-L, V10-A, V10-L`. No V05-L rerun is permitted. V06-A, V06-L and V07-A use their original successful native replay. V05-L receives newly derived safe proof/visible/response files under `results/V05-L/native-projection-v2/`; its original attempt has no COMPLETE receipt or proof file and none is invented there.

## Freeze inputs

Root first copies the drained dispatch process snapshot and captured stdout into new immutable files here. The snapshot must have `status: STOPPED_PRESERVED`, `active_ids: []`, the exact seven `pending_ids`, and the actual old dispatcher PID. The resume gate proves that PID is absent with `ps`; unknown or active process state blocks launch.

Create `SAFE_NATIVE_PROJECTION_MANIFEST.json` with status `SAFE_NATIVE_PROJECTION_PREPARED`, `files: [{path,sha256,bytes}, ...]`, and these exact scope fields:

- `preserved_stop`: descriptor of `runs/deep-verification-20261031/STOP_V4_ARCHIVE_REPAIR.json` (the original V05-L stop).
- `prior_dispatch_snapshot`: descriptor of the immutable drained process copy, never mutable `process.json`.
- `prior_dispatch_stdout`: descriptor of the preserved previous dispatcher log.
- `resume_never_started_ids`: the exact seven IDs above.
- `failed_attempt`: descriptor of `runs/deep-verification-20261031/results/V05-L/attempt-001/failure.json`.
- `mechanical_native_preflight`: descriptor of `archive-repair-v4-sigv4/ACTUAL_V05L_FINAL_PREFLIGHT.json`, using its full project-relative path.

Every scope descriptor must also appear identically in `files`. Include these source/evidence files:

- `archive_progress_v6.py`, `test_archive_progress_v6.py`, `resume_v4_sigv4.py`, `test_resume_v4_sigv4.py`, the frozen `archive_progress_v5.py` and V4 runtime sources referenced by its accepted receipts.
- `archive-repair-v4/SAFE_WEB_PROJECTION_START_RECEIPT.json` and its prior frozen manifest/acceptance evidence; the original V4 acceptance receipt.
- This folder's `signed_url_projection_v2.py`, `native_projection.py`, `test_native_projection.py`, `SIGNED_URL_POLICY_V2.json`, `ACTUAL_V05L_FINAL_PREFLIGHT.json`, `ARCHIVER_ACTUAL_INTEGRATION.json`, test/review reports and this runbook.
- All six exact original V05-L files: `failure.json`, `final.txt`, `launch.json`, `stderr.json`, `visible-events.jsonl`, `structural-diagnostics.jsonl`. Their hashes must match the preflight; no additional attempt file is permitted.
- The immutable old-process/log copies, original STOP and any explicit coordinator disposition.

The manifest and new code are safety-scanned and hash-bound before canonical acceptance. Never include native envelopes or unprojected tool bodies. Do not include generated future projection files in this input manifest.

## Read-only preflight

```sh
python3 -B runs/deep-verification-20261031/archive_progress_v6.py --check
```

This verifies the manifest and replays the thirteen completed results in memory. It must print `READ_ONLY_NATIVE_PROJECTION_CHECK_PASS` with zero writes and provider calls. No projection files are created by this command.

## One audited writer, then finite resumption

Once code is frozen, root may start the writer's single audit while final manifest review finishes:

```sh
python3 -u -B runs/deep-verification-20261031/archive_progress_v6.py --wait-ready --until 20 --timeout-seconds 21600
```

No event is appended until `SAFE_NATIVE_PROJECTION_ARCHIVE_READY.json` exists with status `READY_FOR_CANONICAL_SAFE_NATIVE_PROJECTION_ACCEPTANCE` and the exact `manifest_sha256`. Root creates that READY only after review and successful preflight. Changed running source, malformed readiness, any new STOP, or validation failure stops safely.

The writer first preserves the original failed attempt in `research.verification.mechanical_failure.preserved`, then accepts the manifest in `research.verification.native_projection_policy.accepted`. It writes `SAFE_NATIVE_PROJECTION_START_RECEIPT.json` with status `DEEP_VERIFICATION_SAFE_NATIVE_PROJECTION_ARCHIVED`, event ID, sequence/hash and exact scope. It then accepts completed results, including V05-L without a model call. New result receipts contain their canonical event sequence/hash; old accepted receipts are unchanged.

Wait for V05-L's new `ARCHIVE_RECEIPT.json`, then run:

```sh
python3 -B runs/deep-verification-20261031/resume_v4_sigv4.py --check
python3 -u -B runs/deep-verification-20261031/resume_v4_sigv4.py --workers 3
```

The resume gate independently reads the exact accepted policy event and V05-L scientific acceptance event, verifies old STOP bindings, proves old PID absence, and requires all seven attempt directories still absent. It dispatches only those seven through the isolated hook. It must not be invoked again after any attempt starts. New failures create `STOP_V4_SIGV4_REPAIR.json`; original STOPs remain preserved. No automatic retry is authorized.

For an administrative writer stop, root may create `ARCHIVE_PROGRESS_V6_STOP_REQUEST.json` with exactly `status: STOP_AFTER_CURRENT_ACCEPTANCE`, `run_id: deep-verification-20261031`, and a nonempty `reason`. It releases the writer after the current bounded acceptance without changing failed or completed work.

The final log delta still waits for all20 scientific acceptances, coordinator closure and requested collector recovery. Its exporter/verifier need the separate native-projection-v2 contract; no final export is performed here.
