"""Isolated, manifest-bound public-output hook over the unchanged V4 transport.

No global monkeypatch, input changes, model calls or writes. Complete original
native bytes still supply identity/config/AST/call-pairing/source hashes/final.
Only recognized signed URLs in paired public outputs are omitted before any
proof can be returned or written. Other contexts retain both old safety gates.
"""
from pathlib import Path
import hashlib,importlib.util,types
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('signed_response_policy_v2',HERE/'signed_url_projection_v2.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
RUNNER_SHA='92cdd3f9bc2e326a5b4cb36b8aef8ec5d6eca3d03a47ed0e3b82bab37e3ac0d8'
WEB_SHA='37eeb386f056c9924cd64000f09c2a35a38f4dc977286426a93da6b59be4f249'
def require_base(base):
 P.require(hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest()==RUNNER_SHA,'Frozen runner changed')
 P.require(hashlib.sha256(Path(base.web_v2.__file__).read_bytes()).hexdigest()==WEB_SHA,'Frozen web normalizer changed')
def clone(function,**replacement):
 f=types.FunctionType(function.__code__,dict(function.__globals__,**replacement),function.__name__,function.__defaults__,function.__closure__);f.__kwdefaults__=function.__kwdefaults__;return f

def native_records(base,lines,sid,prompt,job,root):
 require_base(base);normalizations=[]
 def normalize_output(value):
  if isinstance(value,str):text=value
  else:
   P.require(isinstance(value,list) and 1<=len(value)<=16 and all(isinstance(x,dict) and set(x)=={'type','text'} and x['type']=='input_text' and isinstance(x['text'],str) for x in value),'Unsupported public web output shape')
   text='\n'.join(x['text'] for x in value)
  projected,omissions=P.project_text(text)
  # Keep the original stricter transport scanner too (JWT/Bearer included).
  base.web_v2.credential_safe(projected)
  normalizations.append({'source_text_sha256':P.sha(text.encode()),'source_text_bytes':len(text.encode()),'projected_text_sha256':P.sha(projected.encode()),'projected_text_bytes':len(projected.encode()),'omissions':omissions,'omission_count':len(omissions)})
  return projected
 class WebProxy:
  def __getattr__(self,name):return normalize_output if name=='normalize_output' else getattr(base.web_v2,name)
 proof,visible,finals=clone(base.native_records,web_v2=WebProxy())(lines,sid,prompt,job,root)
 P.require(not proof['isolation_failures'],'Original native identity/input/config/tool isolation failed')
 outputs=[x for x in proof['public_web_calls'] if x.get('type')=='public_web_output']
 P.require(len(outputs)==len(normalizations),'Public output normalization coverage differs')
 ledger=[]
 for output,row in zip(outputs,normalizations):
  P.V1.identity(output)
  P.require(P.sha(output['text'].encode())==row['projected_text_sha256'] and len(output['text'].encode())==row['projected_text_bytes'],'Normalized public output changed')
  if row['omissions']:ledger.append(dict(source_line=output['line'],source_record_sha256=output['record_sha256'],call_id=output['call_id'],projection_copies=2,**row))
 P.require(not P.contains_credential(proof) and not P.contains_credential(visible) and not P.contains_credential(finals),'Credential outside approved public response context')
 proof['public_web_projection']={'schema':'native-public-web-projection.v2','policy_id':P.POLICY_ID,'session_id':sid,'source_output_records':len(ledger),'omitted_url_count':sum(x['omission_count'] for x in ledger),'records':ledger,
  'original_native_record_hashes_retained':True,'scientific_text_unchanged':True,'unsafe_intermediate_files_written':False,
  'boundary':'Original source bytes underwent unchanged identity/input/configuration/AST/call-pairing checks. Exact complete signed S3 URLs alone omitted in paired public response text before proof serialization; source record/text hashes and offsets identify every omission. Original visible assistant/user/final text unchanged.'}
 proof['capture_boundary']+=' Explicit native-public-web-projection.v2 ledger qualifies public output text; it is not a byte-exact original public-body claim.'
 return proof,visible,finals

def inspect_native(base,sid,prompt,job,root,cutoff=None):
 require_base(base)
 def selected(lines,sid,prompt,job,root):return native_records(base,lines,sid,prompt,job,root)
 return clone(base.inspect_native,native_records=selected)(sid,prompt,job,root,cutoff=cutoff)

def clone_dispatch_run_one(base):
 """Install only in a reviewed finite-resumption subclass; never dispatch here."""
 require_base(base)
 def selected(sid,prompt,job,root,cutoff=None):return inspect_native(base,sid,prompt,job,root,cutoff)
 return clone(base.Dispatcher.run_one,inspect_native=selected)
