"""Synthetic SigV4/native-hook tests; no native account reads or model calls."""
from pathlib import Path
import concurrent.futures,copy,importlib.util,json,tempfile,unittest,urllib.parse
HERE=Path(__file__).parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
P=module('sigv4_policy_test',HERE/'signed_url_projection_v2.py');N=module('native_projection_test',HERE/'native_projection.py')
F=module('sigv4_runner_fixtures',HERE.parent/'test_runner_v4.py');R=F.r
def signed_url(query=None,host='s3.amazonaws.com',path='/synthetic-bucket/book/preview.pdf'):
 q={'X-Amz-Algorithm':'AWS4-HMAC-SHA256','X-Amz-Credential':'AKIA'+'A'*16+'/20261031/us-east-1/s3/aws4_request','X-Amz-Date':'20261031T120000Z','X-Amz-Expires':'86400','X-Amz-Signature':'a'*64,'X-Amz-SignedHeaders':'host','response-content-disposition':'inline; filename=preview.pdf','response-content-type':'application/pdf'}
 if query:q.update(query)
 return 'https://'+host+path+'?'+urllib.parse.urlencode(q)

class PolicyTests(unittest.TestCase):
 def test_observed_predicate_whole_url_and_unicode_accounting(self):
  u=signed_url();self.assertTrue(P.signed_s3_sigv4_url(u));text='Источник ('+u+'). Text remains.';out,rows=P.project_text(text)
  self.assertEqual(len(rows),1);self.assertNotIn(u,out);self.assertIn('). Text remains.',out);self.assertEqual(rows[0]['source_utf8_start'],len('Источник ('.encode()));self.assertEqual(rows[0]['url_sha256'],P.sha(u.encode()));self.assertEqual(rows[0]['variant'],'SIGV4_PATH_STYLE_PDF')
 def test_foreign_host_auth_port_http_fragment_fail(self):
  u=signed_url()
  for bad in (signed_url(host='s3.amazonaws.com.evil.example'),signed_url(host='other.s3.amazonaws.com'),signed_url(host='127.0.0.1'),u.replace('https:','http:'),u+'#fragment',u.replace('https://','https://person@'),u.replace('.com/','.com:443/')):
   with self.subTest(),self.assertRaises(P.ProjectionError):P.project_text(bad)
 def test_exact_unique_query_fields(self):
  u=signed_url()
  for bad in (u+'&extra=x',u+'&X-Amz-Date=20261031T120000Z',u.replace('X-Amz-Signature=','OtherSignature=')):
   with self.subTest(),self.assertRaises(P.ProjectionError):P.project_text(bad)
 def test_scope_region_service_key_and_date_are_bound(self):
  scope='AKIA'+'A'*16
  for change in ({'X-Amz-Credential':scope+'/20261031/us-west-2/s3/aws4_request'},{'X-Amz-Credential':scope+'/20261031/us-east-1/iam/aws4_request'},{'X-Amz-Credential':'ASIA'+'A'*16+'/20261031/us-east-1/s3/aws4_request'},{'X-Amz-Date':'20261030T120000Z'},{'X-Amz-Date':'20261031T250000Z'},{'X-Amz-Date':'20260231T120000Z'}):
   with self.subTest(),self.assertRaises(P.ProjectionError):P.project_text(signed_url(change))
 def test_algorithm_header_signature_expiry_and_type_bounds(self):
  for change in ({'X-Amz-Algorithm':'other'},{'X-Amz-SignedHeaders':'host;authorization'},{'X-Amz-Signature':'z'*64},{'X-Amz-Signature':'a'*63},{'X-Amz-Expires':'0'},{'X-Amz-Expires':'604801'},{'X-Amz-Expires':'086400'},{'response-content-type':'text/plain'}):
   with self.subTest(),self.assertRaises(P.ProjectionError):P.project_text(signed_url(change))
 def test_decoded_paths_and_other_credentials_cannot_be_hidden(self):
  secret='sk-'+'Z'*30
  for bad in (signed_url(path='/synthetic-bucket/'+secret+'/preview.pdf'),signed_url(path='/synthetic-bucket/../preview.pdf'),signed_url(path='/synthetic-bucket/%0apreview.pdf'),signed_url(path='/synthetic-bucket/%ZZ/preview.pdf'),signed_url({'response-content-disposition':secret}),signed_url()+' '+secret):
   with self.subTest(),self.assertRaises(P.ProjectionError):P.project_text(bad)
 def test_plain_key_or_non_pdf_never_whitelisted(self):
  for text in ('AKIA'+'A'*16,signed_url(path='/synthetic-bucket/object.txt')):
   with self.assertRaises(P.ProjectionError):P.project_text(text)
 def test_frozen_sigv2_predicate_stays_supported(self):
  q={'AWSAccessKeyId':'ASIA'+'A'*16,'Expires':'1772249332','Signature':'YWFhYWFhYWFhYWFhYWFhYWFhYWE=','x-amz-security-token':'YWFh'*30}
  u='https://synthetic-bucket.s3.eu-west-1.amazonaws.com/book/preview.pdf?'+urllib.parse.urlencode(q);out,rows=P.project_text(u)
  self.assertNotEqual(out,u);self.assertEqual(rows[0]['variant'],'SIGV2_REGIONAL_TEMPORARY')
 def test_transport_only_secret_inside_either_signed_url_not_masked(self):
  for secret in ('Bearer '+'b'*30,'eyJ'+'a'*20+'.'+'b'*20+'.'+'c'*20):
   v4=signed_url({'response-content-disposition':secret})
   q={'AWSAccessKeyId':'ASIA'+'A'*16,'Expires':'1772249332','Signature':'YWFhYWFhYWFhYWFhYWFhYWFhYWE=','x-amz-security-token':'YWFh'*30,'response-content-disposition':secret}
   v2='https://synthetic-bucket.s3.eu-west-1.amazonaws.com/book/preview.pdf?'+urllib.parse.urlencode(q)
   for u in (v4,v2):
    with self.subTest(),self.assertRaises(ValueError):P.project_text(u)
  secret=urllib.parse.quote('Bearer '+'b'*30,safe='')
  with self.assertRaises(ValueError):P.project_text(signed_url(path='/synthetic-bucket/'+secret+'/preview.pdf'))
 def test_paired_copies_keep_identity_and_truthful_file_boundary(self):
  record={'line':9,'record_sha256':'b'*64,'role':'tool','type':'public_web_output','call_id':'c','status':'completed','text':signed_url()}
  proof={'session_id':'s','public_web_calls':[record]};visible={'session_id':'s','records':[copy.deepcopy(record)]};before=copy.deepcopy((proof,visible))
  a,b,ledger=P.project_pair(proof,visible,{'role':'literature'});self.assertEqual((proof,visible),before);self.assertEqual(a['public_web_calls'][0],b['records'][0]);self.assertIn('No claim',ledger['boundary'])
  visible['records'].append({'role':'assistant','text':signed_url()})
  with self.assertRaises(P.ProjectionError):P.project_pair(proof,visible,{'role':'literature'})

class NativeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.job=F.job();self.job.update(role='literature',web_search='live');self.prompt='Frozen input\n';self.text='Public response ('+signed_url()+'). Unchanged remaining public text.'
  self.call=F.line('response_item',{'type':'custom_tool_call','name':'exec','call_id':'c1','input':'const result = await tools.web__run({open:[{ref_id:"https://example.org/paper"}]}); text(result);'})
  self.output=F.line('response_item',{'type':'custom_tool_call_output','call_id':'c1','output':[{'type':'input_text','text':self.text}]})
  self.rows=F.native(self.root);self.rows[-1:-1]=[self.call,self.output]
 def tearDown(self):self.tmp.cleanup()
 def replay(self,rows=None,job=None):return N.native_records(R,self.rows if rows is None else rows,F.SID,self.prompt,self.job if job is None else job,self.root)
 def test_full_replay_safe_before_serialization_exact_final_source_hash(self):
  old_normalizer=R.web_v2.normalize_output;before=copy.deepcopy(self.rows)
  with self.assertRaises(ValueError):R.native_records(self.rows,F.SID,self.prompt,self.job,self.root)
  proof,visible,finals=self.replay();self.assertEqual(self.rows,before);self.assertIs(R.web_v2.normalize_output,old_normalizer)
  self.assertFalse(proof['isolation_failures']);self.assertEqual(proof['public_web_completed_call_ids'],['c1']);self.assertEqual(finals[0]['text'],json.dumps(F.ANSWER))
  ledger=proof['public_web_projection'];self.assertEqual(ledger['omitted_url_count'],1);row=ledger['records'][0]
  self.assertEqual(row['source_record_sha256'],P.sha(self.output));self.assertEqual(row['source_text_sha256'],P.sha(self.text.encode()));self.assertFalse(P.contains_credential(proof));self.assertFalse(P.contains_credential(visible));self.assertNotIn('SECRET_REASONING',json.dumps([proof,visible]))
 def test_visible_assistant_user_or_query_credentials_are_not_redacted(self):
  for rows in (self.rows+[F.message('assistant',signed_url(),'commentary')],self.rows+[F.message('user',signed_url())],F.native(self.root)[:-1]+[F.line('response_item',{'type':'custom_tool_call','name':'exec','call_id':'c1','input':'const result = await tools.web__run({open:[{ref_id:'+json.dumps(signed_url())+'}]}); text(result);'}),self.output,F.native(self.root)[-1]]):
   with self.subTest(),self.assertRaises(ValueError):self.replay(rows)
 def test_unpaired_duplicate_or_other_tool_still_rejected(self):
  for rows in ([x for x in self.rows if x!=self.call],self.rows+[self.output],self.rows+[F.line('response_item',{'type':'function_call','name':'shell','call_id':'forbidden','arguments':'{}'})]):
   with self.subTest(),self.assertRaises(ValueError):self.replay(rows)
 def test_foreign_url_jwt_bearer_and_plain_secret_stop(self):
  for text in (signed_url(host='evil.example'),'Bearer '+'b'*30,'eyJ'+'a'*20+'.'+'b'*20+'.'+'c'*20,'AKIA'+'A'*16):
   out=F.line('response_item',{'type':'custom_tool_call_output','call_id':'c1','output':text});rows=[out if x==self.output else x for x in self.rows]
   with self.subTest(),self.assertRaises(ValueError):self.replay(rows)
 def test_model_config_or_unknown_input_still_stop(self):
  rows=copy.deepcopy(self.rows);rows[1]=F.line('turn_context',{'model':'gpt-6-luna','effort':'ultra','service_tier':'default'})
  with self.assertRaises(ValueError):self.replay(rows)
  with self.assertRaises(ValueError):self.replay(self.rows+[F.message('user','injected context')])
 def test_output_bound_and_exact_block_shape_remain(self):
  for value in ([{'type':'input_text','text':'x','extra':'not allowed'}],[{'type':'input_text','text':'x'}]*17,'x'*(2*1024*1024+1)):
   out=F.line('response_item',{'type':'custom_tool_call_output','call_id':'c1','output':value});rows=[out if x==self.output else x for x in self.rows]
   with self.subTest(),self.assertRaises(ValueError):self.replay(rows)
 def test_dispatch_clone_only_replaces_native_hook_no_launch(self):
  original=R.Dispatcher.run_one;hook=N.clone_dispatch_run_one(R)
  self.assertIs(hook.__code__,original.__code__);self.assertIsNot(hook.__globals__['inspect_native'],original.__globals__['inspect_native']);self.assertIs(R.Dispatcher.run_one,original)
  changed={k for k in hook.__globals__ if hook.__globals__[k] is not original.__globals__[k]};self.assertEqual(changed,{'inspect_native'})
 def test_argument_without_web_keeps_original_final_and_zero_omissions(self):
  proof,visible,finals=self.replay(F.native(self.root),F.job());self.assertEqual(proof['public_web_projection']['omitted_url_count'],0);self.assertEqual(finals[0]['text'],json.dumps(F.ANSWER))
 def test_concurrent_hooks_do_not_share_output_ledgers(self):
  old=R.web_v2.normalize_output
  def work(label):
   out=F.line('response_item',{'type':'custom_tool_call_output','call_id':'c1','output':label+' '+signed_url()})
   proof,_,_=self.replay([out if x==self.output else x for x in self.rows]);return proof['public_web_projection']['records'][0]['source_text_sha256']
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:values=list(pool.map(work,['first','second']))
  self.assertEqual(values,[P.sha((label+' '+signed_url()).encode()) for label in ('first','second')]);self.assertIs(R.web_v2.normalize_output,old)
if __name__=='__main__':unittest.main()
