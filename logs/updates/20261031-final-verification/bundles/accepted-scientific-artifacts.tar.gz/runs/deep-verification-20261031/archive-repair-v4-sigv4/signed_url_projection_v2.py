"""Reviewed SigV2 plus observed AWS SigV4 PDF response URL omission only."""
from pathlib import Path
import datetime,hashlib,importlib.util,re,sys,types
from urllib.parse import urlsplit,parse_qsl,unquote
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'archive-repair-v4/signed_url_projection.py'
OLD_SHA='326ffe5371e3cfdeeaf4e09cd66c4dc7f677f7996527465fe88a91a239557421'
if hashlib.sha256(OLD.read_bytes()).hexdigest()!=OLD_SHA:raise ValueError('Frozen SigV2 policy changed')
s=importlib.util.spec_from_file_location('frozen_sigv2_policy',OLD);V1=importlib.util.module_from_spec(s);s.loader.exec_module(V1)
STRICT_SOURCE=HERE.parent/'web_transport_v2.py'
if hashlib.sha256(STRICT_SOURCE.read_bytes()).hexdigest()!='2c0c2fabbcbf3f8753bdd8032e7ff07a48ef2b46dd6bff54bab623eb50d544b9':raise ValueError('Frozen transport credential scanner changed')
sys.path.insert(0,str(HERE.parent));import web_transport_v2 as STRICT
POLICY_ID='SIGNED_S3_PUBLIC_RESPONSE_URL_OMISSION_V2'
ProjectionError=V1.ProjectionError;require=V1.require;sha=V1.sha;URL=V1.URL;contains_credential=V1.contains_credential
SIGV4_KEYS={'X-Amz-Algorithm','X-Amz-Credential','X-Amz-Date','X-Amz-Expires','X-Amz-Signature','X-Amz-SignedHeaders','response-content-disposition','response-content-type'}

def strict_components_safe(value,identity_field):
 """A second secret inside an otherwise signed URL cannot be masked with it."""
 try:
  parts=urlsplit(value);STRICT.credential_safe(unquote(parts.path))
  for key,text in parse_qsl(parts.query,keep_blank_values=True,strict_parsing=True):
   if key!=identity_field:STRICT.credential_safe(text)
  return True
 except (ValueError,TypeError,UnicodeError):return False

def signed_s3_sigv4_url(value):
 """Only observed path-style s3.amazonaws.com/us-east-1 PDF SigV4 shape."""
 try:
  require(isinstance(value,str) and value.isascii() and len(value)<=16384,'URL bound')
  require(not re.search(r'[\x00-\x20\x7f]|%(?![0-9a-fA-F]{2})',value),'URL encoding/control')
  parts=urlsplit(value)
  require(parts.scheme=='https' and parts.netloc==parts.hostname=='s3.amazonaws.com' and parts.username is None and parts.password is None and parts.port is None and not parts.fragment,'Exact AWS endpoint')
  path=unquote(parts.path);segments=path.split('/')
  require(path.startswith('/') and path.endswith('.pdf') and len(segments)>=3 and all(x not in {'.','..'} for x in segments),'PDF object path')
  bucket=segments[1];require(3<=len(bucket)<=63 and all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',x) for x in bucket.split('.')),'S3 bucket')
  require(not re.search(r'[\x00-\x1f\x7f]',path) and not contains_credential(path),'Safe decoded path')
  pairs=parse_qsl(parts.query,keep_blank_values=True,strict_parsing=True,max_num_fields=8);query=dict(pairs)
  require(len(pairs)==len(query)==8 and set(query)==SIGV4_KEYS,'Exact unique signed query fields')
  require(query['X-Amz-Algorithm']=='AWS4-HMAC-SHA256' and query['X-Amz-SignedHeaders']=='host','Signing algorithm/headers')
  credential=query['X-Amz-Credential'].split('/')
  require(len(credential)==5 and re.fullmatch(r'AKIA[A-Z0-9]{16}',credential[0]) and re.fullmatch(r'[0-9]{8}',credential[1])
          and credential[2:]==['us-east-1','s3','aws4_request'],'Exact credential scope')
  date=query['X-Amz-Date'];require(re.fullmatch(r'[0-9]{8}T[0-9]{6}Z',date) and date[:8]==credential[1],'Matching signing date')
  datetime.datetime.strptime(date,'%Y%m%dT%H%M%SZ')
  require(re.fullmatch(r'[1-9][0-9]{0,5}',query['X-Amz-Expires']) and int(query['X-Amz-Expires'])<=604800,'Bounded expiry')
  require(re.fullmatch(r'[a-f0-9]{64}',query['X-Amz-Signature']),'Signature shape')
  disposition=query['response-content-disposition'];require(0<len(disposition)<=512 and not re.search(r'[\x00-\x1f\x7f]',disposition),'Disposition bound')
  require(query['response-content-type']=='application/pdf','PDF content type')
  require(not any(contains_credential(v) for k,v in query.items() if k!='X-Amz-Credential'),'Other credential inside signed URL')
  require(strict_components_safe(value,'X-Amz-Credential'),'Other transport credential inside signed URL')
  return True
 except (ProjectionError,ValueError,TypeError,UnicodeError):return False

def project_text(text):
 require(isinstance(text,str) and len(text.encode())<=2*1024*1024,'Public output text exceeds bound')
 pieces=[];omissions=[];cursor=0
 for match in URL.finditer(text):
  url=match.group();variant='SIGV2_REGIONAL_TEMPORARY' if V1.signed_s3_url(url) and strict_components_safe(url,'AWSAccessKeyId') else 'SIGV4_PATH_STYLE_PDF' if signed_s3_sigv4_url(url) else None
  if variant is None:continue
  raw=url.encode();digest=sha(raw);replacement='[SIGNED PUBLIC URL EXCLUDED; sha256='+digest+'; bytes='+str(len(raw))+']'
  omissions.append({'reason':'SIGNED_PUBLIC_URL_QUERY_CREDENTIALS','variant':variant,'url_sha256':digest,'url_bytes':len(raw),'source_utf8_start':len(text[:match.start()].encode()),'replacement':replacement})
  require(len(omissions)<=64,'Signed URL omission count exceeds bound')
  pieces.extend([text[cursor:match.start()],replacement]);cursor=match.end()
 pieces.append(text[cursor:]);projected=''.join(pieces)
 require(not contains_credential(projected),'Credential outside approved signed public response URL')
 STRICT.credential_safe(projected)
 return projected,omissions

# Keep the exact reviewed paired-copy identity/unchanged-science checks. Only
# the explicit public response text policy and policy identifier are replaced.
_globals=dict(V1.project_pair.__globals__,project_text=project_text,POLICY_ID=POLICY_ID)
_pair=types.FunctionType(V1.project_pair.__code__,_globals,'project_pair',V1.project_pair.__defaults__,V1.project_pair.__closure__)
def project_pair(proof,visible,job):
 a,b,ledger=_pair(proof,visible,job)
 ledger['boundary']='Complete signed public response URLs alone omitted from paired public copies. Original native source bytes and any existing original files remain unchanged. No claim that an unprojected proof file previously existed; source/text hashes identify the in-memory originals.'
 return a,b,ledger
