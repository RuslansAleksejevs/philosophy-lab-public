# Prepared signed public URL successor

No model calls, dispatch or canonical writes occur on import or during tests.
All previous runner, policy, receipt and failure files remain immutable.

`signed_url_projection_v2.py` retains the reviewed SigV2 predicate and adds only
the observed path-style HTTPS `s3.amazonaws.com` PDF SigV4 shape, with its exact
eight query keys and `us-east-1/s3/aws4_request` scope. Both frozen credential
scanners check decoded non-identity components **before** whole-URL omission.
Other credential contexts fail closed. See `SIGNED_URL_POLICY_V2.json`.

`native_projection.inspect_native(base_runner, sid, prompt, job, root, cutoff)`
returns only safe proof/visible copies and unchanged final messages. It clones
the frozen native parser into isolated globals and replaces only the normalizer
for outputs paired to AST-validated public calls. It preserves original native
prefix/record hashes and adds an explicit per-output omission ledger. It never
writes an unsafe intermediate proof. Scientific text remains unchanged.

`clone_dispatch_run_one(base_runner)` returns the exact frozen method code with
only its `inspect_native` global replaced. A separately reviewed finite resume
wrapper must bind and install it. This module does not authorize or dispatch
any jobs. The original runner module is never monkeypatched, including during
parallel calls.

`ACTUAL_V05L_FINAL_PREFLIGHT.json` is the final read-only replay result after
19 synthetic tests and independent review. V05-L completed its original model
call; the historical failure remains preserved. No original COMPLETE receipt,
native proof file or response file is invented. A new mechanical acceptance
must bind that failure, the unchanged original final and native source cutoff,
then explicitly identify any newly generated safe proof/response artifacts.
