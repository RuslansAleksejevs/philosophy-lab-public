"""Synthetic fixtures only: no live archive, native source or provider access."""
from pathlib import Path
import copy,importlib.util,json,tempfile,unittest
SPEC=importlib.util.spec_from_file_location('closure_under_test',Path(__file__).with_name('closure.py'));c=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(c)

class Writer:
 def __init__(self,events,objects):self._state={'records':copy.deepcopy(events)};self.objects=copy.deepcopy(objects);self.puts=0;self.appends=0
 def _ensure_audited(self):pass
 def get(self,h):return self.objects[h]
 def put(self,b):self.puts+=1;h=c.sha(b);self.objects[h]=b;return h
 def append(self,e,key):
  old=next((x for x in self._state['records'] if x.get('delivery_key')==key),None)
  if old:
   c.require(all(old[k]==v for k,v in e.items()),'Replay changed');return old
  self.appends+=1;item=copy.deepcopy(e);item.update(id='new-'+str(self.appends),delivery_key=key);self._state['records'].append(item);return item

class TestClosure(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.run=self.root/'runs/deep-verification-20261031';self.run.mkdir(parents=True);self.objects={};self.events=[];self.bindings={'method':['method'],'instruction':[],'config':[],'input':[]};self.sid='coordinator-original';self.cover=[]
  def ev(eid,kind,sid=None,payload=None,parents=None,outputs=None):
   e={'id':eid,'kind':kind,'session_id':sid or self.sid,'run_id':self.run.name,'actor':{'id':sid or self.sid,'role':'AI'},'bindings':self.bindings,'parents':parents or [],'outputs':outputs or [],'payload':payload or {}};self.events.append(e);return e
  self.ev=ev
  ev('start','operation.started',payload={'protocol':'philosophy-round.v1','purpose':'research'})
  ev('question-raw','capture.raw_record');ev('question','round.stage',payload={'stage':'question'},parents=['start','question-raw'])
  ev('question-cover','capture.coverage',payload={'status':'BOUNDED_COMPLETE'},parents=['question-raw']);self.cover.append('question-cover')
  manuscripts=[]
  for i in range(1,11):
   mid=f'V{i:02d}';body=('SYNTHETIC manuscript '+mid).encode();ref=self.write('originals/'+mid+'.md',body);reading=self.write('reading/'+mid+'.md',body);packet=self.write('packets/'+mid+'/manuscript.md',body)
   manuscripts.append({'manuscript_id':mid,'candidate_id':'E'+str(i),'source':ref['path'],'reading_source':reading['path'],'packet':packet['path'],'sha256':ref['sha256'],'bytes':ref['bytes']})
  manifest=self.write('MANIFEST.json',{'manuscripts':manuscripts});self.manuscripts=manuscripts
  ev('inputs','research.verification.inputs.accepted',payload={'files':[manifest]})
  self.write('START_RECEIPT.json',{'run_start_event':'start','event_id':'inputs','question_stage_event':'question','bindings':self.bindings,'capture_events':['question-cover']})
  jobs=[];tf=[]
  for m in manuscripts:
   for code,role in [('A','argument'),('L','literature')]:
    jid=m['manuscript_id']+'-'+code;prompt=self.write('prompts/'+jid+'.txt',b'SYNTHETIC prompt');schema=self.write('schemas/'+jid+'.json',{'type':'object'});tf += [prompt,schema]
    jobs.append({'id':jid,'manuscript_id':m['manuscript_id'],'role':role,'model':'gpt-6-astra','effort':'ultra','service_tier':'default','prompt_file':prompt['path'],'prompt_sha256':prompt['sha256'],'schema_file':schema['path'],'schema_sha256':schema['sha256']})
  self.jobs=jobs
  for version in (3,4):
   queue=self.write(f'jobs_v{version}.json',{'jobs':jobs+[{'id':'SMOKE-L3'}]});bound=tf+[queue];payload={'status':f'DEEP_VERIFICATION_TRANSPORT_V{version}_ARCHIVED','files':bound}
   if version==4:payload['prior_transport_event_id']='transport3'
   ev('transport'+str(version),f'research.verification.transport_v{version}.accepted',payload=payload,parents=['inputs']+(['transport3'] if version==4 else []));self.write(f'TRANSPORT_V{version}_START_RECEIPT.json',{'event_id':'transport'+str(version),**payload})
  self.result_refs={}
  for job in jobs:
   jid=job['id'];sid='fresh-session-'+jid;a='results/'+jid+'/attempt-001/'
   response=self.write(a+'response.json',{'synthetic':True});proof=self.write(a+'native-check.json',{'session_id':sid,'isolation_failures':[]});outputs={response['path']:response['sha256'],proof['path']:proof['sha256']}
   terminal={k:job[v] for k,v in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]};terminal.update(status='COMPLETE_LOCAL_PENDING_CANONICAL_ARCHIVE',job_id=jid,session_id=sid,quality_flags=[],outputs=outputs)
   receipt=self.write(a+'receipt.json',terminal);self.result_refs[jid]=response;cov='coverage-'+jid;ev(cov,'capture.coverage',sid,{'status':'BOUNDED_COMPLETE'});self.cover.append(cov)
   payload={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':jid,'scientific':True,'independence_verified':True,'receipt':receipt,'native_check':proof,'files':[response,proof,receipt],'capture_event_ids':[cov],'web_event_ids':[]}
   ev('accepted-'+jid,'research.verification.result.accepted',sid,payload,['inputs','transport3' if jid in {'V01-A','V02-A'} else 'transport4']);self.write('results/'+jid+'/ARCHIVE_RECEIPT.json',{'event_id':'accepted-'+jid,**{k:payload[k] for k in ('receipt','native_check','files')}})
  ev('coordinator-raw','capture.raw_record');ev('coordinator-cover','capture.coverage',payload={'status':'BOUNDED_COMPLETE'},parents=['coordinator-raw']);self.cover.append('coordinator-cover')
  ledger={'schema':'verification-source-ledger.v1','coordinator_session_id':self.sid,'access_boundary':'Synthetic access limits','reports':[{'job_id':j['id'],'accepted_event_id':'accepted-'+j['id'],'retrieval_note':'Synthetic source note'} for j in jobs if j['role']=='literature']}
  matrix={'schema':'verification-matrix.v1','coordinator_session_id':self.sid,'manuscripts':[{'manuscript_id':m['manuscript_id'],'candidate_id':m['candidate_id'],'manuscript_sha256':m['sha256'],'review_event_ids':['accepted-'+m['manuscript_id']+'-A','accepted-'+m['manuscript_id']+'-L'],'situation_ru':'Ситуация','surviving_contribution_ru':'Что сохраняется','main_risk_ru':'Риск','reason_ru':['Причина первая.','Причина вторая.'],'unresolved_blocking_defects':[],'reopen_conditions':['Новый проверенный дефект']} for m in manuscripts]}
  arts={'source_ledger':self.write('closure/source-ledger.json',ledger),'contribution_matrix':self.write('closure/matrix.json',matrix)}
  decision={'schema':'verification-decision.v1','coordinator_session_id':self.sid,'matrix_sha256':arts['contribution_matrix']['sha256'],'primary':['V01','V02','V03'],'reserves':['V04','V05'],'recommendation_status':'THREE_PLUS_TWO_READY','submission_authorized':False,'scope_note':'Recommendation only'};arts['decision']=self.write('closure/decision.json',decision)
  cards={'schema':'verification-cards.v1','decision_sha256':arts['decision']['sha256'],'cards':[dict(manuscript_id=mid,essence_ru='Суть',what_is_new_ru='Вклад',main_risk_ru='Риск',why_selected_ru='Основание') for mid in decision['primary']+decision['reserves']]};arts['cards']=self.write('closure/cards.json',cards)
  summary={k:'Synthetic explanation' for k in c.FIELDS};summary.update(outcome='CONTINUE',legacy_api_boundary=c.BOUNDARY,finite_status='VERIFICATION_COMPLETE_BOUNDED');arts['checkpoint_summary']=self.write('closure/checkpoint.json',summary)
  home=Path(__file__).parent;implementation=[]
  for name in ('closure.py','test_closure.py','PROTOCOL_NOTE.md'):implementation.append(self.write('closure-preparation/'+name,(home/name).read_bytes()))
  arts['protocol_note']=next(r for r in implementation if r['path'].endswith('PROTOCOL_NOTE.md'))
  self.req={'schema':'verification-closure-request.v1','run_id':self.run.name,'session_id':self.sid,'boundary':c.BOUNDARY,'artifacts':arts,'implementation_files':implementation,'coordinator_evidence_event_ids':['coordinator-raw'],'coverage_event_ids':self.cover};self.request=self.write('closure/REQUEST.json',self.req)
 def tearDown(self):self.tmp.cleanup()
 def write(self,name,value):
  p=self.run/name;p.parent.mkdir(parents=True,exist_ok=True);raw=value if isinstance(value,bytes) else c.encode(value);p.write_bytes(raw);ref=c.desc(self.root,p);self.objects[ref['sha256']]=raw;return ref
 def update_art(self,key,change):
  ref=self.req['artifacts'][key];doc=c.strict(c.read(self.root,ref));change(doc);self.req['artifacts'][key]=self.write(str(Path(ref['path']).relative_to(self.run.relative_to(self.root))),doc);self.request=self.write('closure/REQUEST.json',self.req)
 def preflight(self):return c.preflight(self.root,self.run,self.request,self.events,self.objects.__getitem__)
 def checkpoint(self,root,w,run,summary,coverage,incomplete):
  self.assertTrue(incomplete);raw=(root/summary).read_bytes();cp=w.append({'kind':'checkpoint','actor':{'id':self.sid,'role':'AI'},'session_id':self.sid,'run_id':run,'parents':['start','question']+coverage,'outputs':[c.sha(raw)],'payload':{'summary':c.strict(raw),'capture_status':'INCOMPLETE','truth_status':'NOT_CERTIFIED'}},'core-checkpoint')
  w.append({'kind':'operation.interrupted','run_id':run,'parents':['start',cp['id']],'payload':{'checkpoint':cp['id']}},'core-terminal');return cp
 def test_full_preflight_preserves_twenty_distinct_attributions(self):
  d=self.preflight();self.assertTrue(d['ready']);self.assertEqual(len({r['session_id'] for r in d['reports']}),20)
  self.assertEqual(sum(r['transport_event_id']=='transport3' for r in d['reports']),2)
  self.assertEqual(sum(r['transport_event_id']=='transport4' for r in d['reports']),18)
 def test_accepted_original_parent_cannot_be_relabelled_as_current_transport(self):
  e=next(e for e in self.events if e['id']=='accepted-V01-A');e['parents']=['inputs','transport4']
  with self.assertRaises(c.Invalid):self.preflight()
 def test_current_transport_receipt_must_match_canonical_files(self):
  p=self.run/'TRANSPORT_V4_START_RECEIPT.json';d=c.strict(p.read_bytes());d['files']=[];p.write_bytes(c.encode(d))
  with self.assertRaises(c.Invalid):self.preflight()
 def test_legacy_canonical_sizeless_refs_and_repeated_same_sha_are_preserved(self):
  for version in (3,4):
   e=next(e for e in self.events if e['id']=='transport'+str(version))
   for ref in e['payload']['files']:ref.pop('bytes',None)
   self.write(f'TRANSPORT_V{version}_START_RECEIPT.json',{'event_id':e['id'],**e['payload']})
  e=next(e for e in self.events if e['id']=='accepted-V01-A');ref=e['payload']['files'][0];e['payload']['files'].append({k:ref[k] for k in ('path','sha256')})
  self.write('results/V01-A/ARCHIVE_RECEIPT.json',{'event_id':e['id'],**{k:e['payload'][k] for k in ('receipt','native_check','files')}})
  d=self.preflight();self.assertEqual(len(next(x for x in d['reports'] if x['job_id']=='V01-A')['files']),4)
  copies=[x for x in d['files'] if x['path']==ref['path']];self.assertEqual(len(copies),1);self.assertIn('bytes',copies[0])
 def test_conflicting_same_path_sha_fails_before_writes(self):
  e=next(e for e in self.events if e['id']=='accepted-V01-A');ref=dict(e['payload']['files'][0]);ref['sha256']='0'*64;e['payload']['files'].append(ref)
  self.write('results/V01-A/ARCHIVE_RECEIPT.json',{'event_id':e['id'],**{k:e['payload'][k] for k in ('receipt','native_check','files')}})
  w=Writer(self.events,self.objects)
  with self.assertRaises(c.Invalid):c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint)
  self.assertEqual((w.puts,w.appends),(0,0))
 def test_missing_twentieth_acceptance_never_reads_scientific_result_bytes(self):
  self.events=[e for e in self.events if e['id']!='accepted-V10-L'];result_hashes={r['sha256'] for r in self.result_refs.values()};seen=[]
  def get(h):seen.append(h);return self.objects[h]
  with self.assertRaises(c.Invalid):c.preflight(self.root,self.run,self.request,self.events,get)
  self.assertTrue(result_hashes.isdisjoint(seen))
 def test_unique_contexts_and_original_input_binding_required(self):
  for field,value in [('session_id','fresh-session-V01-A'),('bindings',{'method':['different']})]:
   old=copy.deepcopy(self.events);e=next(e for e in self.events if e['id']=='accepted-V02-A');e[field]=value
   with self.assertRaises(c.Invalid):self.preflight()
   self.events=old
 def test_original_manuscript_drift_rejected(self):
  (self.root/self.manuscripts[0]['source']).write_text('changed')
  with self.assertRaises(c.Invalid):self.preflight()
 def test_accepted_result_drift_rejected(self):
  (self.root/self.result_refs['V01-A']['path']).write_text('{}')
  with self.assertRaises(c.Invalid):self.preflight()
 def test_human_or_foreign_evidence_cannot_certify_coordinator_authorship(self):
  e=next(e for e in self.events if e['id']=='coordinator-raw');e['actor']['role']='user'
  with self.assertRaises(c.Invalid):self.preflight()
 def test_missing_worker_or_coordinator_coverage_rejected(self):
  self.req['coverage_event_ids']=self.cover[:-1];self.request=self.write('closure/REQUEST.json',self.req)
  with self.assertRaises(c.Invalid):self.preflight()
 def test_matrix_missing_candidate_or_wrong_pair_rejected(self):
  self.update_art('contribution_matrix',lambda d:d['manuscripts'].pop())
  with self.assertRaises(c.Invalid):self.preflight()
 def test_selected_unresolved_defect_fails_before_archive_write(self):
  self.update_art('contribution_matrix',lambda d:d['manuscripts'][0]['unresolved_blocking_defects'].append('fatal'))
  self.update_art('decision',lambda d:d.update(matrix_sha256=self.req['artifacts']['contribution_matrix']['sha256']))
  w=Writer(self.events,self.objects)
  with self.assertRaises(c.Invalid):c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint)
  self.assertEqual((w.puts,w.appends),(0,0))
 def test_submission_or_short_recommendation_cannot_be_success(self):
  self.update_art('decision',lambda d:d.update(primary=['V01','V02']))
  with self.assertRaises(c.Invalid):self.preflight()
 def test_protocol_note_and_code_are_bound(self):
  p=self.run/'closure-preparation/PROTOCOL_NOTE.md';p.write_text('different')
  with self.assertRaises(c.Invalid):self.preflight()
 def test_close_and_replay_preserve_original_authors_and_legacy_boundary(self):
  w=Writer(self.events,self.objects);result=c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint);self.assertEqual(result['status'],'VERIFICATION_COMPLETE_BOUNDED');n=w.appends
  stages=[e for e in w._state['records'] if e['kind']=='research.verification.stage'];self.assertEqual([e['payload']['stage'] for e in stages],list(c.STAGES));crit=stages[2]
  self.assertEqual(len(crit['payload']['per_item_attribution']),20);self.assertEqual(crit['actor']['role'],'tool');self.assertNotIn('contribution_origin',crit['payload']);self.assertFalse(crit['payload']['coordinator_evidence_event_ids'])
  again=c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint);self.assertEqual(again,result);self.assertEqual(w.appends,n)
 def test_checkpoint_failure_never_emits_final_and_replay_recovers(self):
  w=Writer(self.events,self.objects)
  def fail(*a,**kw):raise RuntimeError('synthetic interrupted checkpoint')
  with self.assertRaises(RuntimeError):c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=fail)
  self.assertFalse((self.run/'FINAL_RECEIPT.json').exists());result=c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint);self.assertEqual(result['status'],'VERIFICATION_COMPLETE_BOUNDED')
 def test_no_checkpoint_permission_means_no_writes(self):
  w=Writer(self.events,self.objects)
  with self.assertRaises(c.Invalid):c.close_with_writer(self.root,self.run,self.request,w,checkpoint_api=self.checkpoint)
  self.assertEqual((w.puts,w.appends),(0,0))
 def test_conflicting_existing_request_or_final_rejected_before_writes(self):
  for variant in ('request','receipt'):
   with self.subTest(variant=variant):
    w=Writer(self.events,self.objects)
    if variant=='request':w._state['records'].append({'id':'other-intake','run_id':self.run.name,'kind':'research.verification.closure.inputs','payload':{'request':{'sha256':'other'}}})
    else:(self.run/'FINAL_RECEIPT.json').write_bytes(c.encode({'event_id':'missing'}))
    with self.assertRaises(c.Invalid):c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint)
    self.assertEqual((w.puts,w.appends),(0,0))
 def test_withheld_decision_has_no_success_receipt(self):
  self.update_art('decision',lambda d:d.update(primary=[],reserves=[],recommendation_status='WITHHELD_FOR_DEFECTS',withheld_reason_ru='Недостаточно безопасных кандидатов'))
  self.update_art('cards',lambda d:d.update(cards=[],decision_sha256=self.req['artifacts']['decision']['sha256']))
  self.update_art('checkpoint_summary',lambda d:d.update(finite_status='VERIFICATION_INCOMPLETE_RECOMMENDATION_WITHHELD'))
  w=Writer(self.events,self.objects);r=c.close_with_writer(self.root,self.run,self.request,w,allow_checkpoint_derived_updates=True,checkpoint_api=self.checkpoint);self.assertEqual(r['status'],'VERIFICATION_INCOMPLETE_RECOMMENDATION_WITHHELD');self.assertFalse((self.run/'FINAL_RECEIPT.json').exists());self.assertTrue((self.run/'WITHHELD_RECEIPT.json').exists())
 def test_paths_and_existing_outputs_never_overwritten(self):
  p=self.run/'link';p.symlink_to(self.run/'MANIFEST.json')
  with self.assertRaises(c.Invalid):c.path(self.root,str(p.relative_to(self.root)))
  p=self.run/'kept';p.write_bytes(b'old')
  with self.assertRaises(c.Invalid):c.save_once(p,b'new')
  self.assertEqual(p.read_bytes(),b'old')
if __name__=='__main__':unittest.main()
