#!/usr/bin/env python3
"""Administrative multi-session closure; never dispatch, select or rewrite essays.

Import and preflight have no archive writes. Execution requires one explicit
request and the caller's audited writer. Scientific bodies are never parsed.
"""
from pathlib import Path
import argparse,copy,hashlib,json,math,os,sys,uuid

STAGES=('sources','contribution','critique','decision')
FIELDS=('question','outcome','contribution','criticism','limitations','next_step','method_change','comparability','coverage_boundary')
BOUNDARY=('Typed multi-session verification bindings preserve each original author and session. '
 'Critiques concern the frozen manuscripts, not the later coordinator synthesis. '
 'The legacy single-author checkpoint is administrative INCOMPLETE; the separate finite receipt '
 'records only the explicitly accepted verification and recommendation. No novelty certificate, '
 'manuscript authorship transfer, whole-provider coverage, or submission approval is implied.')

class Invalid(ValueError):pass
def require(ok,msg):
 if not ok:raise Invalid(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def strict(raw):
 def pairs(rows):
  d={}
  for k,v in rows:require(k not in d,'Duplicate JSON key');d[k]=v
  return d
 def number(v):
  n=float(v);require(math.isfinite(n),'Nonfinite number');return n
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(Invalid('Nonfinite number')),parse_float=number)
def encode(x):return (json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def nonempty(x):return isinstance(x,str) and bool(x.strip())
def path(root,name):
 p=Path(name);require(not p.is_absolute() and p.parts and '..' not in p.parts,'Relative path required');p=root/p
 require(p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'Missing/nonregular/symlink input');return p
def read(root,ref):
 require(isinstance(ref,dict) and set(ref)>={'path','sha256','bytes'} and type(ref['bytes']) is int,'Exact descriptor required')
 raw=path(root,ref['path']).read_bytes();require(sha(raw)==ref['sha256'] and len(raw)==ref['bytes'],'Input changed: '+ref['path']);return raw
def desc(root,p):
 raw=p.read_bytes();return {'path':str(p.relative_to(root)),'sha256':sha(raw),'bytes':len(raw)}
def save_once(p,raw):
 require(not any(q.is_symlink() for q in (p,*p.parents)),'Symlink output')
 p.parent.mkdir(parents=True,exist_ok=True);temp=p.parent/('.closure-'+uuid.uuid4().hex)
 try:
  with temp.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  try:os.link(temp,p)
  except FileExistsError:require(p.is_file() and p.read_bytes()==raw,'Existing output differs; preserved')
  fd=os.open(p.parent,os.O_RDONLY)
  try:os.fsync(fd)
  finally:os.close(fd)
 finally:
  if temp.exists():temp.unlink()
def object_equal(get,ref,raw):require(get(ref['sha256'])==raw,'Canonical object differs from bound file')
def canonical_read(root,ref,get):
 """Historical canonical descriptors may omit size; SHA/object bytes stay exact."""
 require(isinstance(ref,dict) and set(ref)>={'path','sha256'},'Canonical descriptor missing')
 raw=path(root,ref['path']).read_bytes();require(sha(raw)==ref['sha256'],'Canonical file changed')
 if 'bytes' in ref:require(type(ref['bytes']) is int and len(raw)==ref['bytes'],'Canonical size changed')
 object_equal(get,ref,raw);return raw

def preflight(root,run,request_ref,events,get):
 """Read-only. Gate all20 canonical acceptances before touching result files."""
 root=Path(root).absolute();run=Path(run).absolute();require(run.is_relative_to(root),'Run outside root')
 raw=read(root,request_ref);req=strict(raw);require(req.get('schema')=='verification-closure-request.v1' and req.get('run_id')==run.name,'Wrong closure request')
 require(req.get('session_id') and req.get('boundary')==BOUNDARY,'Explicit coordinator/API boundary required')
 known={e['id']:e for e in events};require(len(known)==len(events),'Duplicate canonical event identity')
 def event(eid,kind=None):
  require(eid in known,'Canonical dependency missing: '+str(eid));e=known[eid]
  require(kind is None or e['kind']==kind,'Wrong event kind');return e
 start_path=run/'START_RECEIPT.json';start=strict(start_path.read_bytes());first=event(start['run_start_event'],'operation.started')
 require(first['run_id']==run.name and first['session_id']==req['session_id'] and first['bindings']==start['bindings'],'Original round identity/bindings changed')
 require(first['payload'].get('protocol')=='philosophy-round.v1' and first['payload'].get('purpose')=='research','Expected original research round')
 inputs=event(start['event_id'],'research.verification.inputs.accepted');require(inputs['run_id']==run.name and inputs['bindings']==first['bindings'],'Original input event mismatch')
 question=event(start['question_stage_event'],'round.stage');require(question['payload']['stage']=='question' and question['session_id']==req['session_id'],'Question stage mismatch')
 original_files={x['path']:x for x in inputs['payload']['files']}
 manifest_rel=str((run/'MANIFEST.json').relative_to(root));require(manifest_rel in original_files,'Original manifest not accepted')
 manifest_raw=read(root,original_files[manifest_rel]);object_equal(get,original_files[manifest_rel],manifest_raw);manifest=strict(manifest_raw)
 manuscripts={m['manuscript_id']:m for m in manifest['manuscripts']};require(len(manuscripts)==10 and set(manuscripts)=={f'V{i:02d}' for i in range(1,11)},'Exactly10 original manuscripts required')
 transports={};transport_paths=[]
 for version in (3,4):
  transport_path=path(root,str((run/f'TRANSPORT_V{version}_START_RECEIPT.json').relative_to(root)));transport=strict(transport_path.read_bytes());te=event(transport['event_id'],f'research.verification.transport_v{version}.accepted')
  require(te['run_id']==run.name and te['bindings']==first['bindings'] and te['payload']['status']==f'DEEP_VERIFICATION_TRANSPORT_V{version}_ARCHIVED' and transport.get('status')==te['payload']['status'] and transport.get('files')==te['payload']['files'],'Transport acceptance mismatch')
  tf={r['path']:r for r in te['payload']['files']};require(len(tf)==len(te['payload']['files']),'Duplicate transport input path')
  queue_rel=str((run/f'jobs_v{version}.json').relative_to(root));require(queue_rel in tf,'Queue not accepted by transport')
  qr=canonical_read(root,tf[queue_rel],get);queue=strict(qr)['jobs'];jobs={j['id']:j for j in queue}
  require(len(jobs)==len(queue),'Duplicate transport job');transports[version]={'event':te,'files':tf,'jobs':jobs};transport_paths.append(transport_path)
 require(transports[3]['event']['id'] in transports[4]['event']['parents'] and transports[4]['event']['payload'].get('prior_transport_event_id')==transports[3]['event']['id'],'V4 does not bind the accepted V3 predecessor')
 require(transports[3]['jobs']==transports[4]['jobs'],'Transport successor changed frozen scientific inputs')
 te=transports[4]['event'];tf=transports[4]['files'];jobs=transports[4]['jobs']
 wanted={mid+'-'+role for mid in manuscripts for role in ('A','L')};require(set(jobs)==wanted|{'SMOKE-L3'} and len(jobs)==len(queue),'Wrong finite queue')
 accepted={};sessions=set()
 for jid in sorted(wanted):
  arpath=run/'results'/jid/'ARCHIVE_RECEIPT.json';require(arpath.is_file(),'All20 canonical acceptances required before closure')
  ar=strict(arpath.read_bytes());e=event(ar.get('event_id'),'research.verification.result.accepted');p=e['payload']
  require(e['run_id']==run.name and e['bindings']==first['bindings'] and p.get('status')=='DEEP_VERIFICATION_RESULT_ARCHIVED' and p.get('job_id')==jid and p.get('scientific') is True and p.get('independence_verified') is True,'Wrong accepted scientific result')
  require(ar.get('receipt')==p['receipt'] and ar.get('native_check')==p['native_check'] and ar.get('files')==p['files'],'Local acceptance differs from canonical')
  require(e['session_id'] not in sessions and e['session_id']!=req['session_id'],'Scientific sessions must be20distinct fresh contexts');sessions.add(e['session_id'])
  version=3 if jid in {'V01-A','V02-A'} else 4;bound_transport=transports[version]
  require(bound_transport['event']['id'] in e['parents'] and inputs['id'] in e['parents'],'Result lacks exact input/transport parents')
  accepted[jid]={'event':e,'job':jobs[jid],'transport':bound_transport}
 # Only after all20 event gates: verify exact result bytes and local metadata.
 files=[request_ref,desc(root,start_path)]+[desc(root,p) for p in transport_paths];report_rows=[];required_coverage=set(start['capture_events'])
 for mid,m in manuscripts.items():
  for name in ('source','reading_source','packet'):
   ref={'path':m[name],'sha256':m['sha256'],'bytes':m['bytes']};body=read(root,ref)
   require(get(m['sha256'])==body,'Original manuscript object missing or changed');files.append(ref)
 for jid,item in accepted.items():
  e,j=item['event'],item['job'];tf=item['transport']['files'];p=e['payload'];receipt_raw=read(root,p['receipt']);object_equal(get,p['receipt'],receipt_raw);r=strict(receipt_raw)
  require(r.get('status')=='COMPLETE_LOCAL_PENDING_CANONICAL_ARCHIVE' and r.get('job_id')==jid and r.get('session_id')==e['session_id'] and not r.get('quality_flags'),'Accepted terminal metadata mismatch')
  for rf,jf in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:require(r.get(rf)==j[jf],'Accepted terminal input/config changed')
  require(j['model']=='gpt-6-astra' and j['effort']=='ultra' and j['service_tier']=='default','Unexpected scientific configuration')
  for field in ('prompt','schema'):
   rel=j[field+'_file'];expected=j[field+'_sha256'];require(rel in tf and tf[rel]['sha256']==expected,'Job input not transport-bound');canonical_read(root,tf[rel],get)
  bound_files={}
  for ref in p['files']:
   require(ref['path'] not in bound_files or bound_files[ref['path']]['sha256']==ref['sha256'],'Conflicting canonical result paths');bound_files[ref['path']]=ref
  require(p['receipt']['path'] in bound_files and p['native_check']['path'] in bound_files,'Accepted terminal/proof file list incomplete')
  for rel,digest in r['outputs'].items():require(rel in bound_files and bound_files[rel]['sha256']==digest,'Terminal output absent from accepted files')
  for ref in p['files']:
   require(path(root,ref['path']).is_relative_to(run/'results'/jid),'Result file outside own job')
   body=canonical_read(root,ref,get);files.append({'path':ref['path'],'sha256':ref['sha256'],'bytes':len(body)})
  proof=strict(read(root,p['native_check']));require(proof.get('session_id')==e['session_id'] and not proof.get('isolation_failures'),'Accepted native proof changed')
  require(p.get('capture_event_ids'),'Accepted native message coverage missing')
  for cid in p['capture_event_ids']:
   c=event(cid,'capture.coverage');require(c['run_id']==run.name and c['session_id']==e['session_id'] and c['payload']['status']=='BOUNDED_COMPLETE','Wrong scientific coverage');required_coverage.add(cid)
  for wid in p.get('web_event_ids',[]):require(event(wid,'research.verification.public_web_fragment')['session_id']==e['session_id'],'Wrong web fragment author')
  report_rows.append({'job_id':jid,'manuscript_id':j['manuscript_id'],'manuscript_sha256':manuscripts[j['manuscript_id']]['sha256'],'role':j['role'],'session_id':e['session_id'],'accepted_event_id':e['id'],'transport_event_id':item['transport']['event']['id'],'receipt':p['receipt'],'files':p['files'],'capture_event_ids':p['capture_event_ids'],'web_event_ids':p.get('web_event_ids',[])})
 # Coordinator artifacts are honest later synthesis, never reassigned reviews.
 arts=req['artifacts'];require(set(arts)=={'source_ledger','contribution_matrix','decision','cards','checkpoint_summary','protocol_note'},'Six explicit closure artifacts required')
 docs={k:strict(read(root,v)) for k,v in arts.items() if k!='protocol_note'};note=read(root,arts['protocol_note']).decode();require(BOUNDARY in note,'Protocol note must state exact API/authorship boundary')
 require(arts['protocol_note']['path']==str((run/'closure-preparation/PROTOCOL_NOTE.md').relative_to(root)),'Wrong protocol note')
 implementation=req['implementation_files'];needed={str((run/'closure-preparation'/n).relative_to(root)) for n in ('closure.py','test_closure.py','PROTOCOL_NOTE.md')}
 require({r['path'] for r in implementation}==needed and len(implementation)==3,'Exact implementation files required')
 for ref in implementation:read(root,ref)
 code=next(x for x in implementation if x['path'].endswith('/closure.py'));require(code['sha256']==sha(Path(__file__).read_bytes()),'Executing closure code is not request-bound')
 evs=req['coordinator_evidence_event_ids'];require(isinstance(evs,list) and evs and len(evs)==len(set(evs)),'Actual coordinator AI evidence required')
 for eid in evs:
  e=event(eid,'capture.raw_record');require(e['session_id']==req['session_id'] and e['run_id']==run.name and e['actor']['role'] in {'assistant','AI'},'Human/tool/foreign evidence cannot certify coordinator authorship')
 coverage=req['coverage_event_ids'];require(len(coverage)==len(set(coverage)) and required_coverage<=set(coverage),'All question/scientific coverage must be preserved')
 covered=set()
 for eid in coverage:
  e=event(eid,'capture.coverage');require(e['run_id']==run.name,'Coverage belongs to another run');covered.update(e['parents'])
 require(set(evs)<=covered,'Coordinator evidence lacks exact coverage')
 ledger=docs['source_ledger'];require(ledger.get('schema')=='verification-source-ledger.v1' and ledger.get('coordinator_session_id')==req['session_id'] and nonempty(ledger.get('access_boundary')),'Source ledger authorship/limits missing')
 require({x['job_id'] for x in ledger['reports']}=={j for j in wanted if j.endswith('-L')} and len(ledger['reports'])==10,'Source ledger must bind10L reports')
 for row in ledger['reports']:require(row['accepted_event_id']==accepted[row['job_id']]['event']['id'] and nonempty(row.get('retrieval_note')),'Source ledger attribution missing')
 matrix=docs['contribution_matrix'];require(matrix.get('schema')=='verification-matrix.v1' and matrix.get('coordinator_session_id')==req['session_id'],'Matrix must be coordinator synthesis')
 rows=matrix['manuscripts'];require(len(rows)==10 and {x['manuscript_id'] for x in rows}==set(manuscripts),'Matrix must cover all10 manuscripts')
 by={x['manuscript_id']:x for x in rows}
 for mid,row in by.items():
  m=manuscripts[mid];require(row.get('candidate_id')==m['candidate_id'] and row.get('manuscript_sha256')==m['sha256'],'Matrix version/candidate changed')
  require(row.get('review_event_ids')==[accepted[mid+'-A']['event']['id'],accepted[mid+'-L']['event']['id']],'Matrix must bind exact A/L pair')
  require(all(nonempty(row.get(k)) for k in ('situation_ru','surviving_contribution_ru','main_risk_ru')),'Every manuscript needs concrete contribution and risk')
  reasons=row.get('reason_ru');require(isinstance(reasons,list) and 2<=len(reasons)<=3 and all(nonempty(x) for x in reasons),'Each of10needs2–3clear reasons')
  require(isinstance(row.get('unresolved_blocking_defects'),list) and all(nonempty(x) for x in row['unresolved_blocking_defects']),'Explicit unresolved defects required')
  require(isinstance(row.get('reopen_conditions'),list) and row['reopen_conditions'] and all(nonempty(x) for x in row['reopen_conditions']),'Reopen conditions required')
 decision=docs['decision'];require(decision.get('schema')=='verification-decision.v1' and decision.get('coordinator_session_id')==req['session_id'] and decision.get('matrix_sha256')==arts['contribution_matrix']['sha256'],'Decision must bind exact coordinator matrix')
 primary=decision.get('primary');reserves=decision.get('reserves');require(isinstance(primary,list) and isinstance(reserves,list),'Explicit recommendation lists required')
 selected=primary+reserves;require(len(selected)==len(set(selected)) and set(selected)<=set(manuscripts) and len(primary)<=3 and len(reserves)<=2,'Invalid/duplicate recommendation')
 for mid in selected:require(not by[mid]['unresolved_blocking_defects'],'Cannot select a declared unresolved blocking defect')
 status=decision.get('recommendation_status');ready=status=='THREE_PLUS_TWO_READY'
 require((ready and len(primary)==3 and len(reserves)==2) or (status=='WITHHELD_FOR_DEFECTS' and nonempty(decision.get('withheld_reason_ru'))),'Do not force3+2or completion')
 require(decision.get('submission_authorized') is False and nonempty(decision.get('scope_note')),'No implied submission approval')
 cards=docs['cards'];require(cards.get('schema')=='verification-cards.v1' and cards.get('decision_sha256')==arts['decision']['sha256'],'Cards must bind exact decision')
 require(len(cards['cards'])==len(selected) and {x['manuscript_id'] for x in cards['cards']}==set(selected),'One card per selected manuscript')
 for card in cards['cards']:require(all(nonempty(card.get(k)) for k in ('essence_ru','what_is_new_ru','main_risk_ru','why_selected_ru')),'Four short substantive card fields required')
 summary=docs['checkpoint_summary'];require(all(nonempty(summary.get(k)) for k in FIELDS) and summary['outcome']=='CONTINUE','Honest CONTINUE administrative summary required')
 require(summary.get('legacy_api_boundary')==BOUNDARY,'Checkpoint must explain administrative INCOMPLETE')
 require(summary.get('finite_status')==('VERIFICATION_COMPLETE_BOUNDED' if ready else 'VERIFICATION_INCOMPLETE_RECOMMENDATION_WITHHELD'),'Summary cannot overclaim completion')
 checkpoints=[e for e in events if e['run_id']==run.name and e['kind']=='checkpoint']
 require(len(checkpoints)<=1,'Duplicate standard checkpoint')
 if checkpoints:
  cp=checkpoints[0];standard=[e for e in events if e['run_id']==run.name and e['kind']=='round.stage']
  require(cp['parents']==[first['id']]+[e['id'] for e in standard]+coverage and cp['outputs']==[arts['checkpoint_summary']['sha256']] and cp['payload'].get('summary')==summary and cp['payload'].get('capture_status')=='INCOMPLETE' and cp['payload'].get('truth_status')=='NOT_CERTIFIED','Existing checkpoint conflicts; preserve original')
 files+=list(arts.values())+implementation;unique={}
 for ref in files:
  body=read(root,ref);require(ref['path'] not in unique or unique[ref['path']]==ref,'Conflicting file descriptors');unique[ref['path']]=ref
 existing_intakes=[e for e in events if e['run_id']==run.name and e['kind']=='research.verification.closure.inputs']
 require(len(existing_intakes)<=1 and all(e['payload'].get('request')==request_ref for e in existing_intakes),'Existing closure belongs to a different request; preserve it')
 for filename,kind in [('FINAL_RECEIPT.json','research.verification.completed'),('WITHHELD_RECEIPT.json','research.verification.recommendation_withheld')]:
  local=run/filename
  if local.exists():
   local=path(root,str(local.relative_to(root)));receipt=strict(local.read_bytes());terminal=event(receipt.get('event_id'),kind)
   require(existing_intakes and terminal['run_id']==run.name and terminal['payload'].get('decision')==arts['decision'] and terminal['payload'].get('cards')==arts['cards'] and receipt.get('status')==terminal['payload']['status'],'Existing terminal receipt conflicts; preserve it')
   keys=('status','scientific_results_accepted','question_stage_event_id','typed_stage_event_ids','administrative_checkpoint_event_id','decision','cards','primary','reserves','submission_authorized','boundary')
   require(receipt==dict(event_id=terminal['id'],**{k:terminal['payload'][k] for k in keys}),'Existing terminal receipt differs from canonical payload')
 return {'request':req,'request_ref':request_ref,'start':start,'first':first,'question':question,'input_event':inputs,'transport_event':te,'transport_events':[transports[v]['event'] for v in (3,4)],'artifacts':arts,'documents':docs,'reports':report_rows,'files':list(unique.values()),'coverage':coverage,'coordinator_evidence':evs,'ready':ready,'known':known,'boundary':BOUNDARY}

def close_with_writer(root,run,request_ref,w,*,allow_checkpoint_derived_updates=False,checkpoint_api=None):
 root=Path(root).absolute();run=Path(run).absolute();w._ensure_audited()
 # All validation before any object or event write.
 data=preflight(root,run,request_ref,w._state['records'],w.get);req=data['request'];known=data['known']
 require(allow_checkpoint_derived_updates is True,'Explicit standard checkpoint derived-update flag required')
 def event(kind,parents,outputs,payload):return {'kind':kind,'actor':{'id':'verification-closure-adapter','role':'tool'},'session_id':req['session_id'],'run_id':run.name,'operation_id':run.name,'attempt_id':'multi-session-closure-v1','bindings':data['first']['bindings'],'parents':list(dict.fromkeys(parents)),'outputs':list(dict.fromkeys(outputs)),'payload':payload}
 def append(kind,key,parents,outputs,payload):return w.append(event(kind,parents,outputs,payload),run.name+':closure:'+key+':v1')
 for ref in data['files']:require(w.put(read(root,ref))==ref['sha256'],'Object write mismatch')
 parent_ids=[data['input_event']['id']]+[e['id'] for e in data['transport_events']]+[r['accepted_event_id'] for r in data['reports']]+data['coordinator_evidence']
 intake=append('research.verification.closure.inputs','inputs',parent_ids,[r['sha256'] for r in data['files']],{'request':request_ref,'files':data['files'],'status':'CLOSURE_INPUTS_BOUND','boundary':BOUNDARY})
 stages={};previous=data['question']['id'];arts=data['artifacts']
 for stage in STAGES:
  reports=[r for r in data['reports'] if stage!='sources' or r['role']=='literature']
  selected_files={'sources':[arts['source_ledger']],'contribution':[arts['contribution_matrix']],'critique':[],'decision':[arts['decision'],arts['cards']]}[stage]
  payload={'stage':stage,'files':selected_files,'per_item_attribution':reports,'coordinator_evidence_event_ids':data['coordinator_evidence'] if stage!='critique' else [],'artifact_author':'AI coordinator compilation/decision' if stage!='critique' else 'Mechanical index of separately authored accepted manuscript critiques','new_scientific_roles':0,'boundary':BOUNDARY}
  if stage=='critique':payload['review_target']='Frozen manuscripts only; no independent review of later coordinator synthesis claimed'
  result=append('research.verification.stage','stage-'+stage,[intake['id'],previous]+[r['accepted_event_id'] for r in reports],[x['sha256'] for x in selected_files],payload);stages[stage]=result['id'];previous=result['id']
 # Use standard API once. Its incomplete terminal is intentional and explained.
 existing=[e for e in w._state['records'] if e['run_id']==run.name and e['kind']=='research.verification.checkpoint_api_returned']
 require(len(existing)<=1,'Duplicate checkpoint return marker')
 if not existing:
  if checkpoint_api is None:
   sys.path.insert(0,str(root/'scripts'));from philosophy_round import checkpoint as checkpoint_api
  cp=checkpoint_api(root,w,run.name,arts['checkpoint_summary']['path'],data['coverage'],incomplete=True)
  terminals=[e for e in w._state['records'] if e['kind']=='operation.interrupted' and e['run_id']==run.name and e['payload'].get('checkpoint')==cp['id']]
  require(len(terminals)==1,'Standard administrative terminal missing')
  marker=append('research.verification.checkpoint_api_returned','checkpoint-api',[cp['id'],terminals[0]['id'],intake['id']],[arts['checkpoint_summary']['sha256']],{'request_sha256':request_ref['sha256'],'checkpoint_event_id':cp['id'],'boundary':BOUNDARY})
 else:
  marker=existing[0];require(marker['payload']['request_sha256']==request_ref['sha256'],'Checkpoint belongs to different request');cp=next(e for e in w._state['records'] if e['id']==marker['payload']['checkpoint_event_id'])
 require(cp['payload'].get('capture_status')=='INCOMPLETE' and cp['payload'].get('truth_status')=='NOT_CERTIFIED' and cp['outputs']==[arts['checkpoint_summary']['sha256']] and cp['payload']['summary']==data['documents']['checkpoint_summary'],'Standard checkpoint mismatch')
 final_status='VERIFICATION_COMPLETE_BOUNDED' if data['ready'] else 'VERIFICATION_INCOMPLETE_RECOMMENDATION_WITHHELD'
 final=append('research.verification.completed' if data['ready'] else 'research.verification.recommendation_withheld','finite-result',[intake['id'],marker['id'],cp['id']]+list(stages.values())+[r['accepted_event_id'] for r in data['reports']],[arts[k]['sha256'] for k in ('contribution_matrix','decision','cards','checkpoint_summary')],{'status':final_status,'scientific_results_accepted':20,'new_scientific_roles':0,'typed_stage_event_ids':stages,'question_stage_event_id':data['question']['id'],'administrative_checkpoint_event_id':cp['id'],'administrative_capture_status':'INCOMPLETE','decision':arts['decision'],'cards':arts['cards'],'primary':data['documents']['decision']['primary'],'reserves':data['documents']['decision']['reserves'],'submission_authorized':False,'boundary':BOUNDARY})
 receipt={'status':final_status,'event_id':final['id'],'scientific_results_accepted':20,'question_stage_event_id':data['question']['id'],'typed_stage_event_ids':stages,'administrative_checkpoint_event_id':cp['id'],'decision':arts['decision'],'cards':arts['cards'],'primary':data['documents']['decision']['primary'],'reserves':data['documents']['decision']['reserves'],'submission_authorized':False,'boundary':BOUNDARY}
 save_once(run/('FINAL_RECEIPT.json' if data['ready'] else 'WITHHELD_RECEIPT.json'),encode(receipt));return receipt

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,required=True);p.add_argument('--allow-checkpoint-derived-updates',action='store_true');p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[3]);p.add_argument('--run-dir',type=Path,default=Path(__file__).resolve().parent.parent);a=p.parse_args()
 root=a.root.absolute();run=a.run_dir.absolute();request=a.request.absolute();require(request.is_relative_to(run),'Request outside run')
 sys.path.insert(0,str(root/'scripts'));from research_archive import Archive
 with Archive(root/'research/archive').writer() as w:result=close_with_writer(root,run,desc(root,request),w,allow_checkpoint_derived_updates=a.allow_checkpoint_derived_updates)
 print(json.dumps({'status':result['status'],'event_id':result['event_id']},ensure_ascii=False))
if __name__=='__main__':main()
