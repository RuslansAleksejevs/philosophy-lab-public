"""Observed native text-block normalization; all role/AST/source limits retained."""
from web_transport_v3 import *

STDOUT_POLICY = json.loads((Path(__file__).resolve().parent / 'transport-repair-v4/STDOUT_NATIVE_AUTHORITY_POLICY.json').read_bytes())


def normalize_output(value):
    if isinstance(value, str): return credential_safe(value)
    require(isinstance(value, list) and 1 <= len(value) <= 16, 'Unsupported public web output shape')
    texts = []
    for block in value:
        require(isinstance(block, dict) and set(block) == {'type','text'}
                and block['type'] == 'input_text' and isinstance(block['text'],str), 'Unsupported public web text block')
        texts.append(block['text'])
    # Preserve all visible blocks in order; retain the existing combined 2MiB
    # bound and credential scan. No images/files/native envelopes are allowed.
    return credential_safe('\n'.join(texts))
