"""Synthetic public projection/acceptance tests; no real source or model calls."""
from pathlib import Path
import ast,copy,importlib.util,json,sys,tempfile,unittest,urllib.parse
from unittest.mock import patch
HERE=Path(__file__).parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=module('projection_adapter_under_test',HERE/'archive_progress_v5.py')
fixtures=module('projection_base_fixtures',HERE/'test_archive_progress_v4.py')
policy=module('projection_policy_under_test',HERE/'archive-repair-v4/signed_url_projection.py')
class ProjectionAdapterTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.ctx,self.path,self.proof,self.visible=fixtures.Tests.terminal_fixture(self)
  self.ctx['scientific_ids']={'JOB'};self.ctx['jobs']['JOB']['role']='literature';self.ctx['projection_policy']=policy
  m=self.ctx['run']/'manifest.json';m.write_text('{}');self.ctx['projection_manifest_path']=m
  query={'AWSAccessKeyId':'ASIA'+'A'*16,'Expires':'1772249332','Signature':'YWFhYWFhYWFhYWFhYWFhYWFhYWE=','x-amz-security-token':'YWFh'*30}
  self.url='https://synthetic-bucket.s3.eu-west-1.amazonaws.com/book/preview.pdf?'+urllib.parse.urlencode(query)
  self.web={'line':3,'record_sha256':'d'*64,'role':'tool','type':'public_web_output','call_id':'synthetic-call','status':'completed','text':'Public source '+self.url+' retained prose'}
  self.proof['public_web_calls']=[self.web];self.visible.insert(1,copy.deepcopy(self.web));self.resave()
 def tearDown(self):self.tmp.cleanup()
 def resave(self):
  (self.path.parent/'native-check.json').write_bytes(p.encoded(self.proof));(self.path.parent/'native-visible.json').write_bytes(p.encoded({'session_id':self.proof['session_id'],'records':self.visible}))
  receipt=p.load(self.path,self.root);receipt['outputs']={str(f.relative_to(self.root)):p.sha(f.read_bytes()) for f in self.path.parent.iterdir() if f!=self.path};self.path.write_bytes(p.encoded(receipt))
 def project(self,write=False):return p.project_result(self.ctx,'JOB',self.path,{'id':'synthetic-policy'},write=write)
 def test_native_replay_precedes_projection_and_mismatch_stops(self):
  self.ctx['runner'].inspect_native=lambda *a,**kw:(dict(self.proof,unexpected='change'),self.visible,[self.visible[-1]])
  with patch.object(policy,'project_pair',side_effect=AssertionError('Projection must not run')):
   with self.assertRaises(ValueError):self.project()
 def test_original_byte_hash_change_rejected_before_projection(self):
  (self.path.parent/'native-check.json').write_text('{}')
  with self.assertRaises(ValueError):self.project()
 def test_public_copies_withhold_both_originals_and_keep_final_exact(self):
  before={x.name:x.read_bytes() for x in self.path.parent.iterdir()};r=self.project()
  self.assertEqual({x.name:x.read_bytes() for x in self.path.parent.iterdir()},before)
  self.assertFalse((self.path.parent.parent/'archive-projection-v1').exists());side=r['projection'];self.assertEqual(side['ledger']['omitted_url_count'],1)
  withheld={x['path']:x['sha256'] for x in side['withheld_originals']};self.assertEqual(len(withheld),2)
  self.assertTrue(set(withheld).isdisjoint(x['path'] for x in r['files']));self.assertTrue(set(withheld).isdisjoint(r['receipt']['outputs']))
  self.assertIn(str(self.path.relative_to(self.root)),r['receipt']['outputs']);self.assertEqual(r['value'],json.loads(before['response.json']))
  for name in ('response.json','final.txt'):
   rel=str((self.path.parent/name).relative_to(self.root));self.assertEqual(r['receipt']['outputs'][rel],p.sha(before[name]))
  self.assertFalse(p.B.contains_credential(r['proof']));self.assertFalse(p.B.contains_credential(r['projection']))
 def test_idempotent_public_writes_preserve_partial_results(self):
  r=self.project(write=True);d=r['receipt_path'].parent;before={x.name:x.read_bytes() for x in d.iterdir()};again=self.project(write=True)
  self.assertEqual({x.name:x.read_bytes() for x in d.iterdir()},before);self.assertEqual(again['receipt'],r['receipt'])
  (d/'native-check.json').write_text('{}')
  with self.assertRaises(ValueError):self.project(write=True)
  self.assertEqual((d/'native-check.json').read_text(),'{}')
 def test_scientific_response_or_prompt_context_is_not_redacted(self):
  (self.path.parent/'response.json').write_bytes(p.encoded({'secret_url':self.url}));self.resave()
  with patch.object(policy,'project_pair',side_effect=AssertionError('Scientific body is not an eligible redaction context')):
   with self.assertRaises(ValueError):self.project()
 def test_assistant_visible_url_is_not_redacted(self):
  self.visible[-1]['text']=json.dumps({'url':self.url});self.resave()
  with self.assertRaises(ValueError):self.project()
 def test_foreign_host_keeps_hard_stop(self):
  bad=self.web['text'].replace('synthetic-bucket.s3.eu-west-1.amazonaws.com','foreign.example');self.web['text']=bad;self.visible[1]['text']=bad;self.resave()
  with self.assertRaises(ValueError):self.project()
 def test_changed_final_or_configuration_cannot_be_rescued(self):
  (self.path.parent/'final.txt').write_text('{"verdict":"changed"}');self.resave()
  with self.assertRaises(ValueError):self.project()
 def test_only_one_unsafe_copy_is_not_accepted(self):
  self.visible[1]['text']='safe replacement';self.resave()
  with self.assertRaises(ValueError):self.project()
 def test_original_response_must_be_bound_before_projection(self):
  receipt=p.load(self.path,self.root);del receipt['outputs'][str((self.path.parent/'response.json').relative_to(self.root))];self.path.write_bytes(p.encoded(receipt))
  with patch.object(policy,'project_pair',side_effect=AssertionError('Unbound scientific response must not be projected')):
   with self.assertRaisesRegex(ValueError,'scientific response is not bound'):self.project()
 def test_manifest_privacy_is_checked_before_any_bound_file(self):
  repair=self.ctx['run']/'archive-repair-v4';repair.mkdir();manifest=repair/'SAFE_WEB_PROJECTION_MANIFEST.json'
  manifest.write_bytes(p.encoded({'status':'SAFE_WEB_PROJECTION_PREPARED','files':[],'unsafe':self.url}))
  with patch.object(p.B,'setup',return_value=self.ctx),patch.object(p,'bound',side_effect=AssertionError('Unsafe manifest must stop before source reads')):
   with self.assertRaises(ValueError):p.setup(self.root,self.ctx['run'])
 def test_all_projection_child_symlinks_fail_before_any_write(self):
  d=self.path.parent.parent/'archive-projection-v1';target=self.ctx['run']/'untouched-target';target.write_text('untouched')
  for name in ('native-check.json','native-visible.json','PROJECTION.json','receipt.json'):
   with self.subTest(name=name):
    d.mkdir();(d/name).symlink_to(target)
    with patch.object(p.B,'save_new',side_effect=AssertionError('All destinations must be checked before first write')):
     with self.assertRaisesRegex(ValueError,'file is a symlink'):self.project(write=True)
    self.assertEqual(target.read_text(),'untouched');self.assertEqual([x.name for x in d.iterdir()],[name]);(d/name).unlink();d.rmdir()
 def test_top_level_unexpected_validation_error_preserves_new_stop(self):
  tree=ast.parse((HERE/'archive_progress_v5.py').read_text());guard=tree.body[-1];self.assertIsInstance(guard,ast.If)
  def fail():raise TypeError('synthetic unexpected shape')
  context={'__name__':'__main__','main':fail,'sys':sys,'B':p.B,'LIVE_MODE':True,'RUN':self.ctx['run'],'NEW_STOP':p.NEW_STOP,'json':json}
  with patch('builtins.print'),self.assertRaises(SystemExit) as caught:exec(compile(ast.Module(body=[guard],type_ignores=[]),'adapter_entry_guard','exec'),context)
  self.assertEqual(caught.exception.code,2);stop=p.load(self.ctx['run']/p.NEW_STOP,self.root)
  self.assertEqual(stop['status'],'STOPPED_PRESERVED');self.assertEqual(stop['error_type'],'TypeError');self.assertFalse(stop['automatic_retry'])
 def test_top_level_does_not_swallow_baseexception(self):
  tree=ast.parse((HERE/'archive_progress_v5.py').read_text())
  def interrupt():raise KeyboardInterrupt()
  context={'__name__':'__main__','main':interrupt,'sys':sys,'B':p.B,'LIVE_MODE':True,'RUN':self.ctx['run'],'NEW_STOP':p.NEW_STOP,'json':json}
  with self.assertRaises(KeyboardInterrupt):exec(compile(ast.Module(body=[tree.body[-1]],type_ignores=[]),'adapter_entry_guard','exec'),context)
  self.assertFalse((self.ctx['run']/p.NEW_STOP).exists())
 def test_safe_originals_delegate_to_frozen_v4_without_projection(self):
  self.web['text']='safe public source';self.visible[1]['text']='safe public source';self.resave()
  sentinel={'marker':'frozen V4'}
  with patch.object(p.B,'validate_terminal',return_value=sentinel) as check:
   r,pr=p.original_result(self.ctx,'JOB',self.path)
  self.assertIs(r,sentinel);self.assertIsNone(pr);check.assert_called_once()
 def test_acceptance_never_puts_unsafe_original_bytes(self):
  archive=p.B.Archive(self.root/'research/archive').init();sid=self.proof['session_id'];stored=[]
  def ev(kind,sid='coordinator',payload=None,parents=()):return {'kind':kind,'session_id':sid,'run_id':self.ctx['run'].name,'actor':{'id':'synthetic','role':'tool'},'operation_id':'synthetic','attempt_id':'synthetic','parents':list(parents),'payload':payload or {}}
  with archive.writer() as w:
   start=w.append(ev('research.verification.inputs.accepted'),'start');transport=w.append(ev('research.verification.transport_v4.accepted'),'transport');policy_event=w.append(ev(p.EVENT),'policy')
   self.ctx['start']={'event_id':start['id'],'bindings':{k:[] for k in ('method','instruction','config','input')}}
   source_map={x['line']:x for x in self.visible if x.get('role')!='tool'}
   def capture(*a,**kw):
    line=kw['start_line'];e=w.append(ev('capture.coverage',sid,{'status':'BOUNDED_COMPLETE'}),'coverage:'+str(line))
    return {'status':'BOUNDED_COMPLETE','captured_records':1,'raw_records':[{'sha256':source_map[line]['record_sha256']}],'coverage_event_id':e['id']}
   original_put=w.put
   def put(raw):stored.append(raw);return original_put(raw)
   with patch.object(w,'put',side_effect=put),patch.object(p.B,'require_smoke'),patch.object(p.B,'require_original_arguments'),patch.object(p.B,'resolve_session',return_value=Path('unused')),patch.object(p.B,'capture',side_effect=capture):
    result=p.accept_job(self.ctx,w,transport,policy_event,'JOB',self.path)
   self.assertNotIn(self.url.encode(),b''.join(stored));self.assertFalse(any(p.B.contains_credential(raw.decode()) for raw in stored))
   old={p.sha((self.path.parent/n).read_bytes()) for n in ('native-check.json','native-visible.json')};self.assertTrue(old.isdisjoint(result['outputs']));self.assertTrue(old.isdisjoint(w._state['present']))
   self.assertIn(policy_event['id'],result['parents']);self.assertIn('archive_projection',result['payload']);self.assertEqual(result['payload']['job_id'],'JOB')
   count=len(w._state['records'])
   with patch.object(p,'project_result',side_effect=AssertionError('Accepted originals must not be reprojected')):
    reused=p.accept_job(self.ctx,w,transport,policy_event,'JOB',self.path)
   self.assertEqual(reused['id'],result['id']);self.assertEqual(len(w._state['records']),count)
if __name__=='__main__':unittest.main()
