'use strict';
// Parse only. Never evaluate submitted JavaScript.
const acorn = require('./acorn.cjs');
function requireShape(condition) { if (!condition) throw Error('Unsupported public web wrapper syntax'); }
function literal(node) {
  if(node.type==='Literal') {
    requireShape(!node.regex && !node.bigint && (node.value===null || ['string','boolean','number'].includes(typeof node.value)));
    requireShape(typeof node.value!=='number' || Number.isFinite(node.value)); return node.value;
  }
  if(node.type==='ArrayExpression') return node.elements.map(x=>{requireShape(x);return literal(x);});
  requireShape(node.type==='ObjectExpression');
  const result=Object.create(null);
  for(const prop of node.properties) {
    requireShape(prop.type==='Property' && prop.kind==='init' && !prop.method && !prop.computed && !prop.shorthand);
    const key=prop.key.type==='Identifier'?prop.key.name:prop.key.type==='Literal'&&typeof prop.key.value==='string'?prop.key.value:null;
    requireShape(key!==null && !['__proto__','prototype','constructor'].includes(key) && !Object.hasOwn(result,key));
    result[key]=literal(prop.value);
  }
  return result;
}
function parse(code) {
  requireShape(typeof code==='string' && code.length<=100000);
  const body=acorn.parse(code,{ecmaVersion:'latest',sourceType:'module'}).body;
  requireShape(body.length===2);
  const declaration=body[0];
  requireShape(declaration.type==='VariableDeclaration' && declaration.kind==='const' && declaration.declarations.length===1);
  const binding=declaration.declarations[0];
  requireShape(binding.id.type==='Identifier' && binding.init?.type==='AwaitExpression');
  const call=binding.init.argument, callee=call.callee;
  requireShape(call.type==='CallExpression' && !call.optional && call.arguments.length===1 &&
    callee.type==='MemberExpression' && !callee.computed && !callee.optional &&
    callee.object.type==='Identifier' && callee.object.name==='tools' &&
    callee.property.type==='Identifier' && callee.property.name==='web__run');
  const output=body[1];
  requireShape(output.type==='ExpressionStatement' && output.expression.type==='CallExpression' &&
    !output.expression.optional && output.expression.callee.type==='Identifier' && output.expression.callee.name==='text' &&
    output.expression.arguments.length===1 && output.expression.arguments[0].type==='Identifier' &&
    output.expression.arguments[0].name===binding.id.name);
  return literal(call.arguments[0]);
}
if(require.main===module) {
  let raw='';process.stdin.setEncoding('utf8');process.stdin.on('data',x=>{raw+=x;if(raw.length>1000000)process.exit(2);});
  process.stdin.on('end',()=>{try{process.stdout.write(JSON.stringify(parse(JSON.parse(raw).code)));}
    catch(error){process.stderr.write('Public web wrapper rejected\n');process.exitCode=2;}});
}
module.exports={parse};
