# Version 2: bounded technical transport repair

The first technical SMOKE-L remains `FAILED_PRESERVED_NO_RETRY`; its attempt,
original STOP, runner, tests, queues and canonical input receipt remain unchanged.
The excluded stdout body was not retained, so its exact format is UNKNOWN.
Null/absent actions in started/updated web items are handled as pending metadata;
they do not establish a completed search/open.

The observed native technical call was a `custom_tool_call`, name `exec`, whose
visible input (after credential scan) contained one awaited `tools.web__run`
literal call and `text(result)`. Version 2 parses that narrow grammar with a
frozen bundled Acorn parser. It never evaluates the wrapper. Other code, shell,
MCP, collaboration calls, local URLs and credential-shaped content are rejected.
Outputs must be bounded visible strings paired with that exact call ID.
Unknown stdout structures cause a new stop and retain only known field names
and value types, without unknown bodies.

The observed `additional_tools` declaration is accepted only when its tool-list
SHA, role and structure match exactly. Only its hash and namespace names enter
the proof. Declaration bodies and hidden reasoning are not exported.

## Immutable inputs and canonical gate

`TRANSPORT_V2_MANIFEST.json` binds original and revised code, tests, queues,
prompts, schemas, helper/parser sources, the original failed smoke and STOP,
`STOP_DISPOSITION_V2.json`, and the reviewed archive adapter. The immutable
`PROMPT_AMENDMENT.json` records ten literature prompts that differ only by
appending the exact neutral `TRANSPORT_INSTRUCTION.txt` bytes. The ten argument
job dictionaries and all twenty manuscript versions remain unchanged.

Root owns canonical acceptance. `archive_progress.py` accepts only the exact
manifest selected by `TRANSPORT_V2_ARCHIVE_READY.json`:

```json
{"status":"READY_FOR_CANONICAL_TRANSPORT_V2_ACCEPTANCE","manifest_sha256":"EXACT_MANIFEST_SHA256"}
```

It then writes `TRANSPORT_V2_START_RECEIPT.json`:

```json
{"status":"DEEP_VERIFICATION_TRANSPORT_V2_ARCHIVED","event_id":"CANONICAL_EVENT_ID","files":[{"path":"PROJECT_RELATIVE_FILE","sha256":"EXACT_SHA256"}]}
```

The files list contains every manifest input plus the manifest itself. Version 2
refuses the original start receipt as its gate. After successful acceptance it
disposes only the exact hash-bound prior STOP. New failures write `STOP_V2.json`;
the original STOP is never deleted or overwritten. The shared dispatch lock
prevents concurrent old/new dispatchers.

## Finished argument output: no rerun

After canonical transport acceptance, root may run:

```sh
python3 -B runs/deep-verification-20261031/revalidate_existing.py --ids V01-A V02-A
```

Each named job must already have finished cleanly with only the declaration
classification failure. The helper replays native evidence, checks the original
prompt/configuration and exact final/schema, and writes a separate
`results/JOB/revalidation-v2/` receipt/proof/response. The original attempt and
failure remain byte-identical. No provider is called. The archive adapter
independently replays this evidence before accepting it.

## Fresh technical smoke, then the remaining original jobs

After the old dispatcher has ended and canonical transport acceptance exists:

```sh
python3 -B runs/deep-verification-20261031/runner_v2.py --workers 1 --ids SMOKE-L2
```

SMOKE-L2 is a new technical probe with the same public-document task and a new
ID/schema/prompt binding. It is not a scientific rerun. Unknown runtime formats
still stop; live success is not claimed by synthetic tests or this preparation.

Scientific literature jobs also require `WEB_SMOKE_ACCEPTED.json` containing:
`status=WEB_SMOKE_ACCEPTED`, canonical `event_id`, `job_id=SMOKE-L2`, its exact
`session_id`, `receipt` and `native_check` path/SHA references, and
`verified_completed_public_web_action=true`. The archive adapter verifies a
completed official-page open with matching visible title/URL, not merely a
started call. Root then dispatches only the remaining unstarted scientific
IDs. Existing attempts are preserved and never automatically retried.

All requested settings remain Astra/ultra/default, ChatGPT subscription, fresh
sessions and no automatic retry. These tools do not submit essays or alter them.
