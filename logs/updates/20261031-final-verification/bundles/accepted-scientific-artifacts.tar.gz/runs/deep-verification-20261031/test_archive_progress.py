"""Synthetic tests only: no live archive, source or provider is accessed."""
import copy, importlib.util, json
from pathlib import Path
import tempfile, unittest, types
from unittest.mock import patch
SPEC=importlib.util.spec_from_file_location('progress',Path(__file__).with_name('archive_progress.py'))
p=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(p)

def event(sid='target-session',run='other-run',kind='test.fixture',attempt='fixture'):
 return {'kind':kind,'actor':{'id':'test','role':'tool'},'session_id':sid,'run_id':run,'operation_id':'fixture','attempt_id':attempt,'payload':{}}
def line(payload,kind='response_item'):
 return (json.dumps({'timestamp':'2026-10-31T00:00:00Z','ordinal':0,'type':kind,'payload':payload})+'\n').encode()

class Tests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve()
 def tearDown(self):self.tmp.cleanup()
 def identify(self):
  (self.root/'.lab').mkdir();(self.root/'LAB_PROFILE.json').write_text('{"lab":{"kind":"PHILOSOPHY_PROGRAM"}}')
  (self.root/'.lab/philosophy.json').write_text('{"schema_version":1,"kernel":"philosophy.v1","archive_format":"research-archive.v1"}')
 def test_session_scope_keeps_all_same_sid_and_run_inputs_and_updates(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   one=w.append(event(),'one');other=w.append(event('other-session'),'other');binding=w.append(event('coordinator','run-active'),'binding')
   s=p.SessionWriter(w,'target-session','run-active');rows=s.events();self.assertEqual({e['id'] for e in rows},{one['id'],binding['id']})
   rows[0]['payload']['tamper']=True;self.assertNotIn('tamper',s.events()[0]['payload'])
   later=s.append(event(),'later');self.assertIn(later['id'],{e['id'] for e in s.events()});self.assertNotIn(other['id'],{e['id'] for e in s.events()})
  with self.assertRaises(p.ArchiveError):s.events()
 def test_standard_capture_reuse_and_source_conflict_under_one_audit(self):
  self.identify();sid='synthetic-session-0001';src=self.root/'native.jsonl'
  head=line({'id':sid,'cwd':str(self.root),'base_instructions':'HIDDEN_SENTINEL'},'session_meta')
  msg=line({'type':'message','role':'assistant','phase':'final_answer','content':[{'type':'output_text','text':'Visible final'}]})
  src.write_bytes(head+msg);a=p.Archive(self.root/'research/archive').init()
  with patch.object(a,'_audit',wraps=a._audit) as audit:
   with a.writer() as w:
    scope=p.SessionWriter(w,sid,'run-active')
    one=p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
    two=p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
    self.assertEqual(one['raw_event_ids'],two['raw_event_ids']);self.assertEqual(audit.call_count,1)
    self.assertFalse(any('HIDDEN_SENTINEL' in w.get(h).decode() for h in w._state['present']))
    src.write_bytes(head+msg.replace(b'Visible final',b'Conflicting final'))
    with self.assertRaises(p.ArchiveError):p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
 def test_scoped_duplicate_global_id_and_delivery_conflicts_remain_global(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   e=w.append(event('foreign'),'same-key');scope=p.SessionWriter(w,'target-session','run-active')
   with self.assertRaises(p.ArchiveError):scope.append(event(),'same-key')
 def test_scoped_duplicate_id_conflicts_with_foreign_session(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   e=w.append(dict(event('foreign'),id='event-fixed-identity'),'foreign-key');scope=p.SessionWriter(w,'target-session','run-active')
   with self.assertRaises(p.ArchiveError):scope.append(dict(event(),id=e['id']),'new-key')
 def test_safe_web_rejects_raw_exec_and_hidden_body(self):
  r={'line':2,'record_sha256':'a'*64,'role':'tool','type':'public_web_call','call_id':'call1','actions':[{'open':[{'ref_id':'https://developers.openai.com/codex/noninteractive'}]}],'status':'issued'}
  self.assertEqual(p.safe_web(r),r)
  with self.assertRaises(ValueError):p.safe_web(dict(r,input='hidden exec body'))
  with self.assertRaises(ValueError):p.safe({'type':'reasoning','text':'hidden'},'fixture')
 def test_smoke_requires_real_completed_matching_official_page(self):
  value={'read_complete':True,'source_access_status':'OPENED','url':'https://developers.openai.com/codex/noninteractive','page_title':'Non-interactive mode'}
  call={'type':'public_web_call','call_id':'a','actions':[{'type':'open','ref_id':value['url']}]}
  out={'type':'public_web_output','call_id':'a','status':'completed','text':value['url']+'\n'+value['page_title']}
  self.assertTrue(p.official_smoke({'public_web_calls':[call,out]},value))
  for proof in [{'public_web_calls':[call]}, {'public_web_calls':[call,dict(out,status='failed')]}, {'public_web_calls':[call,dict(out,text='Failed to fetch '+out['text'])]}]:
   with self.assertRaises(ValueError):p.official_smoke(proof,value)
  with self.assertRaises(ValueError):p.official_smoke({'public_web_calls':[call,out]},dict(value,url='https://example.org'))
 def test_prefers_revalidation_without_replacing_attempt(self):
  d=self.root/'results/JOB';(d/'attempt-001').mkdir(parents=True);(d/'attempt-001/receipt.json').write_text('{}')
  ctx={'run':self.root};self.assertEqual(p.terminal_path(ctx,'JOB').parent.name,'attempt-001')
  (d/'revalidation-v2').mkdir();(d/'revalidation-v2/receipt.json').write_text('{}')
  self.assertEqual(p.terminal_path(ctx,'JOB').parent.name,'revalidation-v2');self.assertTrue((d/'attempt-001/receipt.json').exists())
 def test_descriptor_rejects_drift_and_symlink(self):
  f=self.root/'f.json';f.write_text('{}');d=p.descriptor(f,self.root);self.assertEqual(p.bound(d,self.root),b'{}')
  f.write_text('{"changed":true}')
  with self.assertRaises(ValueError):p.bound(d,self.root)
  link=self.root/'link';link.symlink_to(f)
  with self.assertRaises(ValueError):p.regular(link,self.root)
 def test_duplicate_receipt_not_overwritten(self):
  f=self.root/'r.json';p.save_new(f,{'event_id':'a'});p.save_new(f,{'event_id':'a'})
  with self.assertRaises(ValueError):p.save_new(f,{'event_id':'b'})
  self.assertEqual(json.loads(f.read_bytes()),{'event_id':'a'})
 def test_only_exact_bound_neutral_literature_appendix_allowed(self):
  a=self.root/'old.txt';b=self.root/'new.txt';a.write_bytes(b'Frozen manuscript and task');b.write_bytes(a.read_bytes()+b'\n\nNeutral transport only\n')
  old={'role':'literature','model':'gpt-6-astra','prompt_file':'old.txt','prompt_sha256':p.sha(a.read_bytes())}
  new=dict(old,prompt_file='new.txt',prompt_sha256=p.sha(b.read_bytes()))
  p.job_transition(old,new,b'\n\nNeutral transport only\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(old,dict(new,model='other'),b'\n\nNeutral transport only\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(old,new,b'Different transport\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(dict(old,role='argument'),dict(new,role='argument'),b'\n\nNeutral transport only\n',self.root)
 def terminal_fixture(self):
  run=self.root/'run';attempt=run/'results/JOB/attempt-001';attempt.mkdir(parents=True);sid='synthetic-session-0001'
  prompt=run/'prompt.txt';prompt.write_text('Neutral prompt');schema=run/'schema.json';schema.write_text('{"type":"object"}')
  job={'id':'JOB','role':'argument','model':'gpt-6-astra','effort':'ultra','service_tier':'default','prompt_file':'run/prompt.txt',
       'prompt_sha256':p.sha(prompt.read_bytes()),'schema_file':'run/schema.json','schema_sha256':p.sha(schema.read_bytes())}
  proof={'session_id':sid,'isolation_failures':[]};visible=[{'line':2,'record_sha256':'a'*64,'role':'user','text':'Neutral prompt'},
     {'line':4,'record_sha256':'b'*64,'role':'assistant','phase':'final_answer','text':'{"verdict":"pass"}'}]
  for name,value in [('native-check.json',proof),('native-visible.json',{'session_id':sid,'records':visible}),('response.json',{'verdict':'pass'})]:(attempt/name).write_bytes(p.encoded(value))
  receipt={'job_id':'JOB','status':p.COMPLETE,'session_id':sid,'quality_flags':[],
   'prompt_sha256':job['prompt_sha256'],'schema_sha256':job['schema_sha256'],'requested_model':job['model'],
   'requested_effort':'ultra','requested_service_tier':'default','outputs':{str(f.relative_to(self.root)):p.sha(f.read_bytes()) for f in attempt.iterdir()}}
  path=attempt/'receipt.json';path.write_bytes(p.encoded(receipt))
  runner=types.SimpleNamespace(check_inputs=lambda *args:None,inspect_native=lambda *args:(proof,visible,[visible[-1]]),validate=lambda *args:None)
  return {'root':self.root,'run':run,'runner':runner,'jobs':{'JOB':job}},path,proof,visible
 def test_terminal_independent_native_replay_and_output_hash_gate(self):
  ctx,path,proof,visible=self.terminal_fixture();result=p.validate_terminal(ctx,'JOB',path);self.assertEqual(len(result['messages']),2)
  ctx['runner'].inspect_native=lambda *args:(dict(proof,isolation_failures=['bad']),visible,[visible[-1]])
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
  (path.parent/'response.json').write_text('{"verdict":"different"}')
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
 def test_terminal_rejects_wrong_configuration_before_acceptance(self):
  ctx,path,proof,visible=self.terminal_fixture();receipt=json.loads(path.read_bytes());receipt['requested_effort']='low';path.write_bytes(p.encoded(receipt))
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)

if __name__=='__main__':unittest.main()
