"""Finite successor resumption fixtures; no provider or real archive access."""
from pathlib import Path
import importlib.util,tempfile,unittest,sys
from unittest.mock import patch
S=importlib.util.spec_from_file_location('sigv4_resume_test',Path(__file__).with_name('resume_v4_sigv4.py'));m=importlib.util.module_from_spec(S);S.loader.exec_module(m)
sys.path.insert(0,str(m.ROOT/'scripts'));from research_archive import Archive

class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.run=self.root/'runs/deep-verification-20261031';self.run.mkdir(parents=True);self.archive=Archive(self.root/'research/archive').init()
  def write(name,value):
   p=self.run/name;p.parent.mkdir(parents=True,exist_ok=True);raw=value if isinstance(value,bytes) else m.r.encode(value);p.write_bytes(raw);return {'path':str(p.relative_to(self.root)),'sha256':m.sha(raw),'bytes':len(raw)}
  self.write=write;files=[]
  names=['resume_v4_sigv4.py','test_resume_v4_sigv4.py','archive_progress_v6.py','test_archive_progress_v6.py','runner_v4.py',m.LANE+'/signed_url_projection_v2.py',m.LANE+'/native_projection.py',m.LANE+'/test_native_projection.py',m.LANE+'/SIGNED_URL_POLICY_V2.json','archive-repair-v4/signed_url_projection.py','web_transport_v2.py']
  for name in names:
   source=m.RUN/name;files.append(write(name,source.read_bytes() if source.exists() else b'# Synthetic unpublished test fixture\n'))
  oldstop=write('STOP_V4.json',{'job_id':'archive-progress','automatic_retry':False});files.append(oldstop)
  stop=write('STOP_V4_ARCHIVE_REPAIR.json',{'job_id':'V05-L','reason':'Credential-shaped public text excluded','automatic_retry':False})
  snapshot=write(m.LANE+'/prior-process.json',{'status':'STOPPED_PRESERVED','pid':999999,'active_ids':[],'pending_ids':m.EXPECTED_IDS})
  stdout=write(m.LANE+'/prior-stdout.txt',b'synthetic prior process log\n');failed=write('results/V05-L/attempt-001/failure.json',{'job_id':'V05-L','status':m.r.FAILED})
  preflight=write(m.LANE+'/preflight.json',{'status':'SYNTHETIC_FIXED_PREFIX'});files += [stop,snapshot,stdout,failed,preflight]
  def event(kind,payload,parents=(),outputs=(),sid='synthetic-coordinator'):
   return {'kind':kind,'run_id':self.run.name,'session_id':sid,'actor':{'id':'fixture','role':'tool'},'operation_id':'fixture','attempt_id':'fixture','parents':list(parents),'outputs':list(outputs),'payload':payload}
  self.event=event
  with self.archive.writer() as w:
   prior=w.append(event('research.verification.transport_v4.accepted',{}),'prior-v4');write('TRANSPORT_V4_START_RECEIPT.json',{'event_id':prior['id']})
   old=w.append(event('research.verification.web_projection_policy.accepted',{'preserved_stop':oldstop},[prior['id']]),'prior-v5')
   previous=write('archive-repair-v4/SAFE_WEB_PROJECTION_START_RECEIPT.json',{'event_id':old['id'],'event_sequence':old['sequence'],'event_sha256':old['sha256'],'preserved_stop':oldstop});files.append(previous)
   self.manifest={'status':'SAFE_NATIVE_PROJECTION_PREPARED','files':files,'preserved_stop':stop,'prior_dispatch_snapshot':snapshot,'prior_dispatch_stdout':stdout,'resume_never_started_ids':m.EXPECTED_IDS,'failed_attempt':failed,'mechanical_native_preflight':preflight}
   manifest_ref=write(m.MANIFEST,self.manifest);accepted_files=files+[manifest_ref]
   for row in accepted_files:w.put((self.root/row['path']).read_bytes())
   scope={k:self.manifest[k] for k in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids','failed_attempt','mechanical_native_preflight')}
   payload={'status':'DEEP_VERIFICATION_SAFE_NATIVE_PROJECTION_ARCHIVED','files':accepted_files,**scope}
   e=w.append(event('research.verification.native_projection_policy.accepted',payload,[prior['id'],old['id']],[x['sha256'] for x in accepted_files]),'new-policy')
   self.receipt={**payload,'event_id':e['id'],'event_sequence':e['sequence'],'event_sha256':e['sha256'],'manifest_sha256':manifest_ref['sha256']};write(m.RECEIPT,self.receipt)
   terminal=write('results/V05-L/native-projection-v2/receipt.json',{'status':m.r.COMPLETE,'job_id':'V05-L','session_id':'synthetic-V05-L','disposition':'MECHANICAL_REVALIDATION_NO_MODEL_RERUN','additional_model_calls':0,'archive_projection':{'policy_event_id':e['id']},'mechanical_policy_event_sequence':e['sequence']});w.put((self.root/terminal['path']).read_bytes())
   a=w.append(event('research.verification.result.accepted',{'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':'V05-L','scientific':True,'independence_verified':True,'receipt':terminal},[prior['id'],e['id']],[terminal['sha256']],sid='synthetic-V05-L'),'V05-L-accepted')
   self.accepted={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','session_id':'synthetic-V05-L','event_id':a['id'],'event_sequence':a['sequence'],'event_sha256':a['sha256'],'receipt':terminal};write('results/V05-L/ARCHIVE_RECEIPT.json',self.accepted)
 def tearDown(self):self.tmp.cleanup()
 def gate(self):return m.repair_gate(self.run,self.root,require_old_process_stopped=False)
 def test_exact_seven_gate_has_no_provider_calls(self):
  with patch.object(m.r.subprocess,'Popen',side_effect=AssertionError('NO PROVIDER')):g=self.gate()
  self.assertEqual(g['ids'],['V07-L','V08-A','V08-L','V09-A','V09-L','V10-A','V10-L'])
 def test_prior_policy_receipt_cannot_change_old_stop_binding(self):
  self.write('archive-repair-v4/SAFE_WEB_PROJECTION_START_RECEIPT.json',{'event_id':'invented'})
  with self.assertRaises(ValueError):self.gate()
 def test_existing_attempt_new_stop_and_changed_old_stop_block(self):
  p=self.run/m.NEW_STOP;p.write_text('{}')
  with self.assertRaises(ValueError):self.gate()
  p.unlink();(self.run/'results/V07-L/attempt-001').mkdir(parents=True)
  with self.assertRaises(ValueError):self.gate()
 def test_missing_mechanical_acceptance_blocks_new_work(self):
  (self.run/'results/V05-L/ARCHIVE_RECEIPT.json').unlink()
  with self.assertRaises(ValueError):self.gate()
 def test_non_scientific_forged_acceptance_is_not_a_gate(self):
  ref=self.accepted['receipt']
  with self.archive.writer() as writer:
   bad=writer.append(self.event('research.verification.result.accepted',{'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':'V05-L','scientific':False,'independence_verified':True,'receipt':ref},[self.receipt['event_id']],[ref['sha256']],sid='synthetic-V05-L'),'valid-nonscientific-event')
  self.accepted.update(event_id=bad['id'],event_sequence=bad['sequence'],event_sha256=bad['sha256']);self.write('results/V05-L/ARCHIVE_RECEIPT.json',self.accepted)
  with self.assertRaisesRegex(ValueError,'Mechanical canonical acceptance differs'):self.gate()
 def test_forged_policy_or_mechanical_receipt_rejected(self):
  self.accepted['event_id']='wrong';self.write('results/V05-L/ARCHIVE_RECEIPT.json',self.accepted)
  with self.assertRaises(ValueError):self.gate()
 def test_isolated_hook_keeps_original_run_one_and_only_replaces_inspect_native(self):
  original=m.r.Dispatcher.run_one;d=m.Dispatcher(self.gate(),self.run,self.root);hook=d.projected_run_one.__func__
  self.assertIs(hook.__code__,original.__code__);self.assertIs(m.r.Dispatcher.run_one,original)
  changed={k for k in hook.__globals__ if hook.__globals__[k] is not original.__globals__[k]};self.assertEqual(changed,{'inspect_native'})
 def test_wrapper_never_reruns_failed_completed_or_foreign_job(self):
  d=m.Dispatcher(self.gate(),self.run,self.root);d.projected_run_one=lambda j:(_ for _ in ()).throw(AssertionError('NO PROVIDER'))
  for jid in ('V05-L','V06-A','V07-A','SMOKE-L3'):
   with self.subTest(jid=jid),self.assertRaises(ValueError):d.run_one({'id':jid})
  (self.run/'results/V07-L/attempt-001').mkdir(parents=True)
  with self.assertRaises(ValueError):d.run_one({'id':'V07-L'})
 def test_new_stop_preserves_both_historical_stop_files(self):
  d=m.Dispatcher(self.gate(),self.run,self.root);before={n:(self.run/n).read_bytes() for n in ('STOP_V4.json','STOP_V4_ARCHIVE_REPAIR.json')};self.assertFalse(d.stopped());d.fail_stop('synthetic fail','V07-L');self.assertTrue(d.stopped())
  self.assertEqual(before,{n:(self.run/n).read_bytes() for n in before});self.assertTrue((self.run/m.NEW_STOP).is_file())
 def test_changed_stop_during_finite_run_prevents_dispatch(self):
  d=m.Dispatcher(self.gate(),self.run,self.root);(self.run/'STOP_V4.json').write_text('{}');self.assertTrue(d.stopped())
 def test_active_or_unproven_prior_pid_cannot_authorize_dispatch(self):
  for code,out,err in [(0,'999999\n',''),(2,'',''),(1,'','permission denied')]:
   result=type('Result',(),{'returncode':code,'stdout':out,'stderr':err})()
   with self.subTest(code=code),patch.object(m.subprocess,'run',return_value=result),self.assertRaises(ValueError):m.repair_gate(self.run,self.root)

if __name__=='__main__':unittest.main()
