"""Synthetic tests only: no live archive, source or provider is accessed."""
import copy, importlib.util, json
from pathlib import Path
import tempfile, unittest, types
from unittest.mock import patch
SPEC=importlib.util.spec_from_file_location('progress',Path(__file__).with_name('archive_progress_v4.py'))
p=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(p)

def event(sid='target-session',run='other-run',kind='test.fixture',attempt='fixture'):
 return {'kind':kind,'actor':{'id':'test','role':'tool'},'session_id':sid,'run_id':run,'operation_id':'fixture','attempt_id':attempt,'payload':{}}
def line(payload,kind='response_item'):
 return (json.dumps({'timestamp':'2026-10-31T00:00:00Z','ordinal':0,'type':kind,'payload':payload})+'\n').encode()

class Tests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve()
 def tearDown(self):self.tmp.cleanup()
 def identify(self):
  (self.root/'.lab').mkdir();(self.root/'LAB_PROFILE.json').write_text('{"lab":{"kind":"PHILOSOPHY_PROGRAM"}}')
  (self.root/'.lab/philosophy.json').write_text('{"schema_version":1,"kernel":"philosophy.v1","archive_format":"research-archive.v1"}')
 def test_session_scope_keeps_all_same_sid_and_run_inputs_and_updates(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   one=w.append(event(),'one');other=w.append(event('other-session'),'other');binding=w.append(event('coordinator','run-active'),'binding')
   s=p.SessionWriter(w,'target-session','run-active');rows=s.events();self.assertEqual({e['id'] for e in rows},{one['id'],binding['id']})
   rows[0]['payload']['tamper']=True;self.assertNotIn('tamper',s.events()[0]['payload'])
   later=s.append(event(),'later');self.assertIn(later['id'],{e['id'] for e in s.events()});self.assertNotIn(other['id'],{e['id'] for e in s.events()})
  with self.assertRaises(p.ArchiveError):s.events()
 def test_standard_capture_reuse_and_source_conflict_under_one_audit(self):
  self.identify();sid='synthetic-session-0001';src=self.root/'native.jsonl'
  head=line({'id':sid,'cwd':str(self.root),'base_instructions':'HIDDEN_SENTINEL'},'session_meta')
  msg=line({'type':'message','role':'assistant','phase':'final_answer','content':[{'type':'output_text','text':'Visible final'}]})
  src.write_bytes(head+msg);a=p.Archive(self.root/'research/archive').init()
  with patch.object(a,'_audit',wraps=a._audit) as audit:
   with a.writer() as w:
    scope=p.SessionWriter(w,sid,'run-active')
    one=p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
    two=p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
    self.assertEqual(one['raw_event_ids'],two['raw_event_ids']);self.assertEqual(audit.call_count,1)
    self.assertFalse(any('HIDDEN_SENTINEL' in w.get(h).decode() for h in w._state['present']))
    src.write_bytes(head+msg.replace(b'Visible final',b'Conflicting final'))
    with self.assertRaises(p.ArchiveError):p.capture(a.root,src,sid,self.root,start_line=2,end_line=2,run_id='run-active',archive_writer=scope)
 def test_scoped_duplicate_global_id_and_delivery_conflicts_remain_global(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   e=w.append(event('foreign'),'same-key');scope=p.SessionWriter(w,'target-session','run-active')
   with self.assertRaises(p.ArchiveError):scope.append(event(),'same-key')
 def test_scoped_duplicate_id_conflicts_with_foreign_session(self):
  a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   e=w.append(dict(event('foreign'),id='event-fixed-identity'),'foreign-key');scope=p.SessionWriter(w,'target-session','run-active')
   with self.assertRaises(p.ArchiveError):scope.append(dict(event(),id=e['id']),'new-key')
 def test_safe_web_rejects_raw_exec_and_hidden_body(self):
  r={'line':2,'record_sha256':'a'*64,'role':'tool','type':'public_web_call','call_id':'call1','actions':[{'open':[{'ref_id':'https://developers.openai.com/codex/noninteractive'}]}],'status':'issued'}
  self.assertEqual(p.safe_web(r),r)
  with self.assertRaises(ValueError):p.safe_web(dict(r,input='hidden exec body'))
  with self.assertRaises(ValueError):p.safe({'type':'reasoning','text':'hidden'},'fixture')
 def test_smoke_requires_real_completed_matching_official_page(self):
  value={'read_complete':True,'source_access_status':'OPENED','url':'https://developers.openai.com/codex/noninteractive','page_title':'Non-interactive mode'}
  call={'type':'public_web_call','call_id':'a','actions':[{'type':'open','ref_id':value['url']}]}
  out={'type':'public_web_output','call_id':'a','status':'completed','text':value['url']+'\n'+value['page_title']}
  self.assertTrue(p.official_smoke({'public_web_calls':[call,out]},value))
  for proof in [{'public_web_calls':[call]}, {'public_web_calls':[call,dict(out,status='failed')]}, {'public_web_calls':[call,dict(out,text='Failed to fetch '+out['text'])]}]:
   with self.assertRaises(ValueError):p.official_smoke(proof,value)
  with self.assertRaises(ValueError):p.official_smoke({'public_web_calls':[call,out]},dict(value,url='https://example.org'))
 def test_prefers_revalidation_without_replacing_attempt(self):
  d=self.root/'results/V01-A';(d/'attempt-001').mkdir(parents=True);(d/'attempt-001/receipt.json').write_text('{}')
  ctx={'run':self.root};self.assertEqual(p.terminal_path(ctx,'V01-A').parent.name,'attempt-001')
  (d/'revalidation-v3').mkdir();(d/'revalidation-v3/receipt.json').write_text('{}')
  self.assertEqual(p.terminal_path(ctx,'V01-A').parent.name,'revalidation-v3');self.assertTrue((d/'attempt-001/receipt.json').exists())
 def test_descriptor_rejects_drift_and_symlink(self):
  f=self.root/'f.json';f.write_text('{}');d=p.descriptor(f,self.root);self.assertEqual(p.bound(d,self.root),b'{}')
  f.write_text('{"changed":true}')
  with self.assertRaises(ValueError):p.bound(d,self.root)
  link=self.root/'link';link.symlink_to(f)
  with self.assertRaises(ValueError):p.regular(link,self.root)
 def test_duplicate_receipt_not_overwritten(self):
  f=self.root/'r.json';p.save_new(f,{'event_id':'a'});p.save_new(f,{'event_id':'a'})
  with self.assertRaises(ValueError):p.save_new(f,{'event_id':'b'})
  self.assertEqual(json.loads(f.read_bytes()),{'event_id':'a'})
 def test_only_exact_bound_neutral_literature_appendix_allowed(self):
  a=self.root/'old.txt';b=self.root/'new.txt';a.write_bytes(b'Frozen manuscript and task');b.write_bytes(a.read_bytes()+b'\n\nNeutral transport only\n')
  old={'role':'literature','model':'gpt-6-astra','prompt_file':'old.txt','prompt_sha256':p.sha(a.read_bytes())}
  new=dict(old,prompt_file='new.txt',prompt_sha256=p.sha(b.read_bytes()))
  p.job_transition(old,new,b'\n\nNeutral transport only\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(old,dict(new,model='other'),b'\n\nNeutral transport only\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(old,new,b'Different transport\n',self.root)
  with self.assertRaises(ValueError):p.job_transition(dict(old,role='argument'),dict(new,role='argument'),b'\n\nNeutral transport only\n',self.root)
 def terminal_fixture(self):
  run=self.root/'run';attempt=run/'results/JOB/attempt-001';attempt.mkdir(parents=True);sid='synthetic-session-0001'
  prompt=run/'prompt.txt';prompt.write_text('Neutral prompt');schema=run/'schema.json';schema.write_text('{"type":"object"}')
  job={'id':'JOB','role':'argument','model':'gpt-6-astra','effort':'ultra','service_tier':'default','prompt_file':'run/prompt.txt',
       'prompt_sha256':p.sha(prompt.read_bytes()),'schema_file':'run/schema.json','schema_sha256':p.sha(schema.read_bytes())}
  proof={'session_id':sid,'isolation_failures':[],'native_source_prefix':{'bytes':100,'records':4,'sha256':'c'*64,'newline_terminated':True}};visible=[{'line':2,'record_sha256':'a'*64,'role':'user','text':'Neutral prompt'},
     {'line':4,'record_sha256':'b'*64,'role':'assistant','phase':'final_answer','text':'{"verdict":"pass"}'}]
  for name,value in [('native-check.json',proof),('native-visible.json',{'session_id':sid,'records':visible}),('response.json',{'verdict':'pass'})]:(attempt/name).write_bytes(p.encoded(value))
  (attempt/'final.txt').write_bytes(p.encoded({'verdict':'pass'}))
  receipt={'job_id':'JOB','status':p.COMPLETE,'session_id':sid,'quality_flags':[],'transport_version':4,'cli_exit_code':0,'visible_final_count':1,
   'stdout_diagnostic_gap_count':0,'stdout_projection_complete':True,'stdout_turn_completed':True,
   'stdout_gap_total_bytes':0,'stdout_parse_gap_policy':p.STDOUT_POLICY,'native_replay_authoritative':True,
   'prompt_sha256':job['prompt_sha256'],'schema_sha256':job['schema_sha256'],'requested_model':job['model'],
   'requested_effort':'ultra','requested_service_tier':'default','outputs':{str(f.relative_to(self.root)):p.sha(f.read_bytes()) for f in attempt.iterdir()}}
  path=attempt/'receipt.json';path.write_bytes(p.encoded(receipt))
  runner=types.SimpleNamespace(check_inputs=lambda *args:None,inspect_native=lambda *args,**kwargs:(proof,visible,[visible[-1]]),validate=lambda *args:None)
  return {'root':self.root,'run':run,'runner':runner,'jobs':{'JOB':job}},path,proof,visible
 def test_terminal_independent_native_replay_and_output_hash_gate(self):
  ctx,path,proof,visible=self.terminal_fixture();result=p.validate_terminal(ctx,'JOB',path);self.assertEqual(len(result['messages']),2)
  ctx['runner'].inspect_native=lambda *args,**kwargs:(dict(proof,isolation_failures=['bad']),visible,[visible[-1]])
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
  (path.parent/'response.json').write_text('{"verdict":"different"}')
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
 def test_terminal_rejects_wrong_configuration_before_acceptance(self):
  ctx,path,proof,visible=self.terminal_fixture();receipt=json.loads(path.read_bytes());receipt['requested_effort']='low';path.write_bytes(p.encoded(receipt))
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
 def test_administrative_stop_is_read_only_and_fails_closed(self):
  run=self.root/'run';run.mkdir();self.assertIsNone(p.stop_requested(run,self.root))
  path=run/p.STOP_REQUEST;value={'status':'STOP_AFTER_CURRENT_ACCEPTANCE','run_id':'run','reason':'Reviewed successor ready'}
  path.write_bytes(p.encoded(value));before=path.read_bytes()
  self.assertEqual(p.stop_requested(run,self.root)['status'],'ADMINISTRATIVE_STOP_PRESERVED');self.assertEqual(path.read_bytes(),before)
  path.write_bytes(p.encoded(dict(value,run_id='other')))
  with self.assertRaises(ValueError):p.stop_requested(run,self.root)
 def test_technical_stdout_boundary_preserves_gaps_and_requires_turn_completion(self):
  value={'stdout_diagnostic_gap_count':1,'stdout_projection_complete':False,'stdout_turn_completed':True}
  self.assertEqual(p.technical_stdout(value),value)
  for changed in ({},dict(value,stdout_turn_completed=False),dict(value,stdout_projection_complete=True),dict(value,stdout_diagnostic_gap_count=True)):
   with self.assertRaises(ValueError):p.technical_stdout(changed)
 def test_only_exact_observed_official_redirect_pair_is_accepted(self):
  original='https://developers.openai.com/codex/noninteractive';redirect='https://learn.chatgpt.com/docs/non-interactive-mode'
  value={'read_complete':True,'source_access_status':'OPENED','url':redirect,'page_title':'Non-interactive mode | ChatGPT Learn'}
  call={'type':'public_web_call','call_id':'one','actions':[{'type':'open','ref_id':original}]}
  output={'type':'public_web_output','call_id':'one','status':'completed','text':original+'\n'+redirect+'\n'+value['page_title']}
  self.assertTrue(p.official_smoke({'public_web_calls':[call,output]},value))
  with self.assertRaises(ValueError):p.official_smoke({'public_web_calls':[call,dict(output,text=redirect+'\n'+value['page_title'])]},value)
  with self.assertRaises(ValueError):p.official_smoke({'public_web_calls':[dict(call,actions=[{'type':'open','ref_id':'https://openai.com'}]),output]},value)
  with self.assertRaises(ValueError):p.official_smoke({'public_web_calls':[call,output]},dict(value,url=redirect+'/other'))
 def test_bounded_parse_only_gap_can_remain_explicit_without_blocking_native_authority(self):
  ctx,path,proof,visible=self.terminal_fixture();receipt=p.load(path,self.root)
  row={'line_sha256':'a'*64,'line_bytes':23,'exact_json_null':False,'error_class':'ValueError','error_category':'DUPLICATE_KEY','stage':'json_parse'}
  (path.parent/'structural-diagnostics.jsonl').write_text(json.dumps(row)+'\n')
  receipt.update(stdout_diagnostic_gap_count=1,stdout_projection_complete=False,stdout_gap_total_bytes=23)
  boundary=p.native_stdout_boundary(ctx,path,receipt);self.assertFalse(boundary['stdout_projection_complete']);self.assertTrue(boundary['native_replay_authoritative'])
  for altered in (dict(row,stage='projection'),dict(row,error_category='UNKNOWN_TOOL'),dict(row,line_bytes=262145)):
   (path.parent/'structural-diagnostics.jsonl').write_text(json.dumps(altered)+'\n')
   with self.assertRaises(ValueError):p.native_stdout_boundary(ctx,path,receipt)
 def test_legacy_gap_projection_requires_exact_original_manifest_binding(self):
  run=self.root/'run';attempt=run/'results/SMOKE-L3/attempt-001';repair=run/'results/SMOKE-L3/revalidation-v4';attempt.mkdir(parents=True);repair.mkdir()
  original={'line_sha256':'a'*64,'line_bytes':19,'exact_json_null':False,'error_class':'ValueError'}
  rawpath=attempt/'structural-diagnostics.jsonl';rawpath.write_text(json.dumps(original)+'\n');ref=p.descriptor(rawpath,self.root)
  row=dict(original,error_category='LEGACY_VALUEERROR_CATEGORY_UNAVAILABLE',stage='json_parse')
  evidence={'schema':'stdout-gap-evidence.v4','policy':p.STDOUT_POLICY,'original':ref,'rows':[row],'count':1,'total_bytes':19}
  (repair/'stdout-gap-evidence.json').write_bytes(p.encoded(evidence));ctx={'run':run,'root':self.root,'indexed':{ref['path']:ref}}
  receipt={'job_id':'SMOKE-L3','disposition':'MECHANICAL_REVALIDATION_NO_MODEL_RERUN','stdout_diagnostic_gap_count':1,
    'stdout_projection_complete':False,'stdout_turn_completed':True,'stdout_gap_total_bytes':19,'stdout_parse_gap_policy':p.STDOUT_POLICY,'native_replay_authoritative':True}
  self.assertEqual(p.native_stdout_boundary(ctx,repair/'receipt.json',receipt)['stdout_diagnostic_gap_count'],1)
  evidence['rows'][0]['line_sha256']='b'*64;(repair/'stdout-gap-evidence.json').write_bytes(p.encoded(evidence))
  with self.assertRaises(ValueError):p.native_stdout_boundary(ctx,repair/'receipt.json',receipt)
 def test_native_replay_uses_saved_cutoff_and_checks_original_final_file(self):
  ctx,path,proof,visible=self.terminal_fixture();called=[]
  def replay(*args,**kwargs):called.append(kwargs);return proof,visible,[visible[-1]]
  ctx['runner'].inspect_native=replay;p.validate_terminal(ctx,'JOB',path)
  self.assertEqual(called,[{'cutoff':proof['native_source_prefix']}])
  (path.parent/'final.txt').write_text('{"verdict":"wrong"}')
  receipt=p.load(path,self.root);receipt['outputs']['run/results/JOB/attempt-001/final.txt']=p.sha((path.parent/'final.txt').read_bytes());path.write_bytes(p.encoded(receipt))
  with self.assertRaises(ValueError):p.validate_terminal(ctx,'JOB',path)
 def test_original_argument_is_never_newly_accepted(self):
  a=p.Archive(self.root/'research/archive').init();ctx={'run':self.root,'scientific_ids':{'V01-A'},'jobs':{'V01-A':{'role':'argument'}}}
  with a.writer() as writer,patch.object(p,'validate_terminal',side_effect=AssertionError('Must not revalidate original A')):
   writer._ensure_audited()
   with self.assertRaises(ValueError):p.accept_job(ctx,writer,{},'V01-A',self.root/'missing')
 def setup_fixture(self):
  run=self.root/'run';run.mkdir()
  def put(name,value):
   path=run/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(value if isinstance(value,bytes) else p.encoded(value));return path
  put('START_RECEIPT.json',{'status':'DEEP_VERIFICATION_INPUTS_ARCHIVED','event_id':'event-start','bindings':{k:[] for k in ('method','instruction','config','input')}})
  put('schema.json',{'type':'object'});put('original.txt',b'Frozen original manuscript and task')
  instruction=b'\n\nNeutral transport appendix\n';put('transport-repair-v2/TRANSPORT_INSTRUCTION.txt',instruction);put('amended.txt',b'Frozen original manuscript and task'+instruction)
  original=[];current=[]
  for i in range(1,11):
   for suffix,role in [('A','argument'),('L','literature')]:
    job={'id':f'V{i:02d}-{suffix}','role':role,'model':'gpt-6-astra','effort':'ultra','service_tier':'default',
         'prompt_file':'run/original.txt','prompt_sha256':p.sha((run/'original.txt').read_bytes()),'schema_file':'run/schema.json','schema_sha256':p.sha((run/'schema.json').read_bytes())}
    original.append(job);current.append(dict(job,prompt_file='run/amended.txt',prompt_sha256=p.sha((run/'amended.txt').read_bytes())) if role=='literature' else dict(job))
  put('jobs.json',{'jobs':original});put('jobs_v2.json',{'jobs':current+[dict(current[-1],id='SMOKE-L2')]})
  put('jobs_v3.json',{'jobs':current+[dict(current[-1],id='SMOKE-L3')]});put('jobs_v4.json',{'jobs':current+[dict(current[-1],id='SMOKE-L3')]})
  old=put('historical.txt',b'Preserved history')
  put('TRANSPORT_V3_MANIFEST.json',{'status':'TRANSPORT_V2_PREPARED_NOT_DISPATCHED','files':[p.descriptor(old,self.root)]})
  put('TRANSPORT_V3_START_RECEIPT.json',{'status':'DEEP_VERIFICATION_TRANSPORT_V3_ARCHIVED','event_id':'event-old','files':[p.descriptor(old,self.root)]})
  disposition={'action':'PRESERVE_FAILED_TECHNICAL_ATTEMPTS_AND_REVALIDATE_COMPLETED_L3','scientific_retries':False,'technical_retries':False,'revalidate_job_id':'SMOKE-L3','new_stop_filename':'STOP_V4.json'}
  for jid,stop,key,failed in [('SMOKE-L','STOP.json','preserved_stop','failed_attempt'),('SMOKE-L2','STOP_V2.json','preserved_v2_stop','failed_v2_attempt'),('SMOKE-L3','STOP_V3.json','preserved_v3_stop','failed_v3_attempt')]:
   disposition[key]=p.descriptor(put(stop,{'job_id':jid,'reason':'bounded technical failure'}),self.root)
   disposition[failed]=p.descriptor(put('results/'+jid+'/attempt-001/failure.json',{'job_id':jid,'session_id':'synthetic-'+jid,'status':'FAILED_PRESERVED_NO_RETRY'}),self.root)
  put('STOP_DISPOSITION_V4.json',disposition)
  for name in ['archive_progress_v4.py','test_archive_progress_v4.py','runner_v3.py','runner_v4.py','test_runner_v4.py','web_transport_v4.py','revalidate_existing_v4.py','transport-repair-v4/DECLARATIONS_BY_ROLE.json','transport-repair-v4/STDOUT_NATIVE_AUTHORITY_POLICY.json','results/V01-A/ARCHIVE_RECEIPT.json','results/V02-A/ARCHIVE_RECEIPT.json']:put(name,b'fixture')
  runner=types.SimpleNamespace(check_job=lambda *a:None,check_inputs=lambda *a:None,actual_quota=lambda reason:False)
  self.refresh_manifest(run)
  return run,runner
 def refresh_manifest(self,run):
  files=[p.descriptor(f,self.root) for f in sorted(run.rglob('*')) if f.is_file() and f.name!='TRANSPORT_V4_MANIFEST.json']
  (run/'TRANSPORT_V4_MANIFEST.json').write_bytes(p.encoded({'status':'TRANSPORT_V4_PREPARED_NOT_DISPATCHED','files':files}))
 def test_v3_setup_preserves_exact_scientific_queue_and_two_failures(self):
  run,runner=self.setup_fixture()
  with patch.object(p,'import_runner',return_value=runner):ctx=p.setup(self.root,run)
  self.assertEqual(len(ctx['scientific_ids']),20);self.assertEqual(set(ctx['failures']),{'SMOKE-L','SMOKE-L2','SMOKE-L3'})
  queue=p.load(run/'jobs_v4.json',self.root);queue['jobs'][0]['model']='other';(run/'jobs_v4.json').write_bytes(p.encoded(queue));self.refresh_manifest(run)
  with patch.object(p,'import_runner',return_value=runner),self.assertRaises(ValueError):p.setup(self.root,run)
 def test_v3_setup_rejects_extra_job_and_stop_drift(self):
  run,runner=self.setup_fixture();queue=p.load(run/'jobs_v4.json',self.root);queue['jobs'].append(dict(queue['jobs'][0],id='UNAUTHORIZED'))
  (run/'jobs_v4.json').write_bytes(p.encoded(queue));self.refresh_manifest(run)
  with patch.object(p,'import_runner',return_value=runner),self.assertRaises(ValueError):p.setup(self.root,run)
  queue['jobs'].pop();(run/'jobs_v4.json').write_bytes(p.encoded(queue));(run/'STOP_V2.json').write_bytes(p.encoded({'job_id':'SMOKE-L2','reason':'changed'}));self.refresh_manifest(run)
  with patch.object(p,'import_runner',return_value=runner),self.assertRaises(ValueError):p.setup(self.root,run)
 def test_transport_acceptance_links_v2_and_preserves_both_failures_without_duplicates(self):
  run,runner=self.setup_fixture();a=p.Archive(self.root/'research/archive').init()
  with a.writer() as w:
   start=w.append(event('coordinator',run.name),'start')
   saved=p.load(run/'START_RECEIPT.json',self.root);saved['event_id']=start['id'];(run/'START_RECEIPT.json').write_bytes(p.encoded(saved))
   old_files=[p.descriptor(run/'historical.txt',self.root)];w.put((run/'historical.txt').read_bytes())
   old=w.append(dict(event('coordinator',run.name,'research.verification.transport_v3.accepted'),parents=[start['id']],payload={'status':'DEEP_VERIFICATION_TRANSPORT_V3_ARCHIVED','files':old_files}),'old')
   saved=p.load(run/'TRANSPORT_V3_START_RECEIPT.json',self.root);saved['event_id']=old['id'];(run/'TRANSPORT_V3_START_RECEIPT.json').write_bytes(p.encoded(saved))
   first_files=[p.descriptor(run/'STOP.json',self.root),p.descriptor(run/'results/SMOKE-L/attempt-001/failure.json',self.root)]
   for row in first_files:w.put(p.bound(row,self.root))
   first=w.append(dict(event('synthetic-SMOKE-L',run.name,'research.verification.technical_failure.archived'),payload={'status':'TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY','job_id':'SMOKE-L','files':first_files}),run.name+':SMOKE-L:failure-preserved')
   second_files=[p.descriptor(run/'STOP_V2.json',self.root),p.descriptor(run/'results/SMOKE-L2/attempt-001/failure.json',self.root)]
   for row in second_files:w.put(p.bound(row,self.root))
   second=w.append(dict(event('synthetic-SMOKE-L2',run.name,'research.verification.technical_failure.archived'),payload={'status':'TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY','job_id':'SMOKE-L2','files':second_files}),run.name+':SMOKE-L2:failure-preserved')
   self.refresh_manifest(run)
   with patch.object(p,'import_runner',return_value=runner):ctx=p.setup(self.root,run)
   with patch.object(p,'require_original_arguments',return_value=None):
    accepted=p.accept_transport(ctx,w);count=len(w._state['records']);again=p.accept_transport(ctx,w)
   self.assertEqual(accepted['id'],again['id']);self.assertEqual(count,len(w._state['records']));self.assertIn(old['id'],accepted['parents']);self.assertIn(first['id'],accepted['parents'])
   self.assertEqual(p.load(run/'results/SMOKE-L/ARCHIVE_RECEIPT.json',self.root)['event_id'],first['id'])
   self.assertEqual(p.load(run/'results/SMOKE-L2/ARCHIVE_RECEIPT.json',self.root)['status'],'TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY')
   self.assertEqual(p.load(run/'results/SMOKE-L3/FAILED_ATTEMPT_ARCHIVE_RECEIPT.json',self.root)['status'],'TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY')
   self.assertFalse((run/'results/SMOKE-L3/ARCHIVE_RECEIPT.json').exists())
 def test_prior_result_requires_canonical_bytes_and_exact_identity(self):
  ctx,path,proof,visible=self.terminal_fixture();a=p.Archive(self.root/'research/archive').init()
  files=[p.descriptor(f,self.root) for f in path.parent.iterdir()]
  with a.writer() as w:
   for row in files:w.put(p.bound(row,self.root))
   accepted=w.append(dict(event('synthetic-session-0001',ctx['run'].name,'research.verification.result.accepted'),payload={
    'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':'JOB','receipt':p.descriptor(path,self.root),'native_check':p.descriptor(path.parent/'native-check.json',self.root),'files':files}),'accepted')
   p.verify_accepted(ctx,w,accepted,'JOB',path)
   with self.assertRaises(ValueError):p.verify_accepted(ctx,w,accepted,'OTHER',path)
   (path.parent/'response.json').write_bytes(b'{}')
   with self.assertRaises(ValueError):p.verify_accepted(ctx,w,accepted,'JOB',path)

if __name__=='__main__':unittest.main()
