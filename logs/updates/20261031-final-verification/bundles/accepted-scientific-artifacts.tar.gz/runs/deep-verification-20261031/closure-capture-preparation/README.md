# One coordinator capture and one closure writer

Prepared only. This helper never dispatches models or controls the collector.
Run after all twenty scientific results are canonically accepted, the research
writer has exited, and the coordinator has written its later synthesis. Keep
the service unloaded until closure releases its writer.

The coordinator must first send its actual assistant commentary explaining its
decision, then provide its exact native source line and SHA-256. The fixed SID
is `01a190b5-03e2-70d0-8fcf-b4a1e67148d0`. No text search chooses the source.
User, internal, analysis and tool records are ineligible. The selected original
must be a safe visible assistant commentary/final record. Selection parses only
the first identity record and the explicitly selected line. Standard capture
internally validates the local source context; a constrained writer allows
only the exact selected original and its complete one-line coverage report.
Nothing from other native records is returned, printed or retained by it.

Create `closure/CAPTURE_PLAN.json` with exactly these fields:

```json
{
  "schema": "verification-capture-closure-plan.v1",
  "run_id": "deep-verification-20261031",
  "session_id": "01a190b5-03e2-70d0-8fcf-b4a1e67148d0",
  "source": {"source_line": 0, "sha256": "REPLACE_WITH_ACTUAL_RECORD_SHA256"},
  "artifacts": {},
  "implementation_files": [],
  "driver_files": []
}
```

The placeholder line is deliberately invalid. `artifacts` and
`implementation_files` follow the frozen closure helper's README: six exact
coordinator artifacts and exactly its three original implementation files.
`driver_files` binds the four files in this directory: this README, the script,
its tests and `CAPTURE_CONTRACT.json`. Every descriptor has project-relative
`path`, SHA-256 and byte count. Existing files are never overwritten.

After independent review, execute once, with the actual plan SHA:

```sh
python3 -B runs/deep-verification-20261031/closure-capture-preparation/capture_and_close.py \
  --plan runs/deep-verification-20261031/closure/CAPTURE_PLAN.json \
  --plan-sha256 ACTUAL_PLAN_SHA256 \
  --allow-checkpoint-derived-updates
```

The helper opens one writer and audits once. All twenty canonical acceptance
metadata gates run before source, manuscript or scientific result body reads.
It first binds the exact plan, driver and dependency files in one canonical
`research.verification.coordinator.capture_intent` event, whose parents include
all twenty accepted results. The one-line coverage includes this intent as a
parent; retry cannot change the plan even after a crash before local receipts.
It captures one exact explanation, saves `COORDINATOR_CAPTURE.json`, builds
`REQUEST.json` with the actual original/coverage IDs, then invokes the frozen
closure helper on that same audited capability. The original question and
every scientific coverage are included. No scientific author is reassigned.

An error may leave a valid captured explanation without closing the run. Retry
with the exact same plan only: the canonical original/coverage are explicitly
verified and reused, including a crash before the local capture receipt was
saved. Different source, plan or existing request fails closed. An original
already assigned to another run is not relabelled. Full closure validation
still decides whether to emit the bounded ready receipt or the explicit
withheld receipt; this helper does not choose candidates or force success.
The standard administrative checkpoint remains `INCOMPLETE`, as documented by
the unchanged closure protocol. Its derived views/lineage updates are included
in the one operation and may take time.
