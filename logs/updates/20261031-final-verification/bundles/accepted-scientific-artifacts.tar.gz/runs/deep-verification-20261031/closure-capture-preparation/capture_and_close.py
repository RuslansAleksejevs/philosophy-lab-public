#!/usr/bin/env python3
"""Capture one explicitly selected coordinator message, then close in one writer.

No discovery, models, service actions or scientific judgment. Source selection
parses only session metadata and the exact requested visible message. The pinned
standard capture subsequently validates local source context internally, but
the constrained writer can retain only that one exact record and its report.
"""
from pathlib import Path
import argparse,copy,hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;RUN=HERE.parent;ROOT=RUN.parents[1]
SID='01a190b5-03e2-70d0-8fcf-b4a1e67148d0'
HEX=re.compile('[a-f0-9]{64}\\Z');MAX_SOURCE=64*1024*1024;MAX_LINE=8*1024*1024
CLOSURE_SHA='fb9babe7b5964f593759349fddbfc6a209b7e3e47c3d72a5b7ba46b2cd3f374d'
BASE_SHA='e05c400d70f1eeddbdff81cb6d8bf519bfbbfa76ef5d3c3d33f6ea6d6b1ba607'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def module(name,path,digest):
 if sha(path.read_bytes())!=digest:raise ValueError('Frozen dependency changed')
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
C=module('capture_closure_frozen',RUN/'closure-preparation/closure.py',CLOSURE_SHA)
B=module('capture_closure_base',RUN/'archive_progress_v4.py',BASE_SHA)
import capture_codex as CAP
from codex_rollout import rollout_file
need=C.require

def metadata_gate(root,run,events):
 """All twenty metadata gates precede source, manuscript or report-body reads."""
 known={e['id']:e for e in events};need(len(known)==len(events),'Duplicate canonical identity')
 start=C.strict(C.path(root,str((run/'START_RECEIPT.json').relative_to(root))).read_bytes())
 first=known.get(start.get('run_start_event'),{})
 need(first.get('kind')=='operation.started' and first.get('session_id')==SID and first.get('run_id')==run.name
      and first.get('bindings')==start.get('bindings'),'Original coordinator round mismatch')
 inputs=known.get(start.get('event_id'),{});need(inputs.get('kind')=='research.verification.inputs.accepted' and inputs.get('run_id')==run.name,'Original inputs not accepted')
 transports={}
 for v in (3,4):
  receipt=C.strict(C.path(root,str((run/f'TRANSPORT_V{v}_START_RECEIPT.json').relative_to(root))).read_bytes());event=known.get(receipt.get('event_id'),{})
  need(event.get('kind')==f'research.verification.transport_v{v}.accepted' and event.get('run_id')==run.name
       and receipt.get('status')==event.get('payload',{}).get('status') and receipt.get('files')==event.get('payload',{}).get('files'),'Transport metadata mismatch')
  transports[v]=event
 rows=[];sessions=set();coverage=list(start['capture_events'])
 for i in range(1,11):
  for role in ('A','L'):
   jid=f'V{i:02d}-{role}';receipt=C.strict(C.path(root,str((run/'results'/jid/'ARCHIVE_RECEIPT.json').relative_to(root))).read_bytes())
   event=known.get(receipt.get('event_id'),{});p=event.get('payload',{});version=3 if jid in {'V01-A','V02-A'} else 4
   need(event.get('kind')=='research.verification.result.accepted' and event.get('run_id')==run.name
        and event.get('bindings')==first['bindings'] and p.get('job_id')==jid and p.get('status')=='DEEP_VERIFICATION_RESULT_ARCHIVED'
        and p.get('scientific') is True and p.get('independence_verified') is True,'All twenty exact canonical scientific results required')
   need(all(receipt.get(k)==p.get(k) for k in ('receipt','native_check','files')),'Local result acceptance differs from canonical')
   need(inputs['id'] in event['parents'] and transports[version]['id'] in event['parents'],'Exact original input/transport parents required')
   need(event.get('session_id') not in sessions|{SID} and isinstance(event.get('session_id'),str),'Twenty fresh scientific session identities required');sessions.add(event['session_id'])
   need(isinstance(p.get('capture_event_ids'),list) and p['capture_event_ids'],'Scientific native coverage missing')
   for cid in p['capture_event_ids']:
    e=known.get(cid,{});need(e.get('kind')=='capture.coverage' and e.get('run_id')==run.name and e.get('session_id')==event['session_id'] and e.get('payload',{}).get('status')=='BOUNDED_COMPLETE','Scientific coverage mismatch');coverage.append(cid)
   rows.append(event)
 for cid in start['capture_events']:
  e=known.get(cid,{});need(e.get('kind')=='capture.coverage' and e.get('run_id')==run.name and e.get('payload',{}).get('status')=='BOUNDED_COMPLETE','Original question/authorization coverage mismatch')
 return {'start':start,'first':first,'accepted':rows,'coverage':list(dict.fromkeys(coverage))}

def validate_plan(root,run,ref):
 plan=C.strict(C.read(root,ref));B.safe(plan,'coordinator capture plan')
 need(set(plan)=={'schema','run_id','session_id','source','artifacts','implementation_files','driver_files'},'Exact capture plan fields required')
 need(plan['schema']=='verification-capture-closure-plan.v1' and plan['run_id']==run.name and plan['session_id']==SID,'Wrong capture plan identity')
 source=plan['source'];need(isinstance(source,dict) and set(source)=={'source_line','sha256'} and type(source['source_line']) is int and 1<source['source_line']<=1000000 and isinstance(source['sha256'],str) and HEX.fullmatch(source['sha256']),'Exact future source line/SHA required')
 expected={str((run/'closure-capture-preparation'/n).relative_to(root)) for n in ('capture_and_close.py','test_capture_and_close.py','README.md','CAPTURE_CONTRACT.json')}
 need(len(plan['driver_files'])==4 and {r['path'] for r in plan['driver_files']}==expected,'Exact reviewed driver files required')
 for r in plan['driver_files']:
  raw=C.read(root,r)
  if r['path'].endswith('/capture_and_close.py'):need(raw==Path(__file__).read_bytes(),'Executing capture driver not plan-bound')
 contract_ref=next(r for r in plan['driver_files'] if r['path'].endswith('/CAPTURE_CONTRACT.json'));contract=C.strict(C.read(root,contract_ref))
 expected_code={str((run/'closure-preparation/closure.py').relative_to(root)),str((run/'archive_progress_v4.py').relative_to(root))}|{'scripts/'+n for n in ('capture_codex.py','codex_rollout.py','research_archive.py','collector_safety.py','philosophy_round.py','essay_lineage.py','collector_views.py','research_timeline.py')}
 need(contract.get('schema')=='verification-coordinator-capture-contract.v1' and set(contract['files'])==expected_code,'Exact capture dependency contract required')
 for rel,h in contract['files'].items():need(sha(C.path(root,rel).read_bytes())==h,'Pinned capture dependency changed')
 need(contract['files'].get(str((run/'closure-preparation/closure.py').relative_to(root)))==CLOSURE_SHA,'Frozen closure contract missing')
 need(contract['files'].get(str((run/'archive_progress_v4.py').relative_to(root)))==BASE_SHA,'Frozen writer scope contract missing')
 need({r['path'] for r in plan['implementation_files']}=={str((run/'closure-preparation'/n).relative_to(root)) for n in ('closure.py','test_closure.py','PROTOCOL_NOTE.md')},'Frozen closure implementation required')
 for r in plan['implementation_files']:C.read(root,r)
 need(set(plan['artifacts'])=={'source_ledger','contribution_matrix','decision','cards','checkpoint_summary','protocol_note'},'Six coordinator artifacts required')
 for name,r in plan['artifacts'].items():
  raw=C.read(root,r);B.safe(C.strict(raw) if name!='protocol_note' else raw.decode(),'coordinator artifact')
 return plan

def bind_intent(root,run,plan_ref,plan,gate,w):
 """A durable exact-plan commitment before any selected original is written."""
 contract_ref=next(r for r in plan['driver_files'] if r['path'].endswith('/CAPTURE_CONTRACT.json'));contract=C.strict(C.read(root,contract_ref))
 refs=[plan_ref]+plan['driver_files']+[C.desc(root,C.path(root,p)) for p in contract['files']]
 unique={}
 for ref in refs:
  raw=C.read(root,ref);need(ref['path'] not in unique or unique[ref['path']]==ref,'Conflicting capture dependency descriptor');unique[ref['path']]=ref
  B.safe(C.strict(raw) if ref['path'].endswith('.json') else raw.decode(),'capture intent input')
 files=list(unique.values());key=run.name+':coordinator-capture-intent:v1'
 payload={'status':'COORDINATOR_CAPTURE_INTENT_BOUND','plan':plan_ref,'files':files,'source':plan['source'],
  'scientific_results_accepted':20,'new_scientific_roles':0,'boundary':'Exact later coordinator explanation and closure plan; original worker/manuscript authorship unchanged.'}
 request={'kind':'research.verification.coordinator.capture_intent','actor':{'id':'coordinator-capture-closure-driver','role':'tool'},'session_id':SID,'run_id':run.name,
  'operation_id':run.name,'attempt_id':'coordinator-capture-closure-v1','bindings':gate['first']['bindings'],
  'parents':[gate['first']['id']]+[e['id'] for e in gate['accepted']],'outputs':list(dict.fromkeys(r['sha256'] for r in files)),'payload':payload}
 existing=[e for e in w._state['records'] if e.get('delivery_key')==key]
 need(len(existing)<=1,'Conflicting capture intents')
 if existing:
  event=existing[0];need(all(event.get(k)==v for k,v in request.items()),'Capture intent differs; prior plan is immutable')
  for ref in files:need(w.get(ref['sha256'])==C.read(root,ref),'Accepted capture input object changed')
  return event
 for ref in files:need(w.put(C.read(root,ref))==ref['sha256'],'Capture intent object mismatch')
 return w.append(request,key)

def source_record(source,root,selection):
 line=selection['source_line'];total=0
 with rollout_file(source,max_bytes=MAX_SOURCE) as stream:
  need(stream.logical_stat().st_size<=MAX_SOURCE,'Coordinator source exceeds bounded size')
  first=None;raw=None
  for n in range(1,line+1):
   item=stream.readline(MAX_LINE+1);total+=len(item)
   need(item.endswith(b'\n') and len(item)<=MAX_LINE and total<=MAX_SOURCE,'Selected source line unavailable or oversized')
   if n==1:first=CAP.strict_json(item)
   if n==line:raw=item
  stream.verify_unchanged()
 need(isinstance(first,dict) and first.get('type')=='session_meta' and first.get('payload',{}).get('id')==SID
      and first['payload'].get('cwd')==str(root),'Exact native session/project identity mismatch')
 need(sha(raw)==selection['sha256'],'Selected source bytes changed')
 record=CAP.strict_json(raw);need(CAP.classify(record,line,set(),set()) is None,'Selected source is not eligible visible content')
 p=record.get('payload',{});need(p.get('type')=='message' and p.get('role')=='assistant' and p.get('phase',p.get('channel')) in {'commentary','final','final_answer'},'Only an actual assistant explanation is eligible')
 need(not B.contains_credential(record),'Credential-shaped selected message is withheld')
 return raw,record

def valid_report(report,run,selection,raw):
 need(report.get('format')=='codex-visible-selection.v1' and report.get('session_id')==SID and report.get('run_id')==run.name
      and report.get('selected_range')==[selection['source_line']]*2 and report.get('reviewed_tool_lines')==[]
      and report.get('captured_records')==1 and report.get('status')=='BOUNDED_COMPLETE' and report.get('gaps')==[]
      and report.get('excluded_counts')=={} and report.get('tool_link_ids')==[]
      and report.get('raw_records')==[{'source_line':selection['source_line'],'sha256':selection['sha256'],'bytes':len(raw)}],'Capture report differs from exact single visible record')
 B.safe(report,'single-source coverage report')

class SelectedWriter(B.SessionWriter):
 """Prevent a source change between preflight and capture from being stored."""
 def __init__(self,w,run,selection,raw,intent):
  super().__init__(w,SID,run.name);self.run=run;self.selection=selection;self.raw=raw;self.reports={};self.intent=intent
 def put(self,raw):
  if raw!=self.raw:
   report=C.strict(raw);valid_report(report,self.run,self.selection,self.raw);self.reports[sha(raw)]=report
  return self.base.put(raw)
 def append(self,event,delivery_key):
  p=event.get('payload',{});need(event.get('session_id')==SID and event.get('run_id')==self.run.name,'Capture attempted foreign identity')
  if event.get('kind')=='capture.raw_record':
   need(event.get('actor',{}).get('role')=='assistant' and p.get('source_line')==self.selection['source_line'] and p.get('raw_sha256')==self.selection['sha256'] and event.get('outputs')==[self.selection['sha256']],'Capture attempted another original')
  elif event.get('kind')=='capture.coverage':
   report=self.reports.get(p.get('report_sha256'));need(report is not None and event.get('parents')==report['raw_event_ids'] and event.get('outputs')==[p['report_sha256']] and p.get('status')=='BOUNDED_COMPLETE','Capture attempted unbound coverage')
   event=copy.deepcopy(event);event['parents'].append(self.intent['id'])
  else:raise C.Invalid('No tool, foreign-run or other capture event is allowed')
  return self.base.append(event,delivery_key)
 def append_many(self,*args):raise C.Invalid('Capture batch not permitted')

def existing_capture(w,run,selection,raw,record,intent):
 rows=[e for e in w._state['records'] if e.get('session_id')==SID or e.get('run_id')==run.name]
 original=CAP.existing_original(rows,SID,selection['source_line'],raw,record)
 if original is None:return None
 need(original['run_id']==run.name,'Existing original belongs to another run; never reassign authorship')
 need(w.get(selection['sha256'])==raw,'Existing original object changed')
 for e in rows:
  if e['kind']!='capture.coverage' or e['run_id']!=run.name or e['session_id']!=SID or e['parents']!=[original['id'],intent['id']] or e['payload'].get('status')!='BOUNDED_COMPLETE':continue
  report=C.strict(w.get(e['payload']['report_sha256']))
  if report.get('selected_range')!=[selection['source_line']]*2:continue
  valid_report(report,run,selection,raw);need(report.get('raw_event_ids')==[original['id']],'Stored coverage original differs')
  return {'raw_event_id':original['id'],'coverage_event_id':e['id'],'report_sha256':e['payload']['report_sha256']}
 return None

def run_with_writer(root,run,plan_ref,w,*,allow_checkpoint_derived_updates=False):
 need(allow_checkpoint_derived_updates is True,'Explicit checkpoint derived-update permission required')
 w._ensure_audited();gate=metadata_gate(root,run,w._state['records'])
 plan=validate_plan(root,run,plan_ref);selection=plan['source'];source=CAP.resolve_session(SID,root);raw,record=source_record(source,root,selection)
 directory=run/'closure';capture_path=directory/'COORDINATOR_CAPTURE.json';request_path=directory/'REQUEST.json'
 for p in (directory,capture_path,request_path):need(not any(x.is_symlink() for x in (p,*p.parents)),'Symlink closure output')
 intent=bind_intent(root,run,plan_ref,plan,gate,w)
 recovered=existing_capture(w,run,selection,raw,record,intent)
 if capture_path.exists():
  previous=C.strict(capture_path.read_bytes());need(recovered is not None and previous==dict(schema='verification-coordinator-capture.v1',session_id=SID,run_id=run.name,source=selection,plan_sha256=plan_ref['sha256'],**recovered),'Existing capture receipt differs; preserve it')
 if recovered is None:
  need(not request_path.exists(),'Existing closure request has no matching capture; preserve it')
  CAP.capture(root/'research/archive',source,SID,root,start_line=selection['source_line'],end_line=selection['source_line'],run_id=run.name,max_bytes=MAX_SOURCE,archive_writer=SelectedWriter(w,run,selection,raw,intent))
  recovered=existing_capture(w,run,selection,raw,record,intent);need(recovered is not None,'Exact coordinator capture did not complete')
 capture_receipt=dict(schema='verification-coordinator-capture.v1',session_id=SID,run_id=run.name,source=selection,plan_sha256=plan_ref['sha256'],**recovered)
 C.save_once(capture_path,C.encode(capture_receipt))
 request={'schema':'verification-closure-request.v1','run_id':run.name,'session_id':SID,'boundary':C.BOUNDARY,
  'artifacts':plan['artifacts'],'implementation_files':plan['implementation_files'],
  'coordinator_evidence_event_ids':[recovered['raw_event_id']],'coverage_event_ids':list(dict.fromkeys(gate['coverage']+[recovered['coverage_event_id']])),
  'capture_plan':plan_ref,'capture_receipt':C.desc(root,capture_path),'capture_driver_files':plan['driver_files'],'capture_intent_event_id':intent['id']}
 C.save_once(request_path,C.encode(request))
 return C.close_with_writer(root,run,C.desc(root,request_path),w,allow_checkpoint_derived_updates=True)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,required=True);p.add_argument('--plan-sha256',required=True);p.add_argument('--allow-checkpoint-derived-updates',action='store_true');a=p.parse_args()
 need(isinstance(a.plan_sha256,str) and HEX.fullmatch(a.plan_sha256),'Exact capture plan SHA required')
 plan=a.plan.absolute();need(plan.is_relative_to(RUN/'closure'),'Capture plan must be inside the fixed run closure directory')
 ref=C.desc(ROOT,C.path(ROOT,str(plan.relative_to(ROOT))));need(ref['sha256']==a.plan_sha256,'Capture plan SHA changed')
 with B.Archive(ROOT/'research/archive').writer() as w:result=run_with_writer(ROOT,RUN,ref,w,allow_checkpoint_derived_updates=a.allow_checkpoint_derived_updates)
 print(json.dumps({'status':result['status'],'event_id':result['event_id'],'scientific_calls':0}))
if __name__=='__main__':main()
