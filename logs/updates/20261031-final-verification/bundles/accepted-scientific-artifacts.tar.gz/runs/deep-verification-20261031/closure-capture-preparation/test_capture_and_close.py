"""Synthetic temporary sources/archives only; no real native or scientific read."""
from pathlib import Path
import copy,importlib.util,json,tempfile,unittest
from unittest.mock import patch
HERE=Path(__file__).parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=module('capture_close_under_test',HERE/'capture_and_close.py')
fixtures=module('capture_close_fixtures',HERE.parent/'closure-preparation/test_closure.py')

class CaptureClosureTests(unittest.TestCase):
 def setUp(self):
  f=self.f=fixtures.TestClosure('test_full_preflight_preserves_twenty_distinct_attributions');f.setUp();old=f.sid;f.sid=m.SID
  f.events=[e for e in f.events if e['id'] not in {'coordinator-raw','coordinator-cover'}]
  for e in f.events:
   if e['session_id']==old:e['session_id']=m.SID
   e['delivery_key']=e['id'];e['timestamp']='2026-10-31T20:00:00Z'
  for key in ('source_ledger','contribution_matrix','decision'):f.update_art(key,lambda d:d.update(coordinator_session_id=m.SID))
  f.update_art('decision',lambda d:d.update(matrix_sha256=f.req['artifacts']['contribution_matrix']['sha256']))
  f.update_art('cards',lambda d:d.update(decision_sha256=f.req['artifacts']['decision']['sha256']))
  self.record={'timestamp':'2026-10-31T20:01:00Z','type':'response_item','payload':{'type':'message','role':'assistant','phase':'commentary','content':[{'type':'output_text','text':'Synthetic later coordinator explanation.'}]}}
  self.raw=m.C.encode(self.record).replace(b'\n',b'')+b'\n'
  first={'type':'session_meta','payload':{'id':m.SID,'cwd':str(f.root)}}
  hidden={'type':'response_item','payload':{'type':'message','role':'assistant','phase':'analysis','content':[{'type':'output_text','text':'SYNTHETIC_HIDDEN_NEVER_SELECTED'}]}}
  self.source=f.root/'synthetic.jsonl';self.source.write_bytes((json.dumps(first)+'\n'+json.dumps(hidden)+'\n').encode()+self.raw)
  self.selection={'source_line':3,'sha256':m.sha(self.raw)}
  contract=m.C.strict((HERE/'CAPTURE_CONTRACT.json').read_bytes())
  for rel in contract['files']:
   dst=f.root/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((m.ROOT/rel).read_bytes())
  drivers=[]
  for name in ('capture_and_close.py','test_capture_and_close.py','README.md','CAPTURE_CONTRACT.json'):
   drivers.append(f.write('closure-capture-preparation/'+name,(HERE/name).read_bytes()))
  self.plan={'schema':'verification-capture-closure-plan.v1','run_id':f.run.name,'session_id':m.SID,'source':self.selection,'artifacts':f.req['artifacts'],'implementation_files':f.req['implementation_files'],'driver_files':drivers}
  self.plan_ref=f.write('closure/CAPTURE_PLAN.json',self.plan);(f.run/'closure/REQUEST.json').unlink()
  self.w=fixtures.Writer(f.events,f.objects);self.capture_calls=0;self.real_close=m.C.close_with_writer
 def tearDown(self):self.f.tearDown()
 def save_plan(self):self.plan_ref=self.f.write('closure/CAPTURE_PLAN.json',self.plan)
 def intent(self):
  gate=m.metadata_gate(self.f.root,self.f.run,self.w._state['records']);plan=m.validate_plan(self.f.root,self.f.run,self.plan_ref)
  return m.bind_intent(self.f.root,self.f.run,self.plan_ref,plan,gate,self.w)
 def minimal_intent(self,w):
  return w.append({'kind':'research.verification.coordinator.capture_intent','actor':{'id':'synthetic','role':'tool'},'session_id':m.SID,'run_id':self.f.run.name,'operation_id':'synthetic','attempt_id':'synthetic','parents':[],'outputs':[],'payload':{}},'synthetic-intent')
 def fake_capture(self,*args,**kwargs):
  self.capture_calls+=1;w=self.w;intent=self.intent();digest=w.put(self.raw);line=self.selection['source_line'];record=self.record
  original=w.append({'kind':'capture.raw_record','actor':{'id':'codex:assistant','role':'assistant'},'session_id':m.SID,'run_id':self.f.run.name,'timestamp':record['timestamp'],'parents':[],'outputs':[digest],'payload':{'source_line':line,'raw_sha256':digest,'source_type':'message','call_id':None,'cwd_binding_verified':True}},f'codex-visible-v1:{m.SID}:{line}')
  report={'format':'codex-visible-selection.v1','session_id':m.SID,'run_id':self.f.run.name,'selected_range':[line,line],'reviewed_tool_lines':[],'captured_records':1,'status':'BOUNDED_COMPLETE','gaps':[],'excluded_counts':{},'tool_link_ids':[],'raw_records':[{'source_line':line,'sha256':digest,'bytes':len(self.raw)}],'raw_event_ids':[original['id']]}
  rh=w.put(m.C.encode(report));coverage=w.append({'kind':'capture.coverage','actor':{'id':'synthetic','role':'tool'},'session_id':m.SID,'run_id':self.f.run.name,'parents':[original['id'],intent['id']],'outputs':[rh],'payload':{'status':'BOUNDED_COMPLETE','report_sha256':rh}},'coverage:'+rh)
  return dict(report,coverage_event_id=coverage['id'])
 def close(self,*args,**kwargs):return self.real_close(*args,**kwargs,checkpoint_api=self.f.checkpoint)
 def run_capture(self,close=None):
  with patch.object(m.CAP,'resolve_session',return_value=self.source),patch.object(m.CAP,'capture',side_effect=self.fake_capture),patch.object(m,'SelectedWriter',return_value=object()),patch.object(m.C,'close_with_writer',side_effect=close or self.close):
   return m.run_with_writer(self.f.root,self.f.run,self.plan_ref,self.w,allow_checkpoint_derived_updates=True)
 def test_one_capture_and_full_frozen_closure_with_same_writer(self):
  result=self.run_capture();self.assertEqual(result['status'],'VERIFICATION_COMPLETE_BOUNDED');self.assertEqual(self.capture_calls,1)
  req=m.C.strict((self.f.run/'closure/REQUEST.json').read_bytes());self.assertEqual(len(req['coordinator_evidence_event_ids']),1);self.assertEqual(len(req['coverage_event_ids']),22)
  hidden_raw=self.source.read_bytes().splitlines(keepends=True)[1];self.assertNotIn(hidden_raw,self.w.objects.values())
  count=self.w.appends;again=self.run_capture();self.assertEqual(again,result);self.assertEqual(self.capture_calls,1);self.assertEqual(self.w.appends,count)
 def test_all_twenty_metadata_required_before_source_or_packets(self):
  self.w._state['records']=[e for e in self.w._state['records'] if e['id']!='accepted-V10-L']
  with patch.object(m,'validate_plan',side_effect=AssertionError('No plan/artifact reads before twenty')),patch.object(m.CAP,'resolve_session',side_effect=AssertionError('No native read before twenty')):
   with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual((self.w.puts,self.w.appends),(0,0))
 def test_wrong_original_transport_or_duplicate_session_rejected(self):
  for change in ('parent','session'):
   saved=copy.deepcopy(self.w._state['records']);e=next(e for e in self.w._state['records'] if e['id']=='accepted-V02-A')
   if change=='parent':e['parents']=['inputs','transport4']
   else:e['session_id']='fresh-session-V01-A'
   with self.assertRaises(m.C.Invalid):m.metadata_gate(self.f.root,self.f.run,self.w._state['records'])
   self.w._state['records']=saved
 def test_closure_failure_reuses_exact_capture_without_duplicate(self):
  def fail(*args,**kw):raise RuntimeError('synthetic closure interruption')
  with self.assertRaises(RuntimeError):self.run_capture(fail)
  self.assertFalse((self.f.run/'FINAL_RECEIPT.json').exists());self.assertTrue((self.f.run/'closure/COORDINATOR_CAPTURE.json').exists())
  self.assertEqual(self.run_capture()['status'],'VERIFICATION_COMPLETE_BOUNDED');self.assertEqual(self.capture_calls,1)
 def test_crash_before_local_capture_receipt_reuses_canonical_capture(self):
  self.fake_capture();self.assertFalse((self.f.run/'closure/COORDINATOR_CAPTURE.json').exists())
  self.assertEqual(self.run_capture()['status'],'VERIFICATION_COMPLETE_BOUNDED');self.assertEqual(self.capture_calls,1)
 def test_changed_plan_after_capture_before_local_receipt_is_rejected(self):
  self.fake_capture();original_events=len(self.w._state['records']);old_plan=copy.deepcopy(self.plan)
  self.plan['artifacts']=dict(self.plan['artifacts'],source_ledger=self.f.write('closure/new-ledger.json',{'changed':'synthetic'}));self.save_plan()
  with self.assertRaisesRegex(m.C.Invalid,'prior plan is immutable'):self.run_capture()
  self.assertEqual(len(self.w._state['records']),original_events);self.assertEqual(self.capture_calls,1);self.assertFalse((self.f.run/'FINAL_RECEIPT.json').exists())
  self.plan=old_plan;self.save_plan();self.assertEqual(self.run_capture()['status'],'VERIFICATION_COMPLETE_BOUNDED')
 def test_capture_intent_stores_exact_plan_and_dependency_objects(self):
  event=self.intent();self.assertEqual(event['payload']['scientific_results_accepted'],20);self.assertEqual(len(event['parents']),21)
  for ref in event['payload']['files']:self.assertEqual(self.w.get(ref['sha256']),m.C.read(self.f.root,ref))
  self.assertEqual(event['payload']['plan'],self.plan_ref)
 def test_conflicting_existing_plan_capture_receipt_or_request_preserved(self):
  self.fake_capture();p=self.f.run/'closure/REQUEST.json';p.write_text('preserve existing conflict')
  with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual(p.read_text(),'preserve existing conflict');self.assertFalse((self.f.run/'FINAL_RECEIPT.json').exists())
 def test_foreign_run_original_is_not_relabelled(self):
  self.fake_capture();e=next(e for e in self.w._state['records'] if e['kind']=='capture.raw_record' and e.get('payload',{}).get('source_line')==3);e['run_id']='other-run'
  with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual(self.capture_calls,1)
 def test_exact_source_hash_and_identity_required(self):
  with self.assertRaises(m.C.Invalid):m.source_record(self.source,self.f.root,dict(self.selection,sha256='0'*64))
  old=self.source.read_bytes();self.source.write_bytes(old.replace(m.SID.encode(),b'wrong-session'))
  with self.assertRaises(m.C.Invalid):m.source_record(self.source,self.f.root,self.selection)
 def test_selection_parses_only_identity_and_requested_line(self):
  actual=m.CAP.strict_json
  with patch.object(m.CAP,'strict_json',wraps=actual) as parser:
   raw,record=m.source_record(self.source,self.f.root,self.selection)
  self.assertEqual(raw,self.raw);self.assertEqual(parser.call_count,2);self.assertNotIn('SYNTHETIC_HIDDEN',str(record))
 def test_hidden_user_and_tool_source_are_ineligible(self):
  first=self.source.read_bytes().splitlines(keepends=True)[:2]
  for payload in ({'type':'message','role':'assistant','phase':'analysis','content':[{'type':'output_text','text':'synthetic'}]}, {'type':'message','role':'user','content':[{'type':'input_text','text':'synthetic'}]}, {'type':'function_call_output','call_id':'synthetic','output':'synthetic'}):
   record=dict(self.record,payload=payload);raw=(json.dumps(record)+'\n').encode();self.source.write_bytes(b''.join(first)+raw)
   with self.assertRaises(m.C.Invalid):m.source_record(self.source,self.f.root,dict(self.selection,sha256=m.sha(raw)))
 def test_selected_credential_is_not_accepted(self):
  record=copy.deepcopy(self.record);record['payload']['content'][0]['text']='ASIA'+'A'*16;raw=(json.dumps(record)+'\n').encode();self.source.write_bytes(b''.join(self.source.read_bytes().splitlines(keepends=True)[:2])+raw)
  with self.assertRaises(m.C.Invalid):m.source_record(self.source,self.f.root,dict(self.selection,sha256=m.sha(raw)))
 def test_symlink_source_and_destination_rejected(self):
  link=self.f.root/'source-link';link.symlink_to(self.source)
  with self.assertRaises(ValueError):m.source_record(link,self.f.root,self.selection)
  p=self.f.run/'closure/COORDINATOR_CAPTURE.json';p.symlink_to(self.f.run/'MANIFEST.json')
  with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual(self.capture_calls,0)
 def test_guard_rejects_different_record_before_object_write(self):
  archive=m.B.Archive(self.f.root/'guard/research/archive').init()
  with archive.writer() as w:
   intent=self.minimal_intent(w);guard=m.SelectedWriter(w,self.f.run,self.selection,self.raw,intent);before=set(w._state['present'])
   with self.assertRaises(m.C.Invalid):guard.put(self.raw.replace(b'explanation',b'changed'))
   self.assertEqual(set(w._state['present']),before)
   self.assertEqual(guard.put(self.raw),m.sha(self.raw))
   with self.assertRaises(m.C.Invalid):guard.append({'kind':'capture.tool_link','session_id':m.SID,'run_id':self.f.run.name,'payload':{}},'forbidden')
 def test_real_standard_capture_and_guard_recover_partial_tail_without_duplicate(self):
  root=self.f.root;(root/'LAB_PROFILE.json').write_bytes(m.C.encode({'lab':{'kind':'PHILOSOPHY_PROGRAM'}}));(root/'.lab').mkdir()
  (root/'.lab/philosophy.json').write_bytes(m.C.encode({'schema_version':1,'kernel':'philosophy.v1','archive_format':'research-archive.v1'}))
  archive=m.B.Archive(root/'research/archive').init()
  with archive.writer() as w:
   intent=self.minimal_intent(w)
   self.source.write_bytes(self.source.read_bytes()+b'{')
   with self.assertRaises(m.C.Invalid):m.CAP.capture(root/'research/archive',self.source,m.SID,root,start_line=3,end_line=3,run_id=self.f.run.name,archive_writer=m.SelectedWriter(w,self.f.run,self.selection,self.raw,intent))
   self.assertEqual(sum(e['kind']=='capture.raw_record' for e in w._state['records']),1)
   self.assertIsNone(m.existing_capture(w,self.f.run,self.selection,self.raw,self.record,intent))
   with self.source.open('ab') as stream:stream.write(b'}\n')
   report=m.CAP.capture(root/'research/archive',self.source,m.SID,root,start_line=3,end_line=3,run_id=self.f.run.name,archive_writer=m.SelectedWriter(w,self.f.run,self.selection,self.raw,intent))
   self.assertEqual(report['status'],'BOUNDED_COMPLETE');self.assertEqual(sum(e['kind']=='capture.raw_record' for e in w._state['records']),1)
   recovered=m.existing_capture(w,self.f.run,self.selection,self.raw,self.record,intent);self.assertEqual(recovered['coverage_event_id'],report['coverage_event_id'])
   hidden=self.source.read_bytes().splitlines(keepends=True)[1];self.assertNotIn(m.sha(hidden),w._state['present'])
 def test_no_derived_update_permission_means_no_capture(self):
  with self.assertRaises(m.C.Invalid):m.run_with_writer(self.f.root,self.f.run,self.plan_ref,self.w)
  self.assertEqual((self.w.puts,self.w.appends),(0,0))
 def test_dependency_drift_or_bad_plan_sid_fails_before_capture(self):
  self.plan['session_id']='another-coordinator';self.save_plan()
  with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual(self.capture_calls,0)
  self.plan['session_id']=m.SID;self.save_plan();(self.f.root/'scripts/capture_codex.py').write_text('changed')
  with self.assertRaises(m.C.Invalid):self.run_capture()
  self.assertEqual(self.capture_calls,0)
if __name__=='__main__':unittest.main()
