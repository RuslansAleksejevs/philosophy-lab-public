"""Narrow public-web wrapper validation; no generic code execution."""
from pathlib import Path
import hashlib
import ipaddress
import json
import re
import subprocess
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent / 'transport-repair-v2'
RUNTIME = json.loads((HERE / 'AST_RUNTIME.json').read_bytes())
DECLARATION = json.loads((HERE / 'ADDITIONAL_TOOLS.json').read_bytes())
_runtime_verified = False


def require(ok, message='Unsupported public web metadata'):
    if not ok: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def credential_safe(text):
    require(isinstance(text, str) and len(text.encode()) <= 2 * 1024 * 1024, 'Public text exceeds capture bound')
    patterns = (r'\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b',
                r'(?i)\bbearer\s+[A-Za-z0-9._~+/-]{12,}',
                r'\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b',
                r'(?i)(?:api_key|password|secret|authorization|bearer)\s*[:=]\s*[\"\x27]?[A-Za-z0-9_+/=-]{12,}')
    require(not any(re.search(p, text) for p in patterns), 'Credential-shaped public text excluded')
    return text


def public_url(value, reference=False):
    require(isinstance(value, str) and len(value) <= 8192)
    if reference and re.fullmatch(r'turn\d+[A-Za-z]+\d+', value): return value
    parts = urlsplit(value)
    require(parts.scheme in {'http','https'} and parts.hostname and not parts.username and not parts.password)
    host = parts.hostname.lower()
    require('.' in host and host != 'localhost' and not host.endswith(('.localhost','.local','.internal','.test','.invalid')))
    try: address = ipaddress.ip_address(host)
    except ValueError:
        require(re.fullmatch(r'[a-z0-9.-]+', host) is not None)
        require(not all(re.fullmatch(r'(?:[0-9]+|0x[0-9a-f]+)', part) for part in host.rstrip('.').split('.')))
    else: require(address.is_global)
    credential_safe(value)
    return value


def validate_args(args):
    commands = {'search_query','open','find','click','screenshot'}
    require(isinstance(args, dict) and args and set(args) <= commands | {'response_length'} and set(args) & commands)
    require(args.get('response_length','short') in {'short','medium','long'})
    actions = []
    for kind, rows in args.items():
        if kind == 'response_length': continue
        require(isinstance(rows,list) and 0 < len(rows) <= (4 if kind == 'search_query' else 20))
        for row in rows:
            require(isinstance(row,dict))
            allowed = {'search_query':{'q','domains','recency'},'open':{'ref_id','lineno'},'find':{'ref_id','pattern'},
                       'click':{'ref_id','id'},'screenshot':{'ref_id','pageno'}}[kind]
            require(set(row) <= allowed)
            if kind == 'search_query':
                require(isinstance(row.get('q'),str) and bool(row['q'].strip()))
                credential_safe(row['q'])
                if 'domains' in row:
                    require(isinstance(row['domains'],list) and len(row['domains']) <= 20)
                    for domain in row['domains']:
                        require(isinstance(domain,str) and '/' not in domain)
                        public_url('https://' + domain)
                if 'recency' in row: require(type(row['recency']) is int and row['recency'] > 0)
            else:
                public_url(row.get('ref_id'), reference=True)
                if kind == 'find': require(isinstance(row.get('pattern'),str) and bool(credential_safe(row['pattern'])))
                required_number = {'click':'id','screenshot':'pageno'}.get(kind)
                if required_number: require(type(row.get(required_number)) is int and row[required_number] >= 0)
                if 'lineno' in row: require(type(row['lineno']) is int and row['lineno'] >= 0)
            actions.append({'type':kind, **row})
    return actions


def parse_wrapper(code):
    global _runtime_verified
    credential_safe(code)
    require(len(code) <= 100000, 'Web wrapper exceeds parser bound')
    if not _runtime_verified:
        require(sha(Path(RUNTIME['node_path']).read_bytes()) == RUNTIME['node_sha256'], 'Node runtime changed')
        require(sha((HERE/'acorn.cjs').read_bytes()) == RUNTIME['parser_sha256'], 'AST parser changed')
        _runtime_verified = True
    result = subprocess.run([RUNTIME['node_path'], str(HERE/'parse_web_wrapper.cjs')],
                            input=json.dumps({'code':code}).encode(), stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=10)
    require(result.returncode == 0 and len(result.stdout) <= 1024*1024, 'Public web wrapper rejected')
    return validate_args(json.loads(result.stdout))


def declaration(payload):
    require(sorted(payload) == DECLARATION['payload_keys'] and payload['type']=='additional_tools'
            and payload['role']==DECLARATION['role'] and isinstance(payload['id'],str), 'Unexpected tools declaration')
    digest = sha(json.dumps(payload['tools'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    require(digest == DECLARATION['tools_sha256'], 'Runtime tools declaration changed')
    return {'tools_sha256':digest,'namespaces':DECLARATION['namespaces']}
