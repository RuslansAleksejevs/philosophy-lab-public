#!/usr/bin/env python3
"""Bounded SigV4 successor: preserve one completed failure and seven fresh slots.

--check replays originals in memory. Only root runs the audited writer. Old
V4/V5 code, accepted receipts, failures and source bytes remain unchanged.
"""
from pathlib import Path
import argparse,copy,hashlib,json,sys,time
sys.dont_write_bytecode=True
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1];LANE='archive-repair-v4-sigv4';REPAIR=RUN/LANE
V5_SHA='8698e982fba0859951f257385389f767bbce485c98e1440a9cc268d5a18120c2'
if hashlib.sha256((RUN/'archive_progress_v5.py').read_bytes()).hexdigest()!=V5_SHA:raise ValueError('Frozen V5 adapter changed')
sys.path.insert(0,str(RUN));import archive_progress_v5 as V5
B=V5.B;require=B.require;sha=B.sha;encoded=B.encoded;canon=B.canon;read=B.read;load=B.load;bound=B.bound;descriptor=B.descriptor
EXPECTED_IDS=['V07-L']+[f'V{i:02d}-{role}' for i in range(8,11) for role in ('A','L')]
STATUS='DEEP_VERIFICATION_SAFE_NATIVE_PROJECTION_ARCHIVED';EVENT='research.verification.native_projection_policy.accepted'
MANIFEST='SAFE_NATIVE_PROJECTION_MANIFEST.json';READY='SAFE_NATIVE_PROJECTION_ARCHIVE_READY.json';RECEIPT='SAFE_NATIVE_PROJECTION_START_RECEIPT.json'
STOP_REQUEST='ARCHIVE_PROGRESS_V6_STOP_REQUEST.json';NEW_STOP='STOP_V4_SIGV4_REPAIR.json';LIVE_MODE=False
SCOPE=('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids','failed_attempt','mechanical_native_preflight')

def setup(root=ROOT,run=RUN):
 ctx=V5.setup(root,run);repair=run/LANE;manifest_path=repair/MANIFEST;raw=read(manifest_path,root);V5.safe_file(raw,manifest_path.name);manifest=B.strict_json(raw)
 require(manifest.get('status')=='SAFE_NATIVE_PROJECTION_PREPARED','Native projection manifest not prepared')
 indexed={}
 for row in manifest['files']:
  data=bound(row,root);require(row['path'] not in indexed,'Duplicate native projection input');V5.safe_file(data,row['path']);indexed[row['path']]=row
 required=('archive_progress_v6.py','test_archive_progress_v6.py','resume_v4_sigv4.py','test_resume_v4_sigv4.py','archive_progress_v5.py',
  'archive-repair-v4/SAFE_WEB_PROJECTION_START_RECEIPT.json',LANE+'/signed_url_projection_v2.py',LANE+'/native_projection.py',LANE+'/test_native_projection.py',LANE+'/SIGNED_URL_POLICY_V2.json')
 for name in required:require(str((run/name).relative_to(root)) in indexed,'Missing native projection source: '+name)
 require(indexed[str((run/'archive_progress_v5.py').relative_to(root))]['sha256']==V5_SHA,'Unbound frozen predecessor')
 for key in SCOPE:
  if key=='resume_never_started_ids':continue
  row=manifest[key];require(indexed.get(row['path'])==row,'Unbound native projection scope evidence');bound(row,root)
 require(manifest['resume_never_started_ids']==EXPECTED_IDS,'Exactly seven never-started jobs required')
 require(manifest['preserved_stop']['path']==str((run/'STOP_V4_ARCHIVE_REPAIR.json').relative_to(root)),'Wrong preserved STOP')
 stop=B.strict_json(bound(manifest['preserved_stop'],root));require(stop.get('job_id')=='V05-L' and stop.get('reason')=='Credential-shaped public text excluded' and stop.get('automatic_retry') is False,'Wrong failed stop disposition')
 snapshot=B.strict_json(bound(manifest['prior_dispatch_snapshot'],root));require(snapshot.get('status')=='STOPPED_PRESERVED' and snapshot.get('active_ids')==[] and snapshot.get('pending_ids')==EXPECTED_IDS,'Old dispatcher not drained at exact seven pending')
 require(manifest['prior_dispatch_snapshot']['path']!=str((run/'process.json').relative_to(root)),'Mutable process snapshot prohibited')
 require(manifest['failed_attempt']['path']==str((run/'results/V05-L/attempt-001/failure.json').relative_to(root)),'Only original V05-L failure may be mechanically revalidated')
 preflight=B.strict_json(bound(manifest['mechanical_native_preflight'],root));require(preflight.get('status')=='ACTUAL_V05L_SIGV4_FIXED_PREFIX_REPLAY_PASS' and preflight.get('job_id')=='V05-L','Mechanical fixed-prefix preflight absent')
 require(set(preflight['original_files'])=={'failure.json','launch.json','stderr.json','visible-events.jsonl','structural-diagnostics.jsonl','final.txt'},'Mechanical original file inventory differs from reviewed six')
 for name,digest in preflight['original_files'].items():
  original_path=run/'results/V05-L/attempt-001'/name;rel=str(original_path.relative_to(root));require(rel in indexed and indexed[rel]==descriptor(original_path,root) and indexed[rel]['sha256']==digest,'Mechanical original file is not bound by policy manifest')
 hook=B.import_runner(repair/'native_projection.py',root);previous=load(run/'archive-repair-v4/SAFE_WEB_PROJECTION_START_RECEIPT.json',root)
 ctx.update(native_manifest=manifest,native_manifest_path=manifest_path,native_indexed=indexed,native_hook=hook,native_preflight=preflight,native_repair=repair,previous_projection=previous)
 return ctx

def safe_original_files(ctx,directory):
 root=ctx['root'];files=[]
 for path in sorted(directory.iterdir()):
  require(path.is_file() and not path.is_symlink(),'Unexpected original attempt entry')
  raw=read(path,root);require(path.suffix in {'.json','.jsonl','.txt','.md'},'Unknown original artifact extension');V5.safe_file(raw,path.name);files.append(descriptor(path,root))
 return files

def stdout_boundary(ctx,directory,receipt):
 rows=[B.strict_json(x) for x in read(directory/'structural-diagnostics.jsonl',ctx['root']).splitlines() if x] if (directory/'structural-diagnostics.jsonl').exists() else []
 metadata=dict(receipt,stdout_projection_complete=not rows,stdout_diagnostic_gap_count=len(rows),stdout_turn_completed=True,
   stdout_parse_gap_policy=B.STDOUT_POLICY,native_replay_authoritative=True,stdout_gap_total_bytes=sum(x['line_bytes'] for x in rows))
 # V4's mechanical branch was specifically for L3. Validate the same exact
 # new-format diagnostic rows using its unchanged ordinary-attempt branch.
 check=dict(metadata);check.pop('disposition',None);boundary=B.native_stdout_boundary(ctx,directory/'receipt.json',check)
 return metadata,boundary

def prepared_result(ctx,jid,policy_event,write=False):
 root,run,runner=ctx['root'],ctx['run'],ctx['runner'];job=ctx['jobs'][jid];attempt=run/'results'/jid/'attempt-001';mechanical=jid=='V05-L'
 require(mechanical or jid in EXPECTED_IDS,'Native projection only applies to exact repaired/fresh scope')
 original_path=attempt/('failure.json' if mechanical else 'receipt.json');original=load(original_path,root);B.safe(original,'original terminal')
 require(original.get('job_id')==jid and original.get('transport_version')==4,'Original job/runtime differs');runner.check_inputs(job,root)
 for recorded,requested in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:require(original.get(recorded)==job[requested],'Original requested inputs/configuration differ')
 sid=original.get('session_id');require(isinstance(sid,str) and B.re.fullmatch('[A-Za-z0-9_-]{8,100}',sid),'Original SID invalid')
 if mechanical:
  require(original.get('status')=='FAILED_PRESERVED_NO_RETRY' and original.get('error')=='Credential-shaped public text excluded' and original.get('automatic_retry') is False,'Only exact preserved formatter failure eligible')
  state=original.get('process_state',{});require(state.get('process_stopped') is True and state.get('stderr_drained') is True and type(state.get('exit_code')) is int and state['exit_code']==0 and state.get('forced_kill') is False,'Original failed attempt did not complete cleanly')
  require(all(not (attempt/name).exists() for name in ('receipt.json','native-check.json','native-visible.json','response.json')),'Mechanical repair cannot invent or replace original proof files')
  report=ctx['native_preflight'];require(report['session_id']==sid,'Mechanical preflight session differs');cutoff=report['native_source_prefix']
  require({p.name for p in attempt.iterdir()}==set(report['original_files']),'Mechanical original attempt inventory changed after preflight')
  for name,digest in report['original_files'].items():require(sha(read(attempt/name,root))==digest,'Mechanical original changed since preflight')
 else:
  require(original.get('status')==B.COMPLETE and not original.get('quality_flags') and type(original.get('cli_exit_code')) is int and original['cli_exit_code']==0 and original.get('visible_final_count')==1,'Future result is not cleanly complete')
  expected_outputs={x['path']:x['sha256'] for x in safe_original_files(ctx,attempt) if x['path']!=str(original_path.relative_to(root))}
  require(original.get('outputs')==expected_outputs,'Future original outputs must bind exactly its own complete attempt files')
  oldproof=load(attempt/'native-check.json',root);cutoff=oldproof.get('native_source_prefix');require('public_web_projection' in oldproof,'Fresh scoped job lacks reviewed native hook')
 proof,visible,finals=ctx['native_hook'].inspect_native(runner,sid,read(job['prompt_file'],root).decode(),job,root,cutoff=cutoff)
 require(not proof.get('isolation_failures') and proof.get('session_id')==sid and len(finals)==1,'Native isolation/final failed')
 ledger=proof['public_web_projection'];require(ledger.get('schema')=='native-public-web-projection.v2' and ledger.get('policy_id')==ctx['native_hook'].P.POLICY_ID and ledger.get('scientific_text_unchanged') is True and ledger.get('unsafe_intermediate_files_written') is False,'Native projection ledger invalid')
 final_path=attempt/'final.txt';final_raw=read(final_path,root);require(finals[0]['text'].encode()==final_raw,'Native final bytes differ from original final.txt')
 value=B.strict_json(final_raw);schema=load(job['schema_file'],root);runner.validate(value,schema)
 stderr=load(attempt/'stderr.json',root);require(type(stderr.get('exit_code')) is int and stderr['exit_code']==0,'Original stderr exit is not zero')
 stdout=[B.strict_json(x) for x in read(attempt/'visible-events.jsonl',root).splitlines() if x]
 starts=[x for x in stdout if x.get('type')=='thread.started'];completed=[x for x in stdout if x.get('type')=='turn.completed'];errors=[x['message'] for x in stdout if x.get('type') in {'error','turn.failed'}]
 require(len(starts)==1 and starts[0].get('thread_id')==sid and len(completed)==1 and not any(x.get('unexpected') for x in stdout),'Original stdout identity/completion differs')
 status,flags,classified=runner.classify(finals,stderr['lines'],final_raw.decode(),schema,errors,True,0,job)
 require(status==B.COMPLETE and not flags and canon(classified)==canon(value),'Original final classification not complete')
 if not mechanical:
  require(canon(proof)==canon(oldproof) and canon(visible)==canon(load(attempt/'native-visible.json',root)['records']),'Independent hooked native replay differs')
  require(canon(value)==canon(load(attempt/'response.json',root)),'Completed response differs')
  for name,digest in original['outputs'].items():require(sha(read(name,root))==digest,'Completed original output changed')
 files=safe_original_files(ctx,attempt);metadata,boundary=stdout_boundary(ctx,attempt,original)
 if not mechanical:
  for key in ('stdout_projection_complete','stdout_diagnostic_gap_count','stdout_turn_completed','stdout_parse_gap_policy','native_replay_authoritative','stdout_gap_total_bytes'):require(original.get(key)==metadata[key],'Original stdout boundary changed')
 else:
  metadata.update(status=B.COMPLETE,disposition='MECHANICAL_REVALIDATION_NO_MODEL_RERUN',additional_model_calls=0,
    original_attempt_receipt=descriptor(original_path,root),cli_exit_code=0,visible_final_count=1,quality_flags=[],mechanical_policy_event_sequence=policy_event['sequence'],
    mechanical_boundary='Original FAILED attempt remains preserved. Same native result revalidated without a model call; proof/visible/response below are newly derived safe artifacts, not files claimed to have existed in the failed attempt.')
 directory=run/'results'/jid/'native-projection-v2'
 def ref(name,raw):return {'path':str((directory/name).relative_to(root)),'sha256':sha(raw),'bytes':len(raw)}
 public=[('native-check.json',proof),('native-visible.json',{'session_id':sid,'records':visible}),('response.json',value)]
 public_refs=[ref(name,encoded(v)) for name,v in public]
 side={'schema':'archive-native-output-projection.v2','policy_id':ctx['native_hook'].P.POLICY_ID,'policy_event_id':policy_event['id'],'policy_manifest_sha256':sha(read(ctx['native_manifest_path'],root)),
  'job_id':jid,'session_id':sid,'native_source_prefix':proof['native_source_prefix'],'ledger':ledger,
  'mode':'MECHANICAL_REVALIDATION_FROM_FAILED_ATTEMPT' if mechanical else 'COMPLETED_NATIVE_PROJECTED_ATTEMPT',
  'original_attempt_receipt':descriptor(original_path,root),'original_receipt_status':original['status'],'original_proof_files_existed':not mechanical,
  'original_files':files,'public_files':public_refs,'unchanged_scientific_final':descriptor(final_path,root),'scientific_text_unchanged':True,'unsafe_intermediate_files_written':False,
  'boundary':'Original native source/record hashes identify the source. Only approved public response URLs are omitted before serialization. No original unsafe proof file or COMPLETE receipt is invented.'}
 side_ref=ref('PROJECTION.json',encoded(side));metadata['outputs']={x['path']:x['sha256'] for x in files+public_refs+[side_ref]}
 metadata['archive_projection']={'schema':side['schema'],'evidence':side_ref,'policy_event_id':policy_event['id'],'manifest_sha256':side['policy_manifest_sha256'],'scientific_text_unchanged':True}
 public += [('PROJECTION.json',side),('receipt.json',metadata)];receipt_ref=ref('receipt.json',encoded(metadata))
 for name,v in public:B.safe(v,name)
 if write:
  directory.mkdir(exist_ok=True);require(not directory.is_symlink(),'Projection directory symlink')
  for name,v in public:require(not (directory/name).is_symlink(),'Projection file symlink')
  for name,v in public:B.save_new(directory/name,v)
 messages=[x for x in visible if x.get('role')!='tool'];web=[B.safe_web(x) for x in visible if x.get('role')=='tool']
 require(messages and any(x.get('role')=='user' for x in messages) and any(x.get('phase') in {'final','final_answer'} for x in messages),'Prompt/final visible evidence missing')
 return {'job':job,'receipt':metadata,'receipt_path':directory/'receipt.json','session_id':sid,'files':files+public_refs+[side_ref,receipt_ref],'proof':proof,'messages':messages,'web':web,'value':value,'stdout_boundary':boundary,'projection':side,'projection_ref':side_ref,'projection_blobs':{ref(name,encoded(v))['path']:encoded(v) for name,v in public}}

def accept_policy(ctx,w):
 prior=B.canonical_event(w,ctx['previous_projection']['event_id']);require(prior['kind']=='research.verification.web_projection_policy.accepted' and prior['payload']['files']==ctx['previous_projection']['files'],'Prior V5 policy differs');B.verify_event_files(ctx,w,prior)
 runtime=B.canonical_event(w,ctx['runtime_receipt']['event_id']);require(runtime['kind']=='research.verification.transport_v4.accepted' and runtime['payload']['files']==ctx['runtime_receipt']['files'],'Original V4 runtime parent absent/different');B.verify_event_files(ctx,w,runtime)
 manifest=ctx['native_manifest'];files=list(manifest['files'])+[descriptor(ctx['native_manifest_path'],ctx['root'])];key=ctx['run'].name+':native-projection-policy:v2';existing=B.existing(w,key)
 if existing:
  require(existing['kind']==EVENT and existing['payload']['files']==files,'Existing native policy differs');B.verify_event_files(ctx,w,existing);event=existing
 else:
  for jid in EXPECTED_IDS:require(not (ctx['run']/'results'/jid/'attempt-001').exists(),'Declared fresh job already started')
  # Replay before admitting the new policy; no derived proof is written here.
  prepared_result(ctx,'V05-L',{'id':'READ_ONLY_POLICY_PREFLIGHT','sequence':0},write=False)
  for row in files:require(w.put(bound(row,ctx['root']))==row['sha256'],'Native policy object mismatch')
  prefix=str((ctx['run']/'results/V05-L/attempt-001').relative_to(ctx['root']))+'/'
  originals=[x for x in files if x['path'].startswith(prefix)];require(manifest['failed_attempt'] in originals,'Original failed attempt not among preserved files')
  failure_key=ctx['run'].name+':V05-L:mechanical-failure-preserved';failure=B.existing(w,failure_key)
  if failure:require(failure['payload']['files']==originals,'Existing mechanical failure differs');B.verify_event_files(ctx,w,failure)
  else:failure=w.append(B.request(ctx,'research.verification.mechanical_failure.preserved',ctx['native_preflight']['session_id'],'V05-L:failed',[prior['id'],runtime['id']],originals,{'status':'MECHANICAL_FAILURE_PRESERVED_NO_MODEL_RERUN','job_id':'V05-L','files':originals,'automatic_retry':False,'additional_model_calls':0}),failure_key)
  B.save_new(ctx['run']/'results/V05-L/FAILED_ATTEMPT_ARCHIVE_RECEIPT.json',B.receipt_from_event(failure))
  payload={'status':STATUS,'files':files,'manifest_sha256':sha(read(ctx['native_manifest_path'],ctx['root'])),**{k:manifest[k] for k in SCOPE},
    'mechanical_failure_event_id':failure['id'],'runtime_transport_version':4,'scientific_retries':False,'public_output_projection_before_serialization':True,'boundary':'One completed V05-L mechanical revalidation and exactly seven never-started jobs. Input/configuration/native identity/AST/final gates remain original V4; explicit public-response projection is the only runtime hook.'}
  event=w.append(B.request(ctx,EVENT,ctx['native_preflight']['session_id'],'native-projection-v2',[prior['id'],runtime['id'],failure['id']],files,payload),key)
 result={'status':STATUS,'event_id':event['id'],'event_sequence':event['sequence'],'event_sha256':event['sha256'],**{k:event['payload'][k] for k in ('files','manifest_sha256',*SCOPE)}}
 B.save_new(ctx['native_repair']/RECEIPT,result);return runtime,event

def accept_job(ctx,w,runtime,policy,jid,path=None):
 prior=B.existing(w,ctx['run'].name+':accepted-result:'+jid)
 if prior:
  B.verify_accepted(ctx,w,prior,jid,ctx['root']/prior['payload']['receipt']['path'])
  existing=ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json';require(existing.exists(),'Previously accepted result lost its receipt');retained=load(existing,ctx['root'])
  require(all(retained.get(k)==v for k,v in B.receipt_from_event(prior).items()),'Retained acceptance receipt differs');return prior
 require(jid not in {'V01-A','V02-A'},'Original accepted arguments cannot be recreated');B.require_smoke(ctx,w);B.require_original_arguments(ctx,w)
 hooked=jid=='V05-L' or jid in EXPECTED_IDS
 result=prepared_result(ctx,jid,policy,write=True) if hooked else B.validate_terminal(ctx,jid,path)
 sid=result['session_id'];scope=B.SessionWriter(w,sid,ctx['run'].name)
 for row in result['files']:require(w.put(bound(row,ctx['root']))==row['sha256'],'Safe result object mismatch')
 captures=[];web_ids=[]
 for message in result['messages']:
  coverage=B.capture(ctx['root']/'research/archive',B.resolve_session(sid,ctx['root']),sid,ctx['root'],start_line=message['line'],end_line=message['line'],run_id=ctx['run'].name,archive_writer=scope)
  require(coverage['status']=='BOUNDED_COMPLETE' and coverage['captured_records']==1 and coverage['raw_records'][0]['sha256']==message['record_sha256'],'Visible original capture failed');captures.append(coverage['coverage_event_id'])
 for record in result['web']:
  digest=w.put(encoded(record));payload={'status':'ACCEPTED_NORMALIZED_PUBLIC_WEB_EVIDENCE','job_id':jid,'fragment_sha256':digest,'source_line':record['line'],'source_record_sha256':record['record_sha256'],'type':record['type'],'boundary':'Public normalized evidence; any whole signed-URL omission is explicitly bound by the native projection ledger.'}
  if hooked:
   rows=[x for x in result['projection']['ledger']['records'] if x['source_line']==record['line']]
   payload.update(archive_projection=result['projection_ref'],signed_urls_omitted=bool(rows))
   if rows:payload.update(source_text_sha256=rows[0]['source_text_sha256'],source_text_bytes=rows[0]['source_text_bytes'])
  request=B.request(ctx,'research.verification.public_web_fragment',sid,jid+':web',[runtime['id'],policy['id']],[{'sha256':digest}],payload)
  if hooked:request['inputs']=[result['projection_ref']['sha256']]
  event=w.append(request,ctx['run'].name+':web:'+sid+':'+str(record['line'])+':'+record['record_sha256']+':native-projection-v2');web_ids.append(event['id'])
 payload={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':jid,'receipt':descriptor(result['receipt_path'],ctx['root']),'native_check':descriptor(result['receipt_path'].parent/'native-check.json',ctx['root']),'files':result['files'],'capture_event_ids':captures,'web_event_ids':web_ids,'scientific':True,'independence_verified':True,'whole_provider_capture':False,'stdout_boundary':result['stdout_boundary'],'boundary':'Exact fixed native prefix, original scientific final and V4 scientific inputs verified. Public output projection and mechanical origin, where applicable, remain explicit.'}
 if hooked:payload['archive_projection']=result['projection_ref']
 event=w.append(B.request(ctx,'research.verification.result.accepted',sid,jid+':accepted',[ctx['start']['event_id'],runtime['id'],policy['id']]+captures+web_ids,result['files'],payload),ctx['run'].name+':accepted-result:'+jid)
 B.save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',dict(B.receipt_from_event(event),event_sequence=event['sequence'],event_sha256=event['sha256']));return event

def stopped_request():
 path=RUN/STOP_REQUEST
 if not path.exists():return False
 value=load(path);require(set(value)=={'status','run_id','reason'} and value['status']=='STOP_AFTER_CURRENT_ACCEPTANCE' and value['run_id']==RUN.name and isinstance(value['reason'],str) and 0<len(value['reason'])<=2000,'Malformed administrative stop');B.safe(value,'stop');return True

def main(argv=None):
 global LIVE_MODE
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');p.add_argument('--wait-ready',action='store_true');p.add_argument('--until',type=int,default=20);p.add_argument('--timeout-seconds',type=int,default=21600);p.add_argument('--poll-seconds',type=int,default=5);args=p.parse_args(argv)
 require(not(args.check and args.wait_ready) and 0<=args.until<=20 and 1<=args.poll_seconds<=30 and 1<=args.timeout_seconds<=43200,'Invalid bounded command')
 if args.check:
  ctx=setup();report=[]
  for jid in sorted(ctx['scientific_ids']):
   path=B.terminal_path(ctx,jid)
   if jid=='V05-L' or path:
    if jid=='V05-L' or jid in EXPECTED_IDS:result=prepared_result(ctx,jid,{'id':'READ_ONLY_PREFLIGHT','sequence':0})
    else:result=V5.project_result(ctx,jid,path,{'id':'READ_ONLY_PREFLIGHT'},write=False)
    report.append({'job_id':jid,'session_id':result['session_id'],'omitted_urls':result.get('projection',{}).get('ledger',{}).get('omitted_url_count',0)})
  print(json.dumps({'status':'READ_ONLY_NATIVE_PROJECTION_CHECK_PASS','results':report,'canonical_writes':0,'projection_files_written':0,'provider_calls':0}));return 0
 LIVE_MODE=True;deadline=time.monotonic()+args.timeout_seconds;selfhash=sha(Path(__file__).read_bytes());ctx=None if args.wait_ready else setup();accepted=set()
 print('ONE_CANONICAL_AUDIT_STARTED',flush=True)
 with B.Archive(ROOT/'research/archive').writer() as writer:
  writer._ensure_audited();print('ONE_CANONICAL_AUDIT_COMPLETE',flush=True)
  if args.wait_ready:
   while not (REPAIR/READY).exists():
    if stopped_request():return 0
    if time.monotonic()>=deadline:print('INCOMPLETE_WAITING_FOR_READY_PRESERVED',flush=True);return 2
    time.sleep(args.poll_seconds)
   ready=load(REPAIR/READY);require(ready.get('status')=='READY_FOR_CANONICAL_SAFE_NATIVE_PROJECTION_ACCEPTANCE' and ready.get('manifest_sha256')==sha(read(REPAIR/MANIFEST)),'Invalid native projection ready gate');require(sha(Path(__file__).read_bytes())==selfhash,'Running adapter changed');ctx=setup()
  if stopped_request():return 0
  require(not (RUN/NEW_STOP).exists(),'New STOP preserved');runtime,policy=accept_policy(ctx,writer)
  while True:
   for jid in sorted(ctx['scientific_ids']):
    if stopped_request():print(json.dumps({'status':'ADMINISTRATIVE_STOP_PRESERVED','scientific_accepted':len(accepted)}),flush=True);return 0
    require(sha(Path(__file__).read_bytes())==selfhash,'Running adapter changed');require(not (RUN/NEW_STOP).exists(),'New STOP preserved')
    if jid in accepted:continue
    path=B.terminal_path(ctx,jid)
    if path or jid=='V05-L':
     event=accept_job(ctx,writer,runtime,policy,jid,path);accepted.add(jid);print(json.dumps({'status':'ARCHIVED','job_id':jid,'event_id':event['id']}),flush=True)
    elif (RUN/'results'/jid/'attempt-001/failure.json').exists():raise ValueError('New failed scientific attempt preserved: '+jid)
   if len(accepted)>=args.until:print(json.dumps({'status':'BOUNDED_ARCHIVE_TARGET_REACHED','scientific_accepted':len(accepted)}),flush=True);return 0
   if time.monotonic()>=deadline:print(json.dumps({'status':'INCOMPLETE_TIMEOUT_PRESERVED','scientific_accepted':len(accepted)}),flush=True);return 2
   time.sleep(args.poll_seconds)

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as exc:
  message=str(exc)[:1000]
  if B.contains_credential(message):message='Validation failed; credential-shaped details withheld'
  if LIVE_MODE and not (RUN/NEW_STOP).exists():B.save_new(RUN/NEW_STOP,{'status':'STOPPED_PRESERVED','job_id':'archive-progress','reason':message,'error_type':type(exc).__name__,'automatic_retry':False})
  print(json.dumps({'status':'ARCHIVE_PROGRESS_STOPPED_PRESERVED','error_type':type(exc).__name__,'error':message,'automatic_retry':False}),flush=True);sys.exit(2)
