#!/usr/bin/env python3
"""Accept only the completed V10-L exact-URL repair; no dispatcher or new jobs."""
from pathlib import Path
import argparse,hashlib,json,sys,time
sys.dont_write_bytecode=True
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1];LANE='archive-repair-v10-exact-url';REPAIR=RUN/LANE
V6_SHA='1b3e7e7e650e43fb31c25006e2a3697a4814c0a26998ed584b0162bcd8d21b1e'
if hashlib.sha256((RUN/'archive_progress_v6.py').read_bytes()).hexdigest()!=V6_SHA:raise ValueError('Frozen V6 adapter changed')
sys.path.insert(0,str(RUN));import archive_progress_v6 as V6
V5=V6.V5;B=V6.B;require=B.require;sha=B.sha;encoded=B.encoded;canon=B.canon;read=B.read;load=B.load;bound=B.bound;descriptor=B.descriptor
TARGET='V10-L';STATUS='DEEP_VERIFICATION_SAFE_NATIVE_PROJECTION_ARCHIVED';EVENT='research.verification.native_projection_policy.accepted'
MANIFEST='SAFE_V10_EXACT_URL_PROJECTION_MANIFEST.json';READY='SAFE_V10_EXACT_URL_PROJECTION_ARCHIVE_READY.json';RECEIPT='SAFE_V10_EXACT_URL_PROJECTION_START_RECEIPT.json'
STOP_REQUEST='ARCHIVE_PROGRESS_V7_STOP_REQUEST.json';NEW_STOP='STOP_V10_EXACT_URL_REPAIR.json';LIVE_MODE=False
SCOPE=('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','failed_attempt','mechanical_native_preflight','accepted_before','exact_rule')

def setup(root=ROOT,run=RUN):
 ctx=V6.setup(root,run);repair=run/LANE;path=repair/MANIFEST;raw=read(path,root);V5.safe_file(raw,path.name);manifest=B.strict_json(raw)
 require(manifest.get('status')=='SAFE_V10_EXACT_URL_PROJECTION_PREPARED','Exact V10 policy not prepared')
 indexed={}
 for row in manifest['files']:
  require(row['path'] not in indexed,'Duplicate exact policy file');data=bound(row,root);V5.safe_file(data,row['path']);indexed[row['path']]=row
 required=('archive_progress_v7.py','test_archive_progress_v7.py','archive_progress_v6.py',
  'archive-repair-v4-sigv4/SAFE_NATIVE_PROJECTION_START_RECEIPT.json',LANE+'/signed_url_projection_v3.py',LANE+'/native_projection_v3.py',LANE+'/test_native_projection_v3.py',LANE+'/EXACT_URL_RULE.json')
 for name in required:require(str((run/name).relative_to(root)) in indexed,'Missing exact V10 source: '+name)
 for key in SCOPE:
  if key=='accepted_before':continue
  row=manifest[key];require(indexed.get(row['path'])==row,'Unbound exact policy scope evidence')
 require(manifest['preserved_stop']['path']==str((run/'STOP_V4_SIGV4_REPAIR.json').relative_to(root)),'Wrong V6 STOP')
 stop=B.strict_json(bound(manifest['preserved_stop'],root));require(stop.get('job_id')==TARGET and stop.get('reason')=='Credential outside approved signed public response URL' and stop.get('automatic_retry') is False,'Wrong preserved failure')
 snapshot=B.strict_json(bound(manifest['prior_dispatch_snapshot'],root));require(snapshot.get('status')=='STOPPED_PRESERVED' and snapshot.get('active_ids')==[] and snapshot.get('pending_ids')==[],'Prior dispatcher not fully drained')
 require(manifest['prior_dispatch_snapshot']['path']!=str((run/'process.json').relative_to(root)),'Mutable process snapshot prohibited')
 expected=set(ctx['scientific_ids'])-{TARGET};receipts={}
 for ref in manifest['accepted_before']:
  require(indexed.get(ref['path'])==ref,'Unbound prior accepted receipt');value=B.strict_json(bound(ref,root));jid=value.get('job_id')
  require(jid in expected and jid not in receipts and value.get('status')=='DEEP_VERIFICATION_RESULT_ARCHIVED'
   and ref['path']==str((run/'results'/jid/'ARCHIVE_RECEIPT.json').relative_to(root)),'Prior acceptance inventory differs');receipts[jid]=value
 require(set(receipts)==expected and len(receipts)==19,'Exactly nineteen previous accepted results required')
 require(manifest['failed_attempt']['path']==str((run/'results'/TARGET/'attempt-001/failure.json').relative_to(root)),'Only original V10-L failed attempt eligible')
 require(manifest['exact_rule']['path']==str((repair/'EXACT_URL_RULE.json').relative_to(root)),'Wrong exact rule path')
 preflight=B.strict_json(bound(manifest['mechanical_native_preflight'],root));require(preflight.get('status')=='ACTUAL_V10L_EXACT_URL_FIXED_PREFIX_REPLAY_PASS' and preflight.get('job_id')==TARGET,'Missing actual V10 replay preflight')
 require(set(preflight['original_files'])=={'failure.json','launch.json','stderr.json','visible-events.jsonl','structural-diagnostics.jsonl','final.txt'},'Exact six original files required')
 for name,digest in preflight['original_files'].items():
  p=run/'results'/TARGET/'attempt-001'/name;ref=descriptor(p,root);require(indexed.get(ref['path'])==ref and ref['sha256']==digest,'Original V10 file not exactly manifest-bound')
 hook=B.import_runner(repair/'native_projection_v3.py',root);rule=B.strict_json(bound(manifest['exact_rule'],root))
 require(rule==hook.P.RULE and preflight['native_source_prefix']==rule['native_source_prefix'] and preflight['session_id']==rule['session_id'],'Exact source rule/preflight differs')
 previous=load(run/'archive-repair-v4-sigv4/SAFE_NATIVE_PROJECTION_START_RECEIPT.json',root)
 ctx.update(native_manifest=manifest,native_manifest_path=path,native_indexed=indexed,native_hook=hook,native_preflight=preflight,native_repair=repair,previous_projection=previous,accepted_before=receipts)
 return ctx

def safe_original_files(ctx,directory):
 root=ctx['root'];files=[]
 for path in sorted(directory.iterdir()):
  require(path.is_file() and not path.is_symlink(),'Unexpected original attempt entry')
  raw=read(path,root);require(path.suffix in {'.json','.jsonl','.txt','.md'},'Unknown original artifact extension');V5.safe_file(raw,path.name);files.append(descriptor(path,root))
 return files

def stdout_boundary(ctx,directory,receipt):
 rows=[B.strict_json(x) for x in read(directory/'structural-diagnostics.jsonl',ctx['root']).splitlines() if x] if (directory/'structural-diagnostics.jsonl').exists() else []
 metadata=dict(receipt,stdout_projection_complete=not rows,stdout_diagnostic_gap_count=len(rows),stdout_turn_completed=True,
   stdout_parse_gap_policy=B.STDOUT_POLICY,native_replay_authoritative=True,stdout_gap_total_bytes=sum(x['line_bytes'] for x in rows))
 # V4's mechanical branch was specifically for L3. Validate the same exact
 # new-format diagnostic rows using its unchanged ordinary-attempt branch.
 check=dict(metadata);check.pop('disposition',None);boundary=B.native_stdout_boundary(ctx,directory/'receipt.json',check)
 return metadata,boundary

def prepared_result(ctx,jid,policy_event,write=False):
 root,run,runner=ctx['root'],ctx['run'],ctx['runner'];job=ctx['jobs'][jid];attempt=run/'results'/jid/'attempt-001';mechanical=jid=='V10-L'
 require(mechanical,'Only the completed V10-L failure is eligible')
 original_path=attempt/('failure.json' if mechanical else 'receipt.json');original=load(original_path,root);B.safe(original,'original terminal')
 require(original.get('job_id')==jid and original.get('transport_version')==4,'Original job/runtime differs');runner.check_inputs(job,root)
 for recorded,requested in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:require(original.get(recorded)==job[requested],'Original requested inputs/configuration differ')
 sid=original.get('session_id');require(isinstance(sid,str) and B.re.fullmatch('[A-Za-z0-9_-]{8,100}',sid),'Original SID invalid')
 if mechanical:
  require(original.get('status')=='FAILED_PRESERVED_NO_RETRY' and original.get('error')=='Credential outside approved signed public response URL' and original.get('automatic_retry') is False,'Only exact preserved formatter failure eligible')
  state=original.get('process_state',{});require(state.get('process_stopped') is True and state.get('stderr_drained') is True and type(state.get('exit_code')) is int and state['exit_code']==0 and state.get('forced_kill') is False,'Original failed attempt did not complete cleanly')
  require(all(not (attempt/name).exists() for name in ('receipt.json','native-check.json','native-visible.json','response.json')),'Mechanical repair cannot invent or replace original proof files')
  report=ctx['native_preflight'];require(report['session_id']==sid,'Mechanical preflight session differs');cutoff=report['native_source_prefix']
  require({p.name for p in attempt.iterdir()}==set(report['original_files']),'Mechanical original attempt inventory changed after preflight')
  for name,digest in report['original_files'].items():require(sha(read(attempt/name,root))==digest,'Mechanical original changed since preflight')
 else:
  require(original.get('status')==B.COMPLETE and not original.get('quality_flags') and type(original.get('cli_exit_code')) is int and original['cli_exit_code']==0 and original.get('visible_final_count')==1,'Future result is not cleanly complete')
  expected_outputs={x['path']:x['sha256'] for x in safe_original_files(ctx,attempt) if x['path']!=str(original_path.relative_to(root))}
  require(original.get('outputs')==expected_outputs,'Future original outputs must bind exactly its own complete attempt files')
  oldproof=load(attempt/'native-check.json',root);cutoff=oldproof.get('native_source_prefix');require('public_web_projection' in oldproof,'Fresh scoped job lacks reviewed native hook')
 proof,visible,finals=ctx['native_hook'].inspect_native(runner,sid,read(job['prompt_file'],root).decode(),job,root,cutoff=cutoff)
 require(not proof.get('isolation_failures') and proof.get('session_id')==sid and len(finals)==1,'Native isolation/final failed')
 ledger=proof['public_web_projection'];require(ledger.get('schema')=='native-public-web-projection.v3' and ledger.get('policy_id')==ctx['native_hook'].P.POLICY_ID and ledger.get('scientific_text_unchanged') is True and ledger.get('unsafe_intermediate_files_written') is False,'Native projection ledger invalid')
 require(sid==ctx['native_hook'].P.RULE['session_id'] and ledger.get('exact_rule')==ctx['native_hook'].P.RULE
  and proof.get('native_source_prefix')==ctx['native_hook'].P.RULE['native_source_prefix'],'Exact V10 source rule differs')
 final_path=attempt/'final.txt';final_raw=read(final_path,root);require(finals[0]['text'].encode()==final_raw,'Native final bytes differ from original final.txt')
 value=B.strict_json(final_raw);schema=load(job['schema_file'],root);runner.validate(value,schema)
 stderr=load(attempt/'stderr.json',root);require(type(stderr.get('exit_code')) is int and stderr['exit_code']==0,'Original stderr exit is not zero')
 stdout=[B.strict_json(x) for x in read(attempt/'visible-events.jsonl',root).splitlines() if x]
 starts=[x for x in stdout if x.get('type')=='thread.started'];completed=[x for x in stdout if x.get('type')=='turn.completed'];errors=[x['message'] for x in stdout if x.get('type') in {'error','turn.failed'}]
 require(len(starts)==1 and starts[0].get('thread_id')==sid and len(completed)==1 and not any(x.get('unexpected') for x in stdout),'Original stdout identity/completion differs')
 status,flags,classified=runner.classify(finals,stderr['lines'],final_raw.decode(),schema,errors,True,0,job)
 require(status==B.COMPLETE and not flags and canon(classified)==canon(value),'Original final classification not complete')
 if not mechanical:
  require(canon(proof)==canon(oldproof) and canon(visible)==canon(load(attempt/'native-visible.json',root)['records']),'Independent hooked native replay differs')
  require(canon(value)==canon(load(attempt/'response.json',root)),'Completed response differs')
  for name,digest in original['outputs'].items():require(sha(read(name,root))==digest,'Completed original output changed')
 files=safe_original_files(ctx,attempt);metadata,boundary=stdout_boundary(ctx,attempt,original)
 if not mechanical:
  for key in ('stdout_projection_complete','stdout_diagnostic_gap_count','stdout_turn_completed','stdout_parse_gap_policy','native_replay_authoritative','stdout_gap_total_bytes'):require(original.get(key)==metadata[key],'Original stdout boundary changed')
 else:
  metadata.update(status=B.COMPLETE,disposition='MECHANICAL_REVALIDATION_NO_MODEL_RERUN',additional_model_calls=0,
    original_attempt_receipt=descriptor(original_path,root),cli_exit_code=0,visible_final_count=1,quality_flags=[],mechanical_policy_event_sequence=policy_event['sequence'],
    mechanical_boundary='Original FAILED attempt remains preserved. Same native result revalidated without a model call; proof/visible/response below are newly derived safe artifacts, not files claimed to have existed in the failed attempt.')
 directory=run/'results'/jid/'native-projection-v3'
 def ref(name,raw):return {'path':str((directory/name).relative_to(root)),'sha256':sha(raw),'bytes':len(raw)}
 public=[('native-check.json',proof),('native-visible.json',{'session_id':sid,'records':visible}),('response.json',value)]
 public_refs=[ref(name,encoded(v)) for name,v in public]
 side={'schema':'archive-native-output-projection.v3','policy_id':ctx['native_hook'].P.POLICY_ID,'policy_event_id':policy_event['id'],'policy_manifest_sha256':sha(read(ctx['native_manifest_path'],root)),
  'exact_rule':descriptor(ctx['native_repair']/'EXACT_URL_RULE.json',root),
  'job_id':jid,'session_id':sid,'native_source_prefix':proof['native_source_prefix'],'ledger':ledger,
  'mode':'MECHANICAL_REVALIDATION_FROM_FAILED_ATTEMPT' if mechanical else 'COMPLETED_NATIVE_PROJECTED_ATTEMPT',
  'original_attempt_receipt':descriptor(original_path,root),'original_receipt_status':original['status'],'original_proof_files_existed':not mechanical,
  'original_files':files,'public_files':public_refs,'unchanged_scientific_final':descriptor(final_path,root),'scientific_text_unchanged':True,'unsafe_intermediate_files_written':False,
  'boundary':'Original native source/record hashes identify the source. Only approved public response URLs are omitted before serialization. No original unsafe proof file or COMPLETE receipt is invented.'}
 side_ref=ref('PROJECTION.json',encoded(side));metadata['outputs']={x['path']:x['sha256'] for x in files+public_refs+[side_ref]}
 metadata['archive_projection']={'schema':side['schema'],'evidence':side_ref,'policy_event_id':policy_event['id'],'manifest_sha256':side['policy_manifest_sha256'],'scientific_text_unchanged':True}
 public += [('PROJECTION.json',side),('receipt.json',metadata)];receipt_ref=ref('receipt.json',encoded(metadata))
 for name,v in public:B.safe(v,name)
 if write:
  directory.mkdir(exist_ok=True);require(not directory.is_symlink(),'Projection directory symlink')
  for name,v in public:require(not (directory/name).is_symlink(),'Projection file symlink')
  for name,v in public:B.save_new(directory/name,v)
 messages=[x for x in visible if x.get('role')!='tool'];web=[B.safe_web(x) for x in visible if x.get('role')=='tool']
 require(messages and any(x.get('role')=='user' for x in messages) and any(x.get('phase') in {'final','final_answer'} for x in messages),'Prompt/final visible evidence missing')
 return {'job':job,'receipt':metadata,'receipt_path':directory/'receipt.json','session_id':sid,'files':files+public_refs+[side_ref,receipt_ref],'proof':proof,'messages':messages,'web':web,'value':value,'stdout_boundary':boundary,'projection':side,'projection_ref':side_ref,'projection_blobs':{ref(name,encoded(v))['path']:encoded(v) for name,v in public}}

def verify_previous(ctx,w):
 require(len(ctx['accepted_before'])==19 and TARGET not in ctx['accepted_before'],'Wrong prior accepted scope')
 for jid,receipt in ctx['accepted_before'].items():
  event=B.canonical_event(w,receipt['event_id'])
  require(event['kind']=='research.verification.result.accepted' and event['run_id']==ctx['run'].name and event['payload'].get('job_id')==jid,'Prior accepted event differs')
  B.verify_accepted(ctx,w,event,jid,ctx['root']/event['payload']['receipt']['path'])
  require(all(receipt.get(k)==v for k,v in B.receipt_from_event(event).items()),'Prior accepted receipt differs')

def accept_policy(ctx,w):
 verify_previous(ctx,w)
 prior=B.canonical_event(w,ctx['previous_projection']['event_id'])
 require(prior['kind']==EVENT and prior['payload']['files']==ctx['previous_projection']['files'],'Prior V6 policy differs');B.verify_event_files(ctx,w,prior)
 runtime=B.canonical_event(w,ctx['runtime_receipt']['event_id'])
 require(runtime['kind']=='research.verification.transport_v4.accepted' and runtime['payload']['files']==ctx['runtime_receipt']['files'],'Original V4 runtime differs');B.verify_event_files(ctx,w,runtime)
 manifest=ctx['native_manifest'];files=list(manifest['files'])+[descriptor(ctx['native_manifest_path'],ctx['root'])]
 key=ctx['run'].name+':native-projection-policy:v3:V10-L';event=B.existing(w,key)
 if event:
  require(event['kind']==EVENT and event['payload']['files']==files and event['payload'].get('exact_rule')==manifest['exact_rule'],'Existing exact V10 policy differs');B.verify_event_files(ctx,w,event)
 else:
  prepared_result(ctx,TARGET,{'id':'READ_ONLY_POLICY_PREFLIGHT','sequence':0},write=False)
  for row in files:require(w.put(bound(row,ctx['root']))==row['sha256'],'Exact policy object mismatch')
  prefix=str((ctx['run']/'results'/TARGET/'attempt-001').relative_to(ctx['root']))+'/'
  originals=[x for x in files if x['path'].startswith(prefix)]
  require(len(originals)==6 and manifest['failed_attempt'] in originals,'Exact six original files not preserved')
  failure_key=ctx['run'].name+':V10-L:mechanical-failure-preserved';failure=B.existing(w,failure_key)
  if failure:
   require(failure['kind']=='research.verification.mechanical_failure.preserved' and failure['payload']['files']==originals,'Existing V10 failure differs');B.verify_event_files(ctx,w,failure)
  else:
   payload={'status':'MECHANICAL_FAILURE_PRESERVED_NO_MODEL_RERUN','job_id':TARGET,'files':originals,'automatic_retry':False,'additional_model_calls':0}
   failure=w.append(B.request(ctx,'research.verification.mechanical_failure.preserved',ctx['native_preflight']['session_id'],TARGET+':failed',[prior['id'],runtime['id']],originals,payload),failure_key)
  B.save_new(ctx['run']/'results'/TARGET/'FAILED_ATTEMPT_ARCHIVE_RECEIPT.json',B.receipt_from_event(failure))
  payload={'status':STATUS,'files':files,'manifest_sha256':sha(read(ctx['native_manifest_path'],ctx['root'])),**{k:manifest[k] for k in SCOPE},
   'mechanical_failure_event_id':failure['id'],'runtime_transport_version':4,'scientific_retries':False,'additional_model_calls':0,'public_output_projection_before_serialization':True,
   'boundary':'Only the completed V10-L failure is mechanically revalidated. Exact source/URL rule; original final and nineteen accepted results unchanged. No dispatcher or new model call.'}
  event=w.append(B.request(ctx,EVENT,ctx['native_preflight']['session_id'],'native-projection-v3',[prior['id'],runtime['id'],failure['id']],files,payload),key)
 result={'status':STATUS,'event_id':event['id'],'event_sequence':event['sequence'],'event_sha256':event['sha256'],**{k:event['payload'][k] for k in ('files','manifest_sha256',*SCOPE)}}
 B.save_new(ctx['native_repair']/RECEIPT,result);return runtime,event

def accept_job(ctx,w,runtime,policy):
 jid=TARGET;prior=B.existing(w,ctx['run'].name+':accepted-result:'+jid)
 if prior:
  B.verify_accepted(ctx,w,prior,jid,ctx['root']/prior['payload']['receipt']['path'])
  retained=load(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',ctx['root'])
  require(all(retained.get(k)==v for k,v in B.receipt_from_event(prior).items()),'Retained V10 acceptance differs');return prior
 B.require_smoke(ctx,w);B.require_original_arguments(ctx,w)
 result=prepared_result(ctx,jid,policy,write=True);sid=result['session_id'];scope=B.SessionWriter(w,sid,ctx['run'].name)
 for row in result['files']:require(w.put(bound(row,ctx['root']))==row['sha256'],'Safe result object mismatch')
 captures=[];web_ids=[]
 for message in result['messages']:
  coverage=B.capture(ctx['root']/'research/archive',B.resolve_session(sid,ctx['root']),sid,ctx['root'],start_line=message['line'],end_line=message['line'],run_id=ctx['run'].name,archive_writer=scope)
  require(coverage['status']=='BOUNDED_COMPLETE' and coverage['captured_records']==1 and coverage['raw_records'][0]['sha256']==message['record_sha256'],'Original visible capture failed');captures.append(coverage['coverage_event_id'])
 for record in result['web']:
  digest=w.put(encoded(record));rows=[x for x in result['projection']['ledger']['records'] if x['source_line']==record['line']]
  payload={'status':'ACCEPTED_NORMALIZED_PUBLIC_WEB_EVIDENCE','job_id':jid,'fragment_sha256':digest,'source_line':record['line'],'source_record_sha256':record['record_sha256'],'type':record['type'],
   'archive_projection':result['projection_ref'],'signed_urls_omitted':bool(rows),'boundary':'Exact V10 public output projection; source identities and omission ledger retained.'}
  if rows:payload.update(source_text_sha256=rows[0]['source_text_sha256'],source_text_bytes=rows[0]['source_text_bytes'])
  request=B.request(ctx,'research.verification.public_web_fragment',sid,jid+':web',[runtime['id'],policy['id']],[{'sha256':digest}],payload);request['inputs']=[result['projection_ref']['sha256']]
  event=w.append(request,ctx['run'].name+':web:'+sid+':'+str(record['line'])+':'+record['record_sha256']+':native-projection-v3');web_ids.append(event['id'])
 payload={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':jid,'receipt':descriptor(result['receipt_path'],ctx['root']),'native_check':descriptor(result['receipt_path'].parent/'native-check.json',ctx['root']),
  'files':result['files'],'capture_event_ids':captures,'web_event_ids':web_ids,'scientific':True,'independence_verified':True,'whole_provider_capture':False,
  'stdout_boundary':result['stdout_boundary'],'archive_projection':result['projection_ref'],'boundary':'Same completed V10-L result, exact final bytes and frozen V4 scientific inputs verified. Single exact public URL exception is explicit; no model rerun.'}
 event=w.append(B.request(ctx,'research.verification.result.accepted',sid,jid+':accepted',[ctx['start']['event_id'],runtime['id'],policy['id']]+captures+web_ids,result['files'],payload),ctx['run'].name+':accepted-result:'+jid)
 B.save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',dict(B.receipt_from_event(event),event_sequence=event['sequence'],event_sha256=event['sha256']));return event

def stopped_request():
 path=RUN/STOP_REQUEST
 if not path.exists():return False
 value=load(path);require(set(value)=={'status','run_id','reason'} and value['status']=='STOP_AFTER_CURRENT_ACCEPTANCE' and value['run_id']==RUN.name and isinstance(value['reason'],str) and 0<len(value['reason'])<=2000,'Malformed administrative stop');B.safe(value,'stop');return True

def main(argv=None):
 global LIVE_MODE
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');parser.add_argument('--wait-ready',action='store_true');parser.add_argument('--timeout-seconds',type=int,default=21600);parser.add_argument('--poll-seconds',type=int,default=5);args=parser.parse_args(argv)
 require(not(args.check and args.wait_ready) and 1<=args.timeout_seconds<=43200 and 1<=args.poll_seconds<=30,'Invalid bounded command')
 if args.check:
  ctx=setup();result=prepared_result(ctx,TARGET,{'id':'READ_ONLY_PREFLIGHT','sequence':0})
  print(json.dumps({'status':'READ_ONLY_V10_EXACT_URL_CHECK_PASS','job_id':TARGET,'session_id':result['session_id'],'previous_accepted_receipts':len(ctx['accepted_before']),'omitted_urls':result['projection']['ledger']['omitted_url_count'],'canonical_writes':0,'projection_files_written':0,'provider_calls':0}));return 0
 LIVE_MODE=True;deadline=time.monotonic()+args.timeout_seconds;selfhash=sha(Path(__file__).read_bytes());ctx=None if args.wait_ready else setup()
 print('ONE_CANONICAL_AUDIT_STARTED',flush=True)
 with B.Archive(ROOT/'research/archive').writer() as writer:
  writer._ensure_audited();print('ONE_CANONICAL_AUDIT_COMPLETE',flush=True)
  if args.wait_ready:
   while not (REPAIR/READY).exists():
    if stopped_request():return 0
    if time.monotonic()>=deadline:print('INCOMPLETE_WAITING_FOR_READY_PRESERVED',flush=True);return 2
    time.sleep(args.poll_seconds)
   ready=load(REPAIR/READY);require(ready.get('status')=='READY_FOR_CANONICAL_V10_EXACT_URL_PROJECTION_ACCEPTANCE' and ready.get('manifest_sha256')==sha(read(REPAIR/MANIFEST)),'Invalid exact V10 ready gate')
   require(sha(Path(__file__).read_bytes())==selfhash,'Running adapter changed');ctx=setup()
  if stopped_request():return 0
  require(not (RUN/NEW_STOP).exists(),'New STOP preserved');runtime,policy=accept_policy(ctx,writer)
  require(sha(Path(__file__).read_bytes())==selfhash and not (RUN/NEW_STOP).exists(),'Adapter drift or new STOP')
  if stopped_request():return 0
  event=accept_job(ctx,writer,runtime,policy)
  print(json.dumps({'status':'BOUNDED_ARCHIVE_TARGET_REACHED','scientific_accepted':20,'newly_accepted_job_id':TARGET,'event_id':event['id'],'additional_model_calls':0}),flush=True);return 0

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as exc:
  message=str(exc)[:1000]
  if B.contains_credential(message):message='Validation failed; credential-shaped details withheld'
  if LIVE_MODE and not (RUN/NEW_STOP).exists():B.save_new(RUN/NEW_STOP,{'status':'STOPPED_PRESERVED','job_id':TARGET,'reason':message,'error_type':type(exc).__name__,'automatic_retry':False})
  print(json.dumps({'status':'ARCHIVE_PROGRESS_STOPPED_PRESERVED','error_type':type(exc).__name__,'error':message,'automatic_retry':False}),flush=True);sys.exit(2)

