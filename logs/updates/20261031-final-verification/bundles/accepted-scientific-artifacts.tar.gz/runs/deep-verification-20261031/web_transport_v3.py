"""Role-bound declaration supplement; all v2 public-web limits remain exact."""
from web_transport_v2 import *

ROLE_DECLARATIONS = json.loads((Path(__file__).resolve().parent / 'transport-repair-v3/DECLARATIONS_BY_ROLE.json').read_bytes())['roles']


def declaration(payload, job):
    role = job.get('role')
    require(role in ROLE_DECLARATIONS, 'Unknown declaration role')
    expected = ROLE_DECLARATIONS[role]
    require(job.get('web_search') == expected['web_search'], 'Declaration/web setting mismatch')
    require(sorted(payload) == expected['payload_keys'] and payload['type']=='additional_tools'
            and payload['role']==expected['role'] and isinstance(payload['id'],str), 'Unexpected tools declaration')
    digest = sha(json.dumps(payload['tools'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    require(digest == expected['tools_sha256'], 'Runtime tools declaration changed for assigned role')
    return {'tools_sha256':digest,'namespaces':expected['namespaces']}
