# V3: role-bound runtime declarations and bounded stdout diagnostics

V2 and both failed technical attempts remain immutable. Neither failure contains
the excluded stdout line; its format remains unknown. The second structural
record cannot distinguish a parse failure from parsed JSON null. Therefore the
null-placeholder explanation is a hypothesis, not an observed diagnosis.

The completed argument sessions have the same exact `additional_tools` hash:
`8d991c3724fb3ebe11a2df1b71ca0379d2fc5b1237fba5249e1b587c8612b56e`.
The live-web technical session has a different exact hash:
`7f85b1c706a394298334946d576c06095df14d01356366ab6ecbf8390ae6f0ea`.
`DECLARATIONS_BY_ROLE.json` binds each to its role and web setting. A hash for
one role cannot satisfy the other. Declaration bodies are not exported.

`READ_ONLY_REPLAY_CHECK.json` records successful mechanical replay of both
finished A sessions: exact prompt/configuration, no foreign user input or
forbidden calls, one final, valid schema, and equal native/file JSON. This was
an in-memory technical comparison; report content was not displayed or judged.
It is not canonical result acceptance and did not create replacement attempts.

## Narrow stdout handling

Only successfully parsed JSON `null` becomes a transport placeholder. It has no
semantic/tool authority. Final acceptance still requires normal process exit,
`turn.completed`, exact native prompt/configuration, one valid final and matching
output file. Literature additionally requires allowed paired public-web output.

SMOKE-L3 alone has `technical_stdout_diagnostics=true`. A JSON-parse failure may
then be skipped after saving only SHA-256, byte count, parser exception class
and whether the stripped line equals `null`. No raw line is saved or displayed.
Unknown parsed executable/tool events still stop. No scientific job may enable
this diagnostic continuation. A technical result reports its stdout gap count.

If L3 succeeds in native web validation but has nonzero diagnostic gaps, it
proves web capability only. Scientific dispatch remains blocked until a later
explicitly bound format disposition. Parsed null placeholders have gap count
zero. There is no generic relaxation for scientific stdout parsing.

## Exact scope

`jobs_v3.json` contains the twenty exact V2 scientific job dictionaries and one
new technical SMOKE-L3. All argument inputs and manuscripts remain unchanged.
The ten literature prompts retain only the already recorded V2 neutral
transport appendix; V3 adds nothing to them. L3 has the same public-document
task as L2, with its technical ID/schema changed and diagnostic flag added.

`STOP_DISPOSITION_V3.json` binds both old STOPs and both failed attempts.
Canonical V3 acceptance disposes only those exact hashes; new failures write
`STOP_V3.json`. Old STOPs, attempts, code and receipts are never overwritten.

## Gates and commands owned by root

Root's new archive adapter consumes `TRANSPORT_V3_MANIFEST.json` and a
`TRANSPORT_V3_ARCHIVE_READY.json` marker with status
`READY_FOR_CANONICAL_TRANSPORT_V3_ACCEPTANCE` and the exact manifest SHA. It
checks the prior canonical V2 receipt and writes `TRANSPORT_V3_START_RECEIPT.json`
with status `DEEP_VERIFICATION_TRANSPORT_V3_ARCHIVED`, event ID and all exact
input references. The old archive adapter is not hot-patched.

After that canonical receipt exists, root mechanically validates the original
finished outputs, with no model calls:

```sh
python3 -B runs/deep-verification-20261031/revalidate_existing_v3.py --ids V01-A V02-A
```

New proof/response/receipt files go only into `results/JOB/revalidation-v3/`.
The archive adapter independently verifies and accepts them. It preserves each
original failure as evidence; it does not rerun either argument audit.

Root then runs the single technical probe:

```sh
python3 -B runs/deep-verification-20261031/runner_v3.py --workers 1 --ids SMOKE-L3
```

Scientific dispatch requires both canonical original-argument revalidations and
`WEB_SMOKE_ACCEPTED_V3.json` for SMOKE-L3, with completed official-page evidence
and zero stdout diagnostic gaps. Root then selects only the eighteen remaining
unstarted scientific IDs. Existing attempts are never automatically retried.

The adapter supports a bounded administrative stop request separately from
research failures; see its documented schema. Only one canonical writer may
run at a time. All settings remain Astra/ultra/default and subscription-only.
No manuscript change, submission, scientific repeat or paid API is introduced.
