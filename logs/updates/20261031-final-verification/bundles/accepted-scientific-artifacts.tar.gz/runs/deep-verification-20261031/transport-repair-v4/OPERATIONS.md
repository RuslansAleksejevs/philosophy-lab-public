# Transport V4: completed L3, no new probe

Actual L3 completed with exit 0. Its strict validation failed because native web output is a list of exact input_text blocks, not a string. V4 joins all observed text blocks in order, scans the full result, and keeps the existing 2 MiB output bound. Two web calls and both paired outputs, one final, schema, exact final-file equality, requested configuration and official page redirect were independently replayed successfully. The fixed native prefix is bound in ACTUAL_L3_PREFLIGHT.json.

The manifest-bound method amendment makes the native replay authoritative for actual inputs, tools and final output. Optional CLI stdout JSON parse gaps retain only SHA-256, byte count and safe error metadata. Parsed unknown tools still stop. Acceptance requires every issued web call to have a unique paired result, exit 0, known turn completion and all native checks. A maximum of 512 gaps, 16 MiB total and 256 KiB per line allows a substantial literature search without relaxing native isolation. Nonzero gaps are explicitly reported as incomplete stdout projection. The original four L3 gap records are preserved; their original ValueError categories are unavailable. This is bounded visible capture, not whole-provider capture.

All V1/V2/V3 code, failures and STOP files remain intact. V01-A/V02-A retain their accepted V3 results. The 20 scientific jobs and the same completed SMOKE-L3 job exactly match V3. No fourth technical probe or scientific rerun is allowed.

After TRANSPORT_V4_START_RECEIPT.json is canonical:

    python3 -B runs/deep-verification-20261031/revalidate_existing_v4.py --ids SMOKE-L3

This writes a separate mechanical revalidation receipt under results/SMOKE-L3/revalidation-v4 and makes zero model calls. The running archive_progress_v4 writer then accepts it and creates WEB_SMOKE_ACCEPTED_V4.json. Only after that gate may the remaining 18 scientific jobs run, once each:

    python3 -B runs/deep-verification-20261031/runner_v4.py --ids V03-A V04-A V05-A V06-A V07-A V08-A V09-A V10-A V01-L V02-L V03-L V04-L V05-L V06-L V07-L V08-L V09-L V10-L --workers 2

The parent controls dispatch and canonical writes. New failure creates STOP_V4.json; there are no automatic retries. DECLARATIONS_BY_ROLE.json in this folder is an exact bound copy of the still-imported V3 role declarations.
