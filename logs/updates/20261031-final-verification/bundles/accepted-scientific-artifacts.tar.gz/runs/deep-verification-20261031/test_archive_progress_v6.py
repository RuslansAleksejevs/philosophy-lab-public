"""Synthetic mechanical acceptance; no live sources, writers or model calls."""
from pathlib import Path
import copy,importlib.util,json,tempfile,types,unittest
from unittest.mock import patch
HERE=Path(__file__).parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=module('native_adapter_test',HERE/'archive_progress_v6.py');F=module('native_adapter_fixture',HERE/'test_archive_progress_v4.py')
N=module('native_adapter_hook',HERE/'archive-repair-v4-sigv4/native_projection.py')
U=module('native_adapter_policy_fixture',HERE/'archive-repair-v4-sigv4/test_native_projection.py')
class NativeAdapterTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.ctx,path,self.proof,self.visible=F.Tests.terminal_fixture(self)
  old=path.parent.parent;new=old.with_name('V05-L');old.rename(new);self.attempt=new/'attempt-001';oldreceipt=p.load(self.attempt/'receipt.json',self.root)
  job=self.ctx['jobs'].pop('JOB');job.update(id='V05-L',role='literature');self.ctx['jobs']['V05-L']=job;self.ctx['scientific_ids']={'V05-L'}
  for name in ('receipt.json','native-check.json','native-visible.json','response.json'):(self.attempt/name).unlink()
  self.failure={k:oldreceipt[k] for k in ('session_id','transport_version','prompt_sha256','schema_sha256','requested_model','requested_effort','requested_service_tier')}
  self.failure.update(job_id='V05-L',status='FAILED_PRESERVED_NO_RETRY',error='Credential-shaped public text excluded',automatic_retry=False,process_state={'process_stopped':True,'stderr_drained':True,'exit_code':0,'forced_kill':False})
  (self.attempt/'failure.json').write_bytes(p.encoded(self.failure));(self.attempt/'final.txt').write_bytes(self.visible[-1]['text'].encode())
  (self.attempt/'stderr.json').write_bytes(p.encoded({'lines':[],'exit_code':0}));(self.attempt/'visible-events.jsonl').write_bytes(b''.join(p.encoded(x).replace(b'\n',b'')+b'\n' for x in [{'type':'thread.started','thread_id':self.proof['session_id']},{'type':'turn.completed'}]))
  self.url=U.signed_url();original='Public response ('+self.url+'). Text kept.';safe,omissions=N.P.project_text(original)
  web={'line':3,'record_sha256':'d'*64,'role':'tool','type':'public_web_output','call_id':'c1','status':'completed','text':safe};self.visible.insert(1,web);self.proof['public_web_calls']=[web]
  ledger={'schema':'native-public-web-projection.v2','policy_id':N.P.POLICY_ID,'session_id':self.proof['session_id'],'source_output_records':1,'omitted_url_count':1,'scientific_text_unchanged':True,'unsafe_intermediate_files_written':False,'records':[{'source_line':3,'source_record_sha256':'d'*64,'call_id':'c1','source_text_sha256':p.sha(original.encode()),'source_text_bytes':len(original.encode()),'omissions':omissions,'omission_count':1}]};self.proof['public_web_projection']=ledger
  self.ctx['native_hook']=types.SimpleNamespace(P=N.P,inspect_native=lambda *a,**kw:(self.proof,self.visible,[self.visible[-1]]))
  self.ctx['runner'].classify=lambda *a,**kw:(p.B.COMPLETE,[],{'verdict':'pass'})
  manifest=self.ctx['run']/'native-manifest.json';manifest.write_text('{}');self.ctx['native_manifest_path']=manifest
  self.refresh_preflight();self.policy={'id':'synthetic-policy','sequence':100}
 def tearDown(self):self.tmp.cleanup()
 def refresh_preflight(self):self.ctx['native_preflight']={'session_id':self.proof['session_id'],'native_source_prefix':self.proof['native_source_prefix'],'original_files':{x.name:p.sha(x.read_bytes()) for x in self.attempt.iterdir()}}
 def prepare(self,write=False,jid='V05-L'):return p.prepared_result(self.ctx,jid,self.policy,write=write)
 def failure_change(self,change):
  change(self.failure);(self.attempt/'failure.json').write_bytes(p.encoded(self.failure));self.refresh_preflight()
 def future(self):
  jid='V07-L';old=self.attempt.parent;new=old.with_name(jid);old.rename(new);self.attempt=new/'attempt-001';(self.attempt/'failure.json').unlink()
  job=self.ctx['jobs'].pop('V05-L');job['id']=jid;self.ctx['jobs'][jid]=job
  for name,value in [('native-check.json',self.proof),('native-visible.json',{'session_id':self.proof['session_id'],'records':self.visible}),('response.json',{'verdict':'pass'})]:(self.attempt/name).write_bytes(p.encoded(value))
  receipt={k:self.failure[k] for k in ('session_id','transport_version','prompt_sha256','schema_sha256','requested_model','requested_effort','requested_service_tier')}
  receipt.update(job_id=jid,status=p.B.COMPLETE,quality_flags=[],cli_exit_code=0,visible_final_count=1,stdout_projection_complete=True,stdout_diagnostic_gap_count=0,stdout_turn_completed=True,stdout_parse_gap_policy=p.B.STDOUT_POLICY,native_replay_authoritative=True,stdout_gap_total_bytes=0,outputs={str(x.relative_to(self.root)):p.sha(x.read_bytes()) for x in self.attempt.iterdir()})
  (self.attempt/'receipt.json').write_bytes(p.encoded(receipt));return jid,receipt
 def test_mechanical_preflight_safe_honest_and_no_files_written(self):
  before={x.name:x.read_bytes() for x in self.attempt.iterdir()};r=self.prepare();self.assertEqual(before,{x.name:x.read_bytes() for x in self.attempt.iterdir()});self.assertFalse(r['receipt_path'].parent.exists())
  self.assertFalse(r['projection']['original_proof_files_existed']);self.assertEqual(r['projection']['original_receipt_status'],'FAILED_PRESERVED_NO_RETRY');self.assertEqual(r['receipt']['disposition'],'MECHANICAL_REVALIDATION_NO_MODEL_RERUN');self.assertEqual(r['receipt']['additional_model_calls'],0)
  self.assertIn('failure.json',[Path(x['path']).name for x in r['files']]);self.assertFalse(p.B.contains_credential(r));self.assertNotIn(self.url,str(r))
 def test_source_replay_failure_or_final_drift_cannot_be_rescued(self):
  self.ctx['native_hook'].inspect_native=lambda *a,**k:(_ for _ in ()).throw(ValueError('Native prefix changed'))
  with self.assertRaises(ValueError):self.prepare()
  self.ctx['native_hook'].inspect_native=lambda *a,**k:(self.proof,self.visible,[self.visible[-1]])
  (self.attempt/'final.txt').write_text('{"verdict":"changed"}');self.refresh_preflight()
  with self.assertRaises(ValueError):self.prepare()
 def test_only_exact_completed_formatter_failure_is_eligible(self):
  for change in (lambda d:d.update(error='other failure'),lambda d:d['process_state'].update(exit_code=1),lambda d:d['process_state'].update(forced_kill=True),lambda d:d.update(automatic_retry=True)):
   old=copy.deepcopy(self.failure);self.failure_change(change)
   with self.assertRaises(ValueError):self.prepare()
   self.failure=old;self.failure_change(lambda d:None)
 def test_existing_original_proof_or_complete_receipt_never_overwritten(self):
  for name in ('receipt.json','native-check.json','native-visible.json','response.json'):
   f=self.attempt/name;f.write_text('{}')
   with self.assertRaises(ValueError):self.prepare()
   self.assertEqual(f.read_text(),'{}');f.unlink()
 def test_original_hash_or_unbound_added_file_stops(self):
  f=self.attempt/'stderr.json';f.write_bytes(p.encoded({'lines':['changed'],'exit_code':0}))
  with self.assertRaises(ValueError):self.prepare()
  self.refresh_preflight();(self.attempt/'unbound.txt').write_text('unbound additional original')
  with self.assertRaises(ValueError):self.prepare()
 def test_stdout_missing_completed_unknown_flag_and_diagnostic_stage_stop(self):
  file=self.attempt/'visible-events.jsonl';before=file.read_bytes();file.write_text(json.dumps({'type':'thread.started','thread_id':self.proof['session_id']})+'\n');self.refresh_preflight()
  with self.assertRaises(ValueError):self.prepare()
  file.write_bytes(before);(self.attempt/'structural-diagnostics.jsonl').write_text(json.dumps({'line_sha256':'a'*64,'line_bytes':100,'exact_json_null':False,'error_class':'ValueError','error_category':'INVALID_JSON','stage':'visible_projection'})+'\n');self.refresh_preflight()
  with self.assertRaises(ValueError):self.prepare()
 def test_parse_gap_is_preserved_honestly(self):
  row={'line_sha256':'a'*64,'line_bytes':100,'exact_json_null':False,'error_class':'ValueError','error_category':'DUPLICATE_KEY','stage':'json_parse'}
  (self.attempt/'structural-diagnostics.jsonl').write_text(json.dumps(row)+'\n');self.refresh_preflight();r=self.prepare()
  self.assertFalse(r['receipt']['stdout_projection_complete']);self.assertEqual(r['receipt']['stdout_diagnostic_gap_count'],1);self.assertEqual(r['stdout_boundary']['stdout_gap_total_bytes'],100)
 def test_public_writes_idempotent_all_child_symlinks_prechecked(self):
  r=self.prepare(write=True);d=r['receipt_path'].parent;before={x.name:x.read_bytes() for x in d.iterdir()};self.prepare(write=True);self.assertEqual(before,{x.name:x.read_bytes() for x in d.iterdir()})
  for x in list(d.iterdir()):x.unlink()
  target=self.ctx['run']/'untouched';target.write_text('original');(d/'receipt.json').symlink_to(target)
  with patch.object(p.B,'save_new',side_effect=AssertionError('No partial publication')):
   with self.assertRaises(ValueError):self.prepare(write=True)
  self.assertEqual(target.read_text(),'original');self.assertEqual(len(list(d.iterdir())),1)
 def test_future_hooked_output_requires_exact_original_bindings(self):
  jid,receipt=self.future();self.assertTrue(self.prepare(jid=jid)['projection']['original_proof_files_existed'])
  del receipt['outputs'][str((self.attempt/'native-check.json').relative_to(self.root))];(self.attempt/'receipt.json').write_bytes(p.encoded(receipt))
  with self.assertRaises(ValueError):self.prepare(jid=jid)
 def test_future_independent_proof_or_response_drift_stops(self):
  jid,_=self.future();self.ctx['native_hook'].inspect_native=lambda *a,**k:(dict(self.proof,changed=True),self.visible,[self.visible[-1]])
  with self.assertRaises(ValueError):self.prepare(jid=jid)
 def test_outside_finite_scope_cannot_use_hook(self):
  self.ctx['jobs']['V06-L']=dict(self.ctx['jobs']['V05-L'],id='V06-L')
  with self.assertRaises(ValueError):self.prepare(jid='V06-L')
 def test_actual_temp_acceptance_puts_only_safe_objects_and_reuses(self):
  archive=p.B.Archive(self.root/'research/archive').init();sid=self.proof['session_id'];stored=[]
  def ev(kind,s='coordinator',payload=None,parents=()):return {'kind':kind,'session_id':s,'run_id':self.ctx['run'].name,'actor':{'id':'synthetic','role':'tool'},'operation_id':'synthetic','attempt_id':'synthetic','parents':list(parents),'payload':payload or {}}
  with archive.writer() as w:
   start=w.append(ev('research.verification.inputs.accepted'),'start');runtime=w.append(ev('research.verification.transport_v4.accepted'),'runtime');policy=w.append(ev(p.EVENT),'policy');self.ctx['start']={'event_id':start['id'],'bindings':{k:[] for k in ('method','instruction','config','input')}}
   by={x['line']:x for x in self.visible if x['role']!='tool'}
   def capture(*a,**kw):
    line=kw['start_line'];e=w.append(ev('capture.coverage',sid,{'status':'BOUNDED_COMPLETE'}),'coverage:'+str(line));return {'status':'BOUNDED_COMPLETE','captured_records':1,'raw_records':[{'sha256':by[line]['record_sha256']}],'coverage_event_id':e['id']}
   original=w.put
   def put(raw):stored.append(raw);return original(raw)
   with patch.object(w,'put',side_effect=put),patch.object(p.B,'require_smoke'),patch.object(p.B,'require_original_arguments'),patch.object(p.B,'resolve_session',return_value=Path('unused')),patch.object(p.B,'capture',side_effect=capture):result=p.accept_job(self.ctx,w,runtime,policy,'V05-L')
   self.assertFalse(any(p.B.contains_credential(x.decode()) for x in stored));self.assertNotIn(self.url.encode(),b''.join(stored));self.assertIn(policy['id'],result['parents']);self.assertIn('archive_projection',result['payload'])
   receipt=p.load(self.ctx['run']/'results/V05-L/ARCHIVE_RECEIPT.json',self.root);self.assertEqual(receipt['event_sequence'],result['sequence']);self.assertEqual(receipt['event_sha256'],result['sha256']);count=len(w._state['records'])
   with patch.object(p,'prepared_result',side_effect=AssertionError('Do not replay an already accepted result')):same=p.accept_job(self.ctx,w,runtime,policy,'V05-L')
   self.assertEqual(same['id'],result['id']);self.assertEqual(len(w._state['records']),count)
if __name__=='__main__':unittest.main()
