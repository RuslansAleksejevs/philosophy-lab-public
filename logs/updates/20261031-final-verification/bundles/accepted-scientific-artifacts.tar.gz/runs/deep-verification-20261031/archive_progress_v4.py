#!/usr/bin/env python3
"""Accept a bounded review run through one audited writer; never dispatch work.

--check is read-only. Normal mode preserves all attempts and STOP files, accepts
the reviewed transport transition, then accepts complete immutable results.
"""
from pathlib import Path
from urllib.parse import urlsplit
import argparse, collections, copy, contextlib, datetime, hashlib, importlib.util, json, os, re, sys, time
sys.dont_write_bytecode=True
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from research_archive import Archive, _ArchiveWriter, ArchiveError
from capture_codex import capture, resolve_session, strict_json
from collector_safety import contains_credential

COMPLETE='COMPLETE_LOCAL_PENDING_CANONICAL_ARCHIVE'
STOP_REQUEST='ARCHIVE_PROGRESS_V4_STOP_REQUEST.json'
STDOUT_POLICY='NATIVE_AUTHORITATIVE_PARSE_GAPS_V4'
HEX=re.compile('[0-9a-f]{64}\\Z')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(x):return (json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def require(ok,reason):
 if not ok:raise ValueError(reason)
def regular(name,root=ROOT):
 p=Path(name);p=p if p.is_absolute() else root/p;p=p.absolute()
 require(p.is_relative_to(root.absolute()) and '..' not in p.parts,'Outside bound root')
 require(p.is_file() and not any(x.is_symlink() for x in (p,*p.parents)),'Nonregular/symlink source')
 return p
def read(name,root=ROOT):return regular(name,root).read_bytes()
def load(name,root=ROOT):return strict_json(read(name,root))
def bound(row,root=ROOT):
 require(isinstance(row,dict) and isinstance(row.get('path'),str) and HEX.fullmatch(row.get('sha256','')),'Invalid file descriptor')
 raw=read(row['path'],root);require(sha(raw)==row['sha256'],'Bound file changed: '+row['path'])
 if 'bytes' in row:require(len(raw)==row['bytes'],'Bound size changed')
 return raw
def descriptor(path,root=ROOT):
 p=regular(path,root);raw=p.read_bytes();return {'path':str(p.relative_to(root)),'sha256':sha(raw),'bytes':len(raw)}
def save_new(path,value):
 raw=encoded(value)
 if path.exists():require(path.read_bytes()==raw,'Existing receipt differs');return
 with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 fd=os.open(path.parent,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def forbidden(x):
 if isinstance(x,dict):
  if {'timestamp','type','payload'}<=set(x) or set(x)&{'encrypted_content','base_instructions','system_prompt','developer_prompt'}:return True
  if isinstance(x.get('type'),str) and x['type'] in {'reasoning','thinking','redacted_thinking'}:return True
  return any(forbidden(v) for v in x.values())
 return isinstance(x,list) and any(forbidden(v) for v in x)
def safe(value,label):
 require(not contains_credential(value),'Credential-shaped content: '+label)
 require(not forbidden(value),'Native/hidden record: '+label)

class SessionWriter(_ArchiveWriter):
 """A view of the same live capability, never a replacement archive writer.

 capture() needs all exact-SID originals/links plus the round start. Include
 every event of this run too (inputs/bindings). Global append validation, unique
 IDs, delivery keys, object checks and durable writes stay in the base writer.
 """
 def __init__(self,base,sid,run_id):
  require(isinstance(base,_ArchiveWriter),'Live archive writer required')
  base._ensure_audited();self.base=base;self.root=base.root;self.sid=sid;self.run_id=run_id;self.offset=0;self.rows=[]
 def _ensure_open(self):self.base._ensure_open()
 def _ensure_audited(self):self.base._ensure_audited()
 def events(self):
  self._ensure_open()
  records=self.base._state['records']
  for e in records[self.offset:]:
   if e['session_id']==self.sid or e['run_id']==self.run_id:self.rows.append(e)
  self.offset=len(records)
  return copy.deepcopy(self.rows)
 def get(self,digest):return self.base.get(digest)
 def put(self,raw):return self.base.put(raw)
 def append(self,event,delivery_key):return self.base.append(event,delivery_key)
 def append_many(self,entries):return self.base.append_many(entries)

def import_runner(path,root=ROOT):
 p=regular(path,root);spec=importlib.util.spec_from_file_location('accepted_runner_'+sha(p.read_bytes())[:16],p)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def job_transition(old,new,instruction,root=ROOT):
 if canon(old)==canon(new):return
 changed={key for key in set(old)|set(new) if canon(old.get(key))!=canon(new.get(key))}
 require(old.get('role')=='literature' and changed=={'prompt_file','prompt_sha256'},'Substantive scientific job changed')
 oldraw=read(old['prompt_file'],root);newraw=read(new['prompt_file'],root)
 require(sha(oldraw)==old['prompt_sha256'] and sha(newraw)==new['prompt_sha256'],'Prompt amendment hash mismatch')
 require(newraw==oldraw+instruction,'Prompt amendment is not the exact neutral appendix')

def stop_requested(run=RUN,root=ROOT):
 path=run/STOP_REQUEST
 if not path.exists():return None
 value=load(path,root)
 require(set(value)=={'status','run_id','reason'} and value.get('status')=='STOP_AFTER_CURRENT_ACCEPTANCE'
         and value.get('run_id')==run.name and isinstance(value.get('reason'),str)
         and 0<len(value['reason'])<=2000,'Malformed administrative stop request')
 safe(value,'administrative stop request')
 return {'status':'ADMINISTRATIVE_STOP_PRESERVED','request':descriptor(path,root),
         'archive_writer_released_on_exit':True,'automatic_retry':False}

def setup(root=ROOT,run=RUN,manifest_name='TRANSPORT_V4_MANIFEST.json'):
 start=load(run/'START_RECEIPT.json',root)
 require(start.get('status')=='DEEP_VERIFICATION_INPUTS_ARCHIVED' and start.get('event_id'),'Input acceptance missing')
 manifest=load(run/manifest_name,root)
 require(manifest.get('status')=='TRANSPORT_V4_PREPARED_NOT_DISPATCHED','Transport manifest not prepared')
 require(isinstance(manifest.get('files'),list) and manifest['files'],'Transport file manifest missing')
 indexed={}
 for row in manifest['files']:
  raw=bound(row,root);require(row['path'] not in indexed,'Duplicate transport file');indexed[row['path']]=row
 require(str((run/'runner_v4.py').relative_to(root)) in indexed,'Runner v4 not bound')
 require(str((run/'jobs_v4.json').relative_to(root)) in indexed,'Queue v4 not bound')
 require(str((run/'archive_progress_v4.py').relative_to(root)) in indexed and str((run/'test_archive_progress_v4.py').relative_to(root)) in indexed,'Archiver and tests must be bound')
 required=('START_RECEIPT.json','jobs.json','jobs_v2.json','jobs_v3.json','runner_v3.py','TRANSPORT_V3_START_RECEIPT.json','TRANSPORT_V3_MANIFEST.json','STOP_DISPOSITION_V4.json',
           'web_transport_v4.py','revalidate_existing_v4.py','test_runner_v4.py','transport-repair-v4/DECLARATIONS_BY_ROLE.json',
           'transport-repair-v4/STDOUT_NATIVE_AUTHORITY_POLICY.json',
           'results/V01-A/ARCHIVE_RECEIPT.json','results/V02-A/ARCHIVE_RECEIPT.json')
 for name in required:require(str((run/name).relative_to(root)) in indexed,'Required V4 input not bound: '+name)
 prior=load(run/'TRANSPORT_V3_START_RECEIPT.json',root)
 require(prior.get('status')=='DEEP_VERIFICATION_TRANSPORT_V3_ARCHIVED' and prior.get('event_id') and isinstance(prior.get('files'),list),'Prior V3 acceptance missing')
 for row in prior['files']:bound(row,root)
 runner=import_runner(run/'runner_v4.py',root)
 queue=load(run/'jobs_v4.json',root);jobs=queue['jobs'] if isinstance(queue,dict) else queue
 scientific=load(run/'jobs.json',root);scientific=scientific['jobs'] if isinstance(scientific,dict) else scientific
 expected={j['id']:j for j in scientific};actual={j['id']:j for j in jobs}
 require(len(expected)==20 and len(actual)==len(jobs) and set(actual)==set(expected)|{'SMOKE-L3'},'Queue must contain exactly20 original jobs plus smokeL3')
 instruction_path=str((run/'transport-repair-v2/TRANSPORT_INSTRUCTION.txt').relative_to(root))
 require(instruction_path in indexed,'Neutral instruction not bound')
 instruction=bound(indexed[instruction_path],root)
 for jid,j in expected.items():job_transition(j,actual[jid],instruction,root)
 previous=load(run/'jobs_v3.json',root);previous=previous['jobs'] if isinstance(previous,dict) else previous
 previous={j['id']:j for j in previous}
 require(set(previous)==set(actual) and all(canon(actual[jid])==canon(previous[jid]) for jid in actual),'V4 queue must preserve all V3 jobs including the same L3 probe')
 for job in jobs:runner.check_job(job);runner.check_inputs(job,root)
 for job in jobs:
  for field in ('prompt','schema'):
   require(job[field+'_file'] in indexed and indexed[job[field+'_file']]['sha256']==job[field+'_sha256'],'Job input not bound by V4 manifest')
 disposition=load(run/'STOP_DISPOSITION_V4.json',root)
 require(disposition.get('action')=='PRESERVE_FAILED_TECHNICAL_ATTEMPTS_AND_REVALIDATE_COMPLETED_L3'
         and disposition.get('scientific_retries') is False and disposition.get('technical_retries') is False and disposition.get('revalidate_job_id')=='SMOKE-L3'
         and disposition.get('new_stop_filename')=='STOP_V4.json','Wrong V4 stop disposition')
 failures={}
 for jid,stop,key,failed in [('SMOKE-L','STOP.json','preserved_stop','failed_attempt'),('SMOKE-L2','STOP_V2.json','preserved_v2_stop','failed_v2_attempt'),('SMOKE-L3','STOP_V3.json','preserved_v3_stop','failed_v3_attempt')]:
  for field,name in [(key,stop),(failed,'results/'+jid+'/attempt-001/failure.json')]:
   rel=str((run/name).relative_to(root));row=disposition.get(field,{})
   require(row.get('path')==rel and rel in indexed and row.get('sha256')==indexed[rel]['sha256'],'Historical stop/failure not bound')
   bound(row,root)
  failure=load(run/'results'/jid/'attempt-001/failure.json',root);stopped=load(run/stop,root)
  require(failure.get('job_id')==jid and failure.get('status')=='FAILED_PRESERVED_NO_RETRY'
          and stopped.get('job_id')==jid and not runner.actual_quota(stopped.get('reason','')),'Only exact nonquota technical smoke failure may be disposed')
  failures[jid]=failure
 return {'root':root,'run':run,'start':start,'manifest':manifest,'manifest_path':run/manifest_name,'indexed':indexed,
         'runner':runner,'jobs':actual,'scientific_ids':set(expected),'failures':failures,'prior':prior}

def terminal_path(ctx,jid):
 run=ctx['run'];version='revalidation-v4' if jid=='SMOKE-L3' else 'revalidation-v3' if jid in {'V01-A','V02-A'} else None
 if version:
  repair=run/'results'/jid/version/'receipt.json'
  if repair.exists():return repair
 normal=run/'results'/jid/'attempt-001/receipt.json'
 return normal if normal.exists() else None

def safe_web(record):
 require(record.get('role')=='tool' and type(record.get('line')) is int and record['line']>0 and HEX.fullmatch(record.get('record_sha256','')),'Invalid web source identity')
 kind=record.get('type')
 if kind=='web_search_call':
  allowed={'line','record_sha256','role','type','id','status','action'}
  require(set(record)==allowed,'Unexpected builtin web fields')
  require(record['action'].get('type') in {'search','open_page','find_in_page'},'Unknown web action')
 elif kind=='public_web_call':
  require(set(record)<={'line','record_sha256','role','type','call_id','actions','status'} and isinstance(record.get('call_id'),str)
          and isinstance(record.get('actions'),list) and record['actions'] and record.get('status')=='issued','Unexpected public wrapper call fields')
 elif kind=='public_web_output':
  require(set(record)<={'line','record_sha256','role','type','call_id','text','status'} and isinstance(record.get('call_id'),str)
          and isinstance(record.get('text'),str) and record.get('status')=='completed','Unexpected public wrapper output fields')
 else:raise ValueError('Unapproved public tool kind')
 safe(record,'public web evidence');return record

def official(url):
 if not isinstance(url,str):return False
 p=urlsplit(url)
 return p.scheme=='https' and p.hostname in {'developers.openai.com','platform.openai.com','openai.com','www.openai.com'} and not p.username and not p.password
def official_smoke(proof,value):
 original_url='https://developers.openai.com/codex/noninteractive'
 redirect_url='https://learn.chatgpt.com/docs/non-interactive-mode'
 redirected=value.get('url')==redirect_url and value.get('page_title')=='Non-interactive mode | ChatGPT Learn'
 require(value.get('read_complete') is True and value.get('source_access_status')=='OPENED' and (official(value.get('url')) or redirected),'Smoke did not claim successful official open')
 records=proof.get('public_web_calls',[]);outputs={r.get('call_id'):r for r in records if r.get('type')=='public_web_output'}
 for r in records:
  if not redirected and r.get('type')=='web_search_call' and r.get('status')=='completed' and r.get('action',{}).get('type')=='open_page' and official(r['action'].get('url')):return True
  if r.get('type')!='public_web_call':continue
  output=outputs.get(r.get('call_id'));opened=False
  for action in r.get('actions',[]):
   if isinstance(action,dict):
    valid=lambda url:url==original_url if redirected else official(url)
    opened |= action.get('type')=='open' and valid(action.get('ref_id'))
    opened |= any(isinstance(x,dict) and valid(x.get('ref_id',x.get('url'))) for x in action.get('open',[]))
  if opened and output and output.get('status')=='completed':
   text=output.get('text','');title=value.get('page_title','')
   require(bool(title) and title.casefold() in text.casefold() and value['url'].rstrip('/') in text,'Official opened page/title not present in completed native web output')
   if redirected:require(original_url in text and redirect_url in text,'The exact approved redirect pair is not present in the paired output')
   require(not re.search(r'Internal Error|Failed to fetch|Could not fetch|Unable to resolve',text,re.I),'Web output reports fetch failure')
   return True
 raise ValueError('No completed native official open in smoke proof')

def technical_stdout(receipt):
 count=receipt.get('stdout_diagnostic_gap_count')
 require(type(count) is int and count>=0 and receipt.get('stdout_projection_complete') is (count==0)
         and receipt.get('stdout_turn_completed') is True,'Technical stdout completion/boundary missing')
 return {key:receipt[key] for key in ('stdout_diagnostic_gap_count','stdout_projection_complete','stdout_turn_completed')}

def native_stdout_boundary(ctx,path,receipt):
 boundary=technical_stdout(receipt);count=boundary['stdout_diagnostic_gap_count'];total=receipt.get('stdout_gap_total_bytes')
 require(receipt.get('stdout_parse_gap_policy')==STDOUT_POLICY and receipt.get('native_replay_authoritative') is True
         and count<=512 and type(total) is int and 0<=total<=16*1024*1024,'Unbound native-authoritative stdout policy')
 legacy=receipt.get('disposition')=='MECHANICAL_REVALIDATION_NO_MODEL_RERUN'
 if legacy:
  require(receipt.get('job_id')=='SMOKE-L3' and path.parent.name=='revalidation-v4','Only completed L3 has legacy diagnostic projection')
  evidence=load(path.parent/'stdout-gap-evidence.json',ctx['root'])
  require(evidence.get('schema')=='stdout-gap-evidence.v4' and evidence.get('policy')==STDOUT_POLICY
          and evidence.get('count')==count and evidence.get('total_bytes')==total,'Legacy stdout evidence summary mismatch')
  original=evidence.get('original',{});name=str((ctx['run']/'results/SMOKE-L3/attempt-001/structural-diagnostics.jsonl').relative_to(ctx['root']))
  require(original.get('path')==name and name in ctx['indexed'] and original.get('sha256')==ctx['indexed'][name]['sha256'],'Legacy diagnostics not bound by reviewed manifest')
  original_rows=[strict_json(x) for x in bound(original,ctx['root']).splitlines() if x];rows=evidence.get('rows')
  require(isinstance(rows,list) and len(rows)==len(original_rows),'Legacy diagnostic row count mismatch')
  for old,row in zip(original_rows,rows):
   require(set(old)=={'line_sha256','line_bytes','exact_json_null','error_class'}
           and all(row.get(k)==v for k,v in old.items()) and row.get('error_category')=='LEGACY_VALUEERROR_CATEGORY_UNAVAILABLE','Legacy diagnostic identity/category changed')
 else:
  diagnostic=path.parent/'structural-diagnostics.jsonl'
  rows=[strict_json(x) for x in read(diagnostic,ctx['root']).splitlines() if x] if diagnostic.exists() else []
 require(len(rows)==count,'Stdout diagnostic count differs from receipt')
 for row in rows:
  require(set(row)=={'line_sha256','line_bytes','exact_json_null','error_class','error_category','stage'}
          and HEX.fullmatch(row.get('line_sha256','')) and type(row.get('line_bytes')) is int and 0<row['line_bytes']<=256*1024
          and type(row.get('exact_json_null')) is bool and isinstance(row.get('error_class'),str)
          and row.get('stage')=='json_parse','Unapproved stdout diagnostic shape')
  require(row['error_category'] in ({'LEGACY_VALUEERROR_CATEGORY_UNAVAILABLE'} if legacy else {'INVALID_JSON','DUPLICATE_KEY','NONFINITE_JSON_VALUE'}),'Unknown stdout gap category')
 require(sum(row['line_bytes'] for row in rows)==total,'Stdout diagnostic byte total mismatch')
 return dict(boundary,stdout_parse_gap_policy=STDOUT_POLICY,native_replay_authoritative=True,stdout_gap_total_bytes=total,
             boundary='Visible results and public tools established by exact bounded native replay; stdout projection may remain incomplete.')

def validate_terminal(ctx,jid,path):
 root,run,runner=ctx['root'],ctx['run'],ctx['runner'];job=ctx['jobs'][jid];receipt=load(path,root)
 runner.check_inputs(job,root)
 require(receipt.get('status')==COMPLETE and receipt.get('job_id')==jid,'Terminal result not complete')
 for recorded,expected in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
  require(receipt.get(recorded)==job[expected],'Terminal job/config mismatch')
 sid=receipt.get('session_id');require(isinstance(sid,str) and re.fullmatch('[A-Za-z0-9_-]{8,100}',sid),'Invalid terminal SID')
 outputs=receipt.get('outputs');require(isinstance(outputs,dict) and outputs,'Missing terminal output bindings')
 files=[]
 for name,digest in outputs.items():
  p=regular(name,root);require(p.is_relative_to(run/'results'/jid),'Output outside own job')
  raw=read(p,root);require(sha(raw)==digest,'Terminal output changed')
  if p.suffix=='.json':safe(strict_json(raw),name)
  elif p.suffix=='.jsonl':safe([strict_json(x) for x in raw.splitlines() if x],name)
  elif p.suffix in {'.txt','.md'}:safe(raw.decode(),name)
  else:raise ValueError('Unapproved terminal output extension')
  files.append(descriptor(p,root))
 if receipt.get('disposition')=='MECHANICAL_REVALIDATION_NO_MODEL_RERUN':
  preserved_argument=jid in {'V01-A','V02-A'} and receipt.get('transport_version')==3 and path.parent.name=='revalidation-v3'
  repaired_smoke=jid=='SMOKE-L3' and receipt.get('transport_version')==4 and path.parent.name=='revalidation-v4'
  require(preserved_argument or repaired_smoke,'Unbound mechanical validation path/version')
  require(receipt.get('additional_model_calls')==0,'Mechanical validation may not call a model')
  original=receipt.get('original_attempt_receipt');raw=bound(original,root);failure=strict_json(raw)
  require(failure.get('job_id')==jid and failure.get('session_id')==sid and failure.get('status')=='FAILED_PRESERVED_NO_RETRY','Repair replaced original identity/failure')
  state=failure.get('process_state',{})
  require(state.get('process_stopped') is True and state.get('stderr_drained') is True
          and type(state.get('exit_code')) is int and state['exit_code']==0 and state.get('forced_kill') is False,'Original mechanical result did not finish cleanly')
  files.append(original)
 else:
  require(type(receipt.get('cli_exit_code')) is int and receipt['cli_exit_code']==0 and receipt.get('visible_final_count')==1,'Current result did not finish with one successful final')
 proof=load(path.parent/'native-check.json',root);visible=load(path.parent/'native-visible.json',root)
 require(not proof.get('isolation_failures') and proof.get('session_id')==sid and visible.get('session_id')==sid,'Native proof failed')
 prompt=read(job['prompt_file'],root).decode()
 preserved_argument=jid in {'V01-A','V02-A'} and receipt.get('transport_version')==3 and path.parent.name=='revalidation-v3'
 if preserved_argument:
  old_runner=import_runner(run/'runner_v3.py',root);actual_proof,actual_visible,finals=old_runner.inspect_native(sid,prompt,job,root);stdout=None
 else:
  require(receipt.get('transport_version')==4,'Current result lacks V4 transport version')
  cutoff=proof.get('native_source_prefix')
  require(isinstance(cutoff,dict) and type(cutoff.get('bytes')) is int and cutoff['bytes']>0
          and type(cutoff.get('records')) is int and cutoff['records']>0 and HEX.fullmatch(cutoff.get('sha256',''))
          and cutoff.get('newline_terminated') is True,'Fixed native source prefix missing')
  actual_proof,actual_visible,finals=runner.inspect_native(sid,prompt,job,root,cutoff=cutoff)
  stdout=native_stdout_boundary(ctx,path,receipt)
 require(canon(proof)==canon(actual_proof) and canon(visible.get('records'))==canon(actual_visible),'Independent native replay differs')
 value=load(path.parent/'response.json',root);schema=load(job['schema_file'],root);runner.validate(value,schema)
 require(len(finals)==1 and canon(strict_json(finals[0]['text']))==canon(value),'Final response does not match native final')
 final_file=run/'results'/jid/'attempt-001/final.txt'
 require(str(final_file.relative_to(root)) in outputs and canon(strict_json(read(final_file,root)))==canon(value),'Preserved final output file differs from native/schema result')
 require(not receipt.get('quality_flags'),'Terminal quality flags remain')
 messages=[];web=[]
 for record in actual_visible:
  if record.get('role')=='tool':web.append(safe_web(record));continue
  require(record.get('role') in {'user','assistant'} and isinstance(record.get('text'),str),'Unknown visible record')
  if record['role']=='assistant':require(record.get('phase') in {'commentary','final','final_answer'},'Hidden phase')
  require(type(record.get('line')) is int and HEX.fullmatch(record.get('record_sha256','')),'Message source identity missing')
  safe(record,'visible message');messages.append(record)
 require(messages and any(m['role']=='user' for m in messages) and any(m.get('phase') in {'final','final_answer'} for m in messages),'Prompt/final not both captured')
 if jid=='SMOKE-L3':official_smoke(actual_proof,value);technical_stdout(receipt)
 files.append(descriptor(path,root))
 return {'job':job,'receipt':receipt,'receipt_path':path,'session_id':sid,'files':files,'proof':proof,'messages':messages,'web':web,'value':value,'stdout_boundary':stdout}

def request(ctx,kind,sid,attempt,parents,files,payload):
 return {'kind':kind,'actor':{'id':'verification-archive-adapter','role':'tool'},'session_id':sid,'run_id':ctx['run'].name,
  'operation_id':ctx['run'].name,'attempt_id':attempt,'parents':list(dict.fromkeys(parents)),
  'bindings':ctx['start']['bindings'],'outputs':list(dict.fromkeys(r['sha256'] for r in files)),'payload':payload}
def receipt_from_event(event):
 return {'status':event['payload']['status'],'event_id':event['id'],'session_id':event['session_id'],
         'job_id':event['payload'].get('job_id'),'receipt':event['payload'].get('receipt'),
         'native_check':event['payload'].get('native_check'),'files':event['payload'].get('files',[]),
         'capture_event_ids':event['payload'].get('capture_event_ids',[]),'web_event_ids':event['payload'].get('web_event_ids',[])}
def existing(w,key):
 return next((e for e in reversed(w._state['records']) if e['delivery_key']==key),None)
def canonical_event(w,eid):
 require(eid in w._state['seen'],'Referenced event absent from audited archive')
 return next(e for e in reversed(w._state['records']) if e['id']==eid)
def verify_event_files(ctx,w,event):
 require(event.get('run_id')==ctx['run'].name,'Canonical event belongs to another run')
 files=event.get('payload',{}).get('files')
 require(isinstance(files,list) and files,'Canonical event has no bound files')
 for row in files:require(w.get(row['sha256'])==bound(row,ctx['root']),'Canonical stored bytes differ from bound file')
def verify_accepted(ctx,w,event,jid,path):
 require(event.get('kind')=='research.verification.result.accepted' and event['payload'].get('status')=='DEEP_VERIFICATION_RESULT_ARCHIVED'
         and event['payload'].get('job_id')==jid,'Canonical result identity/status mismatch')
 require(event['payload'].get('receipt')==descriptor(path,ctx['root']),'Previously accepted terminal changed')
 require(event['payload'].get('native_check')==descriptor(path.parent/'native-check.json',ctx['root']),'Previously accepted native proof changed')
 verify_event_files(ctx,w,event)
 receipt=load(path,ctx['root']);job=ctx['jobs'][jid]
 require(receipt.get('job_id')==jid and receipt.get('session_id')==event['session_id'] and receipt.get('status')==COMPLETE,'Canonical terminal identity mismatch')
 for recorded,expected in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
  require(receipt.get(recorded)==job[expected],'Canonical terminal job/config mismatch')
def require_smoke(ctx,w):
 gate=load(ctx['run']/'WEB_SMOKE_ACCEPTED_V4.json',ctx['root'])
 require(gate.get('status')=='WEB_SMOKE_ACCEPTED' and gate.get('job_id')=='SMOKE-L3'
         and gate.get('verified_completed_public_web_action') is True,'Scientific acceptance requires V4 completed web smoke')
 event=canonical_event(w,gate.get('event_id'));path=terminal_path(ctx,'SMOKE-L3')
 require(path is not None,'Accepted smoke terminal missing');verify_accepted(ctx,w,event,'SMOKE-L3',path)
 require(gate.get('session_id')==event['session_id'] and gate.get('receipt')==event['payload']['receipt']
         and gate.get('native_check')==event['payload']['native_check'],'Smoke gate differs from canonical event')
 boundary=native_stdout_boundary(ctx,path,load(path,ctx['root']))
 require(event['payload'].get('stdout_boundary')==boundary and event['payload'].get('independence_verified') is True,'Smoke native-authoritative boundary differs from canonical acceptance')
 official_smoke(load(path.parent/'native-check.json',ctx['root']),load(path.parent/'response.json',ctx['root']))
def require_original_arguments(ctx,w):
 for jid in ('V01-A','V02-A'):
  receipt=load(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',ctx['root'])
  path=ctx['run']/'results'/jid/'revalidation-v3/receipt.json'
  event=canonical_event(w,receipt.get('event_id'));verify_accepted(ctx,w,event,jid,path)
  require(receipt==receipt_from_event(event),'Argument acceptance receipt differs from canonical event')
  local=load(path,ctx['root'])
  require(local.get('disposition')=='MECHANICAL_REVALIDATION_NO_MODEL_RERUN' and local.get('additional_model_calls')==0,'Original argument was not mechanically preserved')
def accept_transport(ctx,w):
 require(ctx['start']['event_id'] in w._state['seen'],'Input acceptance not in audited archive')
 prior=canonical_event(w,ctx['prior']['event_id'])
 require(prior.get('kind')=='research.verification.transport_v3.accepted'
         and prior['payload'].get('status')=='DEEP_VERIFICATION_TRANSPORT_V3_ARCHIVED'
         and ctx['prior']['files']==prior['payload'].get('files')
         and ctx['start']['event_id'] in prior.get('parents',[]),'Prior V3 acceptance does not match canonical event')
 verify_event_files(ctx,w,prior)
 require_original_arguments(ctx,w)
 files=list(ctx['manifest']['files'])+[descriptor(ctx['manifest_path'],ctx['root'])]
 for row in files:require(w.put(bound(row,ctx['root']))==row['sha256'],'Object storage mismatch')
 first=existing(w,ctx['run'].name+':SMOKE-L:failure-preserved')
 require(first is not None and first['payload'].get('job_id')=='SMOKE-L'
         and first['payload'].get('status')=='TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY','Original canonical technical failure missing')
 verify_event_files(ctx,w,first)
 save_new(ctx['run']/'results/SMOKE-L/ARCHIVE_RECEIPT.json',receipt_from_event(first))
 second=existing(w,ctx['run'].name+':SMOKE-L2:failure-preserved')
 require(second is not None and second['payload'].get('job_id')=='SMOKE-L2'
         and second['payload'].get('status')=='TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY','Second canonical technical failure missing')
 verify_event_files(ctx,w,second);save_new(ctx['run']/'results/SMOKE-L2/ARCHIVE_RECEIPT.json',receipt_from_event(second))
 sid=ctx['failures']['SMOKE-L3']['session_id'];key=ctx['run'].name+':transport-v4-accepted'
 failure_files=[row for row in files if row['path'].endswith('/STOP_V3.json') or '/results/SMOKE-L3/attempt-001/' in row['path']]
 failure_key=ctx['run'].name+':SMOKE-L3:failure-preserved';failed=existing(w,failure_key)
 if failed:
  require(failed['payload'].get('job_id')=='SMOKE-L3' and failed['payload'].get('files')==failure_files,'Existing third failure differs')
  verify_event_files(ctx,w,failed)
 else:
  failed=w.append(request(ctx,'research.verification.technical_failure.archived',sid,'SMOKE-L3:failed',
   [prior['id']],failure_files,{'status':'TECHNICAL_FAILURE_ARCHIVED_NO_SCIENTIFIC_RETRY','job_id':'SMOKE-L3',
    'files':failure_files,'automatic_retry':False,'boundary':'Completed third probe, original mechanical rejection and STOP_V3 retained. Same result may be mechanically revalidated; no fourth probe.'}),failure_key)
 save_new(ctx['run']/'results/SMOKE-L3/FAILED_ATTEMPT_ARCHIVE_RECEIPT.json',receipt_from_event(failed))
 event=w.append(request(ctx,'research.verification.transport_v4.accepted',sid,'transport-v4',
  [ctx['start']['event_id'],prior['id'],first['id'],second['id'],failed['id']],files,{'status':'DEEP_VERIFICATION_TRANSPORT_V4_ARCHIVED','files':files,
   'prior_transport_event_id':prior['id'],'old_smoke_status':'FAILED_PRESERVED_NO_RETRY','old_stop_preserved':True,
   'failed_technical_jobs':['SMOKE-L','SMOKE-L2','SMOKE-L3'],'scientific_retries':False,'technical_retries':False,
   'boundary':'Exact successor transport preserves all prior technical failures/STOPs and both canonically accepted original argument results. Mechanical L3 validation only; no new technical probe or scientific rerun.'}),key)
 value={'status':'DEEP_VERIFICATION_TRANSPORT_V4_ARCHIVED','event_id':event['id'],'files':files}
 save_new(ctx['run']/'TRANSPORT_V4_START_RECEIPT.json',value);return event
def accept_job(ctx,w,transport,jid,path):
 if jid in ctx['scientific_ids'] and jid not in {'V01-A','V02-A'}:
  require_smoke(ctx,w);require_original_arguments(ctx,w)
 key=ctx['run'].name+':accepted-result:'+jid;prior=existing(w,key)
 if jid in {'V01-A','V02-A'}:require(prior is not None,'Original argument must already be canonically accepted; new validation is prohibited')
 if prior:
  verify_accepted(ctx,w,prior,jid,path)
  save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',receipt_from_event(prior));event=prior
 else:
  result=validate_terminal(ctx,jid,path);sid=result['session_id'];source=resolve_session(sid,ctx['root']);scope=SessionWriter(w,sid,ctx['run'].name)
  captures=[];web_ids=[]
  for m in result['messages']:
   cap=capture(ctx['root']/'research/archive',source,sid,ctx['root'],start_line=m['line'],end_line=m['line'],run_id=ctx['run'].name,archive_writer=scope)
   require(cap['status']=='BOUNDED_COMPLETE' and cap['captured_records']==1 and cap['raw_records'][0]['sha256']==m['record_sha256'],'Selected visible native capture failed')
   captures.append(cap['coverage_event_id'])
  for record in result['web']:
   raw=encoded(record);digest=w.put(raw);file={'sha256':digest}
   web=w.append(request(ctx,'research.verification.public_web_fragment',sid,jid+':web',
     [transport['id']], [file],{'status':'ACCEPTED_NORMALIZED_PUBLIC_WEB_EVIDENCE','job_id':jid,'fragment_sha256':digest,
      'source_line':record['line'],'source_record_sha256':record['record_sha256'],'type':record['type'],
      'boundary':'Allowlisted native public-web action/output fragment; no exec wrapper, hidden content or full native envelope.'}),
      ctx['run'].name+':web:'+sid+':'+str(record['line'])+':'+record['record_sha256'])
   web_ids.append(web['id'])
  for row in result['files']:require(w.put(bound(row,ctx['root']))==row['sha256'],'Result object mismatch')
  payload={'status':'DEEP_VERIFICATION_RESULT_ARCHIVED','job_id':jid,'receipt':descriptor(path,ctx['root']),
    'native_check':descriptor(path.parent/'native-check.json',ctx['root']),'files':result['files'],'capture_event_ids':captures,'web_event_ids':web_ids,
    'scientific':jid in ctx['scientific_ids'],'independence_verified':True,'whole_provider_capture':False,
    'boundary':'Exact final, schema, inputs/config and visible native replay checked; archive accepted before dependent reading. Tools limited to explicitly normalized public web evidence.'}
  payload['stdout_boundary']=result['stdout_boundary']
  event=w.append(request(ctx,'research.verification.result.accepted',sid,jid+':accepted',
      [ctx['start']['event_id'],transport['id']]+captures+web_ids,result['files'],payload),key)
  save_new(ctx['run']/'results'/jid/'ARCHIVE_RECEIPT.json',receipt_from_event(event))
 if jid=='SMOKE-L3':
  # Initial acceptance performed official_smoke; reuse requires immutable exact
  # canonical event and exact terminal/native-check bindings above.
  gate={'status':'WEB_SMOKE_ACCEPTED','event_id':event['id'],'job_id':jid,'session_id':event['session_id'],
        'receipt':event['payload']['receipt'],'native_check':event['payload']['native_check'],
        'verified_completed_public_web_action':True}
  save_new(ctx['run']/'WEB_SMOKE_ACCEPTED_V4.json',gate)
 return event

def main(argv=None):
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');parser.add_argument('--wait-ready',action='store_true');parser.add_argument('--until',type=int,default=20)
 parser.add_argument('--timeout-seconds',type=int,default=21600);parser.add_argument('--poll-seconds',type=int,default=5);args=parser.parse_args(argv)
 require(0<=args.until<=20 and 1<=args.poll_seconds<=30 and 1<=args.timeout_seconds<=43200,'Invalid bounded polling limits')
 require(not(args.check and args.wait_ready),'--check never waits or acquires the archive writer')
 if args.check:
  ctx=setup();ready=[j for j in ctx['jobs'] if terminal_path(ctx,j)]
  reports=[]
  for jid in ready:
   result=validate_terminal(ctx,jid,terminal_path(ctx,jid));reports.append({'job_id':jid,'session_id':result['session_id'],'messages':len(result['messages']),'web_fragments':len(result['web'])})
  print(json.dumps({'status':'READ_ONLY_CHECK_PASS','complete_terminals':reports,'waiting':sorted(set(ctx['jobs'])-set(ready)),'archive_writes':0}));return 0
 stop=stop_requested()
 if stop:print(json.dumps(stop),flush=True);return 0
 self_hash=sha(Path(__file__).read_bytes());deadline=time.monotonic()+args.timeout_seconds;accepted=set()
 ctx=None if args.wait_ready else setup()
 print('ONE_CANONICAL_AUDIT_STARTED',flush=True)
 with Archive(ROOT/'research/archive').writer() as w:
  w._ensure_audited();print('ONE_CANONICAL_AUDIT_COMPLETE',flush=True)
  if args.wait_ready:
   marker=RUN/'TRANSPORT_V4_ARCHIVE_READY.json'
   while not marker.exists():
    stop=stop_requested()
    if stop:print(json.dumps(stop),flush=True);return 0
    if time.monotonic()>=deadline:
     print(json.dumps({'status':'INCOMPLETE_WAITING_FOR_READY_PRESERVED','archive_events_appended':0,'archive_writer_released_on_exit':True}),flush=True);return 2
    time.sleep(args.poll_seconds)
   ready=load(marker)
   require(ready.get('status')=='READY_FOR_CANONICAL_TRANSPORT_V4_ACCEPTANCE','Invalid ready gate')
   require(ready.get('manifest_sha256')==sha(read(RUN/'TRANSPORT_V4_MANIFEST.json')),'Ready manifest hash mismatch')
   require(self_hash==sha(Path(__file__).read_bytes()),'Running archiver changed while waiting')
   ctx=setup()
  stop=stop_requested()
  if stop:print(json.dumps(stop),flush=True);return 0
  require(not (RUN/'STOP_V4.json').exists(),'New transport STOP preserved; release writer for investigation')
  transport=accept_transport(ctx,w)
  while True:
   for jid in ['SMOKE-L3']+sorted(ctx['scientific_ids']):
    stop=stop_requested()
    if stop:print(json.dumps(dict(stop,scientific_accepted=len(accepted&ctx['scientific_ids']))),flush=True);return 0
    require(self_hash==sha(Path(__file__).read_bytes()),'Running archiver changed while polling')
    require(not (RUN/'STOP_V4.json').exists(),'New transport STOP preserved; release writer for investigation')
    if jid in accepted:continue
    path=terminal_path(ctx,jid)
    failure=RUN/'results'/jid/'attempt-001/failure.json'
    if path is None and failure.exists():
     value=load(failure)
     allowed_mechanical=(jid=='SMOKE-L3' and canon(value)==canon(ctx['failures']['SMOKE-L3']))
     require(allowed_mechanical,'Terminal failed attempt preserved; release writer for investigation: '+jid)
    if path:
     event=accept_job(ctx,w,transport,jid,path);accepted.add(jid)
     print(json.dumps({'status':'ARCHIVED','job_id':jid,'session_id':event['session_id'],'event_id':event['id']}),flush=True)
   count=len(accepted&ctx['scientific_ids'])
   if count>=args.until:
    print(json.dumps({'status':'BOUNDED_ARCHIVE_TARGET_REACHED','scientific_accepted':count,'technical_smoke_accepted':'SMOKE-L3' in accepted,'archive_writer_released_on_exit':True}),flush=True);return 0
   if (RUN/'STOP_V4.json').exists():raise RuntimeError('New transport STOP preserved; release writer for investigation')
   if time.monotonic()>=deadline:
    print(json.dumps({'status':'INCOMPLETE_TIMEOUT_PRESERVED','scientific_accepted':count,'waiting':sorted(ctx['scientific_ids']-accepted),'archive_writer_released_on_exit':True}),flush=True);return 2
   time.sleep(args.poll_seconds)

if __name__=='__main__':
 try:sys.exit(main())
 except (ValueError,RuntimeError,ArchiveError,OSError) as exc:
  print(json.dumps({'status':'ARCHIVE_PROGRESS_STOPPED_PRESERVED','error_type':type(exc).__name__,'error':str(exc)[:1000],'automatic_retry':False}),flush=True);sys.exit(2)
