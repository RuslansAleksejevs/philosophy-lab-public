"""Mechanically revalidate finished argument output after canonical v2 acceptance.

No provider calls, retries, edits of original attempts, or canonical writes.
"""
from pathlib import Path
import argparse
import json
import runner_v2 as r


def revalidate(job_id, run_dir=r.RUN, root=r.ROOT):
    receipt, jobs = r.gate(run_dir, root)
    matches = [job for job in jobs if job['id'] == job_id]
    if len(matches) != 1 or matches[0].get('role') != 'argument':
        raise ValueError('Mechanical repair is limited to the original argument jobs')
    job = matches[0]
    attempt = run_dir / 'results' / job_id / 'attempt-001'
    destination = attempt.parent / 'revalidation-v2'
    if destination.exists(): raise ValueError('Preserve existing mechanical revalidation')
    before = {str(path.relative_to(root)):r.digest(r.regular(path, root).read_bytes())
              for path in sorted(attempt.iterdir()) if path.is_file()}
    original_path = r.regular(attempt/'failure.json', root)
    original = r.strict_json(original_path.read_bytes())
    old_proof = r.strict_json(r.regular(attempt/'native-check.json', root).read_bytes())
    if original.get('job_id') != job_id or original.get('status') != r.FAILED or original.get('error') != 'NATIVE_INPUT_OR_TOOL_ISOLATION_FAILED':
        raise ValueError('Original failure was not the bounded declaration-only failure')
    state = original.get('process_state', {})
    if not state.get('process_stopped') or not state.get('stderr_drained') or state.get('exit_code') != 0:
        raise ValueError('Original process did not finish cleanly')
    if old_proof.get('isolation_failures') != ['NATIVE_INPUT_OR_TOOL_ISOLATION_FAILED'] or old_proof.get('other_user_metadata') or not old_proof.get('tool_calls') or any(row.get('type') != 'additional_tools' for row in old_proof['tool_calls']):
        raise ValueError('Original isolation failure contains more than a tools declaration')
    for key, source in [('prompt_sha256','prompt_sha256'),('schema_sha256','schema_sha256'),
                        ('requested_model','model'),('requested_effort','effort'),('requested_service_tier','service_tier')]:
        if original.get(key) != job[source]: raise ValueError('Original input/configuration changed')
    prompt, schema = r.check_inputs(job, root)
    proof, visible, finals = r.inspect_native(original['session_id'], prompt.decode(), job, root)
    if proof['isolation_failures']: raise ValueError('New proof still fails isolation')
    events = [r.strict_json(line) for line in r.regular(attempt/'visible-events.jsonl', root).read_bytes().splitlines()]
    stderr = r.strict_json(r.regular(attempt/'stderr.json', root).read_bytes())
    errors = [event['message'] for event in events if event['type'] in {'error','turn.failed'}]
    status, flags, value = r.classify(finals, stderr['lines'], r.regular(attempt/'final.txt', root).read_text(),
                                    schema, errors, sum(event['type']=='turn.completed' for event in events)==1,
                                    state['exit_code'], job)
    if status != r.COMPLETE: raise ValueError('Original completed output still fails schema/final checks: '+str(flags))
    for path, expected in before.items():
        if r.digest(r.bound_path(path, root).read_bytes()) != expected: raise ValueError('Original attempt changed during validation')
    destination.mkdir(exist_ok=False)
    r.save_new(destination/'native-check.json',proof)
    r.save_new(destination/'native-visible.json',{'session_id':original['session_id'],'records':visible})
    r.save_new(destination/'response.json',value)
    outputs = {**before, **{str(path.relative_to(root)):r.digest(path.read_bytes()) for path in destination.iterdir()}}
    result = {**{key:original[key] for key in ('job_id','prompt_sha256','schema_sha256','requested_model','requested_effort','requested_service_tier','session_id')},
              'status':r.COMPLETE,'transport_version':2,'disposition':'MECHANICAL_REVALIDATION_NO_MODEL_RERUN',
              'original_attempt_receipt':{'path':str(original_path.relative_to(root)),'sha256':before[str(original_path.relative_to(root))]},
              'input_event_id':receipt['event_id'],'quality_flags':[],'outputs':outputs,'completed_at':r.now(),
              'additional_model_calls':0,'archive_boundary':'Local mechanical validation only; canonical acceptance required before dependence.'}
    r.save_new(destination/'receipt.json',result)
    return {'job_id':job_id,'status':r.COMPLETE,'receipt':str((destination/'receipt.json').relative_to(root)),'additional_model_calls':0}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ids', nargs='+', required=True)
    args=parser.parse_args()
    for job_id in args.ids: print(json.dumps(revalidate(job_id)), flush=True)
