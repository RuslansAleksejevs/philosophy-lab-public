#!/usr/bin/env python3
"""Resume only twelve never-started jobs under a canonical archive-only repair.

The original V4 runner, queue, STOP and attempts remain unchanged. No model
call occurs on import or in --check. Capture/model/isolation logic is inherited
without replacement; only the exact disposed STOP and new STOP path differ.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
RUN=Path(__file__).resolve().parent;ROOT=RUN.parents[1]
FROZEN_RUNNER_SHA='92cdd3f9bc2e326a5b4cb36b8aef8ec5d6eca3d03a47ed0e3b82bab37e3ac0d8'
EXPECTED_IDS=[f'V{i:02d}-{role}' for i in range(5,11) for role in ('A','L')]
LANE='archive-repair-v4'
RECEIPT=LANE+'/SAFE_WEB_PROJECTION_START_RECEIPT.json'
MANIFEST=LANE+'/SAFE_WEB_PROJECTION_MANIFEST.json'
NEW_STOP='STOP_V4_ARCHIVE_REPAIR.json'
def require(ok,message):
 if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
require(sha((RUN/'runner_v4.py').read_bytes())==FROZEN_RUNNER_SHA,'Frozen V4 runner changed')
sys.path.insert(0,str(RUN));import runner_v4 as r

def bound(ref,root):
 require(isinstance(ref,dict) and set(ref)>={'path','sha256','bytes'} and type(ref['bytes']) is int,'Exact descriptor required')
 p=r.bound_path(ref['path'],root);raw=p.read_bytes();require(sha(raw)==ref['sha256'] and len(raw)==ref['bytes'],'Bound repair input changed');return raw
def repair_gate(run=RUN,root=ROOT,*,require_old_process_stopped=True):
 receipt=r.strict_json(r.run_file(RECEIPT,run).read_bytes());manifest_raw=r.run_file(MANIFEST,run).read_bytes();manifest=r.strict_json(manifest_raw)
 require(receipt.get('status')=='DEEP_VERIFICATION_SAFE_WEB_PROJECTION_ARCHIVED' and manifest.get('status')=='SAFE_WEB_PROJECTION_PREPARED'
         and receipt.get('manifest_sha256')==sha(manifest_raw),'Canonical repair acceptance/manifest missing')
 indexed={}
 for ref in manifest['files']:
  bound(ref,root);require(ref['path'] not in indexed,'Duplicate repair input');indexed[ref['path']]=ref
 for name in ('resume_v4.py','test_resume_v4.py',LANE+'/signed_url_projection.py',LANE+'/test_signed_url_projection.py',LANE+'/SIGNED_URL_POLICY.json'):
  rel=str((run/name).relative_to(root));require(rel in indexed,'Required repair source not bound')
 require(indexed[str((run/'resume_v4.py').relative_to(root))]['sha256']==sha(Path(__file__).read_bytes()),'Executing wrapper not bound')
 require(sha(r.run_file('runner_v4.py',run).read_bytes())==FROZEN_RUNNER_SHA,'Frozen runtime runner changed')
 seq=receipt.get('event_sequence');require(type(seq) is int and seq>0,'Canonical repair sequence missing')
 sys.path.insert(0,str(root/'scripts'));from research_archive import _check_event,canonical
 raw=r.regular(root/'research/archive/events'/f'{seq:012d}.json',root).read_bytes();event=r.strict_json(raw);_check_event(event)
 require(canonical(event)==raw and event['id']==receipt.get('event_id') and event['sha256']==receipt.get('event_sha256')
         and event['kind']=='research.verification.web_projection_policy.accepted' and event['run_id']==run.name,'Wrong canonical repair event')
 require(event['payload'].get('status')==receipt['status'] and event['payload'].get('files')==receipt.get('files')
         and sha(manifest_raw) in event['outputs'],'Canonical repair payload differs')
 file_index={ref['path']:ref for ref in receipt['files']}
 for name,ref in indexed.items():require(file_index.get(name)==ref and ref['sha256'] in event['outputs'],'Repair file not accepted by canonical receipt')
 prior=r.strict_json(r.run_file('TRANSPORT_V4_START_RECEIPT.json',run).read_bytes())
 require(prior['event_id'] in event['parents'],'Repair lacks original V4 acceptance parent')
 for key in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids'):
  require(receipt.get(key)==manifest.get(key) and event['payload'].get(key)==manifest.get(key),'Repair scope differs: '+key)
 require(manifest['resume_never_started_ids']==EXPECTED_IDS,'Repair may resume only the exact twelve never-started jobs')
 for key in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout'):
  ref=manifest[key];require(indexed.get(ref['path'])==ref,'Repair evidence absent from manifest');bound(ref,root)
 require(manifest['preserved_stop']['path']==str((run/'STOP_V4.json').relative_to(root)),'Only the preserved V4 archive stop may be disposed')
 stop=r.strict_json(bound(manifest['preserved_stop'],root));require(stop.get('status')=='STOPPED_PRESERVED' and stop.get('job_id')=='archive-progress' and stop.get('automatic_retry') is False and not r.actual_quota(stop.get('reason','')),'Unapproved old STOP disposition')
 snapshot=r.strict_json(bound(manifest['prior_dispatch_snapshot'],root))
 require(snapshot.get('status')=='STOPPED_PRESERVED' and snapshot.get('active_ids')==[] and snapshot.get('pending_ids')==EXPECTED_IDS
         and type(snapshot.get('pid')) is int and snapshot['pid']>0,'Prior dispatcher did not finish with the exact pending twelve')
 require(manifest['prior_dispatch_snapshot']['path']!=str((run/'process.json').relative_to(root)),'Bind an immutable prior process snapshot copy')
 if require_old_process_stopped:
  process=subprocess.run(['/bin/ps','-p',str(snapshot['pid']),'-o','pid='],capture_output=True,text=True)
  require(process.returncode==1 and not process.stdout.strip() and not process.stderr.strip(),'Prior dispatcher absence is not proven; preserve in-flight work')
 for jid in EXPECTED_IDS:require(not (run/'results'/jid/'attempt-001').exists(),'Never-started scope now has an attempt: '+jid)
 require(not (run/NEW_STOP).exists(),'New repair STOP already exists')
 return {'receipt':receipt,'manifest':manifest,'event':event,'preserved_stop_sha256':manifest['preserved_stop']['sha256'],'ids':EXPECTED_IDS}

class Dispatcher(r.Dispatcher):
 def __init__(self,gate,run_dir=RUN,root=ROOT):
  super().__init__(run_dir,root);self.repair=gate;self.allowed=frozenset(gate['ids'])
 def stopped(self):
  if self.stop.is_set() or (self.run_dir/NEW_STOP).exists():return True
  old=self.run_dir/'STOP_V4.json'
  try:
   if sha(r.regular(old,self.root).read_bytes())!=self.repair['preserved_stop_sha256']:return True
   for name,expected in [('STOP.json',self.disposed_stop_sha),('STOP_V2.json',self.disposed_v2_stop_sha),('STOP_V3.json',self.disposed_v3_stop_sha)]:
    p=self.run_dir/name
    if p.exists() and (expected is None or sha(r.regular(p,self.root).read_bytes())!=expected):return True
  except (OSError,ValueError):return True
  return False
 def fail_stop(self,reason,job_id):
  record={'at':r.now(),'job_id':job_id,'reason':r.safe_error(reason),'automatic_retry':False,'repair_policy_event_id':self.repair['event']['id']}
  with self.launch_lock:
   self.stop.set()
   with self.lock:
    try:r.save_new(self.run_dir/NEW_STOP,record)
    except FileExistsError:pass
  self.event({'event':'stop',**record})
 def event(self,record):super().event({**record,'archive_repair_policy_event_id':self.repair['event']['id']})
 def run_one(self,job):
  require(job['id'] in self.allowed,'Job outside canonical never-started scope')
  require(not (self.run_dir/'results'/job['id']/'attempt-001').exists(),'Existing scientific attempt must not be rerun')
  return super().run_one(job)
 def run(self,ids,workers=3):
  require(list(ids)==list(self.repair['ids']),'Exact finite resumption queue required')
  return super().run(ids,workers,'jobs_v4.json','TRANSPORT_V4_START_RECEIPT.json')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');p.add_argument('--workers',type=int,default=3);a=p.parse_args()
 gate=repair_gate();r.gate();r.require_scientific_prerequisites()
 if a.check:print(json.dumps({'status':'RESUMPTION_GATES_PASS_NO_DISPATCH','ids':gate['ids'],'policy_event_id':gate['event']['id'],'model_calls':0}));return 0
 dispatcher=Dispatcher(gate)
 try:result=dispatcher.run(gate['ids'],a.workers)
 except BaseException as exc:dispatcher.fail_stop('DISPATCHER_FAILURE: '+r.safe_error(exc),'dispatcher');raise
 print(json.dumps(result));return 0
if __name__=='__main__':raise SystemExit(main())
