"""Synthetic resumption gates only; no model/native/live archive access."""
from pathlib import Path
import copy,importlib.util,json,tempfile,unittest,sys
from unittest import mock
SPEC=importlib.util.spec_from_file_location('resume',Path(__file__).with_name('resume_v4.py'));m=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(m)
sys.path.insert(0,str(m.ROOT/'scripts'))
from research_archive import Archive
class ResumeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name).resolve();self.run=self.root/'runs/deep-verification-20261031';self.run.mkdir(parents=True);self.archive=Archive(self.root/'research/archive').init()
  def write(name,value):
   p=self.run/name;p.parent.mkdir(parents=True,exist_ok=True);raw=value if isinstance(value,bytes) else m.r.encode(value);p.write_bytes(raw);return {'path':str(p.relative_to(self.root)),'sha256':m.sha(raw),'bytes':len(raw)}
  self.write=write;files=[]
  for name in ('resume_v4.py','test_resume_v4.py','archive-repair-v4/signed_url_projection.py','archive-repair-v4/test_signed_url_projection.py','archive-repair-v4/SIGNED_URL_POLICY.json','runner_v4.py'):
   files.append(write(name,(m.RUN/name).read_bytes()))
  stop=write('STOP_V4.json',{'status':'STOPPED_PRESERVED','job_id':'archive-progress','reason':'bounded synthetic archive rejection','automatic_retry':False})
  snapshot=write('archive-repair-v4/PRIOR_DISPATCH_PROCESS.json',{'status':'STOPPED_PRESERVED','pid':999999,'active_ids':[],'pending_ids':m.EXPECTED_IDS})
  stdout=write('archive-repair-v4/PRIOR_STDOUT.txt',b'synthetic safe transport log\n');files += [stop,snapshot,stdout]
  self.manifest={'status':'SAFE_WEB_PROJECTION_PREPARED','files':files,'preserved_stop':stop,'prior_dispatch_snapshot':snapshot,'prior_dispatch_stdout':stdout,'resume_never_started_ids':m.EXPECTED_IDS}
  manifest_ref=write(m.MANIFEST,self.manifest)
  with self.archive.writer() as w:
   def event(kind,payload,parents=(),outputs=()):return {'kind':kind,'run_id':self.run.name,'session_id':'synthetic-coordinator','actor':{'id':'synthetic','role':'tool'},'operation_id':'synthetic-repair','attempt_id':'synthetic-attempt','parents':list(parents),'outputs':list(outputs),'payload':payload}
   prior=w.append(event('research.verification.transport_v4.accepted',{}),'synthetic-prior')
   write('TRANSPORT_V4_START_RECEIPT.json',{'event_id':prior['id']})
   accepted_files=files+[manifest_ref]
   for ref in accepted_files:w.put((self.root/ref['path']).read_bytes())
   payload={'status':'DEEP_VERIFICATION_SAFE_WEB_PROJECTION_ARCHIVED','files':accepted_files,**{k:self.manifest[k] for k in ('preserved_stop','prior_dispatch_snapshot','prior_dispatch_stdout','resume_never_started_ids')}}
   e=w.append(event('research.verification.web_projection_policy.accepted',payload,[prior['id']],[x['sha256'] for x in accepted_files]),'synthetic-repair')
  self.receipt={**payload,'event_id':e['id'],'event_sequence':e['sequence'],'event_sha256':e['sha256'],'manifest_sha256':manifest_ref['sha256']};write(m.RECEIPT,self.receipt)
 def tearDown(self):self.tmp.cleanup()
 def gate(self):return m.repair_gate(self.run,self.root,require_old_process_stopped=False)
 def test_exact_canonical_gate_passes_without_provider(self):
  with mock.patch.object(m.r.subprocess,'Popen',side_effect=AssertionError('NO MODEL')):g=self.gate()
  self.assertEqual(g['ids'],m.EXPECTED_IDS)
 def test_changed_or_missing_historical_stop_is_not_disposed(self):
  (self.run/'STOP_V4.json').write_text('{}')
  with self.assertRaises(ValueError):self.gate()
 def test_new_stop_and_existing_attempt_block(self):
  p=self.run/m.NEW_STOP;p.write_text('{}')
  with self.assertRaises(ValueError):self.gate()
  p.unlink();(self.run/'results/V05-A/attempt-001').mkdir(parents=True)
  with self.assertRaises(ValueError):self.gate()
 def test_forged_receipt_or_changed_source_rejected(self):
  self.receipt['event_id']='event-wrong';self.write(m.RECEIPT,self.receipt)
  with self.assertRaises(ValueError):self.gate()
 def test_wrapper_cannot_launch_existing_scientific_or_other_job(self):
  d=m.Dispatcher(self.gate(),self.run,self.root)
  with mock.patch.object(m.r.Dispatcher,'run_one',side_effect=AssertionError('MUST NOT RUN')):
   with self.assertRaises(ValueError):d.run_one({'id':'V01-L'})
   (self.run/'results/V05-A/attempt-001').mkdir(parents=True)
   with self.assertRaises(ValueError):d.run_one({'id':'V05-A'})
 def test_exact_stop_disposition_and_new_failure_preserve_original(self):
  d=m.Dispatcher(self.gate(),self.run,self.root);old=(self.run/'STOP_V4.json').read_bytes();self.assertFalse(d.stopped())
  d.fail_stop('synthetic future failure','V05-A');self.assertTrue(d.stopped());self.assertEqual((self.run/'STOP_V4.json').read_bytes(),old);self.assertTrue((self.run/m.NEW_STOP).is_file())
 def test_new_changed_stop_closes_gate(self):
  d=m.Dispatcher(self.gate(),self.run,self.root);(self.run/'STOP_V4.json').write_text('{}');self.assertTrue(d.stopped())
 def test_live_previous_dispatcher_rejected(self):
  completed=type('Result',(),{'returncode':0,'stdout':'999999\n','stderr':''})()
  with mock.patch.object(m.subprocess,'run',return_value=completed):
   with self.assertRaises(ValueError):m.repair_gate(self.run,self.root)
 def test_failed_ps_command_cannot_authorize_resume(self):
  for code,stderr in ((2,''),(1,'permission denied')):
   completed=type('Result',(),{'returncode':code,'stdout':'','stderr':stderr})()
   with self.subTest(code=code),mock.patch.object(m.subprocess,'run',return_value=completed):
    with self.assertRaises(ValueError):m.repair_gate(self.run,self.root)
if __name__=='__main__':unittest.main()
