# Can You Bind Yourself With a Promise?

People often say they made a promise to themselves: to quit smoking, to finish a novel, to call their parents every week. My claim is that a promise made only to yourself cannot, on its own, create a real obligation. When such a promise seems to bind us, the binding force comes from somewhere else.

Start with what makes a promise binding. If I promise you something, I am now under an obligation that I cannot cancel on my own. That is the whole point. If I could wipe out the obligation just by changing my mind, you could not rely on it, and it would not constrain me at all.

Next, notice that the person who receives a promise has a special power: they can release the promisor. If I promise to help you move house and you tell me not to bother, I am off the hook. Nobody thinks I broke my promise.

Now put these together. In a promise to myself, the person who makes the promise and the person who receives it are the same person. So I hold the power of release. I can release myself whenever I like, simply by deciding to. But an obligation that I can cancel alone, at any moment, by a simple decision is exactly the kind of obligation that does not constrain me. So it fails the test from the start. It is not a real obligation.

Here is an example. Suppose I promise myself to run before work every morning. On a cold, dark Tuesday I lie in bed and think, "I release myself from that promise." Nothing has gone wrong in the way something goes wrong when I break a promise to a friend. I have simply changed my plan.

Two things should be said about what this does not show. First, it does not show that self-promises are pointless. Saying "I promise myself" can help me make up my mind, can signal to myself how seriously I take a plan, and can help me organize my time. Those are real uses. They just are not obligations.

Second, the pull we feel from self-promises is real, but it is better explained by other things. I may already have good reasons for the action, such as my health in the running case. I may care about being a consistent person whose resolutions mean something. Or there may be a promise to someone else hidden inside the self-promise, as when I told my partner I would start running. Each of these can explain the pull without any obligation created by the self-promise itself.

The strongest objection is that the promise is really made to my future self. My future self is the one who will benefit, so perhaps my future self is a separate party who could hold me to it. But my future self is not here to release me or to refuse to. It is my present self that decides, on behalf of the future one, so the power of release still sits with the person who made the promise. And if my future self really were a separate person, then this would be a promise to someone else, not a promise to myself. Either way, my claim stands.

A second objection is that people feel guilty when they break promises to themselves, so these promises must bind. But guilt can have other sources. I may feel guilty because I failed to act on my own good reasons, or because I see a pattern of unreliability in myself. Feeling guilty is not decisive evidence that an obligation existed.

Finally, a note on scope. My argument is only about obligations created by the act of promising. It does not deny that we may have duties to ourselves of other kinds.

So a promise to yourself can be useful and can feel weighty, but it cannot by itself bind you, because you always hold the key to your own release.
