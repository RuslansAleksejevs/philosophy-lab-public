# Retrospective Affect and the Fittingness Conditions of Self-Directed Blame

It is not infrequently the case that a decision reasonable at the time of its making eventuates in an adverse outcome, whereupon agents exhibit a marked tendency toward self-blame. The thesis defended herein is that, in cases of this type, regret concerning the outcome is fitting, whereas self-directed blame is not.

The analysis commences from the fittingness conditions of blame. Blame, whether other-directed or self-directed, is fitting exclusively where some fault is attributable to its object, whether in the procedure by which the decision was reached or in the configuration of that agent's concerns.

It is further posited that the reasonableness of a decision is a function of the information available to the agent at the time of decision and of the manner in which that information was weighed, and is independent of the subsequent unfolding of events.

Regret is to be distinguished therefrom. To regret is to wish that matters had transpired otherwise, a wish that may encompass the wish to have acted otherwise; and regret may be fitting in relation to an adverse outcome irrespective of the presence or absence of fault.

The conjunction of these premises yields the following. Where the decision was reasonable, no fault attaches to the procedure by which it was reached, and self-blame is accordingly unfitting. The outcome nonetheless remains adverse, and the agent's own action figures in its causal history; regret is therefore fitting.

A simple case illustrates the point. Given a forecast assigning a ten percent probability to rain, an agent leaves their umbrella at home; a downpour ensues, and the agent arrives at a job interview soaked. The wish to have brought the umbrella is intelligible, yet the decision was sound, and no ground for self-blame obtains.

A case of greater gravity is the following. An agent assists their father in the selection of a surgeon possessed of excellent reviews and a strong record; a rare complication nevertheless occurs. Profound regret that the operation was undertaken with that surgeon may be warranted, yet the choice was well made on the available information, and self-blame is unfitting.

Three qualifications are necessary. First, the foregoing applies only on condition that the decision was in fact reasonable; retrospective assessments are frequently erroneous on this point, hindsight tending to inflate the apparent foreseeability of adverse outcomes. Second, reasonable decision-making incorporates reasonable epistemic effort: if consultation of the forecast would have been easy and was omitted, fault may after all be present. Third, it is not maintained that adverse outcomes never furnish reasons for revising one's decision procedures; where an outcome discloses new information, learning therefrom is appropriate.

A first objection holds that agents who never engage in self-blame will become careless, such that self-blame possesses motivational utility. The motivational efficacy of an affective state, however, constitutes a reason for having it rather than an indication of its fittingness to the situation. Furthermore, the agent who decides reasonably has already manifested the care that self-blame is putatively intended to produce; and self-blame for reasonable decisions may induce excessive caution.

A second objection appeals to an example due to the philosopher Bernard Williams in his essay "Moral Luck". A lorry driver, without any fault on his part, runs over a child; Williams observed that the driver will experience something distinct from what a bystander experiences, and designated it "agent-regret". The objection maintains that this state is a species of self-blame, and that it is appropriate. The appropriateness of the driver's state is conceded; it is, however, regret indexed to his own agency rather than blame, involving the wish not to have been the one who did it and possibly a desire to make amends, but involving no judgement that he decided badly.

Accordingly, where a reasonable choice issues in an adverse outcome, it is fitting to wish that matters had gone otherwise, and even to experience the distinctive sting of one's own involvement; what is unfitting is the verdict that one was at fault.
