# Regret Without Blame

Sometimes we make a sensible decision and it turns out badly. When that happens, people tend to blame themselves. I want to argue that, in these cases, regret about what happened makes sense, but blaming yourself does not.

Start with blame. Blaming someone, including yourself, fits only when there is a fault in that person: a fault in how they made the decision, or in what they cared about.

Next, whether a decision was reasonable depends on what the person knew at the time and how they weighed it. It does not depend on how things turned out afterwards.

Regret is different. To regret something is to wish it had gone otherwise, which can include wishing you had acted otherwise. Regret can fit a bad outcome whether or not anyone was at fault.

Put these together. If your decision was reasonable, then there was no fault in how you made it. So blaming yourself does not fit. But the outcome is still bad, and your own action was part of how it came about. So regret does fit.

Here is a simple case. The forecast says there is a ten percent chance of rain, so you leave your umbrella at home. It pours, and you arrive at a job interview soaked. You can sensibly wish you had brought the umbrella. But you made a fine decision, and there is nothing to blame yourself for.

Here is a more serious case. You help your father choose a surgeon who has excellent reviews and a strong record. A rare complication happens anyway. You may deeply regret that he had that operation with that surgeon. But you chose well on what you knew, and self-blame is not fitting.

Three qualifications. First, all of this applies only if the decision really was reasonable. People often get this wrong after the fact, and hindsight tends to make bad outcomes look more foreseeable than they were. Second, a reasonable decision includes reasonable effort to find things out. If checking the forecast would have been easy and you skipped it, there may be a fault after all. Third, I am not saying that a bad outcome never gives you reason to change how you decide. If the outcome teaches you something new, you should learn from it.

One objection is that people who never blame themselves will become careless, so self-blame is useful because it motivates us. But the fact that a feeling would motivate us is a reason to have it, not a sign that it fits the situation. Besides, a person who decides reasonably has already shown the care that self-blame is supposed to produce. And blaming yourself for reasonable decisions may make you too cautious.

A second objection draws on an example from the philosopher Bernard Williams, in his essay "Moral Luck". A lorry driver, through no fault of his own, runs over a child. Williams pointed out that the driver will feel something different from what a bystander feels, and he called it "agent-regret". Surely, the objection goes, this feeling is a kind of self-blame, and surely it is appropriate. I agree that the driver's feeling is appropriate. But it is regret tied to his own agency, not blame. It involves wishing he had not been the one who did it, and perhaps wanting to make amends. It does not involve judging that he decided badly.

So when a sensible choice goes wrong, it is right to wish things had gone otherwise, and even to feel the special sting of having been involved. What does not fit is the verdict that you were at fault.
