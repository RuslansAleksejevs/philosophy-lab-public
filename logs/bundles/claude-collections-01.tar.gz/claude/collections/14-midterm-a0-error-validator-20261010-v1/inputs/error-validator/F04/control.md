# The Direction of a Reason

A short philosophical formula can be read at several levels. A reader may ask whether its claims are true, whether its reasoning is convincing, or simply which claim it presents as a reason for which other claim. These questions should be distinguished. The last is a question about the direction of the stated justification, and it can be answered without first settling a complete theory of mind.

The passage considered here is a short extract from René Descartes, *A Discourse on Method*, Part IV:

> I think, therefore I am

Source: [Project Gutenberg, ebook 59, translated by John Veitch](https://www.gutenberg.org/files/59/59-h/59-h.htm), Part IV, first occurrence of the English cogito formula; browser-extracted line 154.

For this reading, the two first-person references concern the same speaker. The claim about thinking concerns that speaker's activity; the claim about being concerns that speaker's existence. These modest identifications fix the terms of the question. They do not require a decision about whether the speaker is an immaterial substance, a body, or something described in some other way.

A useful comparison is an ordinary argument about a shape. Someone might present a shape's having three sides as a reason to classify it as a triangle. Another person might start with its classification and use that to infer the number of sides. Even if both arguments are defensible under the same definitions, they present their reasons in different directions. The truth of two connected claims does not erase the difference between those presentations.

The same distinction matters when interpreting a compact philosophical statement. Identifying the direction in which a reason is offered does not by itself establish that the reason is sufficient. Nor does it turn a relation of justification into a claim about what physically causes what. An assessment of validity, a causal explanation, and an account of the author's stated starting point remain different tasks.

The reading proposed here concerns only the displayed formula. It does not decide whether the surrounding philosophy succeeds, whether an unstated general principle is needed, or whether the insight is best understood as a formal deduction. Those issues can be left open while identifying the relation expressed in this particular passage. The quoted formula therefore presents the speaker's thinking as a reason for affirming the speaker's existence.