# Competition constraints — checked 2026-09-20 UTC
Official pages were downloaded and read on this date:
https://www.zacharygoodsell.com/ai-philosophy-competition-rules
https://www.zacharygoodsell.com/ai-philosophy-competition-faq

Each entrant may submit up to three essays. Private generation is not submission.
Essay limit: 6000 words excluding bibliography only; abstract, notes and appendices count.
No minimum or target word count. Deadline: 31 October 2026, 23:59 Anywhere on Earth.
Essay and methodology report must be anonymized for review. No submission authorized.
All substantive philosophical contributions must originate and develop in AI.
No human-authored argument, objection or substantive rewrite enters this lineage.
Keep logs and distinguish AI contributions from neutral human workflow instructions.
Do not put instructions aimed at manipulating screeners or judges into an essay.
Judge criteria: clarity, argument quality, significance, originality, engagement
with relevant literature, and accurate scholarship. Methodology is evaluated separately.
No claim of eligibility, accuracy or originality follows from a technical completion check.
