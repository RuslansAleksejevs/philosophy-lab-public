# Inquiry Before the Question

*Draft 001 — initial manuscript*

**Abstract.** Recent work on the norms of inquiry treats a question as the thing an inquiry is about: to inquire is to be in an interrogative attitude towards some Q, and the norms of inquiry are indexed to Q. I argue that this architecture cannot handle the cases in which formulating the question is itself the work, and that these cases are central rather than marginal. I propose that inquiries are individuated, and their norms indexed, not by questions but by *aporiai*: sets of an agent's own commitments that she cannot as she stands jointly discharge. The resulting model supplies a stopping rule for double-checking, makes zetetic negligence intelligible, and gives a negative criterion of success that answers the second horn of Meno's paradox.

---

## 1. The zetetic turn has not gone back far enough

Epistemology has been enlarging its subject matter. Instead of asking only what an agent should believe at a moment, it has begun to ask how she should conduct the extended activity that produces her beliefs: when to take up a matter, how to pursue it, when to stop. Jane Friedman calls the norms governing that activity *zetetic* norms, and calls the shift towards them the zetetic turn. Her complaint against the older picture is well put: there is, she says, “a kind of temporal parochialism to normative epistemology as it's currently done that is not obviously well motivated. What's so special about the moment of belief formation?” (Friedman 2020a: 26).

The complaint is right, and the turn is a good one. My claim is that it has not been carried far enough, and that the framework in which it has been carried out cannot carry it further.

The framework treats a *question* as the unit. An inquiry is an inquiry into Q; an inquirer is someone with an interrogative attitude towards Q; and the proposed norms take Q as a parameter. Friedman's zetetic instrumental principle says: “If one wants to figure out Q?, then one ought to take the necessary means to figuring out Q?” (Friedman 2020a: 503). Her ignorance norm says that one should not both know the answer to Q and have an interrogative attitude towards Q (Friedman 2020b: §3.1). Her diagram of an inquiry runs from the moment a question goes on the agenda, through active investigation of it, to its settlement (Friedman 2020b: §2). Call the commitment that underwrites this architecture **Erotetic Primacy**. It has two components:

> **(EP-i)** *Constitutive.* To inquire at t is to be, at t, in an interrogative attitude towards some question Q.
>
> **(EP-ii)** *Indexing.* The norms governing an inquiry take that question as a parameter: what the inquirer ought to do, and whether she is doing well, is fixed relative to Q.

Friedman is careful not to assert (EP-i) unrestrictedly. She notes that “[t]here may well be parts of inquiry during which we don't quite have a clear question before our minds”, and says her focus is on “determinately question-directed inquiry” (Friedman 2020a: 9–10); elsewhere she writes that she does not “mean to be committing to the claim that all inquiry is question-directed in this way” (Friedman 2020b: n. 1), and wonders whether inquiry might start “before S has even really formulated a question they want to answer and is just poking around somewhat more aimlessly”, adding: “I'm not sure there's a clear answer” (Friedman 2020b: §3.2).

So my target is not a straw man, but neither is the hedge innocent. (EP-ii) is untouched by it. Every zetetic norm on offer is question-indexed, and so every zetetic norm on offer is silent in precisely the region Friedman brackets. If that region were a curiosity — a brief fog before the real inquiry starts — the silence would be tolerable. I shall argue that it is not. The pre-question region is where a great deal of inquiry happens, where inquiries are most often won or lost, and where epistemic criticism has most to say. A theory of inquiry that begins when the question is in hand begins too late, in just the way that a theory of belief that begins at the moment of belief formation begins too late.

The positive proposal is this. What individuates an inquiry, and what its norms should be indexed to, is not a question but an **aporia**: a set of the agent's own commitments that she cannot, as she now stands, jointly discharge. Inquiry is the activity of removing an aporia by improving one's epistemic position. Questions are instruments for that work — often indispensable ones — but they are products of inquiry at least as often as they are its starting points. Section 2 sets out the cases. Sections 3 and 4 rebut three attempts to save the question-indexed architecture. Section 5 develops the aporetic model. Section 6 gives its payoffs, Section 7 its objections.

---

## 2. The formulation problem

Consider three episodes.

**(1) Ana.** Ana comes away from her weekly meeting with a colleague feeling flattened. This happens for months. She believes nothing false about the meetings; she has no complaint she could state; nothing in her evidence is unaccounted for. Something is wrong and she cannot say what. She replays exchanges, tries out descriptions that do not fit (“he interrupts me” — he doesn't; “he disagrees with me” — he does, but so do others, harmlessly), notices a pattern in *when* the flattening occurs, and eventually arrives at a formulation: *is he treating my objections as complaints?* Once she has that question, answering it takes one meeting. The months were not a prelude to the inquiry. They were the inquiry. The question was its result.

**(2) The intermittent fault.** An engineer is handed a service that fails roughly once a day, with no pattern in the logs. She has no question, only a symptom. Her work consists in converting the symptom into a question — in finding a partition of possibilities fine enough to be tested and coarse enough to be tractable. When she can finally ask *does the failure track the cache eviction cycle?*, she is almost done. Most of what she did before that was not a means to answering that question; it was a means to *having* it.

**(3) The uneasy reader.** A reader works through an argument that seems valid and whose premises seem true, and whose conclusion he cannot accept. He does not yet suspect any particular step. After a week he locates an equivocation on a term between the second and fourth premises. Before he located it there was no question he was trying to answer. Afterwards, there was no question left to answer.

These are not exotic. The general pattern — an acknowledged defect long antedating any formulable question about it — is at least as common in the sciences, where anomalies are routinely named, catalogued and worried over before anyone can say what would resolve them. I make no historical claim here beyond the general one, which I take to be uncontroversial.

What these episodes share is a structure I will call the **formulation problem**. At the times that matter, there is no question Q such that (a) the agent has an interrogative attitude towards Q, and (b) her activity is well described as taking the means to figuring out Q. And this is not because she is idling. She is working, and working well or badly: Ana could have been lazier or more honest, the engineer could have been sloppier, the reader could have given up. There is a great deal of zetetic quality on display, and none of it is quality *relative to a question*.

The formulation problem is not the observation that people are sometimes vague. It is a claim about where the difficulty in inquiry tends to sit. In each case, once the question is in hand the rest is comparatively mechanical. The hard, skilled, criticisable part came earlier. If our norms are indexed to questions, they attach to inquiry at the point where it has already mostly succeeded.

---

## 3. Two rescues

The defender of the question-indexed architecture has replies. I take two here and a third, more interesting one, in Section 4.

### 3.1 The coarse question

First reply: Ana does have a question. It is *what is going on in these meetings?* The engineer's is *why does the service fail?* The reader's is *what is wrong with this argument?* So (EP-i) is safe and (EP-ii) applies.

This saves the letter of the architecture and empties it. The guidance a question-indexed norm delivers is a function of the answer-set the question determines — the partition of possibilities its complete answers induce. Run the dilemma.

Either the agent's question determines an answer-set she grasps, or it does not. Take the first horn. In the cases described, she does not grasp any such set. Ana cannot, at month two, characterise the candidate complete answers to *what is going on?*; if she could, she would be nearly finished, since what she eventually achieves *is* a specification of one candidate. To say she grasps the answer-set is to say she already has what the inquiry was for.

Take the second horn: the question is one she genuinely has, but its complete answers are unsurveyable — in the limit, complete specifications of how things stand in the relevant domain. Then the norms go idle, and idle in a diagnosable way. The zetetic instrumental principle enjoins the *necessary* means to figuring out Q. When Q's complete answers are unsurveyable, almost nothing is a necessary means to figuring it out, because the end is not one she is going to reach by any route; so the principle forbids nothing. The ignorance norm forbids inquiring into what one knows the answer to; she never knows a complete answer to *what is going on?*, so it never forbids either. The norms are consistent with everything she might do, including everything she might do badly.

There is no setting of the dial that both fits the phenomenon and guides. Fine questions guide but she lacks them; coarse ones she has but they do not guide. And the dilemma points at what is really missing. What Ana needs guidance about is *which refinement to adopt* — which of the indefinitely many sharper questions in the neighbourhood of *what is going on?* is worth having. That choice is not a choice about means to a fixed end. It is a choice about which end to take up, made under conditions where the candidates cannot be surveyed. The question-indexed norms cannot speak to it, because they begin after it has been made.

### 3.2 The external question

Second reply: the question individuates the inquiry from outside. Ana's inquiry was all along an inquiry into whether her colleague treats her objections as complaints, whether or not she could formulate that; her interrogative attitude had a content she could not articulate.

Three difficulties.

First, it severs the norms from the role they were introduced to play. The zetetic instrumental principle is an instrumental norm, and instrumental norms bind through the agent's own end. One cannot take the necessary means to an end one cannot identify; one can only blunder into them. If Ana's end is a question she cannot formulate, the principle issues her no directive she could act on, and her conformity to it is luck.

Second, it makes the identity of an inquiry retrospective and success-dependent. Suppose Ana never arrives at the formulation, and gives up. If the inquiry is individuated by the question she would have reached, hers was an inquiry into nothing — not a failed inquiry but a non-inquiry. Yet failed gropings are conducted well or badly, and are criticisable in the same terms as successful ones. A theory of inquiry that cannot classify failures as inquiries has miscounted.

Third, under-individuation. In a single episode an inquirer typically arrives at several questions, ordered by discovery: *does this track the meetings or the week?*, *is the pattern in what I say or in how he takes it?*, and finally the formulation she keeps. Nothing in her pre-formulation state selects one of these as *the* question the episode was into. The external question is not there to be found; it is chosen later, and choosing it is part of what she did.

---

## 4. The formal rescue, and why it is instructive

The third reply is the interesting one, because it fails for a reason that points towards the positive view.

Decision theory already has an apparatus for evaluating questions. Given a decision problem, a prior, and a set of candidate experiments, one can compute the expected value of the information each would yield and rank them; Good's theorem tells us that free information never has negative expected value. Friedman herself notes that this machinery may bear on norms for opening questions (2020b: n. 12). Why not say that the norm governing question-choice is: open the question with the highest expected value of information?

Because the apparatus takes as given exactly what the inquirer lacks. Expected value of information is computed over a fixed algebra of propositions with a prior defined on it. A candidate question must already be a partition of that algebra; a candidate experiment must already have a known space of possible outcomes. What Ana needs is not a ranking of the partitions available in her current space of possibilities. It is a new distinction — a way of carving the situation that she did not previously have. That is not an update on an algebra; it is a change of algebra.

The point is familiar in the literature on awareness growth. As Joe Roussos puts it, “in Bayesian models all resolutions of uncertainty take place by updating pre-existing beliefs. Agents must have priors for propositions to learn about them at later stages and so Bayesianism leaves no room for agents to learn about genuinely new states of affairs” (Roussos forthcoming: §1). The proposals in that literature — Reverse Bayesianism and its successors — are, as Roussos argues, accounts of *belief extension*: how to distribute credence once the new space is in view. They presuppose the step he calls *awareness revision*, in which the new space is formed. They help with the half of the problem that comes after the hard part.

One might try to outflank this: put the finer partition into the algebra from the start, as one possibility among others. But to have the finer partition in the algebra *is* to have the concept. An agent who can represent the proposition *he treats my objections as complaints* well enough to assign it a prior has already done Ana's months of work. This is the formal echo of the second horn of Meno's paradox. Meno asks: “And how will you enquire, Socrates, into that which you do not know? What will you put forth as the subject of enquiry? And if you find what you want, how will you ever know that this is the thing which you did not know?” (*Meno* 80d, trans. Jowett). The erotetic model has no good answer, because on that model the criterion of success is *positive*: you have succeeded when you believe a complete answer to Q, which requires having Q's answer-set in advance. Where the answer-set is the achievement, the criterion cannot be met. I shall argue in Section 6.3 that the aporetic model supplies a different, negative criterion, and that this is one of its main recommendations.

It is worth noticing that Socrates' own position in the dialogue is not that of someone with a question. It is that of someone stuck: “I perplex others, not because I am clear, but because I am utterly perplexed myself” (*Meno* 80c). The *aporia* comes first; Meno's question about how inquiry is possible comes second, as an articulation of it.

---

## 5. The aporetic model

### 5.1 The definition

By an agent's **commitments** I mean whatever she is answerable for: her beliefs and acceptances, the presuppositions of her plans and of the questions she does ask, her intentions, her expectations, the practices she maintains, and the standards to which she holds herself. Commitments are *discharged* when they are met — a belief by being true, a plan by being executed, a standard by being satisfied.

> **Aporia.** A set of S's commitments constitutes an aporia for S at t iff S cannot, as she stands at t, jointly discharge them.

> **Inquiry.** Inquiry is activity aimed at putting oneself in a position to discharge a set of commitments one cannot now discharge, by improving one's epistemic position.

The second clause matters. Joint dischargeability can also be restored by abandoning a commitment, or by changing one's circumstances. Those are repairs but not inquiries. Inquiry is the species of repair that proceeds by finding out, by distinguishing, or by coming to understand.

Three sources of undischargeability give three species of aporia.

**Conflict.** The contents cannot all hold. Ana's is of this kind at the start: she is committed to her colleague's good faith, to her own reliability as a reader of situations, and to the flattening being real, and these do not sit together. The reader's is a conflict between accepting each premise, accepting the validity of the argument, and rejecting the conclusion.

**Gap.** The contents are consistent, but S's informational position prevents execution. She has a plan that specifies one action if p and another if not-p, and she is not in a position to determine which. Idle curiosity is the limiting case: the plan is only a standing interest in completeness on some topic, but that is a commitment too, and it is not discharged while the cell is unsettled.

**Strain.** The content is fine and the information is there, but the *mode of holding* is inadequate to a standard the agent also holds. She believes the calculation is right; she also holds herself to not acting on unchecked arithmetic where a mistake would cost someone money. Both commitments cannot be met by her as she stands, though nothing she believes is false and nothing is unknown.

The three are unified: in each, a set of commitments is not jointly dischargeable *by her*, and the differences lie in what blocks discharge — inconsistent content, missing information, inadequate holding.

### 5.2 Where questions come in

On this model a question is not what an inquiry is *of* but a tool it may acquire. To formulate a question is to commit to a *shape* for the defect: to say that the obstruction will be removed by settling which cell of this partition obtains. That commitment can be apt or inept, and its aptness is assessable. A good question is one whose settlement would in fact restore dischargeability and which the inquirer is in a position to settle; a bad one is well formed, answerable, and beside the point.

This explains two things the erotetic model cannot. It explains why arriving at a question can be the main achievement of an inquiry: the question encodes a correct diagnosis. And it explains why inquiries can succeed without answering any question the inquirer could have posed at the outset — because answering is only one of the ways an aporia can go. It can also be removed by rejecting a presupposition (there was no fault: the monitor was miscounting), by revising a standard (the precision I demanded was never warranted here), or by drawing a distinction that lets the conflicting commitments live together (he is not disputing my objections, he is receiving them under a different description). Only the first is question-answering. The erotetic model must score the other three as failures to answer, which is the wrong verdict about some of the best inquiries there are.

### 5.3 Predecessors, and what is new

The thought that inquiry starts from difficulty is old. Aristotle opens *Metaphysics* III by insisting that one must survey the difficulties first: “it is not possible to untie a knot of which one does not know”, and “people who inquire without first stating the difficulties are like those who do not know where they have to go” (995a24–33, trans. Ross). Peirce is more explicit still. “The irritation of doubt causes a struggle to attain a state of belief. I shall term this struggle inquiry”, and, against the erotetic picture directly: “the mere putting of a proposition into the interrogative form does not stimulate the mind to any struggle after belief. There must be a real and living doubt, and without this all discussion is idle” (Peirce 1877: §IV).

I am not claiming this ancestry as a novelty. What I claim is new is threefold.

First, the notion is *structural*, not psychological. Peirce's doubt is a felt irritation; his inquiry ends when the irritation does. An aporia is constituted by relations among commitments and is there whether or not it is felt. Unease is a fallible detector of aporia: one can feel unease without aporia (anxiety) and have an aporia without unease (complacency). Section 6.2 shows why this matters.

Second, the claim is one about *individuation and indexing*, which is a claim about the architecture of zetetic norms and could not have been made before that architecture existed. It is that aporiai, not questions, are the parameter our norms of inquiry should take.

Third, and relatedly, the terminus differs. Peirce says “the sole object of inquiry is the settlement of opinion”, and grants that fixation by tenacity settles opinion (1877: §IV–V). Joint dischargeability is not settlement. The tenacious believer has quieted the feeling and not removed the aporia: his commitment to the reliability of the method by which he holds his belief, and his commitment to the belief itself, are still not jointly dischargeable. That is why the model does not collapse into a coherence theory or into contentment. It also explains, without stipulation, why inquiry is answerable to truth. A repair effected by adopting a falsehood is unstable, because commitments include commitments to act, and action on falsehood fails, generating fresh undischargeability downstream. Truth-aptness falls out of dischargeability over time rather than being written into the aim.

---

## 6. What the model buys

### 6.1 A norm to replace the ignorance norm, with a stopping rule

> **(AN) The Aporia Norm.** One has reason to inquire into a matter at t only if one has at t an aporia whose removal the inquiry would serve; and the aporia, not any question, fixes what counts as proceeding well.

Compare the ignorance norm: “If one knows the answer to some question at some time then one ought not to be investigating that question, or inquiring into it further… at that time” (Friedman 2017: 131, quoted in Woodard 2024: §1). Elise Woodard has argued persuasively that this is too strong, since agents can know that p and rationally double-check p, seeking certainty, resilience, or sensitivity to error (Woodard 2024: §§1–3).

The aporetic model endorses Woodard's data and improves on the explanation. Her diagnosis — that there are epistemic goods beyond knowledge worth seeking — is true but unlimited: certainty and resilience always admit of increase, so on its own the diagnosis licenses checking without end. What the model adds is that double-checking is apt exactly when there is a *strain* aporia: a standard the agent holds herself to that her present holding of p does not meet. That yields a stopping rule. When the standard is met, the aporia is gone, and further checking is not merely pointless but zetetically defective — the familiar vice of the person who cannot leave the house. And it yields a scaling rule: raise the stakes, or introduce a reason to fear a specific error, and you introduce a standard that the current holding fails, hence a fresh aporia, hence a fresh permission.

The model also explains why the ignorance norm seemed compelling. For gap aporiai, the aporia *is* the ignorance, so the aporia norm and the ignorance norm agree. The ignorance norm is a correct special case that was taken for the general rule — which is what one expects, given a framework whose central examples (where are my keys, how many windows) are all gaps.

### 6.2 Zetetic negligence

We criticise people for not inquiring. A manager whose stated standards and whose actual practice cannot both be honoured, and who has never once put the matter to himself, is open to a criticism that is not merely moral. He has been careless about something he had every reason to look into.

This is awkward for the question-indexed architecture. Its norms are indexed to a question the negligent agent does not have; an instrumental norm cannot reproach him for failing to take means to an end he lacks; and the natural repair — a norm saying he *ought to have opened* Q — needs a norm for opening questions that does not presuppose already having them, which is exactly what (EP-ii) cannot supply without circularity. One could reach outside epistemology, and say his failure is practical or moral. That is David Thorstad's territory; he holds that “[t]here are no epistemic norms of inquiry. We have no epistemic duties to open inquiry and no epistemic duties to close it” (Thorstad 2022: §1). I do not here take a stand on whether zetetic norms are *epistemic*. But I note that the aporetic model makes the nihilist's job harder, because it locates the ground of zetetic criticism in something distinctively epistemic rather than in the agent's interests.

On the aporetic model the criticism is straightforward, and its ground is the agent's own. An aporia is constituted by commitments he already has; it does not wait on his noticing. So there is something he is answerable to independently of what he wants to find out: the joint undischargeability of what he is already committed to. Negligence is the failure to detect, or the refusal to acknowledge, a defect of one's own. And because aporiai are structural rather than felt, a person can be criticised precisely for the absence of the feeling — for the complacency that keeps the defect from registering. That is the shape of a great deal of ordinary epistemic criticism, and the erotetic model cannot reconstruct it.

### 6.3 A negative criterion of success

Return to Meno's second horn: if you did not already know what you were looking for, how would you recognise it? On the erotetic model the criterion of success is positive and comparative: success is believing a complete answer to Q, which requires possessing Q's answer-set in advance. Where the answer-set is what the inquiry produces, the criterion cannot be applied.

On the aporetic model the criterion is negative and local: you have succeeded when the commitments you could not jointly discharge have become jointly dischargeable. You do not need advance grasp of the answer. You need only be able to tell that the obstruction is gone — and you have defeasible access to that, because the obstruction was constituted by your own commitments. Ana does not need to have known in advance what she would find. She needs to be able to tell that she can now hold, together, her reading of the meetings, her colleague's good faith, and her own reliability. That is why recognition is possible where anticipation is not.

The criterion is fallible: a repair can seem to have restored dischargeability without doing so, and the appearance of relief is exactly what dogmatism manufactures. The model is not a decision procedure. But it locates success in something the inquirer can check, which is more than the positive criterion manages in the cases that matter.

### 6.4 A dividend: the epistemic–zetetic tension shrinks

Friedman's central puzzle is that the zetetic instrumental principle forbids what standard epistemic permissions allow. Counting windows, she may not come to know things about the scene around her that she is in a position to know; but epistemology says coming to know is always permitted (2020a: §§2, 4.1).

The model does not dissolve this — attention is scarce however inquiry is individuated — but it reduces its scope, and does so non-arbitrarily. On the question-indexed view, anything not serving Q is a candidate distraction, so the conflict is pervasive by construction. On the aporetic view, what zetetic pressure forbids is what makes the aporia harder to remove; and coming to know an unrelated truth does not, *except* by consuming attention. That suggests the act zetetic norms directly govern is the deployment of one's capacities — attention, memory, instruments — rather than the doxastic outputs. Norms of inquiry can reach what the inquirer directs; the knowledge is a consequence. If that is right, the permission to come to know p and the zetetic prohibition do not attach to the same act, and the inconsistency is apparent rather than real. No blanket epistemic permission to *attend* to whatever one's evidence would support has ever been defended, and none is plausible.

A defender of the original puzzle can reply that judging is still an act, and still forbidden under some description. I do not claim to have closed the question. I claim that the revisionary conclusion — rejecting the blanket epistemic permissions — is not forced once the unit of inquiry is corrected, and that the residual tension is the ordinary and manageable one about the allocation of attention.

---

## 7. Objections

**Circularity.** *Removing an aporia just is answering a question, so the model is the erotetic model in other words.*

No. Section 5.2 lists four routes to removal, of which only one is answering; and the model's verdicts differ from the erotetic model's on the other three. There is a further asymmetry. Every question has a presupposition, and inquiry can go well by rejecting it; but then there is no answer, and the erotetic model must score a successful inquiry as a failed one. The aporetic model scores it as a success, and the disagreement is substantive.

**Profligacy.** *Every agent's commitments contain countless undischargeable subsets. The model makes aporiai cheap, and so licenses inquiry into everything.*

The first part is true and the second does not follow, because (AN) states a necessary condition and a shaping constraint, not a sufficient condition. What ranks aporiai is this:

> **(PR) Priority.** The urgency of an aporia is a function of the range of one's other commitments that cannot be discharged while it stands.

An aporia that blocks nothing else is not worth repairing; one that blocks a plan, a practice, or a body of further beliefs is. This is not an appeal to the triviality of subject matter, and it yields something like clutter avoidance as a consequence rather than an axiom. Consider Friedman's point that inquiry-irrelevant information need not be trivial or cluttering (2020a: §4.5). (PR) agrees: what makes an aporia low priority is not that its content is dull but that its persistence costs nothing.

**Idle curiosity.** *Wondering why boats are called* S.S. *something involves no defect at all.*

It involves a gap: a commitment to completeness on a topic one cares about, unmet. But I want to concede more than that. Idle curiosity is the case where inquiry most nearly *is* question-shaped, because the agent's grip on the answer-set is what the wondering consists in. That concession is a point in the model's favour: it explains why the erotetic model, built on such cases, looked so compelling, and why it fails as soon as the stakes and the difficulty rise.

**Vagueness of “commitment”.** *The notion carries the weight and is undefined.*

It is defined by its role — whatever the agent is answerable for — and that role is doing the work I claim, not standing in for it. Two consequences are checkable. Because commitments include standards, the model predicts strain aporiai, and so predicts exactly Woodard's double-checking data plus a stopping rule. Because commitments do not require the agent's notice, the model predicts the intelligibility of zetetic negligence. A vaguer notion would predict neither. I grant that a full theory owes an account of how aporiai are counted and when two are the same; I do not have one.

---

## 8. Conclusion

The zetetic turn corrected epistemology's temporal parochialism by extending evaluation backwards from the moment of belief to the activity that produces it. But it stopped at the question, and treated the question as the fixed point from which all evaluation of inquiry proceeds. The cases in which the question is the achievement show that this is the wrong fixed point: it arrives too late, it goes idle when coarsened, and it makes the most skilled part of inquiry invisible to assessment.

What an inquiry is answerable to is a defect in the inquirer's own commitments — something she cannot, as she stands, jointly discharge. That notion individuates inquiries, indexes their norms, supplies a stopping rule where the ignorance norm gave a prohibition, makes zetetic negligence intelligible, and gives a criterion of success that survives the second horn of Meno's paradox. Aristotle had the shape of it: one cannot untie a knot of which one does not know. The knot comes first. The question, when we are lucky and skilful, is what we make of it.

---

### Notes

1. Friedman 2020a is cited by preprint pagination where I quote text I read in the preprint, and by the published pagination for ZIP, which she herself gives at p. 503. Friedman 2020b is cited by section.

2. The scope of this essay's engagement with the pragmatist tradition is limited. A fuller treatment would have to work through Dewey's *Logic*, Collingwood's logic of question and answer, Laudan's problem-solving model of scientific appraisal, and Christopher Hookway's work on doubt and the regulation of inquiry, which Friedman cites as a contemporary precedent for an inquiry-centred epistemology (2020b: n. 5). I have not consulted those works here, and I do not claim priority over them; the claims I advance as new are the three listed in §5.3.

---

## Bibliography

Aristotle. *Metaphysics*, Book III, trans. W. D. Ross. The Internet Classics Archive. https://classics.mit.edu/Aristotle/metaphysics.3.iii.html

Friedman, Jane. 2017. “Why Suspend Judging?” *Noûs* 51(2): 302–326. [Cited at second hand for the ignorance norm, via Woodard 2024.]

Friedman, Jane. 2020a. “The Epistemic and the Zetetic.” *The Philosophical Review* 129(4): 501–536. Preprint: https://jfriedmanphilo.github.io/E&Z.pdf

Friedman, Jane. 2020b. “Zetetic Epistemology.” In B. Reed and A. K. Flowerree (eds.), *Towards an Expansive Epistemology: Norms, Action, and the Social Sphere*. Routledge. Preprint: https://jfriedmanphilo.github.io/ZETEP.pdf

Good, I. J. 1967. “On the Principle of Total Evidence.” *The British Journal for the Philosophy of Science* 17(4): 319–321. [Cited at second hand, via Friedman 2020b.]

Harman, Gilbert. 1986. *Change in View*. MIT Press. [Cited at second hand, via Friedman 2020a and Thorstad 2022.]

Herschel, John. 1831. *A Preliminary Discourse on the Study of Natural Philosophy*. [Quoted in Friedman 2020b; not consulted directly.]

Peirce, Charles Sanders. 1877. “The Fixation of Belief.” *Popular Science Monthly* 12 (November): 1–15. https://arquivo.bocc.ubi.pt/pag/peirce-charles-fixation-belief.pdf

Plato. *Meno*, trans. Benjamin Jowett. The Internet Classics Archive. https://classics.mit.edu/Plato/meno.html

Roussos, Joe. Forthcoming. “Awareness Revision and Belief Extension.” *Australasian Journal of Philosophy*. Preprint: https://joeroussos.org/wp-content/uploads/2024/03/ARaBE_AJP_Accepted.pdf

Steele, Katie, and H. Orri Stefánsson. 2021. “Belief Revision for Growing Awareness.” *Mind* 130(520): 1207–1232. [Not consulted directly; access blocked.]

Thorstad, David. 2022. “There Are No Epistemic Norms of Inquiry.” *Synthese* 200(410). Preprint: https://www.dthorstad.com/_files/ugd/74503b_1f092eaa7c7942beb5b0d1b6836cff90.pdf

Thorstad, David. 2023. “Norms of Inquiry.” *Philosophical Topics* 51(2): 135–160. Preprint: https://www.dthorstad.com/_files/ugd/74503b_990643d44e0346b48512731ed5cf1ae5.pdf

Woodard, Elise. 2024. “Why Double-Check?” *Episteme* 21(2): 644–667. Preprint (22 April 2022): https://elisewoodard.org/s/Woodard-Why-Double-Check-42222.pdf
