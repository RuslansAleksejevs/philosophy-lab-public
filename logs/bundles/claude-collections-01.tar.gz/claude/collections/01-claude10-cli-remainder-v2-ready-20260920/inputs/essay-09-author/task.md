Read input/NEUTRAL_BRIEF.md, input/RULES.md and the assigned same-essay files. Write clear, engaging, precise English. All topics, philosophical arguments, objections and revisions must be yours; no topic or thesis is assigned by the coordinator. Read relevant primary sources, verify citations and record what you actually read. WebFetch summaries are not full sources: label full/excerpt/summary/unavailable honestly. Save actual source excerpts or readable retrieved text you use under output/source-notes/ with URL and location; never reconstruct a supposed original from memory or invent access. Include sources.md and process.md (visible work products, alternatives set aside, uncertainties and version lineage; no hidden reasoning). Preserve original files and use numbered versions for changes. Write files directly, saving useful progress regularly. No special JSON response or manuscript shortening for transport. No minimum length; manuscripts at most 6000 words excluding bibliography only. Do not simulate later roles yourself. Read no other essays, sessions or global history. No publication, contact, paid access or changes to the workflow.
Develop one independent original philosophical essay, from your own choice of question and source research to a complete first manuscript in draft-001.md. A separate fresh critic will assess it later.
Technical source and archive requirements:
The launcher separately downloads each public HTTPS URL used in WebFetch into
output/sources/, including original HTML/PDF and mechanically extracted text.
Read those saved files when available; inspect the JSON receipts for filenames.
If a source was already supplied in input/source-archives/, use that saved copy
without refetching unless a new retrieval is needed. Do not edit output/sources/.
Reading a WebFetch summary alone does not establish full-source access.
Write source-status.json as {"sources":[{"url":"public source URL",
"coverage":"full|excerpt|summary|unavailable", "artifact":"input/... or output/...",
"note":"what you actually read, locations and limitations"}]}.
For full/excerpt, artifact must name an existing local file you actually read;
for summary/unavailable, explain the limitation without claiming original access.
List all sources materially used. A saved file alone does not prove you read it.
Final manuscript bibliography should be the last section headed # Bibliography
or # References. Notes and appendices go before it and count toward 6000 words.
Save the complete assigned result, not a plan or placeholders. Manuscript checks
are mechanical, not a claim that your philosophy or originality is certified.
